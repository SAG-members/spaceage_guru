<?php

class Database extends CI_Model
{
	/*
	 * Define table constants at the begining of class to ensure single
	 * line of changes applies to whole class.
	 */
	
	
		
	
	public function __construct()
	{
		parent::__construct();
	}

	public function getAll()
	{
		
	}
	
	public function getOne()
	{
		
	}
	
	public function createNewPost()
	{
		
	}
	
	public function updatePost()
	{
		
	}
	
	public function deletePostById()
	{
		
	}
	
}