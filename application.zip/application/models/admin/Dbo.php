<?php

class Dbo extends CI_Model
{
	public static $table;
	protected $id;
	protected $data;
	
	public function __construct(){parent::__construct();}
	
	public function get()
	{
		
	}
	
	public function get_by_id()
	{
		
	}
	
	public function getAll()
	{
		
	}
	
	public function create($data)
	{
	
	}
	
	
	public function read()
	{
		
	}
	
	public function update()
	{
		
	}
	
	public function delete()
	{
		
	}
	
}