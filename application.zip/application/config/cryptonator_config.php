<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

# Cryptonator merchant id and merchant secret
$config['merchant_id'] = 'office@spaceage.guru';
$config['merchant_secret'] = 'office@spaceage.guru';

# Cryptonator currency
$config['paypal_lib_currency_code'] = 'eur';

?>
