<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-26 18:16:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/faq.php 18
ERROR - 2017-12-26 18:22:32 --> Severity: Compile Error --> Cannot redeclare Feedback_controller::timeline() /var/www/html/spaceage_guru/application/controllers/module/services/Feedback_controller.php 40
