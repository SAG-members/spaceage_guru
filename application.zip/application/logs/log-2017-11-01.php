<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-01 10:17:04 --> Config Class Initialized
INFO - 2017-11-01 10:17:04 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:04 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:04 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:04 --> URI Class Initialized
DEBUG - 2017-11-01 10:17:04 --> No URI present. Default controller set.
INFO - 2017-11-01 10:17:04 --> Router Class Initialized
INFO - 2017-11-01 10:17:04 --> Output Class Initialized
INFO - 2017-11-01 10:17:04 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:04 --> Input Class Initialized
INFO - 2017-11-01 10:17:04 --> Language Class Initialized
INFO - 2017-11-01 10:17:04 --> Loader Class Initialized
INFO - 2017-11-01 10:17:04 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:04 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:04 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:04 --> Email Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Controller Class Initialized
INFO - 2017-11-01 10:17:04 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> Model Class Initialized
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:17:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:17:04 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:04 --> Total execution time: 0.6187
INFO - 2017-11-01 10:17:08 --> Config Class Initialized
INFO - 2017-11-01 10:17:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:08 --> URI Class Initialized
INFO - 2017-11-01 10:17:08 --> Router Class Initialized
INFO - 2017-11-01 10:17:08 --> Output Class Initialized
INFO - 2017-11-01 10:17:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:08 --> Input Class Initialized
INFO - 2017-11-01 10:17:08 --> Language Class Initialized
INFO - 2017-11-01 10:17:08 --> Loader Class Initialized
INFO - 2017-11-01 10:17:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:08 --> Email Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Controller Class Initialized
INFO - 2017-11-01 10:17:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> Model Class Initialized
INFO - 2017-11-01 10:17:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:17:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:17:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:17:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:17:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:17:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:08 --> Total execution time: 0.1396
INFO - 2017-11-01 10:17:09 --> Config Class Initialized
INFO - 2017-11-01 10:17:09 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:09 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:09 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:09 --> URI Class Initialized
INFO - 2017-11-01 10:17:09 --> Router Class Initialized
INFO - 2017-11-01 10:17:09 --> Output Class Initialized
INFO - 2017-11-01 10:17:09 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:09 --> Input Class Initialized
INFO - 2017-11-01 10:17:09 --> Language Class Initialized
INFO - 2017-11-01 10:17:09 --> Loader Class Initialized
INFO - 2017-11-01 10:17:09 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:09 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:09 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:09 --> Email Class Initialized
INFO - 2017-11-01 10:17:09 --> Model Class Initialized
INFO - 2017-11-01 10:17:09 --> Controller Class Initialized
INFO - 2017-11-01 10:17:09 --> Model Class Initialized
INFO - 2017-11-01 10:17:09 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:09 --> Total execution time: 0.0149
INFO - 2017-11-01 10:17:11 --> Config Class Initialized
INFO - 2017-11-01 10:17:11 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:11 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:11 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:11 --> URI Class Initialized
INFO - 2017-11-01 10:17:11 --> Router Class Initialized
INFO - 2017-11-01 10:17:11 --> Output Class Initialized
INFO - 2017-11-01 10:17:11 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:11 --> Input Class Initialized
INFO - 2017-11-01 10:17:11 --> Language Class Initialized
INFO - 2017-11-01 10:17:11 --> Loader Class Initialized
INFO - 2017-11-01 10:17:11 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:11 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:11 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:11 --> Email Class Initialized
INFO - 2017-11-01 10:17:11 --> Model Class Initialized
INFO - 2017-11-01 10:17:11 --> Controller Class Initialized
INFO - 2017-11-01 10:17:11 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:11 --> Total execution time: 0.0026
INFO - 2017-11-01 10:17:17 --> Config Class Initialized
INFO - 2017-11-01 10:17:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:17 --> URI Class Initialized
INFO - 2017-11-01 10:17:17 --> Router Class Initialized
INFO - 2017-11-01 10:17:17 --> Output Class Initialized
INFO - 2017-11-01 10:17:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:17 --> Input Class Initialized
INFO - 2017-11-01 10:17:17 --> Language Class Initialized
INFO - 2017-11-01 10:17:17 --> Loader Class Initialized
INFO - 2017-11-01 10:17:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:17 --> Email Class Initialized
INFO - 2017-11-01 10:17:17 --> Model Class Initialized
INFO - 2017-11-01 10:17:17 --> Controller Class Initialized
INFO - 2017-11-01 10:17:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:17 --> Total execution time: 0.0034
INFO - 2017-11-01 10:17:17 --> Config Class Initialized
INFO - 2017-11-01 10:17:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:17 --> URI Class Initialized
INFO - 2017-11-01 10:17:17 --> Router Class Initialized
INFO - 2017-11-01 10:17:17 --> Output Class Initialized
INFO - 2017-11-01 10:17:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:17 --> Input Class Initialized
INFO - 2017-11-01 10:17:17 --> Language Class Initialized
INFO - 2017-11-01 10:17:17 --> Loader Class Initialized
INFO - 2017-11-01 10:17:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:17 --> Email Class Initialized
INFO - 2017-11-01 10:17:17 --> Model Class Initialized
INFO - 2017-11-01 10:17:17 --> Controller Class Initialized
INFO - 2017-11-01 10:17:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:17 --> Total execution time: 0.0014
INFO - 2017-11-01 10:17:17 --> Config Class Initialized
INFO - 2017-11-01 10:17:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:17 --> URI Class Initialized
INFO - 2017-11-01 10:17:17 --> Router Class Initialized
INFO - 2017-11-01 10:17:17 --> Output Class Initialized
INFO - 2017-11-01 10:17:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:17 --> Input Class Initialized
INFO - 2017-11-01 10:17:17 --> Language Class Initialized
INFO - 2017-11-01 10:17:17 --> Loader Class Initialized
INFO - 2017-11-01 10:17:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:17 --> Email Class Initialized
INFO - 2017-11-01 10:17:17 --> Model Class Initialized
INFO - 2017-11-01 10:17:17 --> Controller Class Initialized
INFO - 2017-11-01 10:17:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:17 --> Total execution time: 0.0014
INFO - 2017-11-01 10:17:18 --> Config Class Initialized
INFO - 2017-11-01 10:17:18 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:18 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:18 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:18 --> URI Class Initialized
INFO - 2017-11-01 10:17:18 --> Router Class Initialized
INFO - 2017-11-01 10:17:18 --> Output Class Initialized
INFO - 2017-11-01 10:17:18 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:18 --> Input Class Initialized
INFO - 2017-11-01 10:17:18 --> Language Class Initialized
INFO - 2017-11-01 10:17:18 --> Loader Class Initialized
INFO - 2017-11-01 10:17:18 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:18 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:18 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:18 --> Email Class Initialized
INFO - 2017-11-01 10:17:18 --> Model Class Initialized
INFO - 2017-11-01 10:17:18 --> Controller Class Initialized
INFO - 2017-11-01 10:17:18 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:18 --> Total execution time: 0.0016
INFO - 2017-11-01 10:17:23 --> Config Class Initialized
INFO - 2017-11-01 10:17:23 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:23 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:23 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:23 --> URI Class Initialized
INFO - 2017-11-01 10:17:23 --> Router Class Initialized
INFO - 2017-11-01 10:17:23 --> Output Class Initialized
INFO - 2017-11-01 10:17:23 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:23 --> Input Class Initialized
INFO - 2017-11-01 10:17:23 --> Language Class Initialized
INFO - 2017-11-01 10:17:23 --> Loader Class Initialized
INFO - 2017-11-01 10:17:23 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:23 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:23 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:23 --> Email Class Initialized
INFO - 2017-11-01 10:17:23 --> Model Class Initialized
INFO - 2017-11-01 10:17:23 --> Controller Class Initialized
INFO - 2017-11-01 10:17:23 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:23 --> Total execution time: 0.0040
INFO - 2017-11-01 10:17:27 --> Config Class Initialized
INFO - 2017-11-01 10:17:27 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:27 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:27 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:27 --> URI Class Initialized
INFO - 2017-11-01 10:17:27 --> Router Class Initialized
INFO - 2017-11-01 10:17:27 --> Output Class Initialized
INFO - 2017-11-01 10:17:27 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:27 --> Input Class Initialized
INFO - 2017-11-01 10:17:27 --> Language Class Initialized
INFO - 2017-11-01 10:17:27 --> Loader Class Initialized
INFO - 2017-11-01 10:17:27 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:27 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:27 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:27 --> Email Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Controller Class Initialized
INFO - 2017-11-01 10:17:27 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:17:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:17:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:17:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:17:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:17:27 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:27 --> Total execution time: 0.0598
INFO - 2017-11-01 10:17:27 --> Config Class Initialized
INFO - 2017-11-01 10:17:27 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:27 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:27 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:27 --> URI Class Initialized
INFO - 2017-11-01 10:17:27 --> Router Class Initialized
INFO - 2017-11-01 10:17:27 --> Output Class Initialized
INFO - 2017-11-01 10:17:27 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:27 --> Input Class Initialized
INFO - 2017-11-01 10:17:27 --> Language Class Initialized
INFO - 2017-11-01 10:17:27 --> Loader Class Initialized
INFO - 2017-11-01 10:17:27 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:27 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:27 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:27 --> Email Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Controller Class Initialized
INFO - 2017-11-01 10:17:27 --> Model Class Initialized
INFO - 2017-11-01 10:17:27 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:27 --> Total execution time: 0.0031
INFO - 2017-11-01 10:17:29 --> Config Class Initialized
INFO - 2017-11-01 10:17:29 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:29 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:29 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:29 --> URI Class Initialized
INFO - 2017-11-01 10:17:29 --> Router Class Initialized
INFO - 2017-11-01 10:17:29 --> Output Class Initialized
INFO - 2017-11-01 10:17:29 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:29 --> Input Class Initialized
INFO - 2017-11-01 10:17:29 --> Language Class Initialized
INFO - 2017-11-01 10:17:29 --> Loader Class Initialized
INFO - 2017-11-01 10:17:29 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:29 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:29 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:29 --> Email Class Initialized
INFO - 2017-11-01 10:17:29 --> Model Class Initialized
INFO - 2017-11-01 10:17:29 --> Controller Class Initialized
INFO - 2017-11-01 10:17:29 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:29 --> Total execution time: 0.0015
INFO - 2017-11-01 10:17:36 --> Config Class Initialized
INFO - 2017-11-01 10:17:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:36 --> URI Class Initialized
INFO - 2017-11-01 10:17:36 --> Router Class Initialized
INFO - 2017-11-01 10:17:36 --> Output Class Initialized
INFO - 2017-11-01 10:17:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:36 --> Input Class Initialized
INFO - 2017-11-01 10:17:36 --> Language Class Initialized
INFO - 2017-11-01 10:17:36 --> Loader Class Initialized
INFO - 2017-11-01 10:17:36 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:36 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:36 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:36 --> Email Class Initialized
INFO - 2017-11-01 10:17:36 --> Model Class Initialized
INFO - 2017-11-01 10:17:36 --> Controller Class Initialized
INFO - 2017-11-01 10:17:36 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:36 --> Total execution time: 0.0058
INFO - 2017-11-01 10:17:36 --> Config Class Initialized
INFO - 2017-11-01 10:17:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:36 --> URI Class Initialized
INFO - 2017-11-01 10:17:36 --> Router Class Initialized
INFO - 2017-11-01 10:17:36 --> Output Class Initialized
INFO - 2017-11-01 10:17:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:36 --> Input Class Initialized
INFO - 2017-11-01 10:17:36 --> Language Class Initialized
INFO - 2017-11-01 10:17:36 --> Loader Class Initialized
INFO - 2017-11-01 10:17:36 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:36 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:36 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:36 --> Email Class Initialized
INFO - 2017-11-01 10:17:36 --> Model Class Initialized
INFO - 2017-11-01 10:17:36 --> Controller Class Initialized
INFO - 2017-11-01 10:17:36 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:36 --> Total execution time: 0.0015
INFO - 2017-11-01 10:17:36 --> Config Class Initialized
INFO - 2017-11-01 10:17:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:36 --> URI Class Initialized
INFO - 2017-11-01 10:17:36 --> Router Class Initialized
INFO - 2017-11-01 10:17:36 --> Output Class Initialized
INFO - 2017-11-01 10:17:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:36 --> Input Class Initialized
INFO - 2017-11-01 10:17:36 --> Language Class Initialized
INFO - 2017-11-01 10:17:36 --> Loader Class Initialized
INFO - 2017-11-01 10:17:36 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:36 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:36 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:36 --> Email Class Initialized
INFO - 2017-11-01 10:17:36 --> Model Class Initialized
INFO - 2017-11-01 10:17:36 --> Controller Class Initialized
INFO - 2017-11-01 10:17:36 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:36 --> Total execution time: 0.0021
INFO - 2017-11-01 10:17:36 --> Config Class Initialized
INFO - 2017-11-01 10:17:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:36 --> URI Class Initialized
INFO - 2017-11-01 10:17:36 --> Router Class Initialized
INFO - 2017-11-01 10:17:36 --> Output Class Initialized
INFO - 2017-11-01 10:17:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:36 --> Input Class Initialized
INFO - 2017-11-01 10:17:36 --> Language Class Initialized
INFO - 2017-11-01 10:17:36 --> Loader Class Initialized
INFO - 2017-11-01 10:17:36 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:36 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:36 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:36 --> Email Class Initialized
INFO - 2017-11-01 10:17:36 --> Model Class Initialized
INFO - 2017-11-01 10:17:36 --> Controller Class Initialized
INFO - 2017-11-01 10:17:36 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:36 --> Total execution time: 0.0015
INFO - 2017-11-01 10:17:44 --> Config Class Initialized
INFO - 2017-11-01 10:17:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:44 --> URI Class Initialized
INFO - 2017-11-01 10:17:44 --> Router Class Initialized
INFO - 2017-11-01 10:17:44 --> Output Class Initialized
INFO - 2017-11-01 10:17:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:44 --> Input Class Initialized
INFO - 2017-11-01 10:17:44 --> Language Class Initialized
INFO - 2017-11-01 10:17:44 --> Loader Class Initialized
INFO - 2017-11-01 10:17:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:44 --> Email Class Initialized
INFO - 2017-11-01 10:17:44 --> Model Class Initialized
INFO - 2017-11-01 10:17:44 --> Controller Class Initialized
INFO - 2017-11-01 10:17:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:44 --> Total execution time: 0.0058
INFO - 2017-11-01 10:17:44 --> Config Class Initialized
INFO - 2017-11-01 10:17:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:44 --> URI Class Initialized
INFO - 2017-11-01 10:17:44 --> Router Class Initialized
INFO - 2017-11-01 10:17:44 --> Output Class Initialized
INFO - 2017-11-01 10:17:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:44 --> Input Class Initialized
INFO - 2017-11-01 10:17:44 --> Language Class Initialized
INFO - 2017-11-01 10:17:44 --> Loader Class Initialized
INFO - 2017-11-01 10:17:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:44 --> Email Class Initialized
INFO - 2017-11-01 10:17:44 --> Model Class Initialized
INFO - 2017-11-01 10:17:44 --> Controller Class Initialized
INFO - 2017-11-01 10:17:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:44 --> Total execution time: 0.0021
INFO - 2017-11-01 10:17:44 --> Config Class Initialized
INFO - 2017-11-01 10:17:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:44 --> URI Class Initialized
INFO - 2017-11-01 10:17:44 --> Router Class Initialized
INFO - 2017-11-01 10:17:44 --> Output Class Initialized
INFO - 2017-11-01 10:17:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:44 --> Input Class Initialized
INFO - 2017-11-01 10:17:44 --> Language Class Initialized
INFO - 2017-11-01 10:17:44 --> Loader Class Initialized
INFO - 2017-11-01 10:17:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:44 --> Email Class Initialized
INFO - 2017-11-01 10:17:44 --> Model Class Initialized
INFO - 2017-11-01 10:17:44 --> Controller Class Initialized
INFO - 2017-11-01 10:17:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:44 --> Total execution time: 0.0021
INFO - 2017-11-01 10:17:45 --> Config Class Initialized
INFO - 2017-11-01 10:17:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:17:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:17:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:17:45 --> URI Class Initialized
INFO - 2017-11-01 10:17:45 --> Router Class Initialized
INFO - 2017-11-01 10:17:45 --> Output Class Initialized
INFO - 2017-11-01 10:17:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:17:45 --> Input Class Initialized
INFO - 2017-11-01 10:17:45 --> Language Class Initialized
INFO - 2017-11-01 10:17:45 --> Loader Class Initialized
INFO - 2017-11-01 10:17:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:17:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:17:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:17:45 --> Email Class Initialized
INFO - 2017-11-01 10:17:45 --> Model Class Initialized
INFO - 2017-11-01 10:17:45 --> Controller Class Initialized
INFO - 2017-11-01 10:17:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:17:45 --> Total execution time: 0.0023
INFO - 2017-11-01 10:18:02 --> Config Class Initialized
INFO - 2017-11-01 10:18:02 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:18:02 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:18:02 --> Utf8 Class Initialized
INFO - 2017-11-01 10:18:02 --> URI Class Initialized
INFO - 2017-11-01 10:18:02 --> Router Class Initialized
INFO - 2017-11-01 10:18:02 --> Output Class Initialized
INFO - 2017-11-01 10:18:02 --> Security Class Initialized
DEBUG - 2017-11-01 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:18:02 --> Input Class Initialized
INFO - 2017-11-01 10:18:02 --> Language Class Initialized
INFO - 2017-11-01 10:18:02 --> Loader Class Initialized
INFO - 2017-11-01 10:18:02 --> Helper loaded: url_helper
INFO - 2017-11-01 10:18:02 --> Helper loaded: common_helper
INFO - 2017-11-01 10:18:02 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:18:02 --> Email Class Initialized
INFO - 2017-11-01 10:18:02 --> Model Class Initialized
INFO - 2017-11-01 10:18:02 --> Controller Class Initialized
INFO - 2017-11-01 10:18:02 --> Final output sent to browser
DEBUG - 2017-11-01 10:18:02 --> Total execution time: 0.0313
INFO - 2017-11-01 10:18:54 --> Config Class Initialized
INFO - 2017-11-01 10:18:54 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:18:54 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:18:54 --> Utf8 Class Initialized
INFO - 2017-11-01 10:18:54 --> URI Class Initialized
INFO - 2017-11-01 10:18:54 --> Router Class Initialized
INFO - 2017-11-01 10:18:54 --> Output Class Initialized
INFO - 2017-11-01 10:18:55 --> Security Class Initialized
DEBUG - 2017-11-01 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:18:55 --> Input Class Initialized
INFO - 2017-11-01 10:18:55 --> Language Class Initialized
INFO - 2017-11-01 10:18:55 --> Loader Class Initialized
INFO - 2017-11-01 10:18:55 --> Helper loaded: url_helper
INFO - 2017-11-01 10:18:55 --> Helper loaded: common_helper
INFO - 2017-11-01 10:18:55 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:18:55 --> Email Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Controller Class Initialized
INFO - 2017-11-01 10:18:55 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> Model Class Initialized
INFO - 2017-11-01 10:18:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:18:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:18:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:18:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:18:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:18:55 --> Final output sent to browser
DEBUG - 2017-11-01 10:18:55 --> Total execution time: 0.1536
INFO - 2017-11-01 10:18:56 --> Config Class Initialized
INFO - 2017-11-01 10:18:56 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:18:56 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:18:56 --> Utf8 Class Initialized
INFO - 2017-11-01 10:18:56 --> URI Class Initialized
INFO - 2017-11-01 10:18:56 --> Router Class Initialized
INFO - 2017-11-01 10:18:56 --> Output Class Initialized
INFO - 2017-11-01 10:18:56 --> Security Class Initialized
DEBUG - 2017-11-01 10:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:18:56 --> Input Class Initialized
INFO - 2017-11-01 10:18:56 --> Language Class Initialized
INFO - 2017-11-01 10:18:56 --> Loader Class Initialized
INFO - 2017-11-01 10:18:56 --> Helper loaded: url_helper
INFO - 2017-11-01 10:18:56 --> Helper loaded: common_helper
INFO - 2017-11-01 10:18:56 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:18:56 --> Email Class Initialized
INFO - 2017-11-01 10:18:56 --> Model Class Initialized
INFO - 2017-11-01 10:18:56 --> Controller Class Initialized
INFO - 2017-11-01 10:18:56 --> Model Class Initialized
INFO - 2017-11-01 10:18:56 --> Final output sent to browser
DEBUG - 2017-11-01 10:18:56 --> Total execution time: 0.0104
INFO - 2017-11-01 10:18:57 --> Config Class Initialized
INFO - 2017-11-01 10:18:57 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:18:57 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:18:57 --> Utf8 Class Initialized
INFO - 2017-11-01 10:18:57 --> URI Class Initialized
INFO - 2017-11-01 10:18:57 --> Router Class Initialized
INFO - 2017-11-01 10:18:57 --> Output Class Initialized
INFO - 2017-11-01 10:18:57 --> Security Class Initialized
DEBUG - 2017-11-01 10:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:18:57 --> Input Class Initialized
INFO - 2017-11-01 10:18:57 --> Language Class Initialized
INFO - 2017-11-01 10:18:57 --> Loader Class Initialized
INFO - 2017-11-01 10:18:57 --> Helper loaded: url_helper
INFO - 2017-11-01 10:18:57 --> Helper loaded: common_helper
INFO - 2017-11-01 10:18:57 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:18:57 --> Email Class Initialized
INFO - 2017-11-01 10:18:57 --> Model Class Initialized
INFO - 2017-11-01 10:18:57 --> Controller Class Initialized
INFO - 2017-11-01 10:18:57 --> Final output sent to browser
DEBUG - 2017-11-01 10:18:57 --> Total execution time: 0.0078
INFO - 2017-11-01 10:19:41 --> Config Class Initialized
INFO - 2017-11-01 10:19:41 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:19:41 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:19:41 --> Utf8 Class Initialized
INFO - 2017-11-01 10:19:41 --> URI Class Initialized
INFO - 2017-11-01 10:19:41 --> Router Class Initialized
INFO - 2017-11-01 10:19:41 --> Output Class Initialized
INFO - 2017-11-01 10:19:41 --> Security Class Initialized
DEBUG - 2017-11-01 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:19:41 --> Input Class Initialized
INFO - 2017-11-01 10:19:41 --> Language Class Initialized
INFO - 2017-11-01 10:19:41 --> Loader Class Initialized
INFO - 2017-11-01 10:19:41 --> Helper loaded: url_helper
INFO - 2017-11-01 10:19:41 --> Helper loaded: common_helper
INFO - 2017-11-01 10:19:41 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:19:41 --> Email Class Initialized
INFO - 2017-11-01 10:19:41 --> Model Class Initialized
INFO - 2017-11-01 10:19:41 --> Controller Class Initialized
INFO - 2017-11-01 10:19:41 --> Final output sent to browser
DEBUG - 2017-11-01 10:19:41 --> Total execution time: 0.0020
INFO - 2017-11-01 10:19:45 --> Config Class Initialized
INFO - 2017-11-01 10:19:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:19:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:19:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:19:45 --> URI Class Initialized
INFO - 2017-11-01 10:19:45 --> Router Class Initialized
INFO - 2017-11-01 10:19:45 --> Output Class Initialized
INFO - 2017-11-01 10:19:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:19:45 --> Input Class Initialized
INFO - 2017-11-01 10:19:45 --> Language Class Initialized
INFO - 2017-11-01 10:19:45 --> Loader Class Initialized
INFO - 2017-11-01 10:19:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:19:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:19:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:19:45 --> Email Class Initialized
INFO - 2017-11-01 10:19:45 --> Model Class Initialized
INFO - 2017-11-01 10:19:45 --> Controller Class Initialized
INFO - 2017-11-01 10:19:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:19:45 --> Total execution time: 0.0016
INFO - 2017-11-01 10:19:45 --> Config Class Initialized
INFO - 2017-11-01 10:19:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:19:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:19:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:19:45 --> URI Class Initialized
INFO - 2017-11-01 10:19:45 --> Router Class Initialized
INFO - 2017-11-01 10:19:45 --> Output Class Initialized
INFO - 2017-11-01 10:19:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:19:45 --> Input Class Initialized
INFO - 2017-11-01 10:19:45 --> Language Class Initialized
INFO - 2017-11-01 10:19:45 --> Loader Class Initialized
INFO - 2017-11-01 10:19:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:19:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:19:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:19:45 --> Email Class Initialized
INFO - 2017-11-01 10:19:45 --> Model Class Initialized
INFO - 2017-11-01 10:19:45 --> Controller Class Initialized
INFO - 2017-11-01 10:19:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:19:45 --> Total execution time: 0.0015
INFO - 2017-11-01 10:19:45 --> Config Class Initialized
INFO - 2017-11-01 10:19:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:19:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:19:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:19:45 --> URI Class Initialized
INFO - 2017-11-01 10:19:45 --> Router Class Initialized
INFO - 2017-11-01 10:19:45 --> Output Class Initialized
INFO - 2017-11-01 10:19:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:19:45 --> Input Class Initialized
INFO - 2017-11-01 10:19:45 --> Language Class Initialized
INFO - 2017-11-01 10:19:45 --> Loader Class Initialized
INFO - 2017-11-01 10:19:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:19:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:19:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:19:45 --> Email Class Initialized
INFO - 2017-11-01 10:19:45 --> Model Class Initialized
INFO - 2017-11-01 10:19:45 --> Controller Class Initialized
INFO - 2017-11-01 10:19:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:19:45 --> Total execution time: 0.0030
INFO - 2017-11-01 10:20:13 --> Config Class Initialized
INFO - 2017-11-01 10:20:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:13 --> URI Class Initialized
INFO - 2017-11-01 10:20:13 --> Router Class Initialized
INFO - 2017-11-01 10:20:13 --> Output Class Initialized
INFO - 2017-11-01 10:20:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:13 --> Input Class Initialized
INFO - 2017-11-01 10:20:13 --> Language Class Initialized
INFO - 2017-11-01 10:20:13 --> Loader Class Initialized
INFO - 2017-11-01 10:20:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:13 --> Email Class Initialized
INFO - 2017-11-01 10:20:13 --> Model Class Initialized
INFO - 2017-11-01 10:20:13 --> Controller Class Initialized
INFO - 2017-11-01 10:20:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:13 --> Total execution time: 0.0045
INFO - 2017-11-01 10:20:35 --> Config Class Initialized
INFO - 2017-11-01 10:20:35 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:35 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:35 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:35 --> URI Class Initialized
INFO - 2017-11-01 10:20:35 --> Router Class Initialized
INFO - 2017-11-01 10:20:35 --> Output Class Initialized
INFO - 2017-11-01 10:20:35 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:35 --> Input Class Initialized
INFO - 2017-11-01 10:20:35 --> Language Class Initialized
INFO - 2017-11-01 10:20:35 --> Loader Class Initialized
INFO - 2017-11-01 10:20:35 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:35 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:35 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:35 --> Email Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Controller Class Initialized
INFO - 2017-11-01 10:20:35 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:20:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:20:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:20:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:20:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:20:35 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:35 --> Total execution time: 0.0296
INFO - 2017-11-01 10:20:35 --> Config Class Initialized
INFO - 2017-11-01 10:20:35 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:35 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:35 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:35 --> URI Class Initialized
INFO - 2017-11-01 10:20:35 --> Router Class Initialized
INFO - 2017-11-01 10:20:35 --> Output Class Initialized
INFO - 2017-11-01 10:20:35 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:35 --> Input Class Initialized
INFO - 2017-11-01 10:20:35 --> Language Class Initialized
INFO - 2017-11-01 10:20:35 --> Loader Class Initialized
INFO - 2017-11-01 10:20:35 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:35 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:35 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:35 --> Email Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Controller Class Initialized
INFO - 2017-11-01 10:20:35 --> Model Class Initialized
INFO - 2017-11-01 10:20:35 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:35 --> Total execution time: 0.0022
INFO - 2017-11-01 10:20:38 --> Config Class Initialized
INFO - 2017-11-01 10:20:38 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:38 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:38 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:38 --> URI Class Initialized
INFO - 2017-11-01 10:20:38 --> Router Class Initialized
INFO - 2017-11-01 10:20:38 --> Output Class Initialized
INFO - 2017-11-01 10:20:38 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:38 --> Input Class Initialized
INFO - 2017-11-01 10:20:38 --> Language Class Initialized
INFO - 2017-11-01 10:20:38 --> Loader Class Initialized
INFO - 2017-11-01 10:20:38 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:38 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:38 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:38 --> Email Class Initialized
INFO - 2017-11-01 10:20:38 --> Model Class Initialized
INFO - 2017-11-01 10:20:38 --> Controller Class Initialized
INFO - 2017-11-01 10:20:38 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:38 --> Total execution time: 0.0023
INFO - 2017-11-01 10:20:40 --> Config Class Initialized
INFO - 2017-11-01 10:20:40 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:40 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:40 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:40 --> URI Class Initialized
INFO - 2017-11-01 10:20:40 --> Router Class Initialized
INFO - 2017-11-01 10:20:40 --> Output Class Initialized
INFO - 2017-11-01 10:20:40 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:40 --> Input Class Initialized
INFO - 2017-11-01 10:20:40 --> Language Class Initialized
INFO - 2017-11-01 10:20:40 --> Loader Class Initialized
INFO - 2017-11-01 10:20:40 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:40 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:40 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:40 --> Email Class Initialized
INFO - 2017-11-01 10:20:40 --> Model Class Initialized
INFO - 2017-11-01 10:20:40 --> Controller Class Initialized
INFO - 2017-11-01 10:20:40 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:40 --> Total execution time: 0.0015
INFO - 2017-11-01 10:20:41 --> Config Class Initialized
INFO - 2017-11-01 10:20:41 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:41 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:41 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:41 --> URI Class Initialized
INFO - 2017-11-01 10:20:41 --> Router Class Initialized
INFO - 2017-11-01 10:20:41 --> Output Class Initialized
INFO - 2017-11-01 10:20:41 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:41 --> Input Class Initialized
INFO - 2017-11-01 10:20:41 --> Language Class Initialized
INFO - 2017-11-01 10:20:41 --> Loader Class Initialized
INFO - 2017-11-01 10:20:41 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:41 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:41 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:41 --> Email Class Initialized
INFO - 2017-11-01 10:20:41 --> Model Class Initialized
INFO - 2017-11-01 10:20:41 --> Controller Class Initialized
INFO - 2017-11-01 10:20:41 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:41 --> Total execution time: 0.0016
INFO - 2017-11-01 10:20:41 --> Config Class Initialized
INFO - 2017-11-01 10:20:41 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:41 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:41 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:41 --> URI Class Initialized
INFO - 2017-11-01 10:20:41 --> Router Class Initialized
INFO - 2017-11-01 10:20:41 --> Output Class Initialized
INFO - 2017-11-01 10:20:41 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:41 --> Input Class Initialized
INFO - 2017-11-01 10:20:41 --> Language Class Initialized
INFO - 2017-11-01 10:20:41 --> Loader Class Initialized
INFO - 2017-11-01 10:20:41 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:41 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:41 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:41 --> Email Class Initialized
INFO - 2017-11-01 10:20:41 --> Model Class Initialized
INFO - 2017-11-01 10:20:41 --> Controller Class Initialized
INFO - 2017-11-01 10:20:41 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:41 --> Total execution time: 0.0015
INFO - 2017-11-01 10:20:42 --> Config Class Initialized
INFO - 2017-11-01 10:20:42 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:20:42 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:20:42 --> Utf8 Class Initialized
INFO - 2017-11-01 10:20:42 --> URI Class Initialized
INFO - 2017-11-01 10:20:42 --> Router Class Initialized
INFO - 2017-11-01 10:20:42 --> Output Class Initialized
INFO - 2017-11-01 10:20:42 --> Security Class Initialized
DEBUG - 2017-11-01 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:20:42 --> Input Class Initialized
INFO - 2017-11-01 10:20:42 --> Language Class Initialized
INFO - 2017-11-01 10:20:42 --> Loader Class Initialized
INFO - 2017-11-01 10:20:42 --> Helper loaded: url_helper
INFO - 2017-11-01 10:20:42 --> Helper loaded: common_helper
INFO - 2017-11-01 10:20:42 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:20:42 --> Email Class Initialized
INFO - 2017-11-01 10:20:42 --> Model Class Initialized
INFO - 2017-11-01 10:20:42 --> Controller Class Initialized
INFO - 2017-11-01 10:20:42 --> Final output sent to browser
DEBUG - 2017-11-01 10:20:42 --> Total execution time: 0.0016
INFO - 2017-11-01 10:33:15 --> Config Class Initialized
INFO - 2017-11-01 10:33:15 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:15 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:15 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:15 --> URI Class Initialized
INFO - 2017-11-01 10:33:15 --> Router Class Initialized
INFO - 2017-11-01 10:33:15 --> Output Class Initialized
INFO - 2017-11-01 10:33:15 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:15 --> Input Class Initialized
INFO - 2017-11-01 10:33:15 --> Language Class Initialized
INFO - 2017-11-01 10:33:15 --> Loader Class Initialized
INFO - 2017-11-01 10:33:15 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:15 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:15 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:15 --> Email Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Controller Class Initialized
INFO - 2017-11-01 10:33:15 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:33:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:33:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:33:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:33:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:33:15 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:15 --> Total execution time: 0.0257
INFO - 2017-11-01 10:33:15 --> Config Class Initialized
INFO - 2017-11-01 10:33:15 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:15 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:15 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:15 --> URI Class Initialized
INFO - 2017-11-01 10:33:15 --> Router Class Initialized
INFO - 2017-11-01 10:33:15 --> Output Class Initialized
INFO - 2017-11-01 10:33:15 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:15 --> Input Class Initialized
INFO - 2017-11-01 10:33:15 --> Language Class Initialized
INFO - 2017-11-01 10:33:15 --> Loader Class Initialized
INFO - 2017-11-01 10:33:15 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:15 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:15 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:15 --> Email Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Controller Class Initialized
INFO - 2017-11-01 10:33:15 --> Model Class Initialized
INFO - 2017-11-01 10:33:15 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:15 --> Total execution time: 0.0031
INFO - 2017-11-01 10:33:16 --> Config Class Initialized
INFO - 2017-11-01 10:33:16 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:16 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:16 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:16 --> URI Class Initialized
INFO - 2017-11-01 10:33:16 --> Router Class Initialized
INFO - 2017-11-01 10:33:16 --> Output Class Initialized
INFO - 2017-11-01 10:33:16 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:16 --> Input Class Initialized
INFO - 2017-11-01 10:33:16 --> Language Class Initialized
INFO - 2017-11-01 10:33:16 --> Loader Class Initialized
INFO - 2017-11-01 10:33:16 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:16 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:16 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:16 --> Email Class Initialized
INFO - 2017-11-01 10:33:16 --> Model Class Initialized
INFO - 2017-11-01 10:33:16 --> Controller Class Initialized
INFO - 2017-11-01 10:33:16 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:16 --> Total execution time: 0.0026
INFO - 2017-11-01 10:33:19 --> Config Class Initialized
INFO - 2017-11-01 10:33:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:19 --> URI Class Initialized
INFO - 2017-11-01 10:33:19 --> Router Class Initialized
INFO - 2017-11-01 10:33:19 --> Output Class Initialized
INFO - 2017-11-01 10:33:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:19 --> Input Class Initialized
INFO - 2017-11-01 10:33:19 --> Language Class Initialized
INFO - 2017-11-01 10:33:19 --> Loader Class Initialized
INFO - 2017-11-01 10:33:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:19 --> Email Class Initialized
INFO - 2017-11-01 10:33:19 --> Model Class Initialized
INFO - 2017-11-01 10:33:19 --> Controller Class Initialized
INFO - 2017-11-01 10:33:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:19 --> Total execution time: 0.0015
INFO - 2017-11-01 10:33:19 --> Config Class Initialized
INFO - 2017-11-01 10:33:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:19 --> URI Class Initialized
INFO - 2017-11-01 10:33:19 --> Router Class Initialized
INFO - 2017-11-01 10:33:19 --> Output Class Initialized
INFO - 2017-11-01 10:33:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:19 --> Input Class Initialized
INFO - 2017-11-01 10:33:19 --> Language Class Initialized
INFO - 2017-11-01 10:33:19 --> Loader Class Initialized
INFO - 2017-11-01 10:33:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:19 --> Email Class Initialized
INFO - 2017-11-01 10:33:19 --> Model Class Initialized
INFO - 2017-11-01 10:33:19 --> Controller Class Initialized
INFO - 2017-11-01 10:33:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:19 --> Total execution time: 0.0015
INFO - 2017-11-01 10:33:20 --> Config Class Initialized
INFO - 2017-11-01 10:33:20 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:20 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:20 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:20 --> URI Class Initialized
INFO - 2017-11-01 10:33:20 --> Router Class Initialized
INFO - 2017-11-01 10:33:20 --> Output Class Initialized
INFO - 2017-11-01 10:33:20 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:20 --> Input Class Initialized
INFO - 2017-11-01 10:33:20 --> Language Class Initialized
INFO - 2017-11-01 10:33:20 --> Loader Class Initialized
INFO - 2017-11-01 10:33:20 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:20 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:20 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:20 --> Email Class Initialized
INFO - 2017-11-01 10:33:20 --> Model Class Initialized
INFO - 2017-11-01 10:33:20 --> Controller Class Initialized
INFO - 2017-11-01 10:33:20 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:20 --> Total execution time: 0.0023
INFO - 2017-11-01 10:33:20 --> Config Class Initialized
INFO - 2017-11-01 10:33:20 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:33:20 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:33:20 --> Utf8 Class Initialized
INFO - 2017-11-01 10:33:20 --> URI Class Initialized
INFO - 2017-11-01 10:33:20 --> Router Class Initialized
INFO - 2017-11-01 10:33:20 --> Output Class Initialized
INFO - 2017-11-01 10:33:20 --> Security Class Initialized
DEBUG - 2017-11-01 10:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:33:20 --> Input Class Initialized
INFO - 2017-11-01 10:33:20 --> Language Class Initialized
INFO - 2017-11-01 10:33:20 --> Loader Class Initialized
INFO - 2017-11-01 10:33:20 --> Helper loaded: url_helper
INFO - 2017-11-01 10:33:20 --> Helper loaded: common_helper
INFO - 2017-11-01 10:33:20 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:33:20 --> Email Class Initialized
INFO - 2017-11-01 10:33:20 --> Model Class Initialized
INFO - 2017-11-01 10:33:20 --> Controller Class Initialized
INFO - 2017-11-01 10:33:20 --> Final output sent to browser
DEBUG - 2017-11-01 10:33:20 --> Total execution time: 0.0016
INFO - 2017-11-01 10:35:01 --> Config Class Initialized
INFO - 2017-11-01 10:35:01 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:01 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:01 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:01 --> URI Class Initialized
INFO - 2017-11-01 10:35:01 --> Router Class Initialized
INFO - 2017-11-01 10:35:01 --> Output Class Initialized
INFO - 2017-11-01 10:35:01 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:01 --> Input Class Initialized
INFO - 2017-11-01 10:35:01 --> Language Class Initialized
INFO - 2017-11-01 10:35:01 --> Loader Class Initialized
INFO - 2017-11-01 10:35:01 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:01 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:01 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:01 --> Email Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Controller Class Initialized
INFO - 2017-11-01 10:35:01 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:35:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:35:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:35:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:35:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:35:01 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:01 --> Total execution time: 0.0250
INFO - 2017-11-01 10:35:01 --> Config Class Initialized
INFO - 2017-11-01 10:35:01 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:01 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:01 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:01 --> URI Class Initialized
INFO - 2017-11-01 10:35:01 --> Router Class Initialized
INFO - 2017-11-01 10:35:01 --> Output Class Initialized
INFO - 2017-11-01 10:35:01 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:01 --> Input Class Initialized
INFO - 2017-11-01 10:35:01 --> Language Class Initialized
INFO - 2017-11-01 10:35:01 --> Loader Class Initialized
INFO - 2017-11-01 10:35:01 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:01 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:01 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:01 --> Email Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Controller Class Initialized
INFO - 2017-11-01 10:35:01 --> Model Class Initialized
INFO - 2017-11-01 10:35:01 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:01 --> Total execution time: 0.0030
INFO - 2017-11-01 10:35:02 --> Config Class Initialized
INFO - 2017-11-01 10:35:02 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:02 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:02 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:02 --> URI Class Initialized
INFO - 2017-11-01 10:35:02 --> Router Class Initialized
INFO - 2017-11-01 10:35:02 --> Output Class Initialized
INFO - 2017-11-01 10:35:02 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:02 --> Input Class Initialized
INFO - 2017-11-01 10:35:02 --> Language Class Initialized
INFO - 2017-11-01 10:35:02 --> Loader Class Initialized
INFO - 2017-11-01 10:35:02 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:02 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:02 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:02 --> Email Class Initialized
INFO - 2017-11-01 10:35:02 --> Model Class Initialized
INFO - 2017-11-01 10:35:02 --> Controller Class Initialized
INFO - 2017-11-01 10:35:02 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:02 --> Total execution time: 0.0024
INFO - 2017-11-01 10:35:05 --> Config Class Initialized
INFO - 2017-11-01 10:35:05 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:05 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:05 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:05 --> URI Class Initialized
INFO - 2017-11-01 10:35:05 --> Router Class Initialized
INFO - 2017-11-01 10:35:05 --> Output Class Initialized
INFO - 2017-11-01 10:35:05 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:05 --> Input Class Initialized
INFO - 2017-11-01 10:35:05 --> Language Class Initialized
INFO - 2017-11-01 10:35:05 --> Loader Class Initialized
INFO - 2017-11-01 10:35:05 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:05 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:05 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:05 --> Email Class Initialized
INFO - 2017-11-01 10:35:05 --> Model Class Initialized
INFO - 2017-11-01 10:35:05 --> Controller Class Initialized
INFO - 2017-11-01 10:35:05 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:05 --> Total execution time: 0.0035
INFO - 2017-11-01 10:35:05 --> Config Class Initialized
INFO - 2017-11-01 10:35:05 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:05 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:05 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:05 --> URI Class Initialized
INFO - 2017-11-01 10:35:05 --> Router Class Initialized
INFO - 2017-11-01 10:35:05 --> Output Class Initialized
INFO - 2017-11-01 10:35:05 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:05 --> Input Class Initialized
INFO - 2017-11-01 10:35:05 --> Language Class Initialized
INFO - 2017-11-01 10:35:05 --> Loader Class Initialized
INFO - 2017-11-01 10:35:05 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:05 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:05 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:05 --> Email Class Initialized
INFO - 2017-11-01 10:35:05 --> Model Class Initialized
INFO - 2017-11-01 10:35:05 --> Controller Class Initialized
INFO - 2017-11-01 10:35:05 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:05 --> Total execution time: 0.0015
INFO - 2017-11-01 10:35:05 --> Config Class Initialized
INFO - 2017-11-01 10:35:05 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:05 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:05 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:05 --> URI Class Initialized
INFO - 2017-11-01 10:35:05 --> Router Class Initialized
INFO - 2017-11-01 10:35:05 --> Output Class Initialized
INFO - 2017-11-01 10:35:05 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:05 --> Input Class Initialized
INFO - 2017-11-01 10:35:05 --> Language Class Initialized
INFO - 2017-11-01 10:35:05 --> Loader Class Initialized
INFO - 2017-11-01 10:35:05 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:05 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:05 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:05 --> Email Class Initialized
INFO - 2017-11-01 10:35:05 --> Model Class Initialized
INFO - 2017-11-01 10:35:05 --> Controller Class Initialized
INFO - 2017-11-01 10:35:05 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:05 --> Total execution time: 0.0015
INFO - 2017-11-01 10:35:06 --> Config Class Initialized
INFO - 2017-11-01 10:35:06 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:06 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:06 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:06 --> URI Class Initialized
INFO - 2017-11-01 10:35:06 --> Router Class Initialized
INFO - 2017-11-01 10:35:06 --> Output Class Initialized
INFO - 2017-11-01 10:35:06 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:06 --> Input Class Initialized
INFO - 2017-11-01 10:35:06 --> Language Class Initialized
INFO - 2017-11-01 10:35:06 --> Loader Class Initialized
INFO - 2017-11-01 10:35:06 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:06 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:06 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:06 --> Email Class Initialized
INFO - 2017-11-01 10:35:06 --> Model Class Initialized
INFO - 2017-11-01 10:35:06 --> Controller Class Initialized
INFO - 2017-11-01 10:35:06 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:06 --> Total execution time: 0.0016
INFO - 2017-11-01 10:35:17 --> Config Class Initialized
INFO - 2017-11-01 10:35:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:17 --> URI Class Initialized
INFO - 2017-11-01 10:35:17 --> Router Class Initialized
INFO - 2017-11-01 10:35:17 --> Output Class Initialized
INFO - 2017-11-01 10:35:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:17 --> Input Class Initialized
INFO - 2017-11-01 10:35:17 --> Language Class Initialized
INFO - 2017-11-01 10:35:17 --> Loader Class Initialized
INFO - 2017-11-01 10:35:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:17 --> Email Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Controller Class Initialized
INFO - 2017-11-01 10:35:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:17 --> Total execution time: 0.0036
INFO - 2017-11-01 10:35:17 --> Config Class Initialized
INFO - 2017-11-01 10:35:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:17 --> URI Class Initialized
INFO - 2017-11-01 10:35:17 --> Router Class Initialized
INFO - 2017-11-01 10:35:17 --> Output Class Initialized
INFO - 2017-11-01 10:35:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:17 --> Input Class Initialized
INFO - 2017-11-01 10:35:17 --> Language Class Initialized
INFO - 2017-11-01 10:35:17 --> Loader Class Initialized
INFO - 2017-11-01 10:35:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:17 --> Email Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Controller Class Initialized
INFO - 2017-11-01 10:35:17 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> Model Class Initialized
INFO - 2017-11-01 10:35:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:35:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:35:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:35:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:35:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:35:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:17 --> Total execution time: 0.0259
INFO - 2017-11-01 10:35:18 --> Config Class Initialized
INFO - 2017-11-01 10:35:18 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:18 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:18 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:18 --> URI Class Initialized
INFO - 2017-11-01 10:35:18 --> Router Class Initialized
INFO - 2017-11-01 10:35:18 --> Output Class Initialized
INFO - 2017-11-01 10:35:18 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:18 --> Input Class Initialized
INFO - 2017-11-01 10:35:18 --> Language Class Initialized
INFO - 2017-11-01 10:35:18 --> Loader Class Initialized
INFO - 2017-11-01 10:35:18 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:18 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:18 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:18 --> Email Class Initialized
INFO - 2017-11-01 10:35:18 --> Model Class Initialized
INFO - 2017-11-01 10:35:18 --> Controller Class Initialized
INFO - 2017-11-01 10:35:18 --> Model Class Initialized
INFO - 2017-11-01 10:35:18 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:18 --> Total execution time: 0.0019
INFO - 2017-11-01 10:35:19 --> Config Class Initialized
INFO - 2017-11-01 10:35:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:19 --> URI Class Initialized
INFO - 2017-11-01 10:35:19 --> Router Class Initialized
INFO - 2017-11-01 10:35:19 --> Output Class Initialized
INFO - 2017-11-01 10:35:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:19 --> Input Class Initialized
INFO - 2017-11-01 10:35:19 --> Language Class Initialized
INFO - 2017-11-01 10:35:19 --> Loader Class Initialized
INFO - 2017-11-01 10:35:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:19 --> Email Class Initialized
INFO - 2017-11-01 10:35:19 --> Model Class Initialized
INFO - 2017-11-01 10:35:19 --> Controller Class Initialized
INFO - 2017-11-01 10:35:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:19 --> Total execution time: 0.0024
INFO - 2017-11-01 10:35:21 --> Config Class Initialized
INFO - 2017-11-01 10:35:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:21 --> URI Class Initialized
INFO - 2017-11-01 10:35:21 --> Router Class Initialized
INFO - 2017-11-01 10:35:21 --> Output Class Initialized
INFO - 2017-11-01 10:35:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:21 --> Input Class Initialized
INFO - 2017-11-01 10:35:21 --> Language Class Initialized
INFO - 2017-11-01 10:35:21 --> Loader Class Initialized
INFO - 2017-11-01 10:35:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:21 --> Email Class Initialized
INFO - 2017-11-01 10:35:21 --> Model Class Initialized
INFO - 2017-11-01 10:35:21 --> Controller Class Initialized
INFO - 2017-11-01 10:35:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:21 --> Total execution time: 0.0021
INFO - 2017-11-01 10:35:21 --> Config Class Initialized
INFO - 2017-11-01 10:35:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:21 --> URI Class Initialized
INFO - 2017-11-01 10:35:21 --> Router Class Initialized
INFO - 2017-11-01 10:35:21 --> Output Class Initialized
INFO - 2017-11-01 10:35:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:21 --> Input Class Initialized
INFO - 2017-11-01 10:35:21 --> Language Class Initialized
INFO - 2017-11-01 10:35:21 --> Loader Class Initialized
INFO - 2017-11-01 10:35:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:21 --> Email Class Initialized
INFO - 2017-11-01 10:35:21 --> Model Class Initialized
INFO - 2017-11-01 10:35:21 --> Controller Class Initialized
INFO - 2017-11-01 10:35:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:21 --> Total execution time: 0.0016
INFO - 2017-11-01 10:35:21 --> Config Class Initialized
INFO - 2017-11-01 10:35:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:21 --> URI Class Initialized
INFO - 2017-11-01 10:35:21 --> Router Class Initialized
INFO - 2017-11-01 10:35:21 --> Output Class Initialized
INFO - 2017-11-01 10:35:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:21 --> Input Class Initialized
INFO - 2017-11-01 10:35:21 --> Language Class Initialized
INFO - 2017-11-01 10:35:21 --> Loader Class Initialized
INFO - 2017-11-01 10:35:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:21 --> Email Class Initialized
INFO - 2017-11-01 10:35:21 --> Model Class Initialized
INFO - 2017-11-01 10:35:21 --> Controller Class Initialized
INFO - 2017-11-01 10:35:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:21 --> Total execution time: 0.0035
INFO - 2017-11-01 10:35:22 --> Config Class Initialized
INFO - 2017-11-01 10:35:22 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:22 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:22 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:22 --> URI Class Initialized
INFO - 2017-11-01 10:35:22 --> Router Class Initialized
INFO - 2017-11-01 10:35:22 --> Output Class Initialized
INFO - 2017-11-01 10:35:22 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:22 --> Input Class Initialized
INFO - 2017-11-01 10:35:22 --> Language Class Initialized
INFO - 2017-11-01 10:35:22 --> Loader Class Initialized
INFO - 2017-11-01 10:35:22 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:22 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:22 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:22 --> Email Class Initialized
INFO - 2017-11-01 10:35:22 --> Model Class Initialized
INFO - 2017-11-01 10:35:22 --> Controller Class Initialized
INFO - 2017-11-01 10:35:22 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:22 --> Total execution time: 0.0014
INFO - 2017-11-01 10:35:28 --> Config Class Initialized
INFO - 2017-11-01 10:35:28 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:35:28 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:35:28 --> Utf8 Class Initialized
INFO - 2017-11-01 10:35:28 --> URI Class Initialized
INFO - 2017-11-01 10:35:28 --> Router Class Initialized
INFO - 2017-11-01 10:35:28 --> Output Class Initialized
INFO - 2017-11-01 10:35:28 --> Security Class Initialized
DEBUG - 2017-11-01 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:35:28 --> Input Class Initialized
INFO - 2017-11-01 10:35:28 --> Language Class Initialized
INFO - 2017-11-01 10:35:28 --> Loader Class Initialized
INFO - 2017-11-01 10:35:28 --> Helper loaded: url_helper
INFO - 2017-11-01 10:35:28 --> Helper loaded: common_helper
INFO - 2017-11-01 10:35:28 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:35:28 --> Email Class Initialized
INFO - 2017-11-01 10:35:28 --> Model Class Initialized
INFO - 2017-11-01 10:35:28 --> Controller Class Initialized
INFO - 2017-11-01 10:35:28 --> Final output sent to browser
DEBUG - 2017-11-01 10:35:28 --> Total execution time: 0.0024
INFO - 2017-11-01 10:36:11 --> Config Class Initialized
INFO - 2017-11-01 10:36:11 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:11 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:11 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:11 --> URI Class Initialized
INFO - 2017-11-01 10:36:11 --> Router Class Initialized
INFO - 2017-11-01 10:36:11 --> Output Class Initialized
INFO - 2017-11-01 10:36:11 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:11 --> Input Class Initialized
INFO - 2017-11-01 10:36:11 --> Language Class Initialized
INFO - 2017-11-01 10:36:11 --> Loader Class Initialized
INFO - 2017-11-01 10:36:11 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:11 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:11 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:11 --> Email Class Initialized
INFO - 2017-11-01 10:36:11 --> Model Class Initialized
INFO - 2017-11-01 10:36:11 --> Controller Class Initialized
INFO - 2017-11-01 10:36:11 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:11 --> Total execution time: 0.0034
INFO - 2017-11-01 10:36:15 --> Config Class Initialized
INFO - 2017-11-01 10:36:15 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:15 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:15 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:15 --> URI Class Initialized
INFO - 2017-11-01 10:36:15 --> Router Class Initialized
INFO - 2017-11-01 10:36:15 --> Output Class Initialized
INFO - 2017-11-01 10:36:15 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:15 --> Input Class Initialized
INFO - 2017-11-01 10:36:15 --> Language Class Initialized
INFO - 2017-11-01 10:36:15 --> Loader Class Initialized
INFO - 2017-11-01 10:36:15 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:15 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:15 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:15 --> Email Class Initialized
INFO - 2017-11-01 10:36:15 --> Model Class Initialized
INFO - 2017-11-01 10:36:15 --> Controller Class Initialized
INFO - 2017-11-01 10:36:15 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:15 --> Total execution time: 0.0027
INFO - 2017-11-01 10:36:16 --> Config Class Initialized
INFO - 2017-11-01 10:36:16 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:16 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:16 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:16 --> URI Class Initialized
INFO - 2017-11-01 10:36:16 --> Router Class Initialized
INFO - 2017-11-01 10:36:16 --> Output Class Initialized
INFO - 2017-11-01 10:36:16 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:16 --> Input Class Initialized
INFO - 2017-11-01 10:36:16 --> Language Class Initialized
INFO - 2017-11-01 10:36:16 --> Loader Class Initialized
INFO - 2017-11-01 10:36:16 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:16 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:16 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:16 --> Email Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Controller Class Initialized
INFO - 2017-11-01 10:36:16 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:36:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:36:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:36:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:36:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:36:16 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:16 --> Total execution time: 0.0235
INFO - 2017-11-01 10:36:16 --> Config Class Initialized
INFO - 2017-11-01 10:36:16 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:16 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:16 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:16 --> URI Class Initialized
INFO - 2017-11-01 10:36:16 --> Router Class Initialized
INFO - 2017-11-01 10:36:16 --> Output Class Initialized
INFO - 2017-11-01 10:36:16 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:16 --> Input Class Initialized
INFO - 2017-11-01 10:36:16 --> Language Class Initialized
INFO - 2017-11-01 10:36:16 --> Loader Class Initialized
INFO - 2017-11-01 10:36:16 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:16 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:16 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:16 --> Email Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Controller Class Initialized
INFO - 2017-11-01 10:36:16 --> Model Class Initialized
INFO - 2017-11-01 10:36:16 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:16 --> Total execution time: 0.0025
INFO - 2017-11-01 10:36:17 --> Config Class Initialized
INFO - 2017-11-01 10:36:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:17 --> URI Class Initialized
INFO - 2017-11-01 10:36:17 --> Router Class Initialized
INFO - 2017-11-01 10:36:17 --> Output Class Initialized
INFO - 2017-11-01 10:36:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:17 --> Input Class Initialized
INFO - 2017-11-01 10:36:17 --> Language Class Initialized
INFO - 2017-11-01 10:36:17 --> Loader Class Initialized
INFO - 2017-11-01 10:36:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:17 --> Email Class Initialized
INFO - 2017-11-01 10:36:17 --> Model Class Initialized
INFO - 2017-11-01 10:36:17 --> Controller Class Initialized
INFO - 2017-11-01 10:36:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:17 --> Total execution time: 0.0024
INFO - 2017-11-01 10:36:19 --> Config Class Initialized
INFO - 2017-11-01 10:36:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:19 --> URI Class Initialized
INFO - 2017-11-01 10:36:19 --> Router Class Initialized
INFO - 2017-11-01 10:36:19 --> Output Class Initialized
INFO - 2017-11-01 10:36:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:19 --> Input Class Initialized
INFO - 2017-11-01 10:36:19 --> Language Class Initialized
INFO - 2017-11-01 10:36:19 --> Loader Class Initialized
INFO - 2017-11-01 10:36:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:19 --> Email Class Initialized
INFO - 2017-11-01 10:36:19 --> Model Class Initialized
INFO - 2017-11-01 10:36:19 --> Controller Class Initialized
INFO - 2017-11-01 10:36:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:19 --> Total execution time: 0.0016
INFO - 2017-11-01 10:36:19 --> Config Class Initialized
INFO - 2017-11-01 10:36:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:19 --> URI Class Initialized
INFO - 2017-11-01 10:36:19 --> Router Class Initialized
INFO - 2017-11-01 10:36:19 --> Output Class Initialized
INFO - 2017-11-01 10:36:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:19 --> Input Class Initialized
INFO - 2017-11-01 10:36:19 --> Language Class Initialized
INFO - 2017-11-01 10:36:19 --> Loader Class Initialized
INFO - 2017-11-01 10:36:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:19 --> Email Class Initialized
INFO - 2017-11-01 10:36:19 --> Model Class Initialized
INFO - 2017-11-01 10:36:19 --> Controller Class Initialized
INFO - 2017-11-01 10:36:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:19 --> Total execution time: 0.0017
INFO - 2017-11-01 10:36:19 --> Config Class Initialized
INFO - 2017-11-01 10:36:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:19 --> URI Class Initialized
INFO - 2017-11-01 10:36:19 --> Router Class Initialized
INFO - 2017-11-01 10:36:19 --> Output Class Initialized
INFO - 2017-11-01 10:36:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:19 --> Input Class Initialized
INFO - 2017-11-01 10:36:19 --> Language Class Initialized
INFO - 2017-11-01 10:36:19 --> Loader Class Initialized
INFO - 2017-11-01 10:36:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:19 --> Email Class Initialized
INFO - 2017-11-01 10:36:19 --> Model Class Initialized
INFO - 2017-11-01 10:36:19 --> Controller Class Initialized
INFO - 2017-11-01 10:36:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:19 --> Total execution time: 0.0021
INFO - 2017-11-01 10:36:20 --> Config Class Initialized
INFO - 2017-11-01 10:36:20 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:20 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:20 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:20 --> URI Class Initialized
INFO - 2017-11-01 10:36:20 --> Router Class Initialized
INFO - 2017-11-01 10:36:20 --> Output Class Initialized
INFO - 2017-11-01 10:36:20 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:20 --> Input Class Initialized
INFO - 2017-11-01 10:36:20 --> Language Class Initialized
INFO - 2017-11-01 10:36:20 --> Loader Class Initialized
INFO - 2017-11-01 10:36:20 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:20 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:20 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:20 --> Email Class Initialized
INFO - 2017-11-01 10:36:20 --> Model Class Initialized
INFO - 2017-11-01 10:36:20 --> Controller Class Initialized
INFO - 2017-11-01 10:36:20 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:20 --> Total execution time: 0.0016
INFO - 2017-11-01 10:36:21 --> Config Class Initialized
INFO - 2017-11-01 10:36:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:21 --> URI Class Initialized
INFO - 2017-11-01 10:36:21 --> Router Class Initialized
INFO - 2017-11-01 10:36:21 --> Output Class Initialized
INFO - 2017-11-01 10:36:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:21 --> Input Class Initialized
INFO - 2017-11-01 10:36:21 --> Language Class Initialized
INFO - 2017-11-01 10:36:21 --> Loader Class Initialized
INFO - 2017-11-01 10:36:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:21 --> Email Class Initialized
INFO - 2017-11-01 10:36:21 --> Model Class Initialized
INFO - 2017-11-01 10:36:21 --> Controller Class Initialized
INFO - 2017-11-01 10:36:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:21 --> Total execution time: 0.0020
INFO - 2017-11-01 10:36:22 --> Config Class Initialized
INFO - 2017-11-01 10:36:22 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:22 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:22 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:22 --> URI Class Initialized
INFO - 2017-11-01 10:36:22 --> Router Class Initialized
INFO - 2017-11-01 10:36:22 --> Output Class Initialized
INFO - 2017-11-01 10:36:22 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:22 --> Input Class Initialized
INFO - 2017-11-01 10:36:22 --> Language Class Initialized
INFO - 2017-11-01 10:36:22 --> Loader Class Initialized
INFO - 2017-11-01 10:36:22 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:22 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:22 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:22 --> Email Class Initialized
INFO - 2017-11-01 10:36:22 --> Model Class Initialized
INFO - 2017-11-01 10:36:22 --> Controller Class Initialized
INFO - 2017-11-01 10:36:22 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:22 --> Total execution time: 0.0015
INFO - 2017-11-01 10:36:42 --> Config Class Initialized
INFO - 2017-11-01 10:36:42 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:42 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:42 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:42 --> URI Class Initialized
INFO - 2017-11-01 10:36:42 --> Router Class Initialized
INFO - 2017-11-01 10:36:42 --> Output Class Initialized
INFO - 2017-11-01 10:36:42 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:42 --> Input Class Initialized
INFO - 2017-11-01 10:36:42 --> Language Class Initialized
INFO - 2017-11-01 10:36:42 --> Loader Class Initialized
INFO - 2017-11-01 10:36:42 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:42 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:42 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:42 --> Email Class Initialized
INFO - 2017-11-01 10:36:42 --> Model Class Initialized
INFO - 2017-11-01 10:36:42 --> Controller Class Initialized
INFO - 2017-11-01 10:36:42 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:42 --> Total execution time: 0.0025
INFO - 2017-11-01 10:36:43 --> Config Class Initialized
INFO - 2017-11-01 10:36:43 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:43 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:43 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:43 --> URI Class Initialized
INFO - 2017-11-01 10:36:43 --> Router Class Initialized
INFO - 2017-11-01 10:36:43 --> Output Class Initialized
INFO - 2017-11-01 10:36:43 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:43 --> Input Class Initialized
INFO - 2017-11-01 10:36:43 --> Language Class Initialized
INFO - 2017-11-01 10:36:43 --> Loader Class Initialized
INFO - 2017-11-01 10:36:43 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:43 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:43 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:43 --> Email Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Controller Class Initialized
INFO - 2017-11-01 10:36:43 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:36:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:36:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:36:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:36:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:36:43 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:43 --> Total execution time: 0.0228
INFO - 2017-11-01 10:36:43 --> Config Class Initialized
INFO - 2017-11-01 10:36:43 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:43 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:43 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:43 --> URI Class Initialized
INFO - 2017-11-01 10:36:43 --> Router Class Initialized
INFO - 2017-11-01 10:36:43 --> Output Class Initialized
INFO - 2017-11-01 10:36:43 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:43 --> Input Class Initialized
INFO - 2017-11-01 10:36:43 --> Language Class Initialized
INFO - 2017-11-01 10:36:43 --> Loader Class Initialized
INFO - 2017-11-01 10:36:43 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:43 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:43 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:43 --> Email Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Controller Class Initialized
INFO - 2017-11-01 10:36:43 --> Model Class Initialized
INFO - 2017-11-01 10:36:43 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:43 --> Total execution time: 0.0018
INFO - 2017-11-01 10:36:44 --> Config Class Initialized
INFO - 2017-11-01 10:36:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:44 --> URI Class Initialized
INFO - 2017-11-01 10:36:44 --> Router Class Initialized
INFO - 2017-11-01 10:36:44 --> Output Class Initialized
INFO - 2017-11-01 10:36:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:44 --> Input Class Initialized
INFO - 2017-11-01 10:36:44 --> Language Class Initialized
INFO - 2017-11-01 10:36:44 --> Loader Class Initialized
INFO - 2017-11-01 10:36:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:44 --> Email Class Initialized
INFO - 2017-11-01 10:36:44 --> Model Class Initialized
INFO - 2017-11-01 10:36:44 --> Controller Class Initialized
INFO - 2017-11-01 10:36:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:44 --> Total execution time: 0.0026
INFO - 2017-11-01 10:36:47 --> Config Class Initialized
INFO - 2017-11-01 10:36:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:47 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:47 --> URI Class Initialized
INFO - 2017-11-01 10:36:47 --> Router Class Initialized
INFO - 2017-11-01 10:36:47 --> Output Class Initialized
INFO - 2017-11-01 10:36:47 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:47 --> Input Class Initialized
INFO - 2017-11-01 10:36:47 --> Language Class Initialized
INFO - 2017-11-01 10:36:47 --> Loader Class Initialized
INFO - 2017-11-01 10:36:47 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:47 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:47 --> Email Class Initialized
INFO - 2017-11-01 10:36:47 --> Model Class Initialized
INFO - 2017-11-01 10:36:47 --> Controller Class Initialized
INFO - 2017-11-01 10:36:47 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:47 --> Total execution time: 0.0038
INFO - 2017-11-01 10:36:47 --> Config Class Initialized
INFO - 2017-11-01 10:36:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:47 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:47 --> URI Class Initialized
INFO - 2017-11-01 10:36:47 --> Router Class Initialized
INFO - 2017-11-01 10:36:47 --> Output Class Initialized
INFO - 2017-11-01 10:36:47 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:47 --> Input Class Initialized
INFO - 2017-11-01 10:36:47 --> Language Class Initialized
INFO - 2017-11-01 10:36:47 --> Loader Class Initialized
INFO - 2017-11-01 10:36:47 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:47 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:47 --> Email Class Initialized
INFO - 2017-11-01 10:36:47 --> Model Class Initialized
INFO - 2017-11-01 10:36:47 --> Controller Class Initialized
INFO - 2017-11-01 10:36:47 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:47 --> Total execution time: 0.0017
INFO - 2017-11-01 10:36:47 --> Config Class Initialized
INFO - 2017-11-01 10:36:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:47 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:47 --> URI Class Initialized
INFO - 2017-11-01 10:36:47 --> Router Class Initialized
INFO - 2017-11-01 10:36:47 --> Output Class Initialized
INFO - 2017-11-01 10:36:47 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:47 --> Input Class Initialized
INFO - 2017-11-01 10:36:47 --> Language Class Initialized
INFO - 2017-11-01 10:36:47 --> Loader Class Initialized
INFO - 2017-11-01 10:36:47 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:47 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:47 --> Email Class Initialized
INFO - 2017-11-01 10:36:47 --> Model Class Initialized
INFO - 2017-11-01 10:36:47 --> Controller Class Initialized
INFO - 2017-11-01 10:36:47 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:47 --> Total execution time: 0.0016
INFO - 2017-11-01 10:36:47 --> Config Class Initialized
INFO - 2017-11-01 10:36:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:36:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:36:47 --> Utf8 Class Initialized
INFO - 2017-11-01 10:36:47 --> URI Class Initialized
INFO - 2017-11-01 10:36:47 --> Router Class Initialized
INFO - 2017-11-01 10:36:47 --> Output Class Initialized
INFO - 2017-11-01 10:36:47 --> Security Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:36:47 --> Input Class Initialized
INFO - 2017-11-01 10:36:47 --> Language Class Initialized
INFO - 2017-11-01 10:36:47 --> Loader Class Initialized
INFO - 2017-11-01 10:36:47 --> Helper loaded: url_helper
INFO - 2017-11-01 10:36:47 --> Helper loaded: common_helper
INFO - 2017-11-01 10:36:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:36:47 --> Email Class Initialized
INFO - 2017-11-01 10:36:47 --> Model Class Initialized
INFO - 2017-11-01 10:36:47 --> Controller Class Initialized
INFO - 2017-11-01 10:36:47 --> Final output sent to browser
DEBUG - 2017-11-01 10:36:47 --> Total execution time: 0.0016
INFO - 2017-11-01 10:37:34 --> Config Class Initialized
INFO - 2017-11-01 10:37:34 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:37:34 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:37:34 --> Utf8 Class Initialized
INFO - 2017-11-01 10:37:34 --> URI Class Initialized
INFO - 2017-11-01 10:37:34 --> Router Class Initialized
INFO - 2017-11-01 10:37:34 --> Output Class Initialized
INFO - 2017-11-01 10:37:34 --> Security Class Initialized
DEBUG - 2017-11-01 10:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:37:34 --> Input Class Initialized
INFO - 2017-11-01 10:37:34 --> Language Class Initialized
INFO - 2017-11-01 10:37:34 --> Loader Class Initialized
INFO - 2017-11-01 10:37:34 --> Helper loaded: url_helper
INFO - 2017-11-01 10:37:34 --> Helper loaded: common_helper
INFO - 2017-11-01 10:37:34 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:37:34 --> Email Class Initialized
INFO - 2017-11-01 10:37:34 --> Model Class Initialized
INFO - 2017-11-01 10:37:34 --> Controller Class Initialized
INFO - 2017-11-01 10:37:34 --> Final output sent to browser
DEBUG - 2017-11-01 10:37:34 --> Total execution time: 0.0024
INFO - 2017-11-01 10:37:36 --> Config Class Initialized
INFO - 2017-11-01 10:37:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:37:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:37:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:37:36 --> URI Class Initialized
INFO - 2017-11-01 10:37:36 --> Router Class Initialized
INFO - 2017-11-01 10:37:36 --> Output Class Initialized
INFO - 2017-11-01 10:37:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:37:36 --> Input Class Initialized
INFO - 2017-11-01 10:37:36 --> Language Class Initialized
INFO - 2017-11-01 10:37:36 --> Loader Class Initialized
INFO - 2017-11-01 10:37:36 --> Helper loaded: url_helper
INFO - 2017-11-01 10:37:36 --> Helper loaded: common_helper
INFO - 2017-11-01 10:37:36 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:37:36 --> Email Class Initialized
INFO - 2017-11-01 10:37:36 --> Model Class Initialized
INFO - 2017-11-01 10:37:36 --> Controller Class Initialized
INFO - 2017-11-01 10:37:36 --> Final output sent to browser
DEBUG - 2017-11-01 10:37:36 --> Total execution time: 0.0017
INFO - 2017-11-01 10:37:44 --> Config Class Initialized
INFO - 2017-11-01 10:37:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:37:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:37:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:37:44 --> URI Class Initialized
INFO - 2017-11-01 10:37:44 --> Router Class Initialized
INFO - 2017-11-01 10:37:44 --> Output Class Initialized
INFO - 2017-11-01 10:37:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:37:44 --> Input Class Initialized
INFO - 2017-11-01 10:37:44 --> Language Class Initialized
INFO - 2017-11-01 10:37:44 --> Loader Class Initialized
INFO - 2017-11-01 10:37:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:37:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:37:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:37:44 --> Email Class Initialized
INFO - 2017-11-01 10:37:44 --> Model Class Initialized
INFO - 2017-11-01 10:37:44 --> Controller Class Initialized
INFO - 2017-11-01 10:37:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:37:44 --> Total execution time: 0.0041
INFO - 2017-11-01 10:42:53 --> Config Class Initialized
INFO - 2017-11-01 10:42:53 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:42:53 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:42:53 --> Utf8 Class Initialized
INFO - 2017-11-01 10:42:53 --> URI Class Initialized
INFO - 2017-11-01 10:42:53 --> Router Class Initialized
INFO - 2017-11-01 10:42:53 --> Output Class Initialized
INFO - 2017-11-01 10:42:53 --> Security Class Initialized
DEBUG - 2017-11-01 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:42:53 --> Input Class Initialized
INFO - 2017-11-01 10:42:53 --> Language Class Initialized
INFO - 2017-11-01 10:42:53 --> Loader Class Initialized
INFO - 2017-11-01 10:42:53 --> Helper loaded: url_helper
INFO - 2017-11-01 10:42:53 --> Helper loaded: common_helper
INFO - 2017-11-01 10:42:53 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:42:53 --> Email Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Controller Class Initialized
INFO - 2017-11-01 10:42:53 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:42:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:42:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:42:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:42:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:42:53 --> Final output sent to browser
DEBUG - 2017-11-01 10:42:53 --> Total execution time: 0.0242
INFO - 2017-11-01 10:42:53 --> Config Class Initialized
INFO - 2017-11-01 10:42:53 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:42:53 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:42:53 --> Utf8 Class Initialized
INFO - 2017-11-01 10:42:53 --> URI Class Initialized
INFO - 2017-11-01 10:42:53 --> Router Class Initialized
INFO - 2017-11-01 10:42:53 --> Output Class Initialized
INFO - 2017-11-01 10:42:53 --> Security Class Initialized
DEBUG - 2017-11-01 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:42:53 --> Input Class Initialized
INFO - 2017-11-01 10:42:53 --> Language Class Initialized
INFO - 2017-11-01 10:42:53 --> Loader Class Initialized
INFO - 2017-11-01 10:42:53 --> Helper loaded: url_helper
INFO - 2017-11-01 10:42:53 --> Helper loaded: common_helper
INFO - 2017-11-01 10:42:53 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:42:53 --> Email Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Controller Class Initialized
INFO - 2017-11-01 10:42:53 --> Model Class Initialized
INFO - 2017-11-01 10:42:53 --> Final output sent to browser
DEBUG - 2017-11-01 10:42:53 --> Total execution time: 0.0056
INFO - 2017-11-01 10:43:02 --> Config Class Initialized
INFO - 2017-11-01 10:43:02 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:02 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:02 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:02 --> URI Class Initialized
INFO - 2017-11-01 10:43:02 --> Router Class Initialized
INFO - 2017-11-01 10:43:02 --> Output Class Initialized
INFO - 2017-11-01 10:43:02 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:02 --> Input Class Initialized
INFO - 2017-11-01 10:43:02 --> Language Class Initialized
INFO - 2017-11-01 10:43:02 --> Loader Class Initialized
INFO - 2017-11-01 10:43:02 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:02 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:02 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:02 --> Email Class Initialized
INFO - 2017-11-01 10:43:02 --> Model Class Initialized
INFO - 2017-11-01 10:43:02 --> Controller Class Initialized
INFO - 2017-11-01 10:43:02 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:02 --> Total execution time: 0.0024
INFO - 2017-11-01 10:43:28 --> Config Class Initialized
INFO - 2017-11-01 10:43:28 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:28 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:28 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:28 --> URI Class Initialized
INFO - 2017-11-01 10:43:28 --> Router Class Initialized
INFO - 2017-11-01 10:43:28 --> Output Class Initialized
INFO - 2017-11-01 10:43:28 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:28 --> Input Class Initialized
INFO - 2017-11-01 10:43:28 --> Language Class Initialized
INFO - 2017-11-01 10:43:28 --> Loader Class Initialized
INFO - 2017-11-01 10:43:28 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:28 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:28 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:28 --> Email Class Initialized
INFO - 2017-11-01 10:43:28 --> Model Class Initialized
INFO - 2017-11-01 10:43:28 --> Controller Class Initialized
INFO - 2017-11-01 10:43:28 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:28 --> Total execution time: 0.0036
INFO - 2017-11-01 10:43:29 --> Config Class Initialized
INFO - 2017-11-01 10:43:29 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:29 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:29 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:29 --> URI Class Initialized
INFO - 2017-11-01 10:43:29 --> Router Class Initialized
INFO - 2017-11-01 10:43:29 --> Output Class Initialized
INFO - 2017-11-01 10:43:29 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:29 --> Input Class Initialized
INFO - 2017-11-01 10:43:29 --> Language Class Initialized
INFO - 2017-11-01 10:43:29 --> Loader Class Initialized
INFO - 2017-11-01 10:43:29 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:29 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:29 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:29 --> Email Class Initialized
INFO - 2017-11-01 10:43:29 --> Model Class Initialized
INFO - 2017-11-01 10:43:29 --> Controller Class Initialized
INFO - 2017-11-01 10:43:29 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:29 --> Total execution time: 0.0015
INFO - 2017-11-01 10:43:29 --> Config Class Initialized
INFO - 2017-11-01 10:43:29 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:29 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:29 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:29 --> URI Class Initialized
INFO - 2017-11-01 10:43:29 --> Router Class Initialized
INFO - 2017-11-01 10:43:29 --> Output Class Initialized
INFO - 2017-11-01 10:43:29 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:29 --> Input Class Initialized
INFO - 2017-11-01 10:43:29 --> Language Class Initialized
INFO - 2017-11-01 10:43:29 --> Loader Class Initialized
INFO - 2017-11-01 10:43:29 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:29 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:29 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:29 --> Email Class Initialized
INFO - 2017-11-01 10:43:29 --> Model Class Initialized
INFO - 2017-11-01 10:43:29 --> Controller Class Initialized
INFO - 2017-11-01 10:43:29 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:29 --> Total execution time: 0.0028
INFO - 2017-11-01 10:43:30 --> Config Class Initialized
INFO - 2017-11-01 10:43:30 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:30 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:30 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:30 --> URI Class Initialized
INFO - 2017-11-01 10:43:30 --> Router Class Initialized
INFO - 2017-11-01 10:43:30 --> Output Class Initialized
INFO - 2017-11-01 10:43:30 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:30 --> Input Class Initialized
INFO - 2017-11-01 10:43:30 --> Language Class Initialized
INFO - 2017-11-01 10:43:30 --> Loader Class Initialized
INFO - 2017-11-01 10:43:30 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:30 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:30 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:30 --> Email Class Initialized
INFO - 2017-11-01 10:43:30 --> Model Class Initialized
INFO - 2017-11-01 10:43:30 --> Controller Class Initialized
INFO - 2017-11-01 10:43:30 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:30 --> Total execution time: 0.0037
INFO - 2017-11-01 10:43:31 --> Config Class Initialized
INFO - 2017-11-01 10:43:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:31 --> URI Class Initialized
INFO - 2017-11-01 10:43:31 --> Router Class Initialized
INFO - 2017-11-01 10:43:31 --> Output Class Initialized
INFO - 2017-11-01 10:43:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:31 --> Input Class Initialized
INFO - 2017-11-01 10:43:31 --> Language Class Initialized
INFO - 2017-11-01 10:43:31 --> Loader Class Initialized
INFO - 2017-11-01 10:43:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:31 --> Email Class Initialized
INFO - 2017-11-01 10:43:31 --> Model Class Initialized
INFO - 2017-11-01 10:43:31 --> Controller Class Initialized
INFO - 2017-11-01 10:43:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:31 --> Total execution time: 0.0024
INFO - 2017-11-01 10:43:40 --> Config Class Initialized
INFO - 2017-11-01 10:43:40 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:40 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:40 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:40 --> URI Class Initialized
INFO - 2017-11-01 10:43:40 --> Router Class Initialized
INFO - 2017-11-01 10:43:40 --> Output Class Initialized
INFO - 2017-11-01 10:43:40 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:40 --> Input Class Initialized
INFO - 2017-11-01 10:43:40 --> Language Class Initialized
INFO - 2017-11-01 10:43:40 --> Loader Class Initialized
INFO - 2017-11-01 10:43:40 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:40 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:40 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:40 --> Email Class Initialized
INFO - 2017-11-01 10:43:40 --> Model Class Initialized
INFO - 2017-11-01 10:43:40 --> Controller Class Initialized
INFO - 2017-11-01 10:43:40 --> Model Class Initialized
INFO - 2017-11-01 10:43:40 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:40 --> Total execution time: 0.0964
INFO - 2017-11-01 10:43:45 --> Config Class Initialized
INFO - 2017-11-01 10:43:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:45 --> URI Class Initialized
INFO - 2017-11-01 10:43:45 --> Router Class Initialized
INFO - 2017-11-01 10:43:45 --> Output Class Initialized
INFO - 2017-11-01 10:43:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:45 --> Input Class Initialized
INFO - 2017-11-01 10:43:45 --> Language Class Initialized
INFO - 2017-11-01 10:43:45 --> Loader Class Initialized
INFO - 2017-11-01 10:43:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:45 --> Email Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Controller Class Initialized
INFO - 2017-11-01 10:43:45 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:43:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:43:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:43:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:43:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:43:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:45 --> Total execution time: 0.0222
INFO - 2017-11-01 10:43:45 --> Config Class Initialized
INFO - 2017-11-01 10:43:45 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:43:45 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:43:45 --> Utf8 Class Initialized
INFO - 2017-11-01 10:43:45 --> URI Class Initialized
INFO - 2017-11-01 10:43:45 --> Router Class Initialized
INFO - 2017-11-01 10:43:45 --> Output Class Initialized
INFO - 2017-11-01 10:43:45 --> Security Class Initialized
DEBUG - 2017-11-01 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:43:45 --> Input Class Initialized
INFO - 2017-11-01 10:43:45 --> Language Class Initialized
INFO - 2017-11-01 10:43:45 --> Loader Class Initialized
INFO - 2017-11-01 10:43:45 --> Helper loaded: url_helper
INFO - 2017-11-01 10:43:45 --> Helper loaded: common_helper
INFO - 2017-11-01 10:43:45 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:43:45 --> Email Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Controller Class Initialized
INFO - 2017-11-01 10:43:45 --> Model Class Initialized
INFO - 2017-11-01 10:43:45 --> Final output sent to browser
DEBUG - 2017-11-01 10:43:45 --> Total execution time: 0.0028
INFO - 2017-11-01 10:44:57 --> Config Class Initialized
INFO - 2017-11-01 10:44:57 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:44:57 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:44:57 --> Utf8 Class Initialized
INFO - 2017-11-01 10:44:57 --> URI Class Initialized
INFO - 2017-11-01 10:44:57 --> Router Class Initialized
INFO - 2017-11-01 10:44:57 --> Output Class Initialized
INFO - 2017-11-01 10:44:57 --> Security Class Initialized
DEBUG - 2017-11-01 10:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:44:57 --> Input Class Initialized
INFO - 2017-11-01 10:44:57 --> Language Class Initialized
INFO - 2017-11-01 10:44:57 --> Loader Class Initialized
INFO - 2017-11-01 10:44:57 --> Helper loaded: url_helper
INFO - 2017-11-01 10:44:57 --> Helper loaded: common_helper
INFO - 2017-11-01 10:44:57 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:44:57 --> Email Class Initialized
INFO - 2017-11-01 10:44:57 --> Model Class Initialized
INFO - 2017-11-01 10:44:57 --> Controller Class Initialized
INFO - 2017-11-01 10:44:57 --> Final output sent to browser
DEBUG - 2017-11-01 10:44:57 --> Total execution time: 0.0024
INFO - 2017-11-01 10:49:03 --> Config Class Initialized
INFO - 2017-11-01 10:49:03 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:49:03 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:49:03 --> Utf8 Class Initialized
INFO - 2017-11-01 10:49:03 --> URI Class Initialized
INFO - 2017-11-01 10:49:03 --> Router Class Initialized
INFO - 2017-11-01 10:49:03 --> Output Class Initialized
INFO - 2017-11-01 10:49:03 --> Security Class Initialized
DEBUG - 2017-11-01 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:49:03 --> Input Class Initialized
INFO - 2017-11-01 10:49:03 --> Language Class Initialized
INFO - 2017-11-01 10:49:03 --> Loader Class Initialized
INFO - 2017-11-01 10:49:03 --> Helper loaded: url_helper
INFO - 2017-11-01 10:49:03 --> Helper loaded: common_helper
INFO - 2017-11-01 10:49:03 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:49:03 --> Email Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Controller Class Initialized
INFO - 2017-11-01 10:49:03 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> Model Class Initialized
INFO - 2017-11-01 10:49:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:49:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:49:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:49:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:49:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:49:03 --> Final output sent to browser
DEBUG - 2017-11-01 10:49:03 --> Total execution time: 0.0253
INFO - 2017-11-01 10:49:31 --> Config Class Initialized
INFO - 2017-11-01 10:49:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:49:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:49:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:49:31 --> URI Class Initialized
INFO - 2017-11-01 10:49:31 --> Router Class Initialized
INFO - 2017-11-01 10:49:31 --> Output Class Initialized
INFO - 2017-11-01 10:49:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:49:31 --> Input Class Initialized
INFO - 2017-11-01 10:49:31 --> Language Class Initialized
INFO - 2017-11-01 10:49:31 --> Loader Class Initialized
INFO - 2017-11-01 10:49:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:49:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:49:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:49:31 --> Email Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Controller Class Initialized
INFO - 2017-11-01 10:49:31 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:49:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:49:31 --> Total execution time: 0.0237
INFO - 2017-11-01 10:49:31 --> Config Class Initialized
INFO - 2017-11-01 10:49:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:49:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:49:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:49:31 --> URI Class Initialized
INFO - 2017-11-01 10:49:31 --> Router Class Initialized
INFO - 2017-11-01 10:49:31 --> Output Class Initialized
INFO - 2017-11-01 10:49:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:49:31 --> Input Class Initialized
INFO - 2017-11-01 10:49:31 --> Language Class Initialized
INFO - 2017-11-01 10:49:31 --> Loader Class Initialized
INFO - 2017-11-01 10:49:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:49:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:49:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:49:31 --> Email Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Controller Class Initialized
INFO - 2017-11-01 10:49:31 --> Model Class Initialized
INFO - 2017-11-01 10:49:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:49:31 --> Total execution time: 0.0024
INFO - 2017-11-01 10:49:33 --> Config Class Initialized
INFO - 2017-11-01 10:49:33 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:49:33 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:49:33 --> Utf8 Class Initialized
INFO - 2017-11-01 10:49:33 --> URI Class Initialized
INFO - 2017-11-01 10:49:33 --> Router Class Initialized
INFO - 2017-11-01 10:49:33 --> Output Class Initialized
INFO - 2017-11-01 10:49:33 --> Security Class Initialized
DEBUG - 2017-11-01 10:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:49:33 --> Input Class Initialized
INFO - 2017-11-01 10:49:33 --> Language Class Initialized
INFO - 2017-11-01 10:49:33 --> Loader Class Initialized
INFO - 2017-11-01 10:49:33 --> Helper loaded: url_helper
INFO - 2017-11-01 10:49:33 --> Helper loaded: common_helper
INFO - 2017-11-01 10:49:33 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:49:33 --> Email Class Initialized
INFO - 2017-11-01 10:49:33 --> Model Class Initialized
INFO - 2017-11-01 10:49:33 --> Controller Class Initialized
INFO - 2017-11-01 10:49:33 --> Final output sent to browser
DEBUG - 2017-11-01 10:49:33 --> Total execution time: 0.0024
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0250
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0309
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0307
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0315
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0343
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0384
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0503
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0539
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Config Class Initialized
INFO - 2017-11-01 10:50:07 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:07 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:07 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:07 --> URI Class Initialized
INFO - 2017-11-01 10:50:07 --> Router Class Initialized
INFO - 2017-11-01 10:50:07 --> Output Class Initialized
INFO - 2017-11-01 10:50:07 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:07 --> Input Class Initialized
INFO - 2017-11-01 10:50:07 --> Language Class Initialized
INFO - 2017-11-01 10:50:07 --> Loader Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:07 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:07 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:07 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:07 --> Total execution time: 0.0565
INFO - 2017-11-01 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:07 --> Email Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Controller Class Initialized
INFO - 2017-11-01 10:50:07 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:07 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0424
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0508
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0436
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0406
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0379
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0292
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0340
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0247
INFO - 2017-11-01 10:50:08 --> Config Class Initialized
INFO - 2017-11-01 10:50:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:08 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:08 --> URI Class Initialized
INFO - 2017-11-01 10:50:08 --> Router Class Initialized
INFO - 2017-11-01 10:50:08 --> Output Class Initialized
INFO - 2017-11-01 10:50:08 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:08 --> Input Class Initialized
INFO - 2017-11-01 10:50:08 --> Language Class Initialized
INFO - 2017-11-01 10:50:08 --> Loader Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:08 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:08 --> Email Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Controller Class Initialized
INFO - 2017-11-01 10:50:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> Model Class Initialized
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:50:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:50:08 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:08 --> Total execution time: 0.0242
INFO - 2017-11-01 10:50:09 --> Config Class Initialized
INFO - 2017-11-01 10:50:09 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:09 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:09 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:09 --> URI Class Initialized
INFO - 2017-11-01 10:50:09 --> Router Class Initialized
INFO - 2017-11-01 10:50:09 --> Output Class Initialized
INFO - 2017-11-01 10:50:09 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:09 --> Input Class Initialized
INFO - 2017-11-01 10:50:09 --> Language Class Initialized
INFO - 2017-11-01 10:50:09 --> Loader Class Initialized
INFO - 2017-11-01 10:50:09 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:09 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:09 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:09 --> Email Class Initialized
INFO - 2017-11-01 10:50:09 --> Model Class Initialized
INFO - 2017-11-01 10:50:09 --> Controller Class Initialized
INFO - 2017-11-01 10:50:09 --> Model Class Initialized
INFO - 2017-11-01 10:50:09 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:09 --> Total execution time: 0.0031
INFO - 2017-11-01 10:50:10 --> Config Class Initialized
INFO - 2017-11-01 10:50:10 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:50:10 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:50:10 --> Utf8 Class Initialized
INFO - 2017-11-01 10:50:10 --> URI Class Initialized
INFO - 2017-11-01 10:50:10 --> Router Class Initialized
INFO - 2017-11-01 10:50:10 --> Output Class Initialized
INFO - 2017-11-01 10:50:10 --> Security Class Initialized
DEBUG - 2017-11-01 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:50:10 --> Input Class Initialized
INFO - 2017-11-01 10:50:10 --> Language Class Initialized
INFO - 2017-11-01 10:50:10 --> Loader Class Initialized
INFO - 2017-11-01 10:50:10 --> Helper loaded: url_helper
INFO - 2017-11-01 10:50:10 --> Helper loaded: common_helper
INFO - 2017-11-01 10:50:10 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:50:10 --> Email Class Initialized
INFO - 2017-11-01 10:50:10 --> Model Class Initialized
INFO - 2017-11-01 10:50:10 --> Controller Class Initialized
INFO - 2017-11-01 10:50:10 --> Final output sent to browser
DEBUG - 2017-11-01 10:50:10 --> Total execution time: 0.0024
INFO - 2017-11-01 10:51:18 --> Config Class Initialized
INFO - 2017-11-01 10:51:18 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:18 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:18 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:18 --> URI Class Initialized
INFO - 2017-11-01 10:51:18 --> Router Class Initialized
INFO - 2017-11-01 10:51:18 --> Output Class Initialized
INFO - 2017-11-01 10:51:18 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:18 --> Input Class Initialized
INFO - 2017-11-01 10:51:18 --> Language Class Initialized
INFO - 2017-11-01 10:51:18 --> Loader Class Initialized
INFO - 2017-11-01 10:51:18 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:18 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:18 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:18 --> Email Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Controller Class Initialized
INFO - 2017-11-01 10:51:18 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> Model Class Initialized
INFO - 2017-11-01 10:51:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:51:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:51:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:51:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:51:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:51:18 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:18 --> Total execution time: 0.0224
INFO - 2017-11-01 10:51:19 --> Config Class Initialized
INFO - 2017-11-01 10:51:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:19 --> URI Class Initialized
INFO - 2017-11-01 10:51:19 --> Router Class Initialized
INFO - 2017-11-01 10:51:19 --> Output Class Initialized
INFO - 2017-11-01 10:51:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:19 --> Input Class Initialized
INFO - 2017-11-01 10:51:19 --> Language Class Initialized
INFO - 2017-11-01 10:51:19 --> Loader Class Initialized
INFO - 2017-11-01 10:51:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:19 --> Email Class Initialized
INFO - 2017-11-01 10:51:19 --> Model Class Initialized
INFO - 2017-11-01 10:51:19 --> Controller Class Initialized
INFO - 2017-11-01 10:51:19 --> Model Class Initialized
INFO - 2017-11-01 10:51:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:19 --> Total execution time: 0.0018
INFO - 2017-11-01 10:51:20 --> Config Class Initialized
INFO - 2017-11-01 10:51:20 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:20 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:20 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:20 --> URI Class Initialized
INFO - 2017-11-01 10:51:20 --> Router Class Initialized
INFO - 2017-11-01 10:51:20 --> Output Class Initialized
INFO - 2017-11-01 10:51:20 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:20 --> Input Class Initialized
INFO - 2017-11-01 10:51:20 --> Language Class Initialized
INFO - 2017-11-01 10:51:20 --> Loader Class Initialized
INFO - 2017-11-01 10:51:20 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:20 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:20 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:20 --> Email Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Controller Class Initialized
INFO - 2017-11-01 10:51:20 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:51:20 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:20 --> Total execution time: 0.0230
INFO - 2017-11-01 10:51:20 --> Config Class Initialized
INFO - 2017-11-01 10:51:20 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:20 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:20 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:20 --> URI Class Initialized
INFO - 2017-11-01 10:51:20 --> Router Class Initialized
INFO - 2017-11-01 10:51:20 --> Output Class Initialized
INFO - 2017-11-01 10:51:20 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:20 --> Input Class Initialized
INFO - 2017-11-01 10:51:20 --> Language Class Initialized
INFO - 2017-11-01 10:51:20 --> Loader Class Initialized
INFO - 2017-11-01 10:51:20 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:20 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:20 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:20 --> Email Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Controller Class Initialized
INFO - 2017-11-01 10:51:20 --> Model Class Initialized
INFO - 2017-11-01 10:51:20 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:20 --> Total execution time: 0.0021
INFO - 2017-11-01 10:51:21 --> Config Class Initialized
INFO - 2017-11-01 10:51:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:21 --> URI Class Initialized
INFO - 2017-11-01 10:51:21 --> Router Class Initialized
INFO - 2017-11-01 10:51:21 --> Output Class Initialized
INFO - 2017-11-01 10:51:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:21 --> Input Class Initialized
INFO - 2017-11-01 10:51:21 --> Language Class Initialized
INFO - 2017-11-01 10:51:21 --> Loader Class Initialized
INFO - 2017-11-01 10:51:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:21 --> Email Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Controller Class Initialized
INFO - 2017-11-01 10:51:21 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:51:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:51:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:51:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:51:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:51:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:21 --> Total execution time: 0.0254
INFO - 2017-11-01 10:51:21 --> Config Class Initialized
INFO - 2017-11-01 10:51:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:21 --> URI Class Initialized
INFO - 2017-11-01 10:51:21 --> Router Class Initialized
INFO - 2017-11-01 10:51:21 --> Output Class Initialized
INFO - 2017-11-01 10:51:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:21 --> Input Class Initialized
INFO - 2017-11-01 10:51:21 --> Language Class Initialized
INFO - 2017-11-01 10:51:21 --> Loader Class Initialized
INFO - 2017-11-01 10:51:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:21 --> Email Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Controller Class Initialized
INFO - 2017-11-01 10:51:21 --> Model Class Initialized
INFO - 2017-11-01 10:51:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:21 --> Total execution time: 0.0028
INFO - 2017-11-01 10:51:22 --> Config Class Initialized
INFO - 2017-11-01 10:51:22 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:51:22 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:51:22 --> Utf8 Class Initialized
INFO - 2017-11-01 10:51:22 --> URI Class Initialized
INFO - 2017-11-01 10:51:22 --> Router Class Initialized
INFO - 2017-11-01 10:51:22 --> Output Class Initialized
INFO - 2017-11-01 10:51:22 --> Security Class Initialized
DEBUG - 2017-11-01 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:51:22 --> Input Class Initialized
INFO - 2017-11-01 10:51:22 --> Language Class Initialized
INFO - 2017-11-01 10:51:22 --> Loader Class Initialized
INFO - 2017-11-01 10:51:22 --> Helper loaded: url_helper
INFO - 2017-11-01 10:51:22 --> Helper loaded: common_helper
INFO - 2017-11-01 10:51:22 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:51:22 --> Email Class Initialized
INFO - 2017-11-01 10:51:22 --> Model Class Initialized
INFO - 2017-11-01 10:51:22 --> Controller Class Initialized
INFO - 2017-11-01 10:51:22 --> Final output sent to browser
DEBUG - 2017-11-01 10:51:22 --> Total execution time: 0.0022
INFO - 2017-11-01 10:52:04 --> Config Class Initialized
INFO - 2017-11-01 10:52:04 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:52:04 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:52:04 --> Utf8 Class Initialized
INFO - 2017-11-01 10:52:04 --> URI Class Initialized
INFO - 2017-11-01 10:52:04 --> Router Class Initialized
INFO - 2017-11-01 10:52:04 --> Output Class Initialized
INFO - 2017-11-01 10:52:04 --> Security Class Initialized
DEBUG - 2017-11-01 10:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:52:04 --> Input Class Initialized
INFO - 2017-11-01 10:52:04 --> Language Class Initialized
INFO - 2017-11-01 10:52:04 --> Loader Class Initialized
INFO - 2017-11-01 10:52:04 --> Helper loaded: url_helper
INFO - 2017-11-01 10:52:04 --> Helper loaded: common_helper
INFO - 2017-11-01 10:52:04 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:52:04 --> Email Class Initialized
INFO - 2017-11-01 10:52:04 --> Model Class Initialized
INFO - 2017-11-01 10:52:04 --> Controller Class Initialized
INFO - 2017-11-01 10:52:04 --> Final output sent to browser
DEBUG - 2017-11-01 10:52:04 --> Total execution time: 0.0022
INFO - 2017-11-01 10:53:12 --> Config Class Initialized
INFO - 2017-11-01 10:53:12 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:12 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:12 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:12 --> URI Class Initialized
INFO - 2017-11-01 10:53:12 --> Router Class Initialized
INFO - 2017-11-01 10:53:12 --> Output Class Initialized
INFO - 2017-11-01 10:53:12 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:12 --> Input Class Initialized
INFO - 2017-11-01 10:53:12 --> Language Class Initialized
INFO - 2017-11-01 10:53:12 --> Loader Class Initialized
INFO - 2017-11-01 10:53:12 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:12 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:12 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:12 --> Email Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Controller Class Initialized
INFO - 2017-11-01 10:53:12 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:53:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:53:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:53:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:53:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:53:12 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:12 --> Total execution time: 0.0265
INFO - 2017-11-01 10:53:12 --> Config Class Initialized
INFO - 2017-11-01 10:53:12 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:12 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:12 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:12 --> URI Class Initialized
INFO - 2017-11-01 10:53:12 --> Router Class Initialized
INFO - 2017-11-01 10:53:12 --> Output Class Initialized
INFO - 2017-11-01 10:53:12 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:12 --> Input Class Initialized
INFO - 2017-11-01 10:53:12 --> Language Class Initialized
INFO - 2017-11-01 10:53:12 --> Loader Class Initialized
INFO - 2017-11-01 10:53:12 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:12 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:12 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:12 --> Email Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Controller Class Initialized
INFO - 2017-11-01 10:53:12 --> Model Class Initialized
INFO - 2017-11-01 10:53:12 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:12 --> Total execution time: 0.0019
INFO - 2017-11-01 10:53:13 --> Config Class Initialized
INFO - 2017-11-01 10:53:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:13 --> URI Class Initialized
INFO - 2017-11-01 10:53:13 --> Router Class Initialized
INFO - 2017-11-01 10:53:13 --> Output Class Initialized
INFO - 2017-11-01 10:53:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:13 --> Input Class Initialized
INFO - 2017-11-01 10:53:13 --> Language Class Initialized
INFO - 2017-11-01 10:53:13 --> Loader Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:13 --> Email Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Controller Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:53:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:13 --> Total execution time: 0.0282
INFO - 2017-11-01 10:53:13 --> Config Class Initialized
INFO - 2017-11-01 10:53:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:13 --> URI Class Initialized
INFO - 2017-11-01 10:53:13 --> Router Class Initialized
INFO - 2017-11-01 10:53:13 --> Output Class Initialized
INFO - 2017-11-01 10:53:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:13 --> Input Class Initialized
INFO - 2017-11-01 10:53:13 --> Language Class Initialized
INFO - 2017-11-01 10:53:13 --> Loader Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:13 --> Email Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Controller Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:53:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:13 --> Total execution time: 0.0286
INFO - 2017-11-01 10:53:13 --> Config Class Initialized
INFO - 2017-11-01 10:53:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:13 --> URI Class Initialized
INFO - 2017-11-01 10:53:13 --> Router Class Initialized
INFO - 2017-11-01 10:53:13 --> Output Class Initialized
INFO - 2017-11-01 10:53:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:13 --> Input Class Initialized
INFO - 2017-11-01 10:53:13 --> Language Class Initialized
INFO - 2017-11-01 10:53:13 --> Loader Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:13 --> Email Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Controller Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:53:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:53:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:13 --> Total execution time: 0.0369
INFO - 2017-11-01 10:53:13 --> Config Class Initialized
INFO - 2017-11-01 10:53:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:13 --> URI Class Initialized
INFO - 2017-11-01 10:53:13 --> Router Class Initialized
INFO - 2017-11-01 10:53:13 --> Output Class Initialized
INFO - 2017-11-01 10:53:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:13 --> Input Class Initialized
INFO - 2017-11-01 10:53:13 --> Language Class Initialized
INFO - 2017-11-01 10:53:13 --> Loader Class Initialized
INFO - 2017-11-01 10:53:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:13 --> Email Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Controller Class Initialized
INFO - 2017-11-01 10:53:13 --> Model Class Initialized
INFO - 2017-11-01 10:53:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:13 --> Total execution time: 0.0028
INFO - 2017-11-01 10:53:14 --> Config Class Initialized
INFO - 2017-11-01 10:53:14 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:14 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:14 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:14 --> URI Class Initialized
INFO - 2017-11-01 10:53:14 --> Router Class Initialized
INFO - 2017-11-01 10:53:14 --> Output Class Initialized
INFO - 2017-11-01 10:53:14 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:14 --> Input Class Initialized
INFO - 2017-11-01 10:53:14 --> Language Class Initialized
INFO - 2017-11-01 10:53:14 --> Loader Class Initialized
INFO - 2017-11-01 10:53:14 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:14 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:14 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:14 --> Email Class Initialized
INFO - 2017-11-01 10:53:14 --> Model Class Initialized
INFO - 2017-11-01 10:53:14 --> Controller Class Initialized
INFO - 2017-11-01 10:53:14 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:14 --> Total execution time: 0.0017
INFO - 2017-11-01 10:53:29 --> Config Class Initialized
INFO - 2017-11-01 10:53:29 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:29 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:29 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:29 --> URI Class Initialized
INFO - 2017-11-01 10:53:29 --> Router Class Initialized
INFO - 2017-11-01 10:53:29 --> Output Class Initialized
INFO - 2017-11-01 10:53:29 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:29 --> Input Class Initialized
INFO - 2017-11-01 10:53:29 --> Language Class Initialized
INFO - 2017-11-01 10:53:29 --> Loader Class Initialized
INFO - 2017-11-01 10:53:29 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:29 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:29 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:29 --> Email Class Initialized
INFO - 2017-11-01 10:53:29 --> Model Class Initialized
INFO - 2017-11-01 10:53:29 --> Controller Class Initialized
INFO - 2017-11-01 10:53:29 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:29 --> Total execution time: 0.0016
INFO - 2017-11-01 10:53:30 --> Config Class Initialized
INFO - 2017-11-01 10:53:30 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:30 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:30 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:30 --> URI Class Initialized
INFO - 2017-11-01 10:53:30 --> Router Class Initialized
INFO - 2017-11-01 10:53:30 --> Output Class Initialized
INFO - 2017-11-01 10:53:30 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:30 --> Input Class Initialized
INFO - 2017-11-01 10:53:30 --> Language Class Initialized
INFO - 2017-11-01 10:53:30 --> Loader Class Initialized
INFO - 2017-11-01 10:53:30 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:30 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:30 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:30 --> Email Class Initialized
INFO - 2017-11-01 10:53:30 --> Model Class Initialized
INFO - 2017-11-01 10:53:30 --> Controller Class Initialized
INFO - 2017-11-01 10:53:30 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:30 --> Total execution time: 0.0021
INFO - 2017-11-01 10:53:31 --> Config Class Initialized
INFO - 2017-11-01 10:53:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:31 --> URI Class Initialized
INFO - 2017-11-01 10:53:31 --> Router Class Initialized
INFO - 2017-11-01 10:53:31 --> Output Class Initialized
INFO - 2017-11-01 10:53:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:31 --> Input Class Initialized
INFO - 2017-11-01 10:53:31 --> Language Class Initialized
INFO - 2017-11-01 10:53:31 --> Loader Class Initialized
INFO - 2017-11-01 10:53:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:31 --> Email Class Initialized
INFO - 2017-11-01 10:53:31 --> Model Class Initialized
INFO - 2017-11-01 10:53:31 --> Controller Class Initialized
INFO - 2017-11-01 10:53:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:31 --> Total execution time: 0.0019
INFO - 2017-11-01 10:53:31 --> Config Class Initialized
INFO - 2017-11-01 10:53:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:31 --> URI Class Initialized
INFO - 2017-11-01 10:53:31 --> Router Class Initialized
INFO - 2017-11-01 10:53:31 --> Output Class Initialized
INFO - 2017-11-01 10:53:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:31 --> Input Class Initialized
INFO - 2017-11-01 10:53:31 --> Language Class Initialized
INFO - 2017-11-01 10:53:31 --> Loader Class Initialized
INFO - 2017-11-01 10:53:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:31 --> Email Class Initialized
INFO - 2017-11-01 10:53:31 --> Model Class Initialized
INFO - 2017-11-01 10:53:31 --> Controller Class Initialized
INFO - 2017-11-01 10:53:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:31 --> Total execution time: 0.0020
INFO - 2017-11-01 10:53:31 --> Config Class Initialized
INFO - 2017-11-01 10:53:31 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:31 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:31 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:31 --> URI Class Initialized
INFO - 2017-11-01 10:53:31 --> Router Class Initialized
INFO - 2017-11-01 10:53:31 --> Output Class Initialized
INFO - 2017-11-01 10:53:31 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:31 --> Input Class Initialized
INFO - 2017-11-01 10:53:31 --> Language Class Initialized
INFO - 2017-11-01 10:53:31 --> Loader Class Initialized
INFO - 2017-11-01 10:53:31 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:31 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:31 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:31 --> Email Class Initialized
INFO - 2017-11-01 10:53:31 --> Model Class Initialized
INFO - 2017-11-01 10:53:31 --> Controller Class Initialized
INFO - 2017-11-01 10:53:31 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:31 --> Total execution time: 0.0020
INFO - 2017-11-01 10:53:32 --> Config Class Initialized
INFO - 2017-11-01 10:53:32 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:32 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:32 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:32 --> URI Class Initialized
INFO - 2017-11-01 10:53:32 --> Router Class Initialized
INFO - 2017-11-01 10:53:32 --> Output Class Initialized
INFO - 2017-11-01 10:53:32 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:32 --> Input Class Initialized
INFO - 2017-11-01 10:53:32 --> Language Class Initialized
INFO - 2017-11-01 10:53:32 --> Loader Class Initialized
INFO - 2017-11-01 10:53:32 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:32 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:32 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:32 --> Email Class Initialized
INFO - 2017-11-01 10:53:32 --> Model Class Initialized
INFO - 2017-11-01 10:53:32 --> Controller Class Initialized
INFO - 2017-11-01 10:53:32 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:32 --> Total execution time: 0.0022
INFO - 2017-11-01 10:53:47 --> Config Class Initialized
INFO - 2017-11-01 10:53:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:53:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:53:47 --> Utf8 Class Initialized
INFO - 2017-11-01 10:53:47 --> URI Class Initialized
INFO - 2017-11-01 10:53:47 --> Router Class Initialized
INFO - 2017-11-01 10:53:47 --> Output Class Initialized
INFO - 2017-11-01 10:53:47 --> Security Class Initialized
DEBUG - 2017-11-01 10:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:53:47 --> Input Class Initialized
INFO - 2017-11-01 10:53:47 --> Language Class Initialized
INFO - 2017-11-01 10:53:47 --> Loader Class Initialized
INFO - 2017-11-01 10:53:47 --> Helper loaded: url_helper
INFO - 2017-11-01 10:53:47 --> Helper loaded: common_helper
INFO - 2017-11-01 10:53:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:53:47 --> Email Class Initialized
INFO - 2017-11-01 10:53:47 --> Model Class Initialized
INFO - 2017-11-01 10:53:47 --> Controller Class Initialized
INFO - 2017-11-01 10:53:47 --> Final output sent to browser
DEBUG - 2017-11-01 10:53:47 --> Total execution time: 0.0024
INFO - 2017-11-01 10:54:14 --> Config Class Initialized
INFO - 2017-11-01 10:54:14 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:54:14 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:54:14 --> Utf8 Class Initialized
INFO - 2017-11-01 10:54:14 --> URI Class Initialized
INFO - 2017-11-01 10:54:14 --> Router Class Initialized
INFO - 2017-11-01 10:54:14 --> Output Class Initialized
INFO - 2017-11-01 10:54:14 --> Security Class Initialized
DEBUG - 2017-11-01 10:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:54:14 --> Input Class Initialized
INFO - 2017-11-01 10:54:14 --> Language Class Initialized
INFO - 2017-11-01 10:54:14 --> Loader Class Initialized
INFO - 2017-11-01 10:54:14 --> Helper loaded: url_helper
INFO - 2017-11-01 10:54:14 --> Helper loaded: common_helper
INFO - 2017-11-01 10:54:14 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:54:14 --> Email Class Initialized
INFO - 2017-11-01 10:54:14 --> Model Class Initialized
INFO - 2017-11-01 10:54:14 --> Controller Class Initialized
INFO - 2017-11-01 10:54:14 --> Model Class Initialized
INFO - 2017-11-01 10:54:14 --> Final output sent to browser
DEBUG - 2017-11-01 10:54:14 --> Total execution time: 0.0492
INFO - 2017-11-01 10:54:19 --> Config Class Initialized
INFO - 2017-11-01 10:54:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:54:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:54:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:54:19 --> URI Class Initialized
INFO - 2017-11-01 10:54:19 --> Router Class Initialized
INFO - 2017-11-01 10:54:19 --> Output Class Initialized
INFO - 2017-11-01 10:54:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:54:19 --> Input Class Initialized
INFO - 2017-11-01 10:54:19 --> Language Class Initialized
INFO - 2017-11-01 10:54:19 --> Loader Class Initialized
INFO - 2017-11-01 10:54:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:54:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:54:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:54:19 --> Email Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Controller Class Initialized
INFO - 2017-11-01 10:54:19 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:54:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:54:19 --> Total execution time: 0.0258
INFO - 2017-11-01 10:54:19 --> Config Class Initialized
INFO - 2017-11-01 10:54:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:54:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:54:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:54:19 --> URI Class Initialized
INFO - 2017-11-01 10:54:19 --> Router Class Initialized
INFO - 2017-11-01 10:54:19 --> Output Class Initialized
INFO - 2017-11-01 10:54:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:54:19 --> Input Class Initialized
INFO - 2017-11-01 10:54:19 --> Language Class Initialized
INFO - 2017-11-01 10:54:19 --> Loader Class Initialized
INFO - 2017-11-01 10:54:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:54:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:54:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:54:19 --> Email Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Controller Class Initialized
INFO - 2017-11-01 10:54:19 --> Model Class Initialized
INFO - 2017-11-01 10:54:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:54:19 --> Total execution time: 0.0028
INFO - 2017-11-01 10:57:01 --> Config Class Initialized
INFO - 2017-11-01 10:57:01 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:01 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:01 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:01 --> URI Class Initialized
INFO - 2017-11-01 10:57:01 --> Router Class Initialized
INFO - 2017-11-01 10:57:01 --> Output Class Initialized
INFO - 2017-11-01 10:57:01 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:01 --> Input Class Initialized
INFO - 2017-11-01 10:57:01 --> Language Class Initialized
INFO - 2017-11-01 10:57:01 --> Loader Class Initialized
INFO - 2017-11-01 10:57:01 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:01 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:01 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:01 --> Email Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Controller Class Initialized
INFO - 2017-11-01 10:57:01 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> Model Class Initialized
INFO - 2017-11-01 10:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:57:01 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:01 --> Total execution time: 0.0249
INFO - 2017-11-01 10:57:02 --> Config Class Initialized
INFO - 2017-11-01 10:57:02 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:02 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:02 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:02 --> URI Class Initialized
INFO - 2017-11-01 10:57:02 --> Router Class Initialized
INFO - 2017-11-01 10:57:02 --> Output Class Initialized
INFO - 2017-11-01 10:57:02 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:02 --> Input Class Initialized
INFO - 2017-11-01 10:57:02 --> Language Class Initialized
INFO - 2017-11-01 10:57:02 --> Loader Class Initialized
INFO - 2017-11-01 10:57:02 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:02 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:02 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:02 --> Email Class Initialized
INFO - 2017-11-01 10:57:02 --> Model Class Initialized
INFO - 2017-11-01 10:57:02 --> Controller Class Initialized
INFO - 2017-11-01 10:57:02 --> Model Class Initialized
INFO - 2017-11-01 10:57:02 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:02 --> Total execution time: 0.0021
INFO - 2017-11-01 10:57:03 --> Config Class Initialized
INFO - 2017-11-01 10:57:03 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:03 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:03 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:03 --> URI Class Initialized
INFO - 2017-11-01 10:57:03 --> Router Class Initialized
INFO - 2017-11-01 10:57:03 --> Output Class Initialized
INFO - 2017-11-01 10:57:03 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:03 --> Input Class Initialized
INFO - 2017-11-01 10:57:03 --> Language Class Initialized
INFO - 2017-11-01 10:57:03 --> Loader Class Initialized
INFO - 2017-11-01 10:57:03 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:03 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:03 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:03 --> Email Class Initialized
INFO - 2017-11-01 10:57:03 --> Model Class Initialized
INFO - 2017-11-01 10:57:03 --> Controller Class Initialized
INFO - 2017-11-01 10:57:03 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:03 --> Total execution time: 0.0025
INFO - 2017-11-01 10:57:17 --> Config Class Initialized
INFO - 2017-11-01 10:57:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:17 --> URI Class Initialized
INFO - 2017-11-01 10:57:17 --> Router Class Initialized
INFO - 2017-11-01 10:57:17 --> Output Class Initialized
INFO - 2017-11-01 10:57:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:17 --> Input Class Initialized
INFO - 2017-11-01 10:57:17 --> Language Class Initialized
INFO - 2017-11-01 10:57:17 --> Loader Class Initialized
INFO - 2017-11-01 10:57:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:17 --> Email Class Initialized
INFO - 2017-11-01 10:57:17 --> Model Class Initialized
INFO - 2017-11-01 10:57:17 --> Controller Class Initialized
INFO - 2017-11-01 10:57:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:17 --> Total execution time: 0.0028
INFO - 2017-11-01 10:57:19 --> Config Class Initialized
INFO - 2017-11-01 10:57:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:19 --> URI Class Initialized
INFO - 2017-11-01 10:57:19 --> Router Class Initialized
INFO - 2017-11-01 10:57:19 --> Output Class Initialized
INFO - 2017-11-01 10:57:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:19 --> Input Class Initialized
INFO - 2017-11-01 10:57:19 --> Language Class Initialized
INFO - 2017-11-01 10:57:19 --> Loader Class Initialized
INFO - 2017-11-01 10:57:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:19 --> Email Class Initialized
INFO - 2017-11-01 10:57:19 --> Model Class Initialized
INFO - 2017-11-01 10:57:19 --> Controller Class Initialized
INFO - 2017-11-01 10:57:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:19 --> Total execution time: 0.0016
INFO - 2017-11-01 10:57:19 --> Config Class Initialized
INFO - 2017-11-01 10:57:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:19 --> URI Class Initialized
INFO - 2017-11-01 10:57:19 --> Router Class Initialized
INFO - 2017-11-01 10:57:19 --> Output Class Initialized
INFO - 2017-11-01 10:57:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:19 --> Input Class Initialized
INFO - 2017-11-01 10:57:19 --> Language Class Initialized
INFO - 2017-11-01 10:57:19 --> Loader Class Initialized
INFO - 2017-11-01 10:57:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:19 --> Email Class Initialized
INFO - 2017-11-01 10:57:19 --> Model Class Initialized
INFO - 2017-11-01 10:57:19 --> Controller Class Initialized
INFO - 2017-11-01 10:57:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:19 --> Total execution time: 0.0016
INFO - 2017-11-01 10:57:19 --> Config Class Initialized
INFO - 2017-11-01 10:57:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:19 --> URI Class Initialized
INFO - 2017-11-01 10:57:19 --> Router Class Initialized
INFO - 2017-11-01 10:57:19 --> Output Class Initialized
INFO - 2017-11-01 10:57:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:19 --> Input Class Initialized
INFO - 2017-11-01 10:57:19 --> Language Class Initialized
INFO - 2017-11-01 10:57:19 --> Loader Class Initialized
INFO - 2017-11-01 10:57:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:19 --> Email Class Initialized
INFO - 2017-11-01 10:57:19 --> Model Class Initialized
INFO - 2017-11-01 10:57:19 --> Controller Class Initialized
INFO - 2017-11-01 10:57:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:19 --> Total execution time: 0.0016
INFO - 2017-11-01 10:57:19 --> Config Class Initialized
INFO - 2017-11-01 10:57:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:19 --> URI Class Initialized
INFO - 2017-11-01 10:57:19 --> Router Class Initialized
INFO - 2017-11-01 10:57:19 --> Output Class Initialized
INFO - 2017-11-01 10:57:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:19 --> Input Class Initialized
INFO - 2017-11-01 10:57:19 --> Language Class Initialized
INFO - 2017-11-01 10:57:19 --> Loader Class Initialized
INFO - 2017-11-01 10:57:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:19 --> Email Class Initialized
INFO - 2017-11-01 10:57:19 --> Model Class Initialized
INFO - 2017-11-01 10:57:19 --> Controller Class Initialized
INFO - 2017-11-01 10:57:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:19 --> Total execution time: 0.0025
INFO - 2017-11-01 10:57:19 --> Config Class Initialized
INFO - 2017-11-01 10:57:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:19 --> URI Class Initialized
INFO - 2017-11-01 10:57:19 --> Router Class Initialized
INFO - 2017-11-01 10:57:19 --> Output Class Initialized
INFO - 2017-11-01 10:57:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:19 --> Input Class Initialized
INFO - 2017-11-01 10:57:19 --> Language Class Initialized
INFO - 2017-11-01 10:57:19 --> Loader Class Initialized
INFO - 2017-11-01 10:57:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:19 --> Email Class Initialized
INFO - 2017-11-01 10:57:19 --> Model Class Initialized
INFO - 2017-11-01 10:57:19 --> Controller Class Initialized
INFO - 2017-11-01 10:57:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:19 --> Total execution time: 0.0020
INFO - 2017-11-01 10:57:21 --> Config Class Initialized
INFO - 2017-11-01 10:57:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:21 --> URI Class Initialized
INFO - 2017-11-01 10:57:21 --> Router Class Initialized
INFO - 2017-11-01 10:57:21 --> Output Class Initialized
INFO - 2017-11-01 10:57:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:21 --> Input Class Initialized
INFO - 2017-11-01 10:57:21 --> Language Class Initialized
INFO - 2017-11-01 10:57:21 --> Loader Class Initialized
INFO - 2017-11-01 10:57:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:21 --> Email Class Initialized
INFO - 2017-11-01 10:57:21 --> Model Class Initialized
INFO - 2017-11-01 10:57:21 --> Controller Class Initialized
INFO - 2017-11-01 10:57:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:21 --> Total execution time: 0.0022
INFO - 2017-11-01 10:57:21 --> Config Class Initialized
INFO - 2017-11-01 10:57:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:21 --> URI Class Initialized
INFO - 2017-11-01 10:57:21 --> Router Class Initialized
INFO - 2017-11-01 10:57:21 --> Output Class Initialized
INFO - 2017-11-01 10:57:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:21 --> Input Class Initialized
INFO - 2017-11-01 10:57:21 --> Language Class Initialized
INFO - 2017-11-01 10:57:21 --> Loader Class Initialized
INFO - 2017-11-01 10:57:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:21 --> Email Class Initialized
INFO - 2017-11-01 10:57:21 --> Model Class Initialized
INFO - 2017-11-01 10:57:21 --> Controller Class Initialized
INFO - 2017-11-01 10:57:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:21 --> Total execution time: 0.0015
INFO - 2017-11-01 10:57:21 --> Config Class Initialized
INFO - 2017-11-01 10:57:21 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:21 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:21 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:21 --> URI Class Initialized
INFO - 2017-11-01 10:57:21 --> Router Class Initialized
INFO - 2017-11-01 10:57:21 --> Output Class Initialized
INFO - 2017-11-01 10:57:21 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:21 --> Input Class Initialized
INFO - 2017-11-01 10:57:21 --> Language Class Initialized
INFO - 2017-11-01 10:57:21 --> Loader Class Initialized
INFO - 2017-11-01 10:57:21 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:21 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:21 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:21 --> Email Class Initialized
INFO - 2017-11-01 10:57:21 --> Model Class Initialized
INFO - 2017-11-01 10:57:21 --> Controller Class Initialized
INFO - 2017-11-01 10:57:21 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:21 --> Total execution time: 0.0015
INFO - 2017-11-01 10:57:50 --> Config Class Initialized
INFO - 2017-11-01 10:57:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:50 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:50 --> URI Class Initialized
INFO - 2017-11-01 10:57:50 --> Router Class Initialized
INFO - 2017-11-01 10:57:50 --> Output Class Initialized
INFO - 2017-11-01 10:57:50 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:50 --> Input Class Initialized
INFO - 2017-11-01 10:57:50 --> Language Class Initialized
INFO - 2017-11-01 10:57:50 --> Loader Class Initialized
INFO - 2017-11-01 10:57:50 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:50 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:50 --> Email Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Controller Class Initialized
INFO - 2017-11-01 10:57:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> Model Class Initialized
INFO - 2017-11-01 10:57:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:57:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:57:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:57:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:57:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:57:50 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:50 --> Total execution time: 0.0263
INFO - 2017-11-01 10:57:51 --> Config Class Initialized
INFO - 2017-11-01 10:57:51 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:51 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:51 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:51 --> URI Class Initialized
INFO - 2017-11-01 10:57:51 --> Router Class Initialized
INFO - 2017-11-01 10:57:51 --> Output Class Initialized
INFO - 2017-11-01 10:57:51 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:51 --> Input Class Initialized
INFO - 2017-11-01 10:57:51 --> Language Class Initialized
INFO - 2017-11-01 10:57:51 --> Loader Class Initialized
INFO - 2017-11-01 10:57:51 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:51 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:51 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:51 --> Email Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Controller Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:51 --> Total execution time: 0.0022
INFO - 2017-11-01 10:57:51 --> Config Class Initialized
INFO - 2017-11-01 10:57:51 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:51 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:51 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:51 --> URI Class Initialized
INFO - 2017-11-01 10:57:51 --> Router Class Initialized
INFO - 2017-11-01 10:57:51 --> Output Class Initialized
INFO - 2017-11-01 10:57:51 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:51 --> Input Class Initialized
INFO - 2017-11-01 10:57:51 --> Language Class Initialized
INFO - 2017-11-01 10:57:51 --> Loader Class Initialized
INFO - 2017-11-01 10:57:51 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:51 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:51 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:51 --> Email Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Controller Class Initialized
INFO - 2017-11-01 10:57:51 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:57:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:57:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:57:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:57:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:57:51 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:51 --> Total execution time: 0.0293
INFO - 2017-11-01 10:57:51 --> Config Class Initialized
INFO - 2017-11-01 10:57:51 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:51 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:51 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:51 --> URI Class Initialized
INFO - 2017-11-01 10:57:51 --> Router Class Initialized
INFO - 2017-11-01 10:57:51 --> Output Class Initialized
INFO - 2017-11-01 10:57:51 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:51 --> Input Class Initialized
INFO - 2017-11-01 10:57:51 --> Language Class Initialized
INFO - 2017-11-01 10:57:51 --> Loader Class Initialized
INFO - 2017-11-01 10:57:51 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:51 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:51 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:51 --> Email Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Controller Class Initialized
INFO - 2017-11-01 10:57:51 --> Model Class Initialized
INFO - 2017-11-01 10:57:51 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:51 --> Total execution time: 0.0018
INFO - 2017-11-01 10:57:52 --> Config Class Initialized
INFO - 2017-11-01 10:57:52 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:57:52 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:57:52 --> Utf8 Class Initialized
INFO - 2017-11-01 10:57:52 --> URI Class Initialized
INFO - 2017-11-01 10:57:52 --> Router Class Initialized
INFO - 2017-11-01 10:57:52 --> Output Class Initialized
INFO - 2017-11-01 10:57:52 --> Security Class Initialized
DEBUG - 2017-11-01 10:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:57:52 --> Input Class Initialized
INFO - 2017-11-01 10:57:52 --> Language Class Initialized
INFO - 2017-11-01 10:57:52 --> Loader Class Initialized
INFO - 2017-11-01 10:57:52 --> Helper loaded: url_helper
INFO - 2017-11-01 10:57:52 --> Helper loaded: common_helper
INFO - 2017-11-01 10:57:52 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:57:52 --> Email Class Initialized
INFO - 2017-11-01 10:57:52 --> Model Class Initialized
INFO - 2017-11-01 10:57:52 --> Controller Class Initialized
INFO - 2017-11-01 10:57:52 --> Final output sent to browser
DEBUG - 2017-11-01 10:57:52 --> Total execution time: 0.0016
INFO - 2017-11-01 10:58:12 --> Config Class Initialized
INFO - 2017-11-01 10:58:12 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:12 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:12 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:12 --> URI Class Initialized
INFO - 2017-11-01 10:58:12 --> Router Class Initialized
INFO - 2017-11-01 10:58:12 --> Output Class Initialized
INFO - 2017-11-01 10:58:12 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:12 --> Input Class Initialized
INFO - 2017-11-01 10:58:12 --> Language Class Initialized
INFO - 2017-11-01 10:58:12 --> Loader Class Initialized
INFO - 2017-11-01 10:58:12 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:12 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:12 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:12 --> Email Class Initialized
INFO - 2017-11-01 10:58:12 --> Model Class Initialized
INFO - 2017-11-01 10:58:12 --> Controller Class Initialized
INFO - 2017-11-01 10:58:12 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:12 --> Total execution time: 0.0027
INFO - 2017-11-01 10:58:13 --> Config Class Initialized
INFO - 2017-11-01 10:58:13 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:13 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:13 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:13 --> URI Class Initialized
INFO - 2017-11-01 10:58:13 --> Router Class Initialized
INFO - 2017-11-01 10:58:13 --> Output Class Initialized
INFO - 2017-11-01 10:58:13 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:13 --> Input Class Initialized
INFO - 2017-11-01 10:58:13 --> Language Class Initialized
INFO - 2017-11-01 10:58:13 --> Loader Class Initialized
INFO - 2017-11-01 10:58:13 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:13 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:13 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:13 --> Email Class Initialized
INFO - 2017-11-01 10:58:13 --> Model Class Initialized
INFO - 2017-11-01 10:58:13 --> Controller Class Initialized
INFO - 2017-11-01 10:58:13 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:13 --> Total execution time: 0.0016
INFO - 2017-11-01 10:58:19 --> Config Class Initialized
INFO - 2017-11-01 10:58:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:19 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:19 --> URI Class Initialized
INFO - 2017-11-01 10:58:19 --> Router Class Initialized
INFO - 2017-11-01 10:58:19 --> Output Class Initialized
INFO - 2017-11-01 10:58:19 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:19 --> Input Class Initialized
INFO - 2017-11-01 10:58:19 --> Language Class Initialized
INFO - 2017-11-01 10:58:19 --> Loader Class Initialized
INFO - 2017-11-01 10:58:19 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:19 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:19 --> Email Class Initialized
INFO - 2017-11-01 10:58:19 --> Model Class Initialized
INFO - 2017-11-01 10:58:19 --> Controller Class Initialized
INFO - 2017-11-01 10:58:19 --> Model Class Initialized
INFO - 2017-11-01 10:58:19 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:19 --> Total execution time: 0.0391
INFO - 2017-11-01 10:58:24 --> Config Class Initialized
INFO - 2017-11-01 10:58:24 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:24 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:24 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:24 --> URI Class Initialized
INFO - 2017-11-01 10:58:24 --> Router Class Initialized
INFO - 2017-11-01 10:58:24 --> Output Class Initialized
INFO - 2017-11-01 10:58:24 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:24 --> Input Class Initialized
INFO - 2017-11-01 10:58:24 --> Language Class Initialized
INFO - 2017-11-01 10:58:24 --> Loader Class Initialized
INFO - 2017-11-01 10:58:24 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:24 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:24 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:24 --> Email Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Controller Class Initialized
INFO - 2017-11-01 10:58:24 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> Model Class Initialized
INFO - 2017-11-01 10:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:58:24 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:24 --> Total execution time: 0.0293
INFO - 2017-11-01 10:58:25 --> Config Class Initialized
INFO - 2017-11-01 10:58:25 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:25 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:25 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:25 --> URI Class Initialized
INFO - 2017-11-01 10:58:25 --> Router Class Initialized
INFO - 2017-11-01 10:58:25 --> Output Class Initialized
INFO - 2017-11-01 10:58:25 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:25 --> Input Class Initialized
INFO - 2017-11-01 10:58:25 --> Language Class Initialized
INFO - 2017-11-01 10:58:25 --> Loader Class Initialized
INFO - 2017-11-01 10:58:25 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:25 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:25 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:25 --> Email Class Initialized
INFO - 2017-11-01 10:58:25 --> Model Class Initialized
INFO - 2017-11-01 10:58:25 --> Controller Class Initialized
INFO - 2017-11-01 10:58:25 --> Model Class Initialized
INFO - 2017-11-01 10:58:25 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:25 --> Total execution time: 0.0023
INFO - 2017-11-01 10:58:41 --> Config Class Initialized
INFO - 2017-11-01 10:58:41 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:58:41 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:58:41 --> Utf8 Class Initialized
INFO - 2017-11-01 10:58:41 --> URI Class Initialized
INFO - 2017-11-01 10:58:41 --> Router Class Initialized
INFO - 2017-11-01 10:58:41 --> Output Class Initialized
INFO - 2017-11-01 10:58:41 --> Security Class Initialized
DEBUG - 2017-11-01 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:58:41 --> Input Class Initialized
INFO - 2017-11-01 10:58:41 --> Language Class Initialized
INFO - 2017-11-01 10:58:41 --> Loader Class Initialized
INFO - 2017-11-01 10:58:41 --> Helper loaded: url_helper
INFO - 2017-11-01 10:58:41 --> Helper loaded: common_helper
INFO - 2017-11-01 10:58:41 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:58:41 --> Email Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Controller Class Initialized
INFO - 2017-11-01 10:58:41 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> Model Class Initialized
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:58:41 --> Final output sent to browser
DEBUG - 2017-11-01 10:58:41 --> Total execution time: 0.0541
INFO - 2017-11-01 10:59:05 --> Config Class Initialized
INFO - 2017-11-01 10:59:05 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:05 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:05 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:05 --> URI Class Initialized
INFO - 2017-11-01 10:59:05 --> Router Class Initialized
INFO - 2017-11-01 10:59:05 --> Output Class Initialized
INFO - 2017-11-01 10:59:05 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:05 --> Input Class Initialized
INFO - 2017-11-01 10:59:05 --> Language Class Initialized
INFO - 2017-11-01 10:59:05 --> Loader Class Initialized
INFO - 2017-11-01 10:59:05 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:05 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:05 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:05 --> Email Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Controller Class Initialized
INFO - 2017-11-01 10:59:05 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> Model Class Initialized
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:59:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:59:05 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:05 --> Total execution time: 0.0356
INFO - 2017-11-01 10:59:17 --> Config Class Initialized
INFO - 2017-11-01 10:59:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:17 --> URI Class Initialized
INFO - 2017-11-01 10:59:17 --> Router Class Initialized
INFO - 2017-11-01 10:59:17 --> Output Class Initialized
INFO - 2017-11-01 10:59:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:17 --> Input Class Initialized
INFO - 2017-11-01 10:59:17 --> Language Class Initialized
INFO - 2017-11-01 10:59:17 --> Loader Class Initialized
INFO - 2017-11-01 10:59:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:17 --> Email Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Controller Class Initialized
INFO - 2017-11-01 10:59:17 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:59:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-01 10:59:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-01 10:59:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-01 10:59:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:17 --> Total execution time: 0.0249
INFO - 2017-11-01 10:59:17 --> Config Class Initialized
INFO - 2017-11-01 10:59:17 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:17 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:17 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:17 --> URI Class Initialized
INFO - 2017-11-01 10:59:17 --> Router Class Initialized
INFO - 2017-11-01 10:59:17 --> Output Class Initialized
INFO - 2017-11-01 10:59:17 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:17 --> Input Class Initialized
INFO - 2017-11-01 10:59:17 --> Language Class Initialized
INFO - 2017-11-01 10:59:17 --> Loader Class Initialized
INFO - 2017-11-01 10:59:17 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:17 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:17 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:17 --> Email Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Controller Class Initialized
INFO - 2017-11-01 10:59:17 --> Model Class Initialized
INFO - 2017-11-01 10:59:17 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:17 --> Total execution time: 0.0027
INFO - 2017-11-01 10:59:22 --> Config Class Initialized
INFO - 2017-11-01 10:59:22 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:22 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:22 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:22 --> URI Class Initialized
INFO - 2017-11-01 10:59:22 --> Router Class Initialized
INFO - 2017-11-01 10:59:22 --> Output Class Initialized
INFO - 2017-11-01 10:59:22 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:22 --> Input Class Initialized
INFO - 2017-11-01 10:59:22 --> Language Class Initialized
INFO - 2017-11-01 10:59:22 --> Loader Class Initialized
INFO - 2017-11-01 10:59:22 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:22 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:22 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:22 --> Email Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Controller Class Initialized
INFO - 2017-11-01 10:59:22 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Config Class Initialized
INFO - 2017-11-01 10:59:22 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:22 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:22 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:22 --> URI Class Initialized
INFO - 2017-11-01 10:59:22 --> Router Class Initialized
INFO - 2017-11-01 10:59:22 --> Output Class Initialized
INFO - 2017-11-01 10:59:22 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:22 --> Input Class Initialized
INFO - 2017-11-01 10:59:22 --> Language Class Initialized
INFO - 2017-11-01 10:59:22 --> Loader Class Initialized
INFO - 2017-11-01 10:59:22 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:22 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:22 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:22 --> Email Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Controller Class Initialized
INFO - 2017-11-01 10:59:22 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> Model Class Initialized
INFO - 2017-11-01 10:59:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:59:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-01 10:59:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:59:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:59:22 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:22 --> Total execution time: 0.0213
INFO - 2017-11-01 10:59:35 --> Config Class Initialized
INFO - 2017-11-01 10:59:35 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:35 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:35 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:35 --> URI Class Initialized
INFO - 2017-11-01 10:59:35 --> Router Class Initialized
INFO - 2017-11-01 10:59:35 --> Output Class Initialized
INFO - 2017-11-01 10:59:35 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:35 --> Input Class Initialized
INFO - 2017-11-01 10:59:35 --> Language Class Initialized
INFO - 2017-11-01 10:59:35 --> Loader Class Initialized
INFO - 2017-11-01 10:59:35 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:35 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:35 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:35 --> Email Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Controller Class Initialized
INFO - 2017-11-01 10:59:35 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Config Class Initialized
INFO - 2017-11-01 10:59:35 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:35 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:35 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:35 --> URI Class Initialized
INFO - 2017-11-01 10:59:35 --> Router Class Initialized
INFO - 2017-11-01 10:59:35 --> Output Class Initialized
INFO - 2017-11-01 10:59:35 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:35 --> Input Class Initialized
INFO - 2017-11-01 10:59:35 --> Language Class Initialized
INFO - 2017-11-01 10:59:35 --> Loader Class Initialized
INFO - 2017-11-01 10:59:35 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:35 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:35 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:35 --> Email Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Controller Class Initialized
INFO - 2017-11-01 10:59:35 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> Model Class Initialized
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:59:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:59:35 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:35 --> Total execution time: 0.0442
INFO - 2017-11-01 10:59:36 --> Config Class Initialized
INFO - 2017-11-01 10:59:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:36 --> URI Class Initialized
INFO - 2017-11-01 10:59:36 --> Router Class Initialized
INFO - 2017-11-01 10:59:36 --> Output Class Initialized
INFO - 2017-11-01 10:59:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:36 --> Input Class Initialized
INFO - 2017-11-01 10:59:36 --> Language Class Initialized
ERROR - 2017-11-01 10:59:36 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-01 10:59:36 --> Config Class Initialized
INFO - 2017-11-01 10:59:36 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:36 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:36 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:36 --> URI Class Initialized
INFO - 2017-11-01 10:59:36 --> Router Class Initialized
INFO - 2017-11-01 10:59:36 --> Output Class Initialized
INFO - 2017-11-01 10:59:36 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:36 --> Input Class Initialized
INFO - 2017-11-01 10:59:36 --> Language Class Initialized
ERROR - 2017-11-01 10:59:36 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-01 10:59:44 --> Config Class Initialized
INFO - 2017-11-01 10:59:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:44 --> URI Class Initialized
INFO - 2017-11-01 10:59:44 --> Router Class Initialized
INFO - 2017-11-01 10:59:44 --> Output Class Initialized
INFO - 2017-11-01 10:59:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:44 --> Input Class Initialized
INFO - 2017-11-01 10:59:44 --> Language Class Initialized
INFO - 2017-11-01 10:59:44 --> Loader Class Initialized
INFO - 2017-11-01 10:59:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:44 --> Email Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Controller Class Initialized
INFO - 2017-11-01 10:59:44 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Config Class Initialized
INFO - 2017-11-01 10:59:44 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:44 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:44 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:44 --> URI Class Initialized
INFO - 2017-11-01 10:59:44 --> Router Class Initialized
INFO - 2017-11-01 10:59:44 --> Output Class Initialized
INFO - 2017-11-01 10:59:44 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:44 --> Input Class Initialized
INFO - 2017-11-01 10:59:44 --> Language Class Initialized
INFO - 2017-11-01 10:59:44 --> Loader Class Initialized
INFO - 2017-11-01 10:59:44 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:44 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:44 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:44 --> Email Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Controller Class Initialized
INFO - 2017-11-01 10:59:44 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> Model Class Initialized
INFO - 2017-11-01 10:59:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:59:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-01 10:59:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:59:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:59:44 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:44 --> Total execution time: 0.0168
INFO - 2017-11-01 10:59:50 --> Config Class Initialized
INFO - 2017-11-01 10:59:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:50 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:50 --> URI Class Initialized
INFO - 2017-11-01 10:59:50 --> Router Class Initialized
INFO - 2017-11-01 10:59:50 --> Output Class Initialized
INFO - 2017-11-01 10:59:50 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:50 --> Input Class Initialized
INFO - 2017-11-01 10:59:50 --> Language Class Initialized
INFO - 2017-11-01 10:59:50 --> Loader Class Initialized
INFO - 2017-11-01 10:59:50 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:50 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:50 --> Email Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Controller Class Initialized
INFO - 2017-11-01 10:59:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Config Class Initialized
INFO - 2017-11-01 10:59:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 10:59:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 10:59:50 --> Utf8 Class Initialized
INFO - 2017-11-01 10:59:50 --> URI Class Initialized
INFO - 2017-11-01 10:59:50 --> Router Class Initialized
INFO - 2017-11-01 10:59:50 --> Output Class Initialized
INFO - 2017-11-01 10:59:50 --> Security Class Initialized
DEBUG - 2017-11-01 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 10:59:50 --> Input Class Initialized
INFO - 2017-11-01 10:59:50 --> Language Class Initialized
INFO - 2017-11-01 10:59:50 --> Loader Class Initialized
INFO - 2017-11-01 10:59:50 --> Helper loaded: url_helper
INFO - 2017-11-01 10:59:50 --> Helper loaded: common_helper
INFO - 2017-11-01 10:59:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 10:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 10:59:50 --> Email Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Controller Class Initialized
INFO - 2017-11-01 10:59:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> Model Class Initialized
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 10:59:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 10:59:50 --> Final output sent to browser
DEBUG - 2017-11-01 10:59:50 --> Total execution time: 0.0275
INFO - 2017-11-01 12:09:04 --> Config Class Initialized
INFO - 2017-11-01 12:09:04 --> Hooks Class Initialized
DEBUG - 2017-11-01 12:09:04 --> UTF-8 Support Enabled
INFO - 2017-11-01 12:09:04 --> Utf8 Class Initialized
INFO - 2017-11-01 12:09:04 --> URI Class Initialized
INFO - 2017-11-01 12:09:04 --> Router Class Initialized
INFO - 2017-11-01 12:09:04 --> Output Class Initialized
INFO - 2017-11-01 12:09:04 --> Security Class Initialized
DEBUG - 2017-11-01 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 12:09:04 --> Input Class Initialized
INFO - 2017-11-01 12:09:04 --> Language Class Initialized
INFO - 2017-11-01 12:09:04 --> Loader Class Initialized
INFO - 2017-11-01 12:09:04 --> Helper loaded: url_helper
INFO - 2017-11-01 12:09:04 --> Helper loaded: common_helper
INFO - 2017-11-01 12:09:04 --> Database Driver Class Initialized
DEBUG - 2017-11-01 12:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 12:09:04 --> Email Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Controller Class Initialized
INFO - 2017-11-01 12:09:04 --> Helper loaded: cookie_helper
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Config Class Initialized
INFO - 2017-11-01 12:09:04 --> Hooks Class Initialized
DEBUG - 2017-11-01 12:09:04 --> UTF-8 Support Enabled
INFO - 2017-11-01 12:09:04 --> Utf8 Class Initialized
INFO - 2017-11-01 12:09:04 --> URI Class Initialized
INFO - 2017-11-01 12:09:04 --> Router Class Initialized
INFO - 2017-11-01 12:09:04 --> Output Class Initialized
INFO - 2017-11-01 12:09:04 --> Security Class Initialized
DEBUG - 2017-11-01 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 12:09:04 --> Input Class Initialized
INFO - 2017-11-01 12:09:04 --> Language Class Initialized
INFO - 2017-11-01 12:09:04 --> Loader Class Initialized
INFO - 2017-11-01 12:09:04 --> Helper loaded: url_helper
INFO - 2017-11-01 12:09:04 --> Helper loaded: common_helper
INFO - 2017-11-01 12:09:04 --> Database Driver Class Initialized
DEBUG - 2017-11-01 12:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 12:09:04 --> Email Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Controller Class Initialized
INFO - 2017-11-01 12:09:04 --> Helper loaded: cookie_helper
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> Model Class Initialized
INFO - 2017-11-01 12:09:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 12:09:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 12:09:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-01 12:09:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 12:09:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 12:09:04 --> Final output sent to browser
DEBUG - 2017-11-01 12:09:04 --> Total execution time: 0.0167
INFO - 2017-11-01 18:21:24 --> Config Class Initialized
INFO - 2017-11-01 18:21:24 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:24 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:24 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:24 --> URI Class Initialized
INFO - 2017-11-01 18:21:24 --> Router Class Initialized
INFO - 2017-11-01 18:21:24 --> Output Class Initialized
INFO - 2017-11-01 18:21:24 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:24 --> Input Class Initialized
INFO - 2017-11-01 18:21:24 --> Language Class Initialized
INFO - 2017-11-01 18:21:24 --> Loader Class Initialized
INFO - 2017-11-01 18:21:24 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:24 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:24 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:24 --> Email Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Controller Class Initialized
INFO - 2017-11-01 18:21:24 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Model Class Initialized
INFO - 2017-11-01 18:21:24 --> Config Class Initialized
INFO - 2017-11-01 18:21:24 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:24 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:24 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:24 --> URI Class Initialized
INFO - 2017-11-01 18:21:24 --> Router Class Initialized
INFO - 2017-11-01 18:21:24 --> Output Class Initialized
INFO - 2017-11-01 18:21:24 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:24 --> Input Class Initialized
INFO - 2017-11-01 18:21:24 --> Language Class Initialized
INFO - 2017-11-01 18:21:24 --> Loader Class Initialized
INFO - 2017-11-01 18:21:24 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:24 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:24 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:25 --> Email Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Controller Class Initialized
INFO - 2017-11-01 18:21:25 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> Model Class Initialized
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:21:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:21:25 --> Final output sent to browser
DEBUG - 2017-11-01 18:21:25 --> Total execution time: 1.2300
INFO - 2017-11-01 18:21:25 --> Final output sent to browser
DEBUG - 2017-11-01 18:21:25 --> Total execution time: 0.5752
INFO - 2017-11-01 18:21:38 --> Config Class Initialized
INFO - 2017-11-01 18:21:38 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:38 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:38 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:38 --> URI Class Initialized
INFO - 2017-11-01 18:21:38 --> Router Class Initialized
INFO - 2017-11-01 18:21:38 --> Output Class Initialized
INFO - 2017-11-01 18:21:38 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:38 --> Input Class Initialized
INFO - 2017-11-01 18:21:38 --> Language Class Initialized
INFO - 2017-11-01 18:21:38 --> Loader Class Initialized
INFO - 2017-11-01 18:21:38 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:38 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:38 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:38 --> Email Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Controller Class Initialized
INFO - 2017-11-01 18:21:38 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:38 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Config Class Initialized
INFO - 2017-11-01 18:21:39 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:39 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:39 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:39 --> URI Class Initialized
INFO - 2017-11-01 18:21:39 --> Router Class Initialized
INFO - 2017-11-01 18:21:39 --> Output Class Initialized
INFO - 2017-11-01 18:21:39 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:39 --> Input Class Initialized
INFO - 2017-11-01 18:21:39 --> Language Class Initialized
INFO - 2017-11-01 18:21:39 --> Loader Class Initialized
INFO - 2017-11-01 18:21:39 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:39 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:39 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:39 --> Email Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Controller Class Initialized
INFO - 2017-11-01 18:21:39 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> Model Class Initialized
INFO - 2017-11-01 18:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-01 18:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:21:39 --> Final output sent to browser
DEBUG - 2017-11-01 18:21:39 --> Total execution time: 0.2262
INFO - 2017-11-01 18:21:53 --> Config Class Initialized
INFO - 2017-11-01 18:21:53 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:53 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:53 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:53 --> URI Class Initialized
INFO - 2017-11-01 18:21:53 --> Router Class Initialized
INFO - 2017-11-01 18:21:53 --> Output Class Initialized
INFO - 2017-11-01 18:21:53 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:53 --> Input Class Initialized
INFO - 2017-11-01 18:21:53 --> Language Class Initialized
INFO - 2017-11-01 18:21:53 --> Loader Class Initialized
INFO - 2017-11-01 18:21:53 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:53 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:53 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:53 --> Email Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Controller Class Initialized
INFO - 2017-11-01 18:21:53 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Config Class Initialized
INFO - 2017-11-01 18:21:53 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:21:53 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:21:53 --> Utf8 Class Initialized
INFO - 2017-11-01 18:21:53 --> URI Class Initialized
INFO - 2017-11-01 18:21:53 --> Router Class Initialized
INFO - 2017-11-01 18:21:53 --> Output Class Initialized
INFO - 2017-11-01 18:21:53 --> Security Class Initialized
DEBUG - 2017-11-01 18:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:21:53 --> Input Class Initialized
INFO - 2017-11-01 18:21:53 --> Language Class Initialized
INFO - 2017-11-01 18:21:53 --> Loader Class Initialized
INFO - 2017-11-01 18:21:53 --> Helper loaded: url_helper
INFO - 2017-11-01 18:21:53 --> Helper loaded: common_helper
INFO - 2017-11-01 18:21:53 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:21:53 --> Email Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Controller Class Initialized
INFO - 2017-11-01 18:21:53 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:53 --> Model Class Initialized
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:21:54 --> Model Class Initialized
ERROR - 2017-11-01 18:21:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:21:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:21:54 --> Final output sent to browser
DEBUG - 2017-11-01 18:21:54 --> Total execution time: 0.4701
INFO - 2017-11-01 18:30:50 --> Config Class Initialized
INFO - 2017-11-01 18:30:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:30:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:30:50 --> Utf8 Class Initialized
INFO - 2017-11-01 18:30:50 --> URI Class Initialized
INFO - 2017-11-01 18:30:50 --> Router Class Initialized
INFO - 2017-11-01 18:30:50 --> Output Class Initialized
INFO - 2017-11-01 18:30:50 --> Security Class Initialized
DEBUG - 2017-11-01 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:30:50 --> Input Class Initialized
INFO - 2017-11-01 18:30:50 --> Language Class Initialized
INFO - 2017-11-01 18:30:50 --> Loader Class Initialized
INFO - 2017-11-01 18:30:50 --> Helper loaded: url_helper
INFO - 2017-11-01 18:30:50 --> Helper loaded: common_helper
INFO - 2017-11-01 18:30:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:30:50 --> Email Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Controller Class Initialized
INFO - 2017-11-01 18:30:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:30:50 --> Model Class Initialized
ERROR - 2017-11-01 18:30:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:30:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:30:50 --> Final output sent to browser
DEBUG - 2017-11-01 18:30:50 --> Total execution time: 0.0318
INFO - 2017-11-01 18:30:51 --> Config Class Initialized
INFO - 2017-11-01 18:30:51 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:30:51 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:30:51 --> Utf8 Class Initialized
INFO - 2017-11-01 18:30:51 --> URI Class Initialized
INFO - 2017-11-01 18:30:51 --> Router Class Initialized
INFO - 2017-11-01 18:30:51 --> Output Class Initialized
INFO - 2017-11-01 18:30:51 --> Security Class Initialized
DEBUG - 2017-11-01 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:30:51 --> Input Class Initialized
INFO - 2017-11-01 18:30:51 --> Language Class Initialized
INFO - 2017-11-01 18:30:51 --> Loader Class Initialized
INFO - 2017-11-01 18:30:51 --> Helper loaded: url_helper
INFO - 2017-11-01 18:30:51 --> Helper loaded: common_helper
INFO - 2017-11-01 18:30:51 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:30:51 --> Email Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Controller Class Initialized
INFO - 2017-11-01 18:30:51 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:30:51 --> Model Class Initialized
ERROR - 2017-11-01 18:30:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:30:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:30:51 --> Final output sent to browser
DEBUG - 2017-11-01 18:30:51 --> Total execution time: 0.0624
INFO - 2017-11-01 18:42:52 --> Config Class Initialized
INFO - 2017-11-01 18:42:52 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:42:52 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:42:52 --> Utf8 Class Initialized
INFO - 2017-11-01 18:42:52 --> URI Class Initialized
INFO - 2017-11-01 18:42:52 --> Router Class Initialized
INFO - 2017-11-01 18:42:52 --> Output Class Initialized
INFO - 2017-11-01 18:42:52 --> Security Class Initialized
DEBUG - 2017-11-01 18:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:42:52 --> Input Class Initialized
INFO - 2017-11-01 18:42:52 --> Language Class Initialized
INFO - 2017-11-01 18:42:52 --> Loader Class Initialized
INFO - 2017-11-01 18:42:52 --> Helper loaded: url_helper
INFO - 2017-11-01 18:42:52 --> Helper loaded: common_helper
INFO - 2017-11-01 18:42:52 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:42:52 --> Email Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Controller Class Initialized
INFO - 2017-11-01 18:42:52 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:42:52 --> Model Class Initialized
ERROR - 2017-11-01 18:42:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:42:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:42:52 --> Final output sent to browser
DEBUG - 2017-11-01 18:42:52 --> Total execution time: 0.1018
INFO - 2017-11-01 18:43:01 --> Config Class Initialized
INFO - 2017-11-01 18:43:01 --> Hooks Class Initialized
DEBUG - 2017-11-01 18:43:01 --> UTF-8 Support Enabled
INFO - 2017-11-01 18:43:01 --> Utf8 Class Initialized
INFO - 2017-11-01 18:43:01 --> URI Class Initialized
INFO - 2017-11-01 18:43:01 --> Router Class Initialized
INFO - 2017-11-01 18:43:01 --> Output Class Initialized
INFO - 2017-11-01 18:43:01 --> Security Class Initialized
DEBUG - 2017-11-01 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 18:43:01 --> Input Class Initialized
INFO - 2017-11-01 18:43:01 --> Language Class Initialized
INFO - 2017-11-01 18:43:01 --> Loader Class Initialized
INFO - 2017-11-01 18:43:01 --> Helper loaded: url_helper
INFO - 2017-11-01 18:43:01 --> Helper loaded: common_helper
INFO - 2017-11-01 18:43:01 --> Database Driver Class Initialized
DEBUG - 2017-11-01 18:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 18:43:01 --> Email Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Controller Class Initialized
INFO - 2017-11-01 18:43:01 --> Helper loaded: cookie_helper
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 18:43:01 --> Model Class Initialized
ERROR - 2017-11-01 18:43:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 18:43:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 18:43:01 --> Final output sent to browser
DEBUG - 2017-11-01 18:43:01 --> Total execution time: 0.0321
INFO - 2017-11-01 19:10:41 --> Config Class Initialized
INFO - 2017-11-01 19:10:41 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:10:41 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:10:41 --> Utf8 Class Initialized
INFO - 2017-11-01 19:10:41 --> URI Class Initialized
INFO - 2017-11-01 19:10:41 --> Router Class Initialized
INFO - 2017-11-01 19:10:41 --> Output Class Initialized
INFO - 2017-11-01 19:10:41 --> Security Class Initialized
DEBUG - 2017-11-01 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:10:41 --> Input Class Initialized
INFO - 2017-11-01 19:10:41 --> Language Class Initialized
INFO - 2017-11-01 19:10:41 --> Loader Class Initialized
INFO - 2017-11-01 19:10:41 --> Helper loaded: url_helper
INFO - 2017-11-01 19:10:41 --> Helper loaded: common_helper
INFO - 2017-11-01 19:10:41 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:10:41 --> Email Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Controller Class Initialized
INFO - 2017-11-01 19:10:41 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:10:41 --> Model Class Initialized
ERROR - 2017-11-01 19:10:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 87
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:10:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:10:41 --> Final output sent to browser
DEBUG - 2017-11-01 19:10:41 --> Total execution time: 0.0331
INFO - 2017-11-01 19:11:47 --> Config Class Initialized
INFO - 2017-11-01 19:11:47 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:11:47 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:11:47 --> Utf8 Class Initialized
INFO - 2017-11-01 19:11:47 --> URI Class Initialized
INFO - 2017-11-01 19:11:47 --> Router Class Initialized
INFO - 2017-11-01 19:11:47 --> Output Class Initialized
INFO - 2017-11-01 19:11:47 --> Security Class Initialized
DEBUG - 2017-11-01 19:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:11:47 --> Input Class Initialized
INFO - 2017-11-01 19:11:47 --> Language Class Initialized
INFO - 2017-11-01 19:11:47 --> Loader Class Initialized
INFO - 2017-11-01 19:11:47 --> Helper loaded: url_helper
INFO - 2017-11-01 19:11:47 --> Helper loaded: common_helper
INFO - 2017-11-01 19:11:47 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:11:47 --> Email Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Controller Class Initialized
INFO - 2017-11-01 19:11:47 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:11:47 --> Model Class Initialized
ERROR - 2017-11-01 19:11:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 89
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:11:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:11:47 --> Final output sent to browser
DEBUG - 2017-11-01 19:11:47 --> Total execution time: 0.0308
INFO - 2017-11-01 19:11:49 --> Config Class Initialized
INFO - 2017-11-01 19:11:49 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:11:49 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:11:49 --> Utf8 Class Initialized
INFO - 2017-11-01 19:11:49 --> URI Class Initialized
INFO - 2017-11-01 19:11:49 --> Router Class Initialized
INFO - 2017-11-01 19:11:49 --> Output Class Initialized
INFO - 2017-11-01 19:11:49 --> Security Class Initialized
DEBUG - 2017-11-01 19:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:11:49 --> Input Class Initialized
INFO - 2017-11-01 19:11:49 --> Language Class Initialized
INFO - 2017-11-01 19:11:49 --> Loader Class Initialized
INFO - 2017-11-01 19:11:49 --> Helper loaded: url_helper
INFO - 2017-11-01 19:11:49 --> Helper loaded: common_helper
INFO - 2017-11-01 19:11:49 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:11:49 --> Email Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Controller Class Initialized
INFO - 2017-11-01 19:11:49 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:49 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:11:50 --> Model Class Initialized
ERROR - 2017-11-01 19:11:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 89
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:11:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:11:50 --> Final output sent to browser
DEBUG - 2017-11-01 19:11:50 --> Total execution time: 0.0301
INFO - 2017-11-01 19:12:53 --> Config Class Initialized
INFO - 2017-11-01 19:12:53 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:12:53 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:12:53 --> Utf8 Class Initialized
INFO - 2017-11-01 19:12:53 --> URI Class Initialized
INFO - 2017-11-01 19:12:53 --> Router Class Initialized
INFO - 2017-11-01 19:12:53 --> Output Class Initialized
INFO - 2017-11-01 19:12:53 --> Security Class Initialized
DEBUG - 2017-11-01 19:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:12:53 --> Input Class Initialized
INFO - 2017-11-01 19:12:53 --> Language Class Initialized
INFO - 2017-11-01 19:12:53 --> Loader Class Initialized
INFO - 2017-11-01 19:12:53 --> Helper loaded: url_helper
INFO - 2017-11-01 19:12:53 --> Helper loaded: common_helper
INFO - 2017-11-01 19:12:53 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:12:53 --> Email Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Controller Class Initialized
INFO - 2017-11-01 19:12:53 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:12:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:12:53 --> Model Class Initialized
ERROR - 2017-11-01 19:12:53 --> Severity: error --> Exception: Call to undefined method User_library_event_escrow_model::get_escrow_form_data() /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 76
INFO - 2017-11-01 19:13:08 --> Config Class Initialized
INFO - 2017-11-01 19:13:08 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:13:08 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:13:08 --> Utf8 Class Initialized
INFO - 2017-11-01 19:13:08 --> URI Class Initialized
INFO - 2017-11-01 19:13:08 --> Router Class Initialized
INFO - 2017-11-01 19:13:08 --> Output Class Initialized
INFO - 2017-11-01 19:13:08 --> Security Class Initialized
DEBUG - 2017-11-01 19:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:13:08 --> Input Class Initialized
INFO - 2017-11-01 19:13:08 --> Language Class Initialized
INFO - 2017-11-01 19:13:08 --> Loader Class Initialized
INFO - 2017-11-01 19:13:08 --> Helper loaded: url_helper
INFO - 2017-11-01 19:13:08 --> Helper loaded: common_helper
INFO - 2017-11-01 19:13:08 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:13:08 --> Email Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Controller Class Initialized
INFO - 2017-11-01 19:13:08 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:13:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:13:08 --> Model Class Initialized
ERROR - 2017-11-01 19:13:08 --> Severity: error --> Exception: Call to undefined method User_library_event_escrow_model::get_escrow_form_data() /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 76
INFO - 2017-11-01 19:14:50 --> Config Class Initialized
INFO - 2017-11-01 19:14:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:14:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:14:50 --> Utf8 Class Initialized
INFO - 2017-11-01 19:14:50 --> URI Class Initialized
INFO - 2017-11-01 19:14:50 --> Router Class Initialized
INFO - 2017-11-01 19:14:50 --> Output Class Initialized
INFO - 2017-11-01 19:14:50 --> Security Class Initialized
DEBUG - 2017-11-01 19:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:14:50 --> Input Class Initialized
INFO - 2017-11-01 19:14:50 --> Language Class Initialized
INFO - 2017-11-01 19:14:50 --> Loader Class Initialized
INFO - 2017-11-01 19:14:50 --> Helper loaded: url_helper
INFO - 2017-11-01 19:14:50 --> Helper loaded: common_helper
INFO - 2017-11-01 19:14:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:14:50 --> Email Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Controller Class Initialized
INFO - 2017-11-01 19:14:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> Model Class Initialized
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:14:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
ERROR - 2017-11-01 19:14:50 --> Severity: Notice --> Undefined property: Profile::$uleem /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2017-11-01 19:14:50 --> Severity: error --> Exception: Call to a member function get_offer_status() on null /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 76
INFO - 2017-11-01 19:14:59 --> Config Class Initialized
INFO - 2017-11-01 19:14:59 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:14:59 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:14:59 --> Utf8 Class Initialized
INFO - 2017-11-01 19:14:59 --> URI Class Initialized
INFO - 2017-11-01 19:14:59 --> Router Class Initialized
INFO - 2017-11-01 19:14:59 --> Output Class Initialized
INFO - 2017-11-01 19:14:59 --> Security Class Initialized
DEBUG - 2017-11-01 19:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:14:59 --> Input Class Initialized
INFO - 2017-11-01 19:14:59 --> Language Class Initialized
INFO - 2017-11-01 19:14:59 --> Loader Class Initialized
INFO - 2017-11-01 19:14:59 --> Helper loaded: url_helper
INFO - 2017-11-01 19:14:59 --> Helper loaded: common_helper
INFO - 2017-11-01 19:14:59 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:14:59 --> Email Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Controller Class Initialized
INFO - 2017-11-01 19:14:59 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> Model Class Initialized
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
ERROR - 2017-11-01 19:14:59 --> Severity: Notice --> Undefined property: stdClass::$escrow_limit /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 89
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:14:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:14:59 --> Final output sent to browser
DEBUG - 2017-11-01 19:14:59 --> Total execution time: 0.0290
INFO - 2017-11-01 19:15:50 --> Config Class Initialized
INFO - 2017-11-01 19:15:50 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:15:50 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:15:50 --> Utf8 Class Initialized
INFO - 2017-11-01 19:15:50 --> URI Class Initialized
INFO - 2017-11-01 19:15:50 --> Router Class Initialized
INFO - 2017-11-01 19:15:50 --> Output Class Initialized
INFO - 2017-11-01 19:15:50 --> Security Class Initialized
DEBUG - 2017-11-01 19:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:15:50 --> Input Class Initialized
INFO - 2017-11-01 19:15:50 --> Language Class Initialized
INFO - 2017-11-01 19:15:50 --> Loader Class Initialized
INFO - 2017-11-01 19:15:50 --> Helper loaded: url_helper
INFO - 2017-11-01 19:15:50 --> Helper loaded: common_helper
INFO - 2017-11-01 19:15:50 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:15:50 --> Email Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Controller Class Initialized
INFO - 2017-11-01 19:15:50 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:15:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:15:50 --> Model Class Initialized
ERROR - 2017-11-01 19:15:50 --> Severity: error --> Exception: Call to undefined method Library_event_comment_model::get_offer_status() /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 76
INFO - 2017-11-01 19:16:06 --> Config Class Initialized
INFO - 2017-11-01 19:16:06 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:16:06 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:16:06 --> Utf8 Class Initialized
INFO - 2017-11-01 19:16:06 --> URI Class Initialized
INFO - 2017-11-01 19:16:06 --> Router Class Initialized
INFO - 2017-11-01 19:16:06 --> Output Class Initialized
INFO - 2017-11-01 19:16:06 --> Security Class Initialized
DEBUG - 2017-11-01 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:16:06 --> Input Class Initialized
INFO - 2017-11-01 19:16:06 --> Language Class Initialized
INFO - 2017-11-01 19:16:06 --> Loader Class Initialized
INFO - 2017-11-01 19:16:06 --> Helper loaded: url_helper
INFO - 2017-11-01 19:16:06 --> Helper loaded: common_helper
INFO - 2017-11-01 19:16:06 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:16:06 --> Email Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Controller Class Initialized
INFO - 2017-11-01 19:16:06 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:16:06 --> Model Class Initialized
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:16:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:16:06 --> Final output sent to browser
DEBUG - 2017-11-01 19:16:06 --> Total execution time: 0.0331
INFO - 2017-11-01 19:16:19 --> Config Class Initialized
INFO - 2017-11-01 19:16:19 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:16:19 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:16:19 --> Utf8 Class Initialized
INFO - 2017-11-01 19:16:19 --> URI Class Initialized
INFO - 2017-11-01 19:16:19 --> Router Class Initialized
INFO - 2017-11-01 19:16:19 --> Output Class Initialized
INFO - 2017-11-01 19:16:19 --> Security Class Initialized
DEBUG - 2017-11-01 19:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:16:19 --> Input Class Initialized
INFO - 2017-11-01 19:16:19 --> Language Class Initialized
INFO - 2017-11-01 19:16:19 --> Loader Class Initialized
INFO - 2017-11-01 19:16:19 --> Helper loaded: url_helper
INFO - 2017-11-01 19:16:19 --> Helper loaded: common_helper
INFO - 2017-11-01 19:16:19 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:16:19 --> Email Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Controller Class Initialized
INFO - 2017-11-01 19:16:19 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:19 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:16:20 --> Model Class Initialized
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:16:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:16:20 --> Final output sent to browser
DEBUG - 2017-11-01 19:16:20 --> Total execution time: 0.0326
INFO - 2017-11-01 19:17:01 --> Config Class Initialized
INFO - 2017-11-01 19:17:01 --> Hooks Class Initialized
DEBUG - 2017-11-01 19:17:01 --> UTF-8 Support Enabled
INFO - 2017-11-01 19:17:01 --> Utf8 Class Initialized
INFO - 2017-11-01 19:17:01 --> URI Class Initialized
INFO - 2017-11-01 19:17:01 --> Router Class Initialized
INFO - 2017-11-01 19:17:01 --> Output Class Initialized
INFO - 2017-11-01 19:17:01 --> Security Class Initialized
DEBUG - 2017-11-01 19:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-01 19:17:01 --> Input Class Initialized
INFO - 2017-11-01 19:17:01 --> Language Class Initialized
INFO - 2017-11-01 19:17:01 --> Loader Class Initialized
INFO - 2017-11-01 19:17:01 --> Helper loaded: url_helper
INFO - 2017-11-01 19:17:01 --> Helper loaded: common_helper
INFO - 2017-11-01 19:17:01 --> Database Driver Class Initialized
DEBUG - 2017-11-01 19:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-01 19:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-01 19:17:01 --> Email Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Controller Class Initialized
INFO - 2017-11-01 19:17:01 --> Helper loaded: cookie_helper
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-01 19:17:01 --> Model Class Initialized
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-01 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-01 19:17:01 --> Final output sent to browser
DEBUG - 2017-11-01 19:17:01 --> Total execution time: 0.0320
