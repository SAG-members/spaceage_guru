<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-10 18:38:31 --> Config Class Initialized
INFO - 2017-10-10 18:38:31 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:38:31 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:38:31 --> Utf8 Class Initialized
INFO - 2017-10-10 18:38:31 --> URI Class Initialized
DEBUG - 2017-10-10 18:38:31 --> No URI present. Default controller set.
INFO - 2017-10-10 18:38:31 --> Router Class Initialized
INFO - 2017-10-10 18:38:31 --> Output Class Initialized
INFO - 2017-10-10 18:38:31 --> Security Class Initialized
DEBUG - 2017-10-10 18:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:38:31 --> Input Class Initialized
INFO - 2017-10-10 18:38:31 --> Language Class Initialized
INFO - 2017-10-10 18:38:31 --> Loader Class Initialized
INFO - 2017-10-10 18:38:31 --> Helper loaded: url_helper
INFO - 2017-10-10 18:38:31 --> Helper loaded: common_helper
INFO - 2017-10-10 18:38:31 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:38:31 --> Email Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Controller Class Initialized
INFO - 2017-10-10 18:38:31 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> Model Class Initialized
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:38:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:38:31 --> Final output sent to browser
DEBUG - 2017-10-10 18:38:31 --> Total execution time: 0.0425
INFO - 2017-10-10 18:40:02 --> Config Class Initialized
INFO - 2017-10-10 18:40:02 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:40:02 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:40:02 --> Utf8 Class Initialized
INFO - 2017-10-10 18:40:02 --> URI Class Initialized
DEBUG - 2017-10-10 18:40:02 --> No URI present. Default controller set.
INFO - 2017-10-10 18:40:02 --> Router Class Initialized
INFO - 2017-10-10 18:40:02 --> Output Class Initialized
INFO - 2017-10-10 18:40:02 --> Security Class Initialized
DEBUG - 2017-10-10 18:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:40:02 --> Input Class Initialized
INFO - 2017-10-10 18:40:02 --> Language Class Initialized
INFO - 2017-10-10 18:40:02 --> Loader Class Initialized
INFO - 2017-10-10 18:40:02 --> Helper loaded: url_helper
INFO - 2017-10-10 18:40:02 --> Helper loaded: common_helper
INFO - 2017-10-10 18:40:02 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:40:02 --> Email Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Controller Class Initialized
INFO - 2017-10-10 18:40:02 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> Model Class Initialized
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:40:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:40:02 --> Final output sent to browser
DEBUG - 2017-10-10 18:40:02 --> Total execution time: 0.0244
INFO - 2017-10-10 18:49:48 --> Config Class Initialized
INFO - 2017-10-10 18:49:48 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:49:48 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:49:48 --> Utf8 Class Initialized
INFO - 2017-10-10 18:49:48 --> URI Class Initialized
DEBUG - 2017-10-10 18:49:48 --> No URI present. Default controller set.
INFO - 2017-10-10 18:49:48 --> Router Class Initialized
INFO - 2017-10-10 18:49:48 --> Output Class Initialized
INFO - 2017-10-10 18:49:48 --> Security Class Initialized
DEBUG - 2017-10-10 18:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:49:48 --> Input Class Initialized
INFO - 2017-10-10 18:49:48 --> Language Class Initialized
INFO - 2017-10-10 18:49:48 --> Loader Class Initialized
INFO - 2017-10-10 18:49:48 --> Helper loaded: url_helper
INFO - 2017-10-10 18:49:48 --> Helper loaded: common_helper
INFO - 2017-10-10 18:49:48 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:49:48 --> Email Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Controller Class Initialized
INFO - 2017-10-10 18:49:48 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> Model Class Initialized
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:49:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:49:48 --> Final output sent to browser
DEBUG - 2017-10-10 18:49:48 --> Total execution time: 0.0222
INFO - 2017-10-10 18:53:00 --> Config Class Initialized
INFO - 2017-10-10 18:53:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:53:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:53:00 --> Utf8 Class Initialized
INFO - 2017-10-10 18:53:00 --> URI Class Initialized
DEBUG - 2017-10-10 18:53:00 --> No URI present. Default controller set.
INFO - 2017-10-10 18:53:00 --> Router Class Initialized
INFO - 2017-10-10 18:53:00 --> Output Class Initialized
INFO - 2017-10-10 18:53:00 --> Security Class Initialized
DEBUG - 2017-10-10 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:53:00 --> Input Class Initialized
INFO - 2017-10-10 18:53:00 --> Language Class Initialized
INFO - 2017-10-10 18:53:00 --> Loader Class Initialized
INFO - 2017-10-10 18:53:00 --> Helper loaded: url_helper
INFO - 2017-10-10 18:53:00 --> Helper loaded: common_helper
INFO - 2017-10-10 18:53:00 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:53:00 --> Email Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Controller Class Initialized
INFO - 2017-10-10 18:53:00 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> Model Class Initialized
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:53:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:53:00 --> Final output sent to browser
DEBUG - 2017-10-10 18:53:00 --> Total execution time: 0.0214
INFO - 2017-10-10 18:53:40 --> Config Class Initialized
INFO - 2017-10-10 18:53:40 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:53:40 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:53:40 --> Utf8 Class Initialized
INFO - 2017-10-10 18:53:40 --> URI Class Initialized
DEBUG - 2017-10-10 18:53:40 --> No URI present. Default controller set.
INFO - 2017-10-10 18:53:40 --> Router Class Initialized
INFO - 2017-10-10 18:53:40 --> Output Class Initialized
INFO - 2017-10-10 18:53:40 --> Security Class Initialized
DEBUG - 2017-10-10 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:53:40 --> Input Class Initialized
INFO - 2017-10-10 18:53:40 --> Language Class Initialized
INFO - 2017-10-10 18:53:40 --> Loader Class Initialized
INFO - 2017-10-10 18:53:40 --> Helper loaded: url_helper
INFO - 2017-10-10 18:53:40 --> Helper loaded: common_helper
INFO - 2017-10-10 18:53:40 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:53:40 --> Email Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Controller Class Initialized
INFO - 2017-10-10 18:53:40 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> Model Class Initialized
INFO - 2017-10-10 18:53:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:53:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:53:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:53:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:53:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:53:40 --> Final output sent to browser
DEBUG - 2017-10-10 18:53:40 --> Total execution time: 0.0175
INFO - 2017-10-10 18:53:47 --> Config Class Initialized
INFO - 2017-10-10 18:53:47 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:53:47 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:53:47 --> Utf8 Class Initialized
INFO - 2017-10-10 18:53:47 --> URI Class Initialized
INFO - 2017-10-10 18:53:47 --> Router Class Initialized
INFO - 2017-10-10 18:53:47 --> Output Class Initialized
INFO - 2017-10-10 18:53:47 --> Security Class Initialized
DEBUG - 2017-10-10 18:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:53:47 --> Input Class Initialized
INFO - 2017-10-10 18:53:47 --> Language Class Initialized
INFO - 2017-10-10 18:53:47 --> Loader Class Initialized
INFO - 2017-10-10 18:53:47 --> Helper loaded: url_helper
INFO - 2017-10-10 18:53:47 --> Helper loaded: common_helper
INFO - 2017-10-10 18:53:47 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:53:47 --> Email Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Controller Class Initialized
INFO - 2017-10-10 18:53:47 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Config Class Initialized
INFO - 2017-10-10 18:53:47 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:53:47 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:53:47 --> Utf8 Class Initialized
INFO - 2017-10-10 18:53:47 --> URI Class Initialized
INFO - 2017-10-10 18:53:47 --> Router Class Initialized
INFO - 2017-10-10 18:53:47 --> Output Class Initialized
INFO - 2017-10-10 18:53:47 --> Security Class Initialized
DEBUG - 2017-10-10 18:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:53:47 --> Input Class Initialized
INFO - 2017-10-10 18:53:47 --> Language Class Initialized
INFO - 2017-10-10 18:53:47 --> Loader Class Initialized
INFO - 2017-10-10 18:53:47 --> Helper loaded: url_helper
INFO - 2017-10-10 18:53:47 --> Helper loaded: common_helper
INFO - 2017-10-10 18:53:47 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:53:47 --> Email Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Controller Class Initialized
INFO - 2017-10-10 18:53:47 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> Model Class Initialized
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:53:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:53:47 --> Final output sent to browser
DEBUG - 2017-10-10 18:53:47 --> Total execution time: 0.0719
INFO - 2017-10-10 18:56:24 --> Config Class Initialized
INFO - 2017-10-10 18:56:24 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:24 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:24 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:24 --> URI Class Initialized
DEBUG - 2017-10-10 18:56:24 --> No URI present. Default controller set.
INFO - 2017-10-10 18:56:24 --> Router Class Initialized
INFO - 2017-10-10 18:56:24 --> Output Class Initialized
INFO - 2017-10-10 18:56:24 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:24 --> Input Class Initialized
INFO - 2017-10-10 18:56:24 --> Language Class Initialized
INFO - 2017-10-10 18:56:24 --> Loader Class Initialized
INFO - 2017-10-10 18:56:24 --> Helper loaded: url_helper
INFO - 2017-10-10 18:56:24 --> Helper loaded: common_helper
INFO - 2017-10-10 18:56:24 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:56:24 --> Email Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Controller Class Initialized
INFO - 2017-10-10 18:56:24 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> Model Class Initialized
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:56:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:56:24 --> Final output sent to browser
DEBUG - 2017-10-10 18:56:24 --> Total execution time: 0.0260
INFO - 2017-10-10 18:56:35 --> Config Class Initialized
INFO - 2017-10-10 18:56:35 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:35 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:35 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:35 --> URI Class Initialized
INFO - 2017-10-10 18:56:35 --> Router Class Initialized
INFO - 2017-10-10 18:56:35 --> Output Class Initialized
INFO - 2017-10-10 18:56:35 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:35 --> Input Class Initialized
INFO - 2017-10-10 18:56:35 --> Language Class Initialized
INFO - 2017-10-10 18:56:35 --> Loader Class Initialized
INFO - 2017-10-10 18:56:35 --> Helper loaded: url_helper
INFO - 2017-10-10 18:56:35 --> Helper loaded: common_helper
INFO - 2017-10-10 18:56:35 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:56:35 --> Email Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Controller Class Initialized
INFO - 2017-10-10 18:56:35 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Config Class Initialized
INFO - 2017-10-10 18:56:35 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:35 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:35 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:35 --> URI Class Initialized
INFO - 2017-10-10 18:56:35 --> Router Class Initialized
INFO - 2017-10-10 18:56:35 --> Output Class Initialized
INFO - 2017-10-10 18:56:35 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:35 --> Input Class Initialized
INFO - 2017-10-10 18:56:35 --> Language Class Initialized
INFO - 2017-10-10 18:56:35 --> Loader Class Initialized
INFO - 2017-10-10 18:56:35 --> Helper loaded: url_helper
INFO - 2017-10-10 18:56:35 --> Helper loaded: common_helper
INFO - 2017-10-10 18:56:35 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:56:35 --> Email Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Controller Class Initialized
INFO - 2017-10-10 18:56:35 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> Model Class Initialized
INFO - 2017-10-10 18:56:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:56:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:56:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-10 18:56:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:56:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:56:35 --> Final output sent to browser
DEBUG - 2017-10-10 18:56:35 --> Total execution time: 0.0213
INFO - 2017-10-10 18:56:41 --> Config Class Initialized
INFO - 2017-10-10 18:56:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:41 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:41 --> URI Class Initialized
INFO - 2017-10-10 18:56:41 --> Router Class Initialized
INFO - 2017-10-10 18:56:41 --> Output Class Initialized
INFO - 2017-10-10 18:56:41 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:41 --> Input Class Initialized
INFO - 2017-10-10 18:56:41 --> Language Class Initialized
INFO - 2017-10-10 18:56:41 --> Loader Class Initialized
INFO - 2017-10-10 18:56:41 --> Helper loaded: url_helper
INFO - 2017-10-10 18:56:41 --> Helper loaded: common_helper
INFO - 2017-10-10 18:56:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:56:41 --> Email Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Controller Class Initialized
INFO - 2017-10-10 18:56:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Config Class Initialized
INFO - 2017-10-10 18:56:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:41 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:41 --> URI Class Initialized
INFO - 2017-10-10 18:56:41 --> Router Class Initialized
INFO - 2017-10-10 18:56:41 --> Output Class Initialized
INFO - 2017-10-10 18:56:41 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:41 --> Input Class Initialized
INFO - 2017-10-10 18:56:41 --> Language Class Initialized
INFO - 2017-10-10 18:56:41 --> Loader Class Initialized
INFO - 2017-10-10 18:56:41 --> Helper loaded: url_helper
INFO - 2017-10-10 18:56:41 --> Helper loaded: common_helper
INFO - 2017-10-10 18:56:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:56:41 --> Email Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Controller Class Initialized
INFO - 2017-10-10 18:56:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> Model Class Initialized
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:56:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:56:41 --> Final output sent to browser
DEBUG - 2017-10-10 18:56:41 --> Total execution time: 0.0295
INFO - 2017-10-10 18:56:41 --> Config Class Initialized
INFO - 2017-10-10 18:56:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:56:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:56:41 --> Utf8 Class Initialized
INFO - 2017-10-10 18:56:41 --> URI Class Initialized
INFO - 2017-10-10 18:56:41 --> Router Class Initialized
INFO - 2017-10-10 18:56:41 --> Output Class Initialized
INFO - 2017-10-10 18:56:41 --> Security Class Initialized
DEBUG - 2017-10-10 18:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:56:41 --> Input Class Initialized
INFO - 2017-10-10 18:56:41 --> Language Class Initialized
ERROR - 2017-10-10 18:56:41 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:57:01 --> Config Class Initialized
INFO - 2017-10-10 18:57:01 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:01 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:01 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:01 --> URI Class Initialized
INFO - 2017-10-10 18:57:01 --> Router Class Initialized
INFO - 2017-10-10 18:57:01 --> Output Class Initialized
INFO - 2017-10-10 18:57:01 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:01 --> Input Class Initialized
INFO - 2017-10-10 18:57:01 --> Language Class Initialized
INFO - 2017-10-10 18:57:01 --> Loader Class Initialized
INFO - 2017-10-10 18:57:01 --> Helper loaded: url_helper
INFO - 2017-10-10 18:57:01 --> Helper loaded: common_helper
INFO - 2017-10-10 18:57:01 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:57:01 --> Email Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Controller Class Initialized
INFO - 2017-10-10 18:57:01 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> Model Class Initialized
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:57:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:57:01 --> Final output sent to browser
DEBUG - 2017-10-10 18:57:01 --> Total execution time: 0.1367
INFO - 2017-10-10 18:57:02 --> Config Class Initialized
INFO - 2017-10-10 18:57:02 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:02 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:02 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:02 --> URI Class Initialized
INFO - 2017-10-10 18:57:02 --> Router Class Initialized
INFO - 2017-10-10 18:57:02 --> Output Class Initialized
INFO - 2017-10-10 18:57:02 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:02 --> Input Class Initialized
INFO - 2017-10-10 18:57:02 --> Language Class Initialized
ERROR - 2017-10-10 18:57:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:57:21 --> Config Class Initialized
INFO - 2017-10-10 18:57:21 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:21 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:21 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:21 --> URI Class Initialized
INFO - 2017-10-10 18:57:21 --> Router Class Initialized
INFO - 2017-10-10 18:57:21 --> Output Class Initialized
INFO - 2017-10-10 18:57:21 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:21 --> Input Class Initialized
INFO - 2017-10-10 18:57:21 --> Language Class Initialized
INFO - 2017-10-10 18:57:21 --> Loader Class Initialized
INFO - 2017-10-10 18:57:21 --> Helper loaded: url_helper
INFO - 2017-10-10 18:57:21 --> Helper loaded: common_helper
INFO - 2017-10-10 18:57:21 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:57:21 --> Email Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Controller Class Initialized
INFO - 2017-10-10 18:57:21 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> Model Class Initialized
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:57:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:57:21 --> Final output sent to browser
DEBUG - 2017-10-10 18:57:21 --> Total execution time: 0.0831
INFO - 2017-10-10 18:57:21 --> Config Class Initialized
INFO - 2017-10-10 18:57:21 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:21 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:21 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:21 --> URI Class Initialized
INFO - 2017-10-10 18:57:21 --> Router Class Initialized
INFO - 2017-10-10 18:57:21 --> Output Class Initialized
INFO - 2017-10-10 18:57:21 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:21 --> Input Class Initialized
INFO - 2017-10-10 18:57:21 --> Language Class Initialized
ERROR - 2017-10-10 18:57:21 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:57:42 --> Config Class Initialized
INFO - 2017-10-10 18:57:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:42 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:42 --> URI Class Initialized
INFO - 2017-10-10 18:57:42 --> Router Class Initialized
INFO - 2017-10-10 18:57:42 --> Output Class Initialized
INFO - 2017-10-10 18:57:42 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:42 --> Input Class Initialized
INFO - 2017-10-10 18:57:42 --> Language Class Initialized
INFO - 2017-10-10 18:57:42 --> Loader Class Initialized
INFO - 2017-10-10 18:57:42 --> Helper loaded: url_helper
INFO - 2017-10-10 18:57:42 --> Helper loaded: common_helper
INFO - 2017-10-10 18:57:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:57:42 --> Email Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Controller Class Initialized
INFO - 2017-10-10 18:57:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> Model Class Initialized
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:57:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:57:42 --> Final output sent to browser
DEBUG - 2017-10-10 18:57:42 --> Total execution time: 0.0364
INFO - 2017-10-10 18:57:42 --> Config Class Initialized
INFO - 2017-10-10 18:57:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:57:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:57:42 --> Utf8 Class Initialized
INFO - 2017-10-10 18:57:42 --> URI Class Initialized
INFO - 2017-10-10 18:57:42 --> Router Class Initialized
INFO - 2017-10-10 18:57:42 --> Output Class Initialized
INFO - 2017-10-10 18:57:42 --> Security Class Initialized
DEBUG - 2017-10-10 18:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:57:42 --> Input Class Initialized
INFO - 2017-10-10 18:57:42 --> Language Class Initialized
ERROR - 2017-10-10 18:57:42 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:59:09 --> Config Class Initialized
INFO - 2017-10-10 18:59:09 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:09 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:09 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:09 --> URI Class Initialized
INFO - 2017-10-10 18:59:09 --> Router Class Initialized
INFO - 2017-10-10 18:59:09 --> Output Class Initialized
INFO - 2017-10-10 18:59:09 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:09 --> Input Class Initialized
INFO - 2017-10-10 18:59:09 --> Language Class Initialized
INFO - 2017-10-10 18:59:09 --> Loader Class Initialized
INFO - 2017-10-10 18:59:09 --> Helper loaded: url_helper
INFO - 2017-10-10 18:59:09 --> Helper loaded: common_helper
INFO - 2017-10-10 18:59:09 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:59:09 --> Email Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Controller Class Initialized
INFO - 2017-10-10 18:59:09 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> Model Class Initialized
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:59:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:59:09 --> Final output sent to browser
DEBUG - 2017-10-10 18:59:09 --> Total execution time: 0.0323
INFO - 2017-10-10 18:59:09 --> Config Class Initialized
INFO - 2017-10-10 18:59:09 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:09 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:09 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:09 --> URI Class Initialized
INFO - 2017-10-10 18:59:09 --> Router Class Initialized
INFO - 2017-10-10 18:59:09 --> Output Class Initialized
INFO - 2017-10-10 18:59:09 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:09 --> Input Class Initialized
INFO - 2017-10-10 18:59:09 --> Language Class Initialized
ERROR - 2017-10-10 18:59:09 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:59:10 --> Config Class Initialized
INFO - 2017-10-10 18:59:10 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:10 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:10 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:10 --> URI Class Initialized
INFO - 2017-10-10 18:59:10 --> Router Class Initialized
INFO - 2017-10-10 18:59:10 --> Output Class Initialized
INFO - 2017-10-10 18:59:10 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:10 --> Input Class Initialized
INFO - 2017-10-10 18:59:10 --> Language Class Initialized
INFO - 2017-10-10 18:59:10 --> Loader Class Initialized
INFO - 2017-10-10 18:59:10 --> Helper loaded: url_helper
INFO - 2017-10-10 18:59:10 --> Helper loaded: common_helper
INFO - 2017-10-10 18:59:10 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:59:10 --> Email Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Controller Class Initialized
INFO - 2017-10-10 18:59:10 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> Model Class Initialized
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:59:10 --> Final output sent to browser
DEBUG - 2017-10-10 18:59:10 --> Total execution time: 0.0307
INFO - 2017-10-10 18:59:10 --> Config Class Initialized
INFO - 2017-10-10 18:59:10 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:10 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:10 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:10 --> URI Class Initialized
INFO - 2017-10-10 18:59:10 --> Router Class Initialized
INFO - 2017-10-10 18:59:10 --> Output Class Initialized
INFO - 2017-10-10 18:59:10 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:10 --> Input Class Initialized
INFO - 2017-10-10 18:59:10 --> Language Class Initialized
ERROR - 2017-10-10 18:59:10 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:59:11 --> Config Class Initialized
INFO - 2017-10-10 18:59:11 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:11 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:11 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:11 --> URI Class Initialized
INFO - 2017-10-10 18:59:11 --> Router Class Initialized
INFO - 2017-10-10 18:59:11 --> Output Class Initialized
INFO - 2017-10-10 18:59:11 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:11 --> Input Class Initialized
INFO - 2017-10-10 18:59:11 --> Language Class Initialized
INFO - 2017-10-10 18:59:11 --> Loader Class Initialized
INFO - 2017-10-10 18:59:11 --> Helper loaded: url_helper
INFO - 2017-10-10 18:59:11 --> Helper loaded: common_helper
INFO - 2017-10-10 18:59:11 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:59:11 --> Email Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Controller Class Initialized
INFO - 2017-10-10 18:59:11 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> Model Class Initialized
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:59:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:59:11 --> Final output sent to browser
DEBUG - 2017-10-10 18:59:11 --> Total execution time: 0.0306
INFO - 2017-10-10 18:59:11 --> Config Class Initialized
INFO - 2017-10-10 18:59:11 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:11 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:11 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:11 --> URI Class Initialized
INFO - 2017-10-10 18:59:11 --> Router Class Initialized
INFO - 2017-10-10 18:59:11 --> Output Class Initialized
INFO - 2017-10-10 18:59:11 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:11 --> Input Class Initialized
INFO - 2017-10-10 18:59:11 --> Language Class Initialized
ERROR - 2017-10-10 18:59:11 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 18:59:12 --> Config Class Initialized
INFO - 2017-10-10 18:59:12 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:12 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:12 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:12 --> URI Class Initialized
INFO - 2017-10-10 18:59:12 --> Router Class Initialized
INFO - 2017-10-10 18:59:12 --> Output Class Initialized
INFO - 2017-10-10 18:59:12 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:12 --> Input Class Initialized
INFO - 2017-10-10 18:59:12 --> Language Class Initialized
INFO - 2017-10-10 18:59:12 --> Loader Class Initialized
INFO - 2017-10-10 18:59:12 --> Helper loaded: url_helper
INFO - 2017-10-10 18:59:12 --> Helper loaded: common_helper
INFO - 2017-10-10 18:59:12 --> Database Driver Class Initialized
DEBUG - 2017-10-10 18:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 18:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 18:59:12 --> Email Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Controller Class Initialized
INFO - 2017-10-10 18:59:12 --> Helper loaded: cookie_helper
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> Model Class Initialized
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 18:59:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 18:59:12 --> Final output sent to browser
DEBUG - 2017-10-10 18:59:12 --> Total execution time: 0.0318
INFO - 2017-10-10 18:59:12 --> Config Class Initialized
INFO - 2017-10-10 18:59:12 --> Hooks Class Initialized
DEBUG - 2017-10-10 18:59:12 --> UTF-8 Support Enabled
INFO - 2017-10-10 18:59:12 --> Utf8 Class Initialized
INFO - 2017-10-10 18:59:12 --> URI Class Initialized
INFO - 2017-10-10 18:59:12 --> Router Class Initialized
INFO - 2017-10-10 18:59:12 --> Output Class Initialized
INFO - 2017-10-10 18:59:12 --> Security Class Initialized
DEBUG - 2017-10-10 18:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 18:59:12 --> Input Class Initialized
INFO - 2017-10-10 18:59:12 --> Language Class Initialized
ERROR - 2017-10-10 18:59:12 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:02:24 --> Config Class Initialized
INFO - 2017-10-10 19:02:24 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:02:24 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:02:24 --> Utf8 Class Initialized
INFO - 2017-10-10 19:02:24 --> URI Class Initialized
INFO - 2017-10-10 19:02:24 --> Router Class Initialized
INFO - 2017-10-10 19:02:24 --> Output Class Initialized
INFO - 2017-10-10 19:02:24 --> Security Class Initialized
DEBUG - 2017-10-10 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:02:24 --> Input Class Initialized
INFO - 2017-10-10 19:02:24 --> Language Class Initialized
INFO - 2017-10-10 19:02:24 --> Loader Class Initialized
INFO - 2017-10-10 19:02:24 --> Helper loaded: url_helper
INFO - 2017-10-10 19:02:24 --> Helper loaded: common_helper
INFO - 2017-10-10 19:02:24 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:02:24 --> Email Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Controller Class Initialized
INFO - 2017-10-10 19:02:24 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> Model Class Initialized
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:02:24 --> Final output sent to browser
DEBUG - 2017-10-10 19:02:24 --> Total execution time: 0.0336
INFO - 2017-10-10 19:02:24 --> Config Class Initialized
INFO - 2017-10-10 19:02:24 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:02:24 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:02:24 --> Utf8 Class Initialized
INFO - 2017-10-10 19:02:24 --> URI Class Initialized
INFO - 2017-10-10 19:02:24 --> Router Class Initialized
INFO - 2017-10-10 19:02:24 --> Output Class Initialized
INFO - 2017-10-10 19:02:24 --> Security Class Initialized
DEBUG - 2017-10-10 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:02:24 --> Input Class Initialized
INFO - 2017-10-10 19:02:24 --> Language Class Initialized
ERROR - 2017-10-10 19:02:24 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:04:58 --> Config Class Initialized
INFO - 2017-10-10 19:04:58 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:04:58 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:04:58 --> Utf8 Class Initialized
INFO - 2017-10-10 19:04:58 --> URI Class Initialized
INFO - 2017-10-10 19:04:58 --> Router Class Initialized
INFO - 2017-10-10 19:04:58 --> Output Class Initialized
INFO - 2017-10-10 19:04:58 --> Security Class Initialized
DEBUG - 2017-10-10 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:04:58 --> Input Class Initialized
INFO - 2017-10-10 19:04:58 --> Language Class Initialized
INFO - 2017-10-10 19:04:58 --> Loader Class Initialized
INFO - 2017-10-10 19:04:58 --> Helper loaded: url_helper
INFO - 2017-10-10 19:04:58 --> Helper loaded: common_helper
INFO - 2017-10-10 19:04:58 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:04:58 --> Email Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Controller Class Initialized
INFO - 2017-10-10 19:04:58 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> Model Class Initialized
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:04:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:04:58 --> Final output sent to browser
DEBUG - 2017-10-10 19:04:58 --> Total execution time: 0.0616
INFO - 2017-10-10 19:04:58 --> Config Class Initialized
INFO - 2017-10-10 19:04:58 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:04:58 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:04:58 --> Utf8 Class Initialized
INFO - 2017-10-10 19:04:58 --> URI Class Initialized
INFO - 2017-10-10 19:04:58 --> Router Class Initialized
INFO - 2017-10-10 19:04:58 --> Output Class Initialized
INFO - 2017-10-10 19:04:58 --> Security Class Initialized
DEBUG - 2017-10-10 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:04:58 --> Input Class Initialized
INFO - 2017-10-10 19:04:58 --> Language Class Initialized
ERROR - 2017-10-10 19:04:58 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:10:05 --> Config Class Initialized
INFO - 2017-10-10 19:10:05 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:10:05 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:10:05 --> Utf8 Class Initialized
INFO - 2017-10-10 19:10:05 --> URI Class Initialized
INFO - 2017-10-10 19:10:05 --> Router Class Initialized
INFO - 2017-10-10 19:10:05 --> Output Class Initialized
INFO - 2017-10-10 19:10:05 --> Security Class Initialized
DEBUG - 2017-10-10 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:10:05 --> Input Class Initialized
INFO - 2017-10-10 19:10:05 --> Language Class Initialized
INFO - 2017-10-10 19:10:05 --> Loader Class Initialized
INFO - 2017-10-10 19:10:05 --> Helper loaded: url_helper
INFO - 2017-10-10 19:10:05 --> Helper loaded: common_helper
INFO - 2017-10-10 19:10:05 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:10:05 --> Email Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Controller Class Initialized
INFO - 2017-10-10 19:10:05 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> Model Class Initialized
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:10:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:10:05 --> Final output sent to browser
DEBUG - 2017-10-10 19:10:05 --> Total execution time: 0.0499
INFO - 2017-10-10 19:10:05 --> Config Class Initialized
INFO - 2017-10-10 19:10:05 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:10:05 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:10:05 --> Utf8 Class Initialized
INFO - 2017-10-10 19:10:05 --> URI Class Initialized
INFO - 2017-10-10 19:10:05 --> Router Class Initialized
INFO - 2017-10-10 19:10:05 --> Output Class Initialized
INFO - 2017-10-10 19:10:05 --> Security Class Initialized
DEBUG - 2017-10-10 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:10:05 --> Input Class Initialized
INFO - 2017-10-10 19:10:05 --> Language Class Initialized
ERROR - 2017-10-10 19:10:05 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:12:11 --> Config Class Initialized
INFO - 2017-10-10 19:12:11 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:12:11 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:12:11 --> Utf8 Class Initialized
INFO - 2017-10-10 19:12:11 --> URI Class Initialized
INFO - 2017-10-10 19:12:11 --> Router Class Initialized
INFO - 2017-10-10 19:12:11 --> Output Class Initialized
INFO - 2017-10-10 19:12:11 --> Security Class Initialized
DEBUG - 2017-10-10 19:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:12:11 --> Input Class Initialized
INFO - 2017-10-10 19:12:11 --> Language Class Initialized
INFO - 2017-10-10 19:12:11 --> Loader Class Initialized
INFO - 2017-10-10 19:12:11 --> Helper loaded: url_helper
INFO - 2017-10-10 19:12:11 --> Helper loaded: common_helper
INFO - 2017-10-10 19:12:11 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:12:11 --> Email Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Controller Class Initialized
INFO - 2017-10-10 19:12:11 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> Model Class Initialized
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:12:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:12:11 --> Final output sent to browser
DEBUG - 2017-10-10 19:12:11 --> Total execution time: 0.0369
INFO - 2017-10-10 19:12:12 --> Config Class Initialized
INFO - 2017-10-10 19:12:12 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:12:12 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:12:12 --> Utf8 Class Initialized
INFO - 2017-10-10 19:12:12 --> URI Class Initialized
INFO - 2017-10-10 19:12:12 --> Router Class Initialized
INFO - 2017-10-10 19:12:12 --> Output Class Initialized
INFO - 2017-10-10 19:12:12 --> Security Class Initialized
DEBUG - 2017-10-10 19:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:12:12 --> Input Class Initialized
INFO - 2017-10-10 19:12:12 --> Language Class Initialized
ERROR - 2017-10-10 19:12:12 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:12:31 --> Config Class Initialized
INFO - 2017-10-10 19:12:31 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:12:31 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:12:31 --> Utf8 Class Initialized
INFO - 2017-10-10 19:12:31 --> URI Class Initialized
INFO - 2017-10-10 19:12:31 --> Router Class Initialized
INFO - 2017-10-10 19:12:31 --> Output Class Initialized
INFO - 2017-10-10 19:12:31 --> Security Class Initialized
DEBUG - 2017-10-10 19:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:12:31 --> Input Class Initialized
INFO - 2017-10-10 19:12:31 --> Language Class Initialized
INFO - 2017-10-10 19:12:31 --> Loader Class Initialized
INFO - 2017-10-10 19:12:31 --> Helper loaded: url_helper
INFO - 2017-10-10 19:12:31 --> Helper loaded: common_helper
INFO - 2017-10-10 19:12:31 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:12:31 --> Email Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Controller Class Initialized
INFO - 2017-10-10 19:12:31 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> Model Class Initialized
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:12:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:12:31 --> Final output sent to browser
DEBUG - 2017-10-10 19:12:31 --> Total execution time: 0.0337
INFO - 2017-10-10 19:12:31 --> Config Class Initialized
INFO - 2017-10-10 19:12:31 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:12:31 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:12:31 --> Utf8 Class Initialized
INFO - 2017-10-10 19:12:31 --> URI Class Initialized
INFO - 2017-10-10 19:12:31 --> Router Class Initialized
INFO - 2017-10-10 19:12:31 --> Output Class Initialized
INFO - 2017-10-10 19:12:31 --> Security Class Initialized
DEBUG - 2017-10-10 19:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:12:31 --> Input Class Initialized
INFO - 2017-10-10 19:12:31 --> Language Class Initialized
ERROR - 2017-10-10 19:12:31 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:16:03 --> Config Class Initialized
INFO - 2017-10-10 19:16:03 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:16:03 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:16:03 --> Utf8 Class Initialized
INFO - 2017-10-10 19:16:03 --> URI Class Initialized
INFO - 2017-10-10 19:16:03 --> Router Class Initialized
INFO - 2017-10-10 19:16:03 --> Output Class Initialized
INFO - 2017-10-10 19:16:03 --> Security Class Initialized
DEBUG - 2017-10-10 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:16:03 --> Input Class Initialized
INFO - 2017-10-10 19:16:03 --> Language Class Initialized
INFO - 2017-10-10 19:16:03 --> Loader Class Initialized
INFO - 2017-10-10 19:16:03 --> Helper loaded: url_helper
INFO - 2017-10-10 19:16:03 --> Helper loaded: common_helper
INFO - 2017-10-10 19:16:03 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:16:03 --> Email Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Controller Class Initialized
INFO - 2017-10-10 19:16:03 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> Model Class Initialized
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:16:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:16:03 --> Final output sent to browser
DEBUG - 2017-10-10 19:16:03 --> Total execution time: 0.0346
INFO - 2017-10-10 19:16:03 --> Config Class Initialized
INFO - 2017-10-10 19:16:03 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:16:03 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:16:03 --> Utf8 Class Initialized
INFO - 2017-10-10 19:16:03 --> URI Class Initialized
INFO - 2017-10-10 19:16:03 --> Router Class Initialized
INFO - 2017-10-10 19:16:03 --> Output Class Initialized
INFO - 2017-10-10 19:16:03 --> Security Class Initialized
DEBUG - 2017-10-10 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:16:03 --> Input Class Initialized
INFO - 2017-10-10 19:16:03 --> Language Class Initialized
ERROR - 2017-10-10 19:16:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:16:12 --> Config Class Initialized
INFO - 2017-10-10 19:16:12 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:16:12 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:16:12 --> Utf8 Class Initialized
INFO - 2017-10-10 19:16:12 --> URI Class Initialized
INFO - 2017-10-10 19:16:12 --> Router Class Initialized
INFO - 2017-10-10 19:16:12 --> Output Class Initialized
INFO - 2017-10-10 19:16:12 --> Security Class Initialized
DEBUG - 2017-10-10 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:16:12 --> Input Class Initialized
INFO - 2017-10-10 19:16:12 --> Language Class Initialized
INFO - 2017-10-10 19:16:12 --> Loader Class Initialized
INFO - 2017-10-10 19:16:12 --> Helper loaded: url_helper
INFO - 2017-10-10 19:16:12 --> Helper loaded: common_helper
INFO - 2017-10-10 19:16:12 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:16:12 --> Email Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Controller Class Initialized
INFO - 2017-10-10 19:16:12 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> Model Class Initialized
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:16:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:16:12 --> Final output sent to browser
DEBUG - 2017-10-10 19:16:12 --> Total execution time: 0.0303
INFO - 2017-10-10 19:16:13 --> Config Class Initialized
INFO - 2017-10-10 19:16:13 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:16:13 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:16:13 --> Utf8 Class Initialized
INFO - 2017-10-10 19:16:13 --> URI Class Initialized
INFO - 2017-10-10 19:16:13 --> Router Class Initialized
INFO - 2017-10-10 19:16:13 --> Output Class Initialized
INFO - 2017-10-10 19:16:13 --> Security Class Initialized
DEBUG - 2017-10-10 19:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:16:13 --> Input Class Initialized
INFO - 2017-10-10 19:16:13 --> Language Class Initialized
ERROR - 2017-10-10 19:16:13 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:17:00 --> Config Class Initialized
INFO - 2017-10-10 19:17:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:17:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:17:00 --> Utf8 Class Initialized
INFO - 2017-10-10 19:17:00 --> URI Class Initialized
INFO - 2017-10-10 19:17:00 --> Router Class Initialized
INFO - 2017-10-10 19:17:00 --> Output Class Initialized
INFO - 2017-10-10 19:17:00 --> Security Class Initialized
DEBUG - 2017-10-10 19:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:17:00 --> Input Class Initialized
INFO - 2017-10-10 19:17:00 --> Language Class Initialized
INFO - 2017-10-10 19:17:00 --> Loader Class Initialized
INFO - 2017-10-10 19:17:00 --> Helper loaded: url_helper
INFO - 2017-10-10 19:17:00 --> Helper loaded: common_helper
INFO - 2017-10-10 19:17:00 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:17:00 --> Email Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Controller Class Initialized
INFO - 2017-10-10 19:17:00 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:00 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> Model Class Initialized
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:17:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:17:01 --> Final output sent to browser
DEBUG - 2017-10-10 19:17:01 --> Total execution time: 0.0307
INFO - 2017-10-10 19:17:01 --> Config Class Initialized
INFO - 2017-10-10 19:17:01 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:17:01 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:17:01 --> Utf8 Class Initialized
INFO - 2017-10-10 19:17:01 --> URI Class Initialized
INFO - 2017-10-10 19:17:01 --> Router Class Initialized
INFO - 2017-10-10 19:17:01 --> Output Class Initialized
INFO - 2017-10-10 19:17:01 --> Security Class Initialized
DEBUG - 2017-10-10 19:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:17:01 --> Input Class Initialized
INFO - 2017-10-10 19:17:01 --> Language Class Initialized
ERROR - 2017-10-10 19:17:01 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:17:16 --> Config Class Initialized
INFO - 2017-10-10 19:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:17:16 --> Utf8 Class Initialized
INFO - 2017-10-10 19:17:16 --> URI Class Initialized
INFO - 2017-10-10 19:17:16 --> Router Class Initialized
INFO - 2017-10-10 19:17:16 --> Output Class Initialized
INFO - 2017-10-10 19:17:16 --> Security Class Initialized
DEBUG - 2017-10-10 19:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:17:16 --> Input Class Initialized
INFO - 2017-10-10 19:17:16 --> Language Class Initialized
INFO - 2017-10-10 19:17:16 --> Loader Class Initialized
INFO - 2017-10-10 19:17:16 --> Helper loaded: url_helper
INFO - 2017-10-10 19:17:16 --> Helper loaded: common_helper
INFO - 2017-10-10 19:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:17:16 --> Email Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Controller Class Initialized
INFO - 2017-10-10 19:17:16 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> Model Class Initialized
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:17:16 --> Final output sent to browser
DEBUG - 2017-10-10 19:17:16 --> Total execution time: 0.0336
INFO - 2017-10-10 19:20:51 --> Config Class Initialized
INFO - 2017-10-10 19:20:51 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:20:51 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:20:51 --> Utf8 Class Initialized
INFO - 2017-10-10 19:20:51 --> URI Class Initialized
INFO - 2017-10-10 19:20:51 --> Router Class Initialized
INFO - 2017-10-10 19:20:51 --> Output Class Initialized
INFO - 2017-10-10 19:20:51 --> Security Class Initialized
DEBUG - 2017-10-10 19:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:20:51 --> Input Class Initialized
INFO - 2017-10-10 19:20:51 --> Language Class Initialized
INFO - 2017-10-10 19:20:51 --> Loader Class Initialized
INFO - 2017-10-10 19:20:51 --> Helper loaded: url_helper
INFO - 2017-10-10 19:20:51 --> Helper loaded: common_helper
INFO - 2017-10-10 19:20:51 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:20:51 --> Email Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Controller Class Initialized
INFO - 2017-10-10 19:20:51 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> Model Class Initialized
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:20:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:20:51 --> Final output sent to browser
DEBUG - 2017-10-10 19:20:51 --> Total execution time: 0.0292
INFO - 2017-10-10 19:20:51 --> Config Class Initialized
INFO - 2017-10-10 19:20:51 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:20:51 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:20:51 --> Utf8 Class Initialized
INFO - 2017-10-10 19:20:51 --> URI Class Initialized
INFO - 2017-10-10 19:20:51 --> Router Class Initialized
INFO - 2017-10-10 19:20:51 --> Output Class Initialized
INFO - 2017-10-10 19:20:51 --> Security Class Initialized
DEBUG - 2017-10-10 19:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:20:51 --> Input Class Initialized
INFO - 2017-10-10 19:20:51 --> Language Class Initialized
ERROR - 2017-10-10 19:20:51 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:21:01 --> Config Class Initialized
INFO - 2017-10-10 19:21:01 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:21:01 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:21:01 --> Utf8 Class Initialized
INFO - 2017-10-10 19:21:01 --> URI Class Initialized
INFO - 2017-10-10 19:21:01 --> Router Class Initialized
INFO - 2017-10-10 19:21:01 --> Output Class Initialized
INFO - 2017-10-10 19:21:01 --> Security Class Initialized
DEBUG - 2017-10-10 19:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:21:01 --> Input Class Initialized
INFO - 2017-10-10 19:21:01 --> Language Class Initialized
INFO - 2017-10-10 19:21:01 --> Loader Class Initialized
INFO - 2017-10-10 19:21:01 --> Helper loaded: url_helper
INFO - 2017-10-10 19:21:01 --> Helper loaded: common_helper
INFO - 2017-10-10 19:21:01 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:21:01 --> Email Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Controller Class Initialized
INFO - 2017-10-10 19:21:01 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> Model Class Initialized
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:21:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:21:01 --> Final output sent to browser
DEBUG - 2017-10-10 19:21:01 --> Total execution time: 0.0298
INFO - 2017-10-10 19:21:01 --> Config Class Initialized
INFO - 2017-10-10 19:21:01 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:21:01 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:21:01 --> Utf8 Class Initialized
INFO - 2017-10-10 19:21:01 --> URI Class Initialized
INFO - 2017-10-10 19:21:01 --> Router Class Initialized
INFO - 2017-10-10 19:21:01 --> Output Class Initialized
INFO - 2017-10-10 19:21:01 --> Security Class Initialized
DEBUG - 2017-10-10 19:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:21:01 --> Input Class Initialized
INFO - 2017-10-10 19:21:01 --> Language Class Initialized
ERROR - 2017-10-10 19:21:01 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:21:06 --> Config Class Initialized
INFO - 2017-10-10 19:21:06 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:21:06 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:21:06 --> Utf8 Class Initialized
INFO - 2017-10-10 19:21:06 --> URI Class Initialized
INFO - 2017-10-10 19:21:06 --> Router Class Initialized
INFO - 2017-10-10 19:21:06 --> Output Class Initialized
INFO - 2017-10-10 19:21:06 --> Security Class Initialized
DEBUG - 2017-10-10 19:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:21:06 --> Input Class Initialized
INFO - 2017-10-10 19:21:06 --> Language Class Initialized
INFO - 2017-10-10 19:21:06 --> Loader Class Initialized
INFO - 2017-10-10 19:21:06 --> Helper loaded: url_helper
INFO - 2017-10-10 19:21:06 --> Helper loaded: common_helper
INFO - 2017-10-10 19:21:06 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:21:06 --> Email Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Controller Class Initialized
INFO - 2017-10-10 19:21:06 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> Model Class Initialized
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:21:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:21:06 --> Final output sent to browser
DEBUG - 2017-10-10 19:21:06 --> Total execution time: 0.0297
INFO - 2017-10-10 19:21:06 --> Config Class Initialized
INFO - 2017-10-10 19:21:06 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:21:06 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:21:06 --> Utf8 Class Initialized
INFO - 2017-10-10 19:21:06 --> URI Class Initialized
INFO - 2017-10-10 19:21:06 --> Router Class Initialized
INFO - 2017-10-10 19:21:06 --> Output Class Initialized
INFO - 2017-10-10 19:21:06 --> Security Class Initialized
DEBUG - 2017-10-10 19:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:21:06 --> Input Class Initialized
INFO - 2017-10-10 19:21:06 --> Language Class Initialized
ERROR - 2017-10-10 19:21:06 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-10 19:22:07 --> Config Class Initialized
INFO - 2017-10-10 19:22:07 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:22:07 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:22:07 --> Utf8 Class Initialized
INFO - 2017-10-10 19:22:14 --> Config Class Initialized
INFO - 2017-10-10 19:22:14 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:22:14 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:22:14 --> Utf8 Class Initialized
INFO - 2017-10-10 19:22:14 --> URI Class Initialized
DEBUG - 2017-10-10 19:22:14 --> No URI present. Default controller set.
INFO - 2017-10-10 19:22:14 --> Router Class Initialized
INFO - 2017-10-10 19:22:14 --> Output Class Initialized
INFO - 2017-10-10 19:22:14 --> Security Class Initialized
DEBUG - 2017-10-10 19:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:22:14 --> Input Class Initialized
INFO - 2017-10-10 19:22:14 --> Language Class Initialized
INFO - 2017-10-10 19:22:14 --> Loader Class Initialized
INFO - 2017-10-10 19:22:14 --> Helper loaded: url_helper
INFO - 2017-10-10 19:22:14 --> Helper loaded: common_helper
INFO - 2017-10-10 19:22:14 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:22:14 --> Email Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Controller Class Initialized
INFO - 2017-10-10 19:22:14 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> Model Class Initialized
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:22:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:22:14 --> Final output sent to browser
DEBUG - 2017-10-10 19:22:14 --> Total execution time: 0.0226
INFO - 2017-10-10 19:23:45 --> Config Class Initialized
INFO - 2017-10-10 19:23:45 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:23:45 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:23:45 --> Utf8 Class Initialized
INFO - 2017-10-10 19:23:45 --> URI Class Initialized
DEBUG - 2017-10-10 19:23:45 --> No URI present. Default controller set.
INFO - 2017-10-10 19:23:45 --> Router Class Initialized
INFO - 2017-10-10 19:23:45 --> Output Class Initialized
INFO - 2017-10-10 19:23:45 --> Security Class Initialized
DEBUG - 2017-10-10 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:23:45 --> Input Class Initialized
INFO - 2017-10-10 19:23:45 --> Language Class Initialized
INFO - 2017-10-10 19:23:45 --> Loader Class Initialized
INFO - 2017-10-10 19:23:45 --> Helper loaded: url_helper
INFO - 2017-10-10 19:23:45 --> Helper loaded: common_helper
INFO - 2017-10-10 19:23:45 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:23:45 --> Email Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Controller Class Initialized
INFO - 2017-10-10 19:23:45 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> Model Class Initialized
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:23:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:23:45 --> Final output sent to browser
DEBUG - 2017-10-10 19:23:45 --> Total execution time: 0.0606
INFO - 2017-10-10 19:38:45 --> Config Class Initialized
INFO - 2017-10-10 19:38:45 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:38:45 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:38:45 --> Utf8 Class Initialized
INFO - 2017-10-10 19:38:45 --> URI Class Initialized
DEBUG - 2017-10-10 19:38:45 --> No URI present. Default controller set.
INFO - 2017-10-10 19:38:45 --> Router Class Initialized
INFO - 2017-10-10 19:38:45 --> Output Class Initialized
INFO - 2017-10-10 19:38:45 --> Security Class Initialized
DEBUG - 2017-10-10 19:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:38:45 --> Input Class Initialized
INFO - 2017-10-10 19:38:45 --> Language Class Initialized
INFO - 2017-10-10 19:38:45 --> Loader Class Initialized
INFO - 2017-10-10 19:38:45 --> Helper loaded: url_helper
INFO - 2017-10-10 19:38:45 --> Helper loaded: common_helper
INFO - 2017-10-10 19:38:45 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:38:45 --> Email Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Controller Class Initialized
INFO - 2017-10-10 19:38:45 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> Model Class Initialized
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:38:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:38:45 --> Final output sent to browser
DEBUG - 2017-10-10 19:38:45 --> Total execution time: 0.0893
INFO - 2017-10-10 19:39:46 --> Config Class Initialized
INFO - 2017-10-10 19:39:46 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:39:46 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:39:46 --> Utf8 Class Initialized
INFO - 2017-10-10 19:39:46 --> URI Class Initialized
DEBUG - 2017-10-10 19:39:46 --> No URI present. Default controller set.
INFO - 2017-10-10 19:39:46 --> Router Class Initialized
INFO - 2017-10-10 19:39:46 --> Output Class Initialized
INFO - 2017-10-10 19:39:46 --> Security Class Initialized
DEBUG - 2017-10-10 19:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:39:46 --> Input Class Initialized
INFO - 2017-10-10 19:39:46 --> Language Class Initialized
INFO - 2017-10-10 19:39:46 --> Loader Class Initialized
INFO - 2017-10-10 19:39:46 --> Helper loaded: url_helper
INFO - 2017-10-10 19:39:46 --> Helper loaded: common_helper
INFO - 2017-10-10 19:39:46 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:39:46 --> Email Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Controller Class Initialized
INFO - 2017-10-10 19:39:46 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> Model Class Initialized
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:39:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:39:46 --> Final output sent to browser
DEBUG - 2017-10-10 19:39:46 --> Total execution time: 0.0223
INFO - 2017-10-10 19:41:55 --> Config Class Initialized
INFO - 2017-10-10 19:41:55 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:41:55 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:41:55 --> Utf8 Class Initialized
INFO - 2017-10-10 19:41:55 --> URI Class Initialized
DEBUG - 2017-10-10 19:41:55 --> No URI present. Default controller set.
INFO - 2017-10-10 19:41:55 --> Router Class Initialized
INFO - 2017-10-10 19:41:55 --> Output Class Initialized
INFO - 2017-10-10 19:41:55 --> Security Class Initialized
DEBUG - 2017-10-10 19:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:41:55 --> Input Class Initialized
INFO - 2017-10-10 19:41:55 --> Language Class Initialized
INFO - 2017-10-10 19:41:55 --> Loader Class Initialized
INFO - 2017-10-10 19:41:55 --> Helper loaded: url_helper
INFO - 2017-10-10 19:41:55 --> Helper loaded: common_helper
INFO - 2017-10-10 19:41:55 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:41:55 --> Email Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Controller Class Initialized
INFO - 2017-10-10 19:41:55 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> Model Class Initialized
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:41:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:41:55 --> Final output sent to browser
DEBUG - 2017-10-10 19:41:55 --> Total execution time: 0.0266
INFO - 2017-10-10 19:43:59 --> Config Class Initialized
INFO - 2017-10-10 19:43:59 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:43:59 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:43:59 --> Utf8 Class Initialized
INFO - 2017-10-10 19:43:59 --> URI Class Initialized
DEBUG - 2017-10-10 19:43:59 --> No URI present. Default controller set.
INFO - 2017-10-10 19:43:59 --> Router Class Initialized
INFO - 2017-10-10 19:43:59 --> Output Class Initialized
INFO - 2017-10-10 19:43:59 --> Security Class Initialized
DEBUG - 2017-10-10 19:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:43:59 --> Input Class Initialized
INFO - 2017-10-10 19:43:59 --> Language Class Initialized
INFO - 2017-10-10 19:43:59 --> Loader Class Initialized
INFO - 2017-10-10 19:43:59 --> Helper loaded: url_helper
INFO - 2017-10-10 19:43:59 --> Helper loaded: common_helper
INFO - 2017-10-10 19:43:59 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:43:59 --> Email Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Controller Class Initialized
INFO - 2017-10-10 19:43:59 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> Model Class Initialized
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:43:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:43:59 --> Final output sent to browser
DEBUG - 2017-10-10 19:43:59 --> Total execution time: 0.0229
INFO - 2017-10-10 19:44:23 --> Config Class Initialized
INFO - 2017-10-10 19:44:23 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:44:23 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:44:23 --> Utf8 Class Initialized
INFO - 2017-10-10 19:44:23 --> URI Class Initialized
INFO - 2017-10-10 19:44:23 --> Router Class Initialized
INFO - 2017-10-10 19:44:23 --> Output Class Initialized
INFO - 2017-10-10 19:44:23 --> Security Class Initialized
DEBUG - 2017-10-10 19:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:44:23 --> Input Class Initialized
INFO - 2017-10-10 19:44:23 --> Language Class Initialized
INFO - 2017-10-10 19:44:23 --> Loader Class Initialized
INFO - 2017-10-10 19:44:23 --> Helper loaded: url_helper
INFO - 2017-10-10 19:44:23 --> Helper loaded: common_helper
INFO - 2017-10-10 19:44:23 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:44:23 --> Email Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Controller Class Initialized
INFO - 2017-10-10 19:44:23 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Config Class Initialized
INFO - 2017-10-10 19:44:23 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:44:23 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:44:23 --> Utf8 Class Initialized
INFO - 2017-10-10 19:44:23 --> URI Class Initialized
INFO - 2017-10-10 19:44:23 --> Router Class Initialized
INFO - 2017-10-10 19:44:23 --> Output Class Initialized
INFO - 2017-10-10 19:44:23 --> Security Class Initialized
DEBUG - 2017-10-10 19:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:44:23 --> Input Class Initialized
INFO - 2017-10-10 19:44:23 --> Language Class Initialized
INFO - 2017-10-10 19:44:23 --> Loader Class Initialized
INFO - 2017-10-10 19:44:23 --> Helper loaded: url_helper
INFO - 2017-10-10 19:44:23 --> Helper loaded: common_helper
INFO - 2017-10-10 19:44:23 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:44:23 --> Email Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Controller Class Initialized
INFO - 2017-10-10 19:44:23 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> Model Class Initialized
INFO - 2017-10-10 19:44:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:44:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:44:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-10 19:44:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:44:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:44:23 --> Final output sent to browser
DEBUG - 2017-10-10 19:44:23 --> Total execution time: 0.0182
INFO - 2017-10-10 19:44:28 --> Config Class Initialized
INFO - 2017-10-10 19:44:28 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:44:28 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:44:28 --> Utf8 Class Initialized
INFO - 2017-10-10 19:44:28 --> URI Class Initialized
INFO - 2017-10-10 19:44:28 --> Router Class Initialized
INFO - 2017-10-10 19:44:28 --> Output Class Initialized
INFO - 2017-10-10 19:44:28 --> Security Class Initialized
DEBUG - 2017-10-10 19:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:44:28 --> Input Class Initialized
INFO - 2017-10-10 19:44:28 --> Language Class Initialized
INFO - 2017-10-10 19:44:28 --> Loader Class Initialized
INFO - 2017-10-10 19:44:28 --> Helper loaded: url_helper
INFO - 2017-10-10 19:44:28 --> Helper loaded: common_helper
INFO - 2017-10-10 19:44:28 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:44:28 --> Email Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Controller Class Initialized
INFO - 2017-10-10 19:44:28 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Config Class Initialized
INFO - 2017-10-10 19:44:28 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:44:28 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:44:28 --> Utf8 Class Initialized
INFO - 2017-10-10 19:44:28 --> URI Class Initialized
INFO - 2017-10-10 19:44:28 --> Router Class Initialized
INFO - 2017-10-10 19:44:28 --> Output Class Initialized
INFO - 2017-10-10 19:44:28 --> Security Class Initialized
DEBUG - 2017-10-10 19:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:44:28 --> Input Class Initialized
INFO - 2017-10-10 19:44:28 --> Language Class Initialized
INFO - 2017-10-10 19:44:28 --> Loader Class Initialized
INFO - 2017-10-10 19:44:28 --> Helper loaded: url_helper
INFO - 2017-10-10 19:44:28 --> Helper loaded: common_helper
INFO - 2017-10-10 19:44:28 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:44:28 --> Email Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Controller Class Initialized
INFO - 2017-10-10 19:44:28 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> Model Class Initialized
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:44:28 --> Final output sent to browser
DEBUG - 2017-10-10 19:44:28 --> Total execution time: 0.0277
INFO - 2017-10-10 19:44:38 --> Config Class Initialized
INFO - 2017-10-10 19:44:38 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:44:38 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:44:38 --> Utf8 Class Initialized
INFO - 2017-10-10 19:44:38 --> URI Class Initialized
DEBUG - 2017-10-10 19:44:38 --> No URI present. Default controller set.
INFO - 2017-10-10 19:44:38 --> Router Class Initialized
INFO - 2017-10-10 19:44:38 --> Output Class Initialized
INFO - 2017-10-10 19:44:38 --> Security Class Initialized
DEBUG - 2017-10-10 19:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:44:38 --> Input Class Initialized
INFO - 2017-10-10 19:44:38 --> Language Class Initialized
INFO - 2017-10-10 19:44:38 --> Loader Class Initialized
INFO - 2017-10-10 19:44:38 --> Helper loaded: url_helper
INFO - 2017-10-10 19:44:38 --> Helper loaded: common_helper
INFO - 2017-10-10 19:44:38 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:44:38 --> Email Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Controller Class Initialized
INFO - 2017-10-10 19:44:38 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> Model Class Initialized
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:44:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:44:38 --> Final output sent to browser
DEBUG - 2017-10-10 19:44:38 --> Total execution time: 0.0212
INFO - 2017-10-10 19:45:09 --> Config Class Initialized
INFO - 2017-10-10 19:45:09 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:45:09 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:45:09 --> Utf8 Class Initialized
INFO - 2017-10-10 19:45:09 --> URI Class Initialized
INFO - 2017-10-10 19:45:09 --> Router Class Initialized
INFO - 2017-10-10 19:45:09 --> Output Class Initialized
INFO - 2017-10-10 19:45:09 --> Security Class Initialized
DEBUG - 2017-10-10 19:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:45:09 --> Input Class Initialized
INFO - 2017-10-10 19:45:09 --> Language Class Initialized
INFO - 2017-10-10 19:45:09 --> Loader Class Initialized
INFO - 2017-10-10 19:45:09 --> Helper loaded: url_helper
INFO - 2017-10-10 19:45:09 --> Helper loaded: common_helper
INFO - 2017-10-10 19:45:09 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:45:09 --> Email Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Controller Class Initialized
INFO - 2017-10-10 19:45:09 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:09 --> Model Class Initialized
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:45:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:45:10 --> Final output sent to browser
DEBUG - 2017-10-10 19:45:10 --> Total execution time: 0.1349
INFO - 2017-10-10 19:45:22 --> Config Class Initialized
INFO - 2017-10-10 19:45:22 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:45:22 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:45:22 --> Utf8 Class Initialized
INFO - 2017-10-10 19:45:22 --> URI Class Initialized
DEBUG - 2017-10-10 19:45:22 --> No URI present. Default controller set.
INFO - 2017-10-10 19:45:22 --> Router Class Initialized
INFO - 2017-10-10 19:45:22 --> Output Class Initialized
INFO - 2017-10-10 19:45:22 --> Security Class Initialized
DEBUG - 2017-10-10 19:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:45:22 --> Input Class Initialized
INFO - 2017-10-10 19:45:22 --> Language Class Initialized
INFO - 2017-10-10 19:45:22 --> Loader Class Initialized
INFO - 2017-10-10 19:45:22 --> Helper loaded: url_helper
INFO - 2017-10-10 19:45:22 --> Helper loaded: common_helper
INFO - 2017-10-10 19:45:22 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:45:22 --> Email Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Controller Class Initialized
INFO - 2017-10-10 19:45:22 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> Model Class Initialized
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:45:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:45:22 --> Final output sent to browser
DEBUG - 2017-10-10 19:45:22 --> Total execution time: 0.1140
INFO - 2017-10-10 19:46:01 --> Config Class Initialized
INFO - 2017-10-10 19:46:01 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:46:01 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:46:01 --> Utf8 Class Initialized
INFO - 2017-10-10 19:46:01 --> URI Class Initialized
DEBUG - 2017-10-10 19:46:01 --> No URI present. Default controller set.
INFO - 2017-10-10 19:46:01 --> Router Class Initialized
INFO - 2017-10-10 19:46:01 --> Output Class Initialized
INFO - 2017-10-10 19:46:01 --> Security Class Initialized
DEBUG - 2017-10-10 19:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:46:01 --> Input Class Initialized
INFO - 2017-10-10 19:46:01 --> Language Class Initialized
INFO - 2017-10-10 19:46:01 --> Loader Class Initialized
INFO - 2017-10-10 19:46:01 --> Helper loaded: url_helper
INFO - 2017-10-10 19:46:01 --> Helper loaded: common_helper
INFO - 2017-10-10 19:46:01 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:46:01 --> Email Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Controller Class Initialized
INFO - 2017-10-10 19:46:01 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> Model Class Initialized
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:46:01 --> Final output sent to browser
DEBUG - 2017-10-10 19:46:01 --> Total execution time: 0.0257
INFO - 2017-10-10 19:46:13 --> Config Class Initialized
INFO - 2017-10-10 19:46:13 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:46:13 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:46:13 --> Utf8 Class Initialized
INFO - 2017-10-10 19:46:13 --> URI Class Initialized
DEBUG - 2017-10-10 19:46:13 --> No URI present. Default controller set.
INFO - 2017-10-10 19:46:13 --> Router Class Initialized
INFO - 2017-10-10 19:46:13 --> Output Class Initialized
INFO - 2017-10-10 19:46:13 --> Security Class Initialized
DEBUG - 2017-10-10 19:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:46:13 --> Input Class Initialized
INFO - 2017-10-10 19:46:13 --> Language Class Initialized
INFO - 2017-10-10 19:46:13 --> Loader Class Initialized
INFO - 2017-10-10 19:46:13 --> Helper loaded: url_helper
INFO - 2017-10-10 19:46:13 --> Helper loaded: common_helper
INFO - 2017-10-10 19:46:13 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:46:13 --> Email Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Controller Class Initialized
INFO - 2017-10-10 19:46:13 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> Model Class Initialized
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:46:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:46:13 --> Final output sent to browser
DEBUG - 2017-10-10 19:46:13 --> Total execution time: 0.0274
INFO - 2017-10-10 19:46:24 --> Config Class Initialized
INFO - 2017-10-10 19:46:24 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:46:24 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:46:24 --> Utf8 Class Initialized
INFO - 2017-10-10 19:46:24 --> URI Class Initialized
INFO - 2017-10-10 19:46:24 --> Router Class Initialized
INFO - 2017-10-10 19:46:24 --> Output Class Initialized
INFO - 2017-10-10 19:46:24 --> Security Class Initialized
DEBUG - 2017-10-10 19:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:46:24 --> Input Class Initialized
INFO - 2017-10-10 19:46:24 --> Language Class Initialized
INFO - 2017-10-10 19:46:24 --> Loader Class Initialized
INFO - 2017-10-10 19:46:24 --> Helper loaded: url_helper
INFO - 2017-10-10 19:46:24 --> Helper loaded: common_helper
INFO - 2017-10-10 19:46:24 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:46:24 --> Email Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Controller Class Initialized
INFO - 2017-10-10 19:46:24 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> Model Class Initialized
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:46:24 --> Final output sent to browser
DEBUG - 2017-10-10 19:46:24 --> Total execution time: 0.1001
INFO - 2017-10-10 19:46:27 --> Config Class Initialized
INFO - 2017-10-10 19:46:27 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:46:27 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:46:27 --> Utf8 Class Initialized
INFO - 2017-10-10 19:46:27 --> URI Class Initialized
INFO - 2017-10-10 19:46:27 --> Router Class Initialized
INFO - 2017-10-10 19:46:27 --> Output Class Initialized
INFO - 2017-10-10 19:46:27 --> Security Class Initialized
DEBUG - 2017-10-10 19:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:46:27 --> Input Class Initialized
INFO - 2017-10-10 19:46:27 --> Language Class Initialized
INFO - 2017-10-10 19:46:27 --> Loader Class Initialized
INFO - 2017-10-10 19:46:27 --> Helper loaded: url_helper
INFO - 2017-10-10 19:46:27 --> Helper loaded: common_helper
INFO - 2017-10-10 19:46:27 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:46:27 --> Email Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Controller Class Initialized
INFO - 2017-10-10 19:46:27 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> Model Class Initialized
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:46:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:46:27 --> Final output sent to browser
DEBUG - 2017-10-10 19:46:27 --> Total execution time: 0.0385
INFO - 2017-10-10 19:46:33 --> Config Class Initialized
INFO - 2017-10-10 19:46:33 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:46:33 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:46:33 --> Utf8 Class Initialized
INFO - 2017-10-10 19:46:33 --> URI Class Initialized
INFO - 2017-10-10 19:46:33 --> Router Class Initialized
INFO - 2017-10-10 19:46:33 --> Output Class Initialized
INFO - 2017-10-10 19:46:33 --> Security Class Initialized
DEBUG - 2017-10-10 19:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:46:33 --> Input Class Initialized
INFO - 2017-10-10 19:46:33 --> Language Class Initialized
INFO - 2017-10-10 19:46:33 --> Loader Class Initialized
INFO - 2017-10-10 19:46:33 --> Helper loaded: url_helper
INFO - 2017-10-10 19:46:33 --> Helper loaded: common_helper
INFO - 2017-10-10 19:46:33 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:46:33 --> Email Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Controller Class Initialized
INFO - 2017-10-10 19:46:33 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> Model Class Initialized
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:46:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:46:33 --> Final output sent to browser
DEBUG - 2017-10-10 19:46:33 --> Total execution time: 0.0572
INFO - 2017-10-10 19:47:08 --> Config Class Initialized
INFO - 2017-10-10 19:47:08 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:47:08 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:47:08 --> Utf8 Class Initialized
INFO - 2017-10-10 19:47:08 --> URI Class Initialized
INFO - 2017-10-10 19:47:08 --> Router Class Initialized
INFO - 2017-10-10 19:47:08 --> Output Class Initialized
INFO - 2017-10-10 19:47:08 --> Security Class Initialized
DEBUG - 2017-10-10 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:47:08 --> Input Class Initialized
INFO - 2017-10-10 19:47:08 --> Language Class Initialized
INFO - 2017-10-10 19:47:08 --> Loader Class Initialized
INFO - 2017-10-10 19:47:08 --> Helper loaded: url_helper
INFO - 2017-10-10 19:47:08 --> Helper loaded: common_helper
INFO - 2017-10-10 19:47:08 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:47:08 --> Email Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Controller Class Initialized
INFO - 2017-10-10 19:47:08 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:47:08 --> Final output sent to browser
DEBUG - 2017-10-10 19:47:08 --> Total execution time: 0.0354
INFO - 2017-10-10 19:47:08 --> Config Class Initialized
INFO - 2017-10-10 19:47:08 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:47:08 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:47:08 --> Utf8 Class Initialized
INFO - 2017-10-10 19:47:08 --> URI Class Initialized
INFO - 2017-10-10 19:47:08 --> Router Class Initialized
INFO - 2017-10-10 19:47:08 --> Output Class Initialized
INFO - 2017-10-10 19:47:08 --> Security Class Initialized
DEBUG - 2017-10-10 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:47:08 --> Input Class Initialized
INFO - 2017-10-10 19:47:08 --> Language Class Initialized
INFO - 2017-10-10 19:47:08 --> Loader Class Initialized
INFO - 2017-10-10 19:47:08 --> Helper loaded: url_helper
INFO - 2017-10-10 19:47:08 --> Helper loaded: common_helper
INFO - 2017-10-10 19:47:08 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:47:08 --> Email Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Controller Class Initialized
INFO - 2017-10-10 19:47:08 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> Model Class Initialized
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:47:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:47:08 --> Final output sent to browser
DEBUG - 2017-10-10 19:47:08 --> Total execution time: 0.0362
INFO - 2017-10-10 19:47:13 --> Config Class Initialized
INFO - 2017-10-10 19:47:13 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:47:13 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:47:13 --> Utf8 Class Initialized
INFO - 2017-10-10 19:47:13 --> URI Class Initialized
DEBUG - 2017-10-10 19:47:13 --> No URI present. Default controller set.
INFO - 2017-10-10 19:47:13 --> Router Class Initialized
INFO - 2017-10-10 19:47:13 --> Output Class Initialized
INFO - 2017-10-10 19:47:13 --> Security Class Initialized
DEBUG - 2017-10-10 19:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:47:13 --> Input Class Initialized
INFO - 2017-10-10 19:47:13 --> Language Class Initialized
INFO - 2017-10-10 19:47:13 --> Loader Class Initialized
INFO - 2017-10-10 19:47:13 --> Helper loaded: url_helper
INFO - 2017-10-10 19:47:13 --> Helper loaded: common_helper
INFO - 2017-10-10 19:47:13 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:47:13 --> Email Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Controller Class Initialized
INFO - 2017-10-10 19:47:13 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> Model Class Initialized
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:47:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:47:13 --> Final output sent to browser
DEBUG - 2017-10-10 19:47:13 --> Total execution time: 0.0235
INFO - 2017-10-10 19:59:21 --> Config Class Initialized
INFO - 2017-10-10 19:59:21 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:59:21 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:59:21 --> Utf8 Class Initialized
INFO - 2017-10-10 19:59:21 --> URI Class Initialized
DEBUG - 2017-10-10 19:59:21 --> No URI present. Default controller set.
INFO - 2017-10-10 19:59:21 --> Router Class Initialized
INFO - 2017-10-10 19:59:21 --> Output Class Initialized
INFO - 2017-10-10 19:59:21 --> Security Class Initialized
DEBUG - 2017-10-10 19:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:59:21 --> Input Class Initialized
INFO - 2017-10-10 19:59:21 --> Language Class Initialized
INFO - 2017-10-10 19:59:21 --> Loader Class Initialized
INFO - 2017-10-10 19:59:21 --> Helper loaded: url_helper
INFO - 2017-10-10 19:59:21 --> Helper loaded: common_helper
INFO - 2017-10-10 19:59:21 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:59:21 --> Email Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Controller Class Initialized
INFO - 2017-10-10 19:59:21 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> Model Class Initialized
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:59:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:59:21 --> Final output sent to browser
DEBUG - 2017-10-10 19:59:21 --> Total execution time: 0.0431
INFO - 2017-10-10 19:59:28 --> Config Class Initialized
INFO - 2017-10-10 19:59:28 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:59:28 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:59:28 --> Utf8 Class Initialized
INFO - 2017-10-10 19:59:28 --> URI Class Initialized
INFO - 2017-10-10 19:59:28 --> Router Class Initialized
INFO - 2017-10-10 19:59:28 --> Output Class Initialized
INFO - 2017-10-10 19:59:28 --> Security Class Initialized
DEBUG - 2017-10-10 19:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:59:28 --> Input Class Initialized
INFO - 2017-10-10 19:59:28 --> Language Class Initialized
INFO - 2017-10-10 19:59:28 --> Loader Class Initialized
INFO - 2017-10-10 19:59:28 --> Helper loaded: url_helper
INFO - 2017-10-10 19:59:28 --> Helper loaded: common_helper
INFO - 2017-10-10 19:59:28 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:59:28 --> Email Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Controller Class Initialized
INFO - 2017-10-10 19:59:28 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> Model Class Initialized
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:59:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:59:28 --> Final output sent to browser
DEBUG - 2017-10-10 19:59:28 --> Total execution time: 0.1741
INFO - 2017-10-10 19:59:46 --> Config Class Initialized
INFO - 2017-10-10 19:59:46 --> Hooks Class Initialized
DEBUG - 2017-10-10 19:59:46 --> UTF-8 Support Enabled
INFO - 2017-10-10 19:59:46 --> Utf8 Class Initialized
INFO - 2017-10-10 19:59:46 --> URI Class Initialized
DEBUG - 2017-10-10 19:59:46 --> No URI present. Default controller set.
INFO - 2017-10-10 19:59:46 --> Router Class Initialized
INFO - 2017-10-10 19:59:46 --> Output Class Initialized
INFO - 2017-10-10 19:59:46 --> Security Class Initialized
DEBUG - 2017-10-10 19:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 19:59:46 --> Input Class Initialized
INFO - 2017-10-10 19:59:46 --> Language Class Initialized
INFO - 2017-10-10 19:59:46 --> Loader Class Initialized
INFO - 2017-10-10 19:59:46 --> Helper loaded: url_helper
INFO - 2017-10-10 19:59:46 --> Helper loaded: common_helper
INFO - 2017-10-10 19:59:46 --> Database Driver Class Initialized
DEBUG - 2017-10-10 19:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 19:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 19:59:46 --> Email Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Controller Class Initialized
INFO - 2017-10-10 19:59:46 --> Helper loaded: cookie_helper
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> Model Class Initialized
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 19:59:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 19:59:46 --> Final output sent to browser
DEBUG - 2017-10-10 19:59:46 --> Total execution time: 0.0482
INFO - 2017-10-10 20:02:18 --> Config Class Initialized
INFO - 2017-10-10 20:02:18 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:18 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:18 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:18 --> URI Class Initialized
DEBUG - 2017-10-10 20:02:18 --> No URI present. Default controller set.
INFO - 2017-10-10 20:02:18 --> Router Class Initialized
INFO - 2017-10-10 20:02:18 --> Output Class Initialized
INFO - 2017-10-10 20:02:18 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:18 --> Input Class Initialized
INFO - 2017-10-10 20:02:18 --> Language Class Initialized
INFO - 2017-10-10 20:02:18 --> Loader Class Initialized
INFO - 2017-10-10 20:02:18 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:18 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:18 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:18 --> Email Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Controller Class Initialized
INFO - 2017-10-10 20:02:18 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> Model Class Initialized
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:18 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:18 --> Total execution time: 0.0319
INFO - 2017-10-10 20:02:24 --> Config Class Initialized
INFO - 2017-10-10 20:02:24 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:24 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:24 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:24 --> URI Class Initialized
INFO - 2017-10-10 20:02:24 --> Router Class Initialized
INFO - 2017-10-10 20:02:24 --> Output Class Initialized
INFO - 2017-10-10 20:02:24 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:24 --> Input Class Initialized
INFO - 2017-10-10 20:02:24 --> Language Class Initialized
INFO - 2017-10-10 20:02:24 --> Loader Class Initialized
INFO - 2017-10-10 20:02:24 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:24 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:24 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:24 --> Email Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Controller Class Initialized
INFO - 2017-10-10 20:02:24 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> Model Class Initialized
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:24 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:24 --> Total execution time: 0.0492
INFO - 2017-10-10 20:02:38 --> Config Class Initialized
INFO - 2017-10-10 20:02:38 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:38 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:38 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:38 --> URI Class Initialized
INFO - 2017-10-10 20:02:38 --> Router Class Initialized
INFO - 2017-10-10 20:02:38 --> Output Class Initialized
INFO - 2017-10-10 20:02:38 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:38 --> Input Class Initialized
INFO - 2017-10-10 20:02:38 --> Language Class Initialized
INFO - 2017-10-10 20:02:38 --> Loader Class Initialized
INFO - 2017-10-10 20:02:38 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:38 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:38 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:38 --> Email Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Controller Class Initialized
INFO - 2017-10-10 20:02:38 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:38 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> Model Class Initialized
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:39 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:39 --> Total execution time: 0.1393
INFO - 2017-10-10 20:02:40 --> Config Class Initialized
INFO - 2017-10-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:40 --> URI Class Initialized
INFO - 2017-10-10 20:02:40 --> Router Class Initialized
INFO - 2017-10-10 20:02:40 --> Output Class Initialized
INFO - 2017-10-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:40 --> Input Class Initialized
INFO - 2017-10-10 20:02:40 --> Language Class Initialized
INFO - 2017-10-10 20:02:40 --> Loader Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:40 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:40 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:40 --> Email Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Controller Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:40 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:40 --> Total execution time: 0.1368
INFO - 2017-10-10 20:02:40 --> Config Class Initialized
INFO - 2017-10-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:40 --> URI Class Initialized
INFO - 2017-10-10 20:02:40 --> Router Class Initialized
INFO - 2017-10-10 20:02:40 --> Output Class Initialized
INFO - 2017-10-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:40 --> Input Class Initialized
INFO - 2017-10-10 20:02:40 --> Language Class Initialized
INFO - 2017-10-10 20:02:40 --> Loader Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:40 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:40 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:40 --> Email Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Controller Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:40 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:40 --> Total execution time: 0.1541
INFO - 2017-10-10 20:02:40 --> Config Class Initialized
INFO - 2017-10-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:40 --> URI Class Initialized
INFO - 2017-10-10 20:02:40 --> Router Class Initialized
INFO - 2017-10-10 20:02:40 --> Output Class Initialized
INFO - 2017-10-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:40 --> Input Class Initialized
INFO - 2017-10-10 20:02:40 --> Language Class Initialized
INFO - 2017-10-10 20:02:40 --> Loader Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:40 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:40 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:40 --> Email Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Controller Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:40 --> Config Class Initialized
INFO - 2017-10-10 20:02:40 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:40 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:40 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:40 --> URI Class Initialized
INFO - 2017-10-10 20:02:40 --> Router Class Initialized
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:40 --> Output Class Initialized
INFO - 2017-10-10 20:02:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:40 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:40 --> Input Class Initialized
INFO - 2017-10-10 20:02:40 --> Language Class Initialized
INFO - 2017-10-10 20:02:40 --> Loader Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:40 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:40 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:40 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:40 --> Total execution time: 0.1407
INFO - 2017-10-10 20:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:40 --> Email Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Controller Class Initialized
INFO - 2017-10-10 20:02:40 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:40 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1770
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1182
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1371
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1473
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1653
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Config Class Initialized
INFO - 2017-10-10 20:02:41 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:41 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:41 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:41 --> URI Class Initialized
INFO - 2017-10-10 20:02:41 --> Router Class Initialized
INFO - 2017-10-10 20:02:41 --> Output Class Initialized
INFO - 2017-10-10 20:02:41 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:41 --> Input Class Initialized
INFO - 2017-10-10 20:02:41 --> Language Class Initialized
INFO - 2017-10-10 20:02:41 --> Loader Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:41 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:41 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:41 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:41 --> Total execution time: 0.1618
INFO - 2017-10-10 20:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:41 --> Email Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Controller Class Initialized
INFO - 2017-10-10 20:02:41 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:41 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.1704
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.1838
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.2320
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.2944
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.3257
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.5358
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Config Class Initialized
INFO - 2017-10-10 20:02:42 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:42 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:42 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:42 --> URI Class Initialized
INFO - 2017-10-10 20:02:42 --> Router Class Initialized
INFO - 2017-10-10 20:02:42 --> Output Class Initialized
INFO - 2017-10-10 20:02:42 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:42 --> Input Class Initialized
INFO - 2017-10-10 20:02:42 --> Language Class Initialized
INFO - 2017-10-10 20:02:42 --> Loader Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:42 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:42 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:42 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:42 --> Total execution time: 0.4656
INFO - 2017-10-10 20:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:42 --> Email Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Controller Class Initialized
INFO - 2017-10-10 20:02:42 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:42 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Config Class Initialized
INFO - 2017-10-10 20:02:43 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:02:43 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:02:43 --> Utf8 Class Initialized
INFO - 2017-10-10 20:02:43 --> URI Class Initialized
INFO - 2017-10-10 20:02:43 --> Router Class Initialized
INFO - 2017-10-10 20:02:43 --> Output Class Initialized
INFO - 2017-10-10 20:02:43 --> Security Class Initialized
DEBUG - 2017-10-10 20:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:02:43 --> Input Class Initialized
INFO - 2017-10-10 20:02:43 --> Language Class Initialized
INFO - 2017-10-10 20:02:43 --> Loader Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: url_helper
INFO - 2017-10-10 20:02:43 --> Helper loaded: common_helper
INFO - 2017-10-10 20:02:43 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.9412
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.5707
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.9248
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.6982
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.5561
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 0.7772
INFO - 2017-10-10 20:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:02:43 --> Email Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Controller Class Initialized
INFO - 2017-10-10 20:02:43 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> Model Class Initialized
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:02:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:02:43 --> Final output sent to browser
DEBUG - 2017-10-10 20:02:43 --> Total execution time: 1.0272
INFO - 2017-10-10 20:03:03 --> Config Class Initialized
INFO - 2017-10-10 20:03:03 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:03 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:03 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:03 --> URI Class Initialized
INFO - 2017-10-10 20:03:03 --> Router Class Initialized
INFO - 2017-10-10 20:03:03 --> Output Class Initialized
INFO - 2017-10-10 20:03:03 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:03 --> Input Class Initialized
INFO - 2017-10-10 20:03:03 --> Language Class Initialized
INFO - 2017-10-10 20:03:03 --> Loader Class Initialized
INFO - 2017-10-10 20:03:03 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:03 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:03 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:03 --> Email Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Controller Class Initialized
INFO - 2017-10-10 20:03:03 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Config Class Initialized
INFO - 2017-10-10 20:03:03 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:03 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:03 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:03 --> URI Class Initialized
INFO - 2017-10-10 20:03:03 --> Router Class Initialized
INFO - 2017-10-10 20:03:03 --> Output Class Initialized
INFO - 2017-10-10 20:03:03 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:03 --> Input Class Initialized
INFO - 2017-10-10 20:03:03 --> Language Class Initialized
INFO - 2017-10-10 20:03:03 --> Loader Class Initialized
INFO - 2017-10-10 20:03:03 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:03 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:03 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:03 --> Email Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Controller Class Initialized
INFO - 2017-10-10 20:03:03 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> Model Class Initialized
INFO - 2017-10-10 20:03:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-10 20:03:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:03 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:03 --> Total execution time: 0.0307
INFO - 2017-10-10 20:03:08 --> Config Class Initialized
INFO - 2017-10-10 20:03:08 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:08 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:08 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:08 --> URI Class Initialized
INFO - 2017-10-10 20:03:08 --> Router Class Initialized
INFO - 2017-10-10 20:03:08 --> Output Class Initialized
INFO - 2017-10-10 20:03:08 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:08 --> Input Class Initialized
INFO - 2017-10-10 20:03:08 --> Language Class Initialized
INFO - 2017-10-10 20:03:08 --> Loader Class Initialized
INFO - 2017-10-10 20:03:08 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:08 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:08 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:08 --> Email Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Controller Class Initialized
INFO - 2017-10-10 20:03:08 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Config Class Initialized
INFO - 2017-10-10 20:03:08 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:08 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:08 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:08 --> URI Class Initialized
INFO - 2017-10-10 20:03:08 --> Router Class Initialized
INFO - 2017-10-10 20:03:08 --> Output Class Initialized
INFO - 2017-10-10 20:03:08 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:08 --> Input Class Initialized
INFO - 2017-10-10 20:03:08 --> Language Class Initialized
INFO - 2017-10-10 20:03:08 --> Loader Class Initialized
INFO - 2017-10-10 20:03:08 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:08 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:08 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:08 --> Email Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Controller Class Initialized
INFO - 2017-10-10 20:03:08 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> Model Class Initialized
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:08 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:08 --> Total execution time: 0.0437
INFO - 2017-10-10 20:03:19 --> Config Class Initialized
INFO - 2017-10-10 20:03:19 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:19 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:19 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:19 --> URI Class Initialized
INFO - 2017-10-10 20:03:19 --> Router Class Initialized
INFO - 2017-10-10 20:03:19 --> Output Class Initialized
INFO - 2017-10-10 20:03:19 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:19 --> Input Class Initialized
INFO - 2017-10-10 20:03:19 --> Language Class Initialized
INFO - 2017-10-10 20:03:19 --> Loader Class Initialized
INFO - 2017-10-10 20:03:19 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:19 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:19 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:19 --> Email Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Controller Class Initialized
INFO - 2017-10-10 20:03:19 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Config Class Initialized
INFO - 2017-10-10 20:03:19 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:19 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:19 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:19 --> URI Class Initialized
INFO - 2017-10-10 20:03:19 --> Router Class Initialized
INFO - 2017-10-10 20:03:19 --> Output Class Initialized
INFO - 2017-10-10 20:03:19 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:19 --> Input Class Initialized
INFO - 2017-10-10 20:03:19 --> Language Class Initialized
INFO - 2017-10-10 20:03:19 --> Loader Class Initialized
INFO - 2017-10-10 20:03:19 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:19 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:19 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:19 --> Email Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Controller Class Initialized
INFO - 2017-10-10 20:03:19 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> Model Class Initialized
INFO - 2017-10-10 20:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-10 20:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:19 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:19 --> Total execution time: 0.0217
INFO - 2017-10-10 20:03:25 --> Config Class Initialized
INFO - 2017-10-10 20:03:25 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:25 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:25 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:25 --> URI Class Initialized
INFO - 2017-10-10 20:03:25 --> Router Class Initialized
INFO - 2017-10-10 20:03:25 --> Output Class Initialized
INFO - 2017-10-10 20:03:25 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:25 --> Input Class Initialized
INFO - 2017-10-10 20:03:25 --> Language Class Initialized
INFO - 2017-10-10 20:03:25 --> Loader Class Initialized
INFO - 2017-10-10 20:03:25 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:25 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:25 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:25 --> Email Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Controller Class Initialized
INFO - 2017-10-10 20:03:25 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:25 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Config Class Initialized
INFO - 2017-10-10 20:03:26 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:26 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:26 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:26 --> URI Class Initialized
DEBUG - 2017-10-10 20:03:26 --> No URI present. Default controller set.
INFO - 2017-10-10 20:03:26 --> Router Class Initialized
INFO - 2017-10-10 20:03:26 --> Output Class Initialized
INFO - 2017-10-10 20:03:26 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:26 --> Input Class Initialized
INFO - 2017-10-10 20:03:26 --> Language Class Initialized
INFO - 2017-10-10 20:03:26 --> Loader Class Initialized
INFO - 2017-10-10 20:03:26 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:26 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:26 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:26 --> Email Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Controller Class Initialized
INFO - 2017-10-10 20:03:26 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> Model Class Initialized
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:26 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:26 --> Total execution time: 0.0245
INFO - 2017-10-10 20:03:37 --> Config Class Initialized
INFO - 2017-10-10 20:03:37 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:37 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:37 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:37 --> URI Class Initialized
INFO - 2017-10-10 20:03:37 --> Router Class Initialized
INFO - 2017-10-10 20:03:37 --> Output Class Initialized
INFO - 2017-10-10 20:03:37 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:37 --> Input Class Initialized
INFO - 2017-10-10 20:03:37 --> Language Class Initialized
INFO - 2017-10-10 20:03:37 --> Loader Class Initialized
INFO - 2017-10-10 20:03:37 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:37 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:37 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:37 --> Email Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Controller Class Initialized
INFO - 2017-10-10 20:03:37 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> Model Class Initialized
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:37 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:37 --> Total execution time: 0.0578
INFO - 2017-10-10 20:03:44 --> Config Class Initialized
INFO - 2017-10-10 20:03:44 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:44 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:44 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:44 --> URI Class Initialized
INFO - 2017-10-10 20:03:44 --> Router Class Initialized
INFO - 2017-10-10 20:03:44 --> Output Class Initialized
INFO - 2017-10-10 20:03:44 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:44 --> Input Class Initialized
INFO - 2017-10-10 20:03:44 --> Language Class Initialized
INFO - 2017-10-10 20:03:44 --> Loader Class Initialized
INFO - 2017-10-10 20:03:44 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:44 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:44 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:44 --> Email Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Controller Class Initialized
INFO - 2017-10-10 20:03:44 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> Model Class Initialized
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:44 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:44 --> Total execution time: 0.0692
INFO - 2017-10-10 20:03:52 --> Config Class Initialized
INFO - 2017-10-10 20:03:52 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:03:52 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:03:52 --> Utf8 Class Initialized
INFO - 2017-10-10 20:03:52 --> URI Class Initialized
DEBUG - 2017-10-10 20:03:52 --> No URI present. Default controller set.
INFO - 2017-10-10 20:03:52 --> Router Class Initialized
INFO - 2017-10-10 20:03:52 --> Output Class Initialized
INFO - 2017-10-10 20:03:52 --> Security Class Initialized
DEBUG - 2017-10-10 20:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:03:52 --> Input Class Initialized
INFO - 2017-10-10 20:03:52 --> Language Class Initialized
INFO - 2017-10-10 20:03:52 --> Loader Class Initialized
INFO - 2017-10-10 20:03:52 --> Helper loaded: url_helper
INFO - 2017-10-10 20:03:52 --> Helper loaded: common_helper
INFO - 2017-10-10 20:03:52 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:03:52 --> Email Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Controller Class Initialized
INFO - 2017-10-10 20:03:52 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> Model Class Initialized
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:03:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:03:52 --> Final output sent to browser
DEBUG - 2017-10-10 20:03:52 --> Total execution time: 0.0529
INFO - 2017-10-10 20:04:00 --> Config Class Initialized
INFO - 2017-10-10 20:04:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:04:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:04:00 --> Utf8 Class Initialized
INFO - 2017-10-10 20:04:00 --> URI Class Initialized
INFO - 2017-10-10 20:04:00 --> Router Class Initialized
INFO - 2017-10-10 20:04:00 --> Output Class Initialized
INFO - 2017-10-10 20:04:00 --> Security Class Initialized
DEBUG - 2017-10-10 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:04:00 --> Input Class Initialized
INFO - 2017-10-10 20:04:00 --> Language Class Initialized
INFO - 2017-10-10 20:04:00 --> Loader Class Initialized
INFO - 2017-10-10 20:04:00 --> Helper loaded: url_helper
INFO - 2017-10-10 20:04:00 --> Helper loaded: common_helper
INFO - 2017-10-10 20:04:00 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:04:00 --> Email Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Controller Class Initialized
INFO - 2017-10-10 20:04:00 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> Model Class Initialized
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:04:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:04:00 --> Final output sent to browser
DEBUG - 2017-10-10 20:04:00 --> Total execution time: 0.0922
INFO - 2017-10-10 20:04:35 --> Config Class Initialized
INFO - 2017-10-10 20:04:35 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:04:35 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:04:35 --> Utf8 Class Initialized
INFO - 2017-10-10 20:04:35 --> URI Class Initialized
INFO - 2017-10-10 20:04:35 --> Router Class Initialized
INFO - 2017-10-10 20:04:35 --> Output Class Initialized
INFO - 2017-10-10 20:04:35 --> Security Class Initialized
DEBUG - 2017-10-10 20:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:04:35 --> Input Class Initialized
INFO - 2017-10-10 20:04:35 --> Language Class Initialized
INFO - 2017-10-10 20:04:35 --> Loader Class Initialized
INFO - 2017-10-10 20:04:35 --> Helper loaded: url_helper
INFO - 2017-10-10 20:04:35 --> Helper loaded: common_helper
INFO - 2017-10-10 20:04:35 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:04:35 --> Email Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Controller Class Initialized
INFO - 2017-10-10 20:04:35 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> Model Class Initialized
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:04:35 --> Final output sent to browser
DEBUG - 2017-10-10 20:04:35 --> Total execution time: 0.0295
INFO - 2017-10-10 20:05:09 --> Config Class Initialized
INFO - 2017-10-10 20:05:09 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:05:09 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:05:09 --> Utf8 Class Initialized
INFO - 2017-10-10 20:05:09 --> URI Class Initialized
INFO - 2017-10-10 20:05:09 --> Router Class Initialized
INFO - 2017-10-10 20:05:09 --> Output Class Initialized
INFO - 2017-10-10 20:05:09 --> Security Class Initialized
DEBUG - 2017-10-10 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:05:09 --> Input Class Initialized
INFO - 2017-10-10 20:05:09 --> Language Class Initialized
INFO - 2017-10-10 20:05:09 --> Loader Class Initialized
INFO - 2017-10-10 20:05:09 --> Helper loaded: url_helper
INFO - 2017-10-10 20:05:09 --> Helper loaded: common_helper
INFO - 2017-10-10 20:05:09 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:05:09 --> Email Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Controller Class Initialized
INFO - 2017-10-10 20:05:09 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> Model Class Initialized
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:05:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:05:09 --> Final output sent to browser
DEBUG - 2017-10-10 20:05:09 --> Total execution time: 0.0453
INFO - 2017-10-10 20:05:16 --> Config Class Initialized
INFO - 2017-10-10 20:05:16 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:05:16 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:05:16 --> Utf8 Class Initialized
INFO - 2017-10-10 20:05:16 --> URI Class Initialized
INFO - 2017-10-10 20:05:16 --> Router Class Initialized
INFO - 2017-10-10 20:05:16 --> Output Class Initialized
INFO - 2017-10-10 20:05:16 --> Security Class Initialized
DEBUG - 2017-10-10 20:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:05:16 --> Input Class Initialized
INFO - 2017-10-10 20:05:16 --> Language Class Initialized
INFO - 2017-10-10 20:05:16 --> Loader Class Initialized
INFO - 2017-10-10 20:05:16 --> Helper loaded: url_helper
INFO - 2017-10-10 20:05:16 --> Helper loaded: common_helper
INFO - 2017-10-10 20:05:16 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:05:16 --> Email Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Controller Class Initialized
INFO - 2017-10-10 20:05:16 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> Model Class Initialized
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:05:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:05:16 --> Final output sent to browser
DEBUG - 2017-10-10 20:05:16 --> Total execution time: 0.1305
INFO - 2017-10-10 20:05:37 --> Config Class Initialized
INFO - 2017-10-10 20:05:37 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:05:37 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:05:37 --> Utf8 Class Initialized
INFO - 2017-10-10 20:05:37 --> URI Class Initialized
DEBUG - 2017-10-10 20:05:37 --> No URI present. Default controller set.
INFO - 2017-10-10 20:05:37 --> Router Class Initialized
INFO - 2017-10-10 20:05:37 --> Output Class Initialized
INFO - 2017-10-10 20:05:37 --> Security Class Initialized
DEBUG - 2017-10-10 20:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:05:37 --> Input Class Initialized
INFO - 2017-10-10 20:05:37 --> Language Class Initialized
INFO - 2017-10-10 20:05:37 --> Loader Class Initialized
INFO - 2017-10-10 20:05:37 --> Helper loaded: url_helper
INFO - 2017-10-10 20:05:37 --> Helper loaded: common_helper
INFO - 2017-10-10 20:05:37 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:05:37 --> Email Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Controller Class Initialized
INFO - 2017-10-10 20:05:37 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> Model Class Initialized
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:05:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:05:37 --> Final output sent to browser
DEBUG - 2017-10-10 20:05:37 --> Total execution time: 0.0922
INFO - 2017-10-10 20:06:36 --> Config Class Initialized
INFO - 2017-10-10 20:06:36 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:06:36 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:06:36 --> Utf8 Class Initialized
INFO - 2017-10-10 20:06:36 --> URI Class Initialized
DEBUG - 2017-10-10 20:06:36 --> No URI present. Default controller set.
INFO - 2017-10-10 20:06:36 --> Router Class Initialized
INFO - 2017-10-10 20:06:36 --> Output Class Initialized
INFO - 2017-10-10 20:06:36 --> Security Class Initialized
DEBUG - 2017-10-10 20:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:06:36 --> Input Class Initialized
INFO - 2017-10-10 20:06:36 --> Language Class Initialized
INFO - 2017-10-10 20:06:36 --> Loader Class Initialized
INFO - 2017-10-10 20:06:36 --> Helper loaded: url_helper
INFO - 2017-10-10 20:06:36 --> Helper loaded: common_helper
INFO - 2017-10-10 20:06:36 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:06:36 --> Email Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Controller Class Initialized
INFO - 2017-10-10 20:06:36 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> Model Class Initialized
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:06:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:06:36 --> Final output sent to browser
DEBUG - 2017-10-10 20:06:36 --> Total execution time: 0.0250
INFO - 2017-10-10 20:06:46 --> Config Class Initialized
INFO - 2017-10-10 20:06:46 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:06:46 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:06:46 --> Utf8 Class Initialized
INFO - 2017-10-10 20:06:46 --> URI Class Initialized
DEBUG - 2017-10-10 20:06:46 --> No URI present. Default controller set.
INFO - 2017-10-10 20:06:46 --> Router Class Initialized
INFO - 2017-10-10 20:06:46 --> Output Class Initialized
INFO - 2017-10-10 20:06:46 --> Security Class Initialized
DEBUG - 2017-10-10 20:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:06:46 --> Input Class Initialized
INFO - 2017-10-10 20:06:46 --> Language Class Initialized
INFO - 2017-10-10 20:06:46 --> Loader Class Initialized
INFO - 2017-10-10 20:06:46 --> Helper loaded: url_helper
INFO - 2017-10-10 20:06:46 --> Helper loaded: common_helper
INFO - 2017-10-10 20:06:46 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:06:46 --> Email Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Controller Class Initialized
INFO - 2017-10-10 20:06:46 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> Model Class Initialized
INFO - 2017-10-10 20:06:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:06:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:06:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-10 20:06:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:06:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:06:46 --> Final output sent to browser
DEBUG - 2017-10-10 20:06:46 --> Total execution time: 0.0892
INFO - 2017-10-10 20:07:00 --> Config Class Initialized
INFO - 2017-10-10 20:07:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:00 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:00 --> URI Class Initialized
INFO - 2017-10-10 20:07:00 --> Router Class Initialized
INFO - 2017-10-10 20:07:00 --> Output Class Initialized
INFO - 2017-10-10 20:07:00 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:00 --> Input Class Initialized
INFO - 2017-10-10 20:07:00 --> Language Class Initialized
INFO - 2017-10-10 20:07:00 --> Loader Class Initialized
INFO - 2017-10-10 20:07:00 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:00 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:00 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:00 --> Email Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Controller Class Initialized
INFO - 2017-10-10 20:07:00 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Config Class Initialized
INFO - 2017-10-10 20:07:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:00 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:00 --> URI Class Initialized
INFO - 2017-10-10 20:07:00 --> Router Class Initialized
INFO - 2017-10-10 20:07:00 --> Output Class Initialized
INFO - 2017-10-10 20:07:00 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:00 --> Input Class Initialized
INFO - 2017-10-10 20:07:00 --> Language Class Initialized
INFO - 2017-10-10 20:07:00 --> Loader Class Initialized
INFO - 2017-10-10 20:07:00 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:00 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:00 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:00 --> Email Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Controller Class Initialized
INFO - 2017-10-10 20:07:00 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
INFO - 2017-10-10 20:07:00 --> Model Class Initialized
ERROR - 2017-10-10 20:07:00 --> Severity: Notice --> Undefined variable: logo /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php 22
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:07:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:07:00 --> Final output sent to browser
DEBUG - 2017-10-10 20:07:00 --> Total execution time: 0.0694
INFO - 2017-10-10 20:07:00 --> Config Class Initialized
INFO - 2017-10-10 20:07:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:00 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:00 --> Config Class Initialized
INFO - 2017-10-10 20:07:00 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:00 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:00 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:37 --> Config Class Initialized
INFO - 2017-10-10 20:07:37 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:37 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:37 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:37 --> URI Class Initialized
INFO - 2017-10-10 20:07:37 --> Router Class Initialized
INFO - 2017-10-10 20:07:37 --> Output Class Initialized
INFO - 2017-10-10 20:07:37 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:37 --> Input Class Initialized
INFO - 2017-10-10 20:07:37 --> Language Class Initialized
INFO - 2017-10-10 20:07:37 --> Loader Class Initialized
INFO - 2017-10-10 20:07:37 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:37 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:37 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:37 --> Email Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Controller Class Initialized
INFO - 2017-10-10 20:07:37 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> Model Class Initialized
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:07:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:07:37 --> Final output sent to browser
DEBUG - 2017-10-10 20:07:37 --> Total execution time: 0.0620
INFO - 2017-10-10 20:07:47 --> Config Class Initialized
INFO - 2017-10-10 20:07:47 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:47 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:47 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:47 --> URI Class Initialized
INFO - 2017-10-10 20:07:47 --> Router Class Initialized
INFO - 2017-10-10 20:07:47 --> Output Class Initialized
INFO - 2017-10-10 20:07:47 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:47 --> Input Class Initialized
INFO - 2017-10-10 20:07:47 --> Language Class Initialized
INFO - 2017-10-10 20:07:47 --> Loader Class Initialized
INFO - 2017-10-10 20:07:47 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:47 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:47 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:47 --> Email Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Controller Class Initialized
INFO - 2017-10-10 20:07:47 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Config Class Initialized
INFO - 2017-10-10 20:07:47 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:47 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:47 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:47 --> URI Class Initialized
INFO - 2017-10-10 20:07:47 --> Router Class Initialized
INFO - 2017-10-10 20:07:47 --> Output Class Initialized
INFO - 2017-10-10 20:07:47 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:47 --> Input Class Initialized
INFO - 2017-10-10 20:07:47 --> Language Class Initialized
INFO - 2017-10-10 20:07:47 --> Loader Class Initialized
INFO - 2017-10-10 20:07:47 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:47 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:47 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:47 --> Email Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Controller Class Initialized
INFO - 2017-10-10 20:07:47 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> Model Class Initialized
INFO - 2017-10-10 20:07:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:07:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:07:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-10 20:07:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:07:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:07:47 --> Final output sent to browser
DEBUG - 2017-10-10 20:07:47 --> Total execution time: 0.0248
INFO - 2017-10-10 20:07:53 --> Config Class Initialized
INFO - 2017-10-10 20:07:53 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:53 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:53 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:53 --> URI Class Initialized
INFO - 2017-10-10 20:07:53 --> Router Class Initialized
INFO - 2017-10-10 20:07:53 --> Output Class Initialized
INFO - 2017-10-10 20:07:53 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:53 --> Input Class Initialized
INFO - 2017-10-10 20:07:53 --> Language Class Initialized
INFO - 2017-10-10 20:07:53 --> Loader Class Initialized
INFO - 2017-10-10 20:07:53 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:53 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:53 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:53 --> Email Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Controller Class Initialized
INFO - 2017-10-10 20:07:53 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Config Class Initialized
INFO - 2017-10-10 20:07:53 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:53 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:53 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:53 --> URI Class Initialized
INFO - 2017-10-10 20:07:53 --> Router Class Initialized
INFO - 2017-10-10 20:07:53 --> Output Class Initialized
INFO - 2017-10-10 20:07:53 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:53 --> Input Class Initialized
INFO - 2017-10-10 20:07:53 --> Language Class Initialized
INFO - 2017-10-10 20:07:53 --> Loader Class Initialized
INFO - 2017-10-10 20:07:53 --> Helper loaded: url_helper
INFO - 2017-10-10 20:07:53 --> Helper loaded: common_helper
INFO - 2017-10-10 20:07:53 --> Database Driver Class Initialized
DEBUG - 2017-10-10 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-10 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-10 20:07:53 --> Email Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Controller Class Initialized
INFO - 2017-10-10 20:07:53 --> Helper loaded: cookie_helper
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> Model Class Initialized
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-10 20:07:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-10 20:07:53 --> Final output sent to browser
DEBUG - 2017-10-10 20:07:53 --> Total execution time: 0.0386
INFO - 2017-10-10 20:07:53 --> Config Class Initialized
INFO - 2017-10-10 20:07:53 --> Hooks Class Initialized
DEBUG - 2017-10-10 20:07:53 --> UTF-8 Support Enabled
INFO - 2017-10-10 20:07:53 --> Utf8 Class Initialized
INFO - 2017-10-10 20:07:53 --> URI Class Initialized
INFO - 2017-10-10 20:07:53 --> Router Class Initialized
INFO - 2017-10-10 20:07:53 --> Output Class Initialized
INFO - 2017-10-10 20:07:53 --> Security Class Initialized
DEBUG - 2017-10-10 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-10 20:07:53 --> Input Class Initialized
INFO - 2017-10-10 20:07:53 --> Language Class Initialized
ERROR - 2017-10-10 20:07:53 --> 404 Page Not Found: Assets/uploads
