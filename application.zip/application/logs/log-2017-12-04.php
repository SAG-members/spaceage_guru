<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-04 13:53:21 --> 404 Page Not Found: User/add
ERROR - 2017-12-04 13:53:35 --> 404 Page Not Found: User/add
ERROR - 2017-12-04 13:56:53 --> Severity: Notice --> Array to string conversion /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 741
ERROR - 2017-12-04 13:57:06 --> Severity: Notice --> Array to string conversion /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 741
ERROR - 2017-12-04 18:48:18 --> 404 Page Not Found: Assets/img
ERROR - 2017-12-04 18:49:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-12-04 18:50:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-12-04 18:50:45 --> 404 Page Not Found: Assets/img
ERROR - 2017-12-04 18:53:49 --> 404 Page Not Found: Assets/img
ERROR - 2017-12-04 19:12:51 --> 404 Page Not Found: Assets/uploads
