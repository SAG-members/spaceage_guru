<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-30 12:10:09 --> Config Class Initialized
INFO - 2017-10-30 12:10:09 --> Hooks Class Initialized
DEBUG - 2017-10-30 12:10:09 --> UTF-8 Support Enabled
INFO - 2017-10-30 12:10:09 --> Utf8 Class Initialized
INFO - 2017-10-30 12:10:09 --> URI Class Initialized
INFO - 2017-10-30 12:10:09 --> Router Class Initialized
INFO - 2017-10-30 12:10:09 --> Output Class Initialized
INFO - 2017-10-30 12:10:09 --> Security Class Initialized
DEBUG - 2017-10-30 12:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 12:10:09 --> Input Class Initialized
INFO - 2017-10-30 12:10:09 --> Language Class Initialized
INFO - 2017-10-30 12:10:09 --> Loader Class Initialized
INFO - 2017-10-30 12:10:09 --> Helper loaded: url_helper
INFO - 2017-10-30 12:10:09 --> Helper loaded: common_helper
INFO - 2017-10-30 12:10:09 --> Database Driver Class Initialized
DEBUG - 2017-10-30 12:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 12:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 12:10:09 --> Email Class Initialized
INFO - 2017-10-30 12:10:09 --> Model Class Initialized
INFO - 2017-10-30 12:10:09 --> Controller Class Initialized
INFO - 2017-10-30 12:10:09 --> Helper loaded: cookie_helper
INFO - 2017-10-30 12:10:09 --> Model Class Initialized
INFO - 2017-10-30 12:10:09 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:10 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Config Class Initialized
INFO - 2017-10-30 12:10:11 --> Hooks Class Initialized
DEBUG - 2017-10-30 12:10:11 --> UTF-8 Support Enabled
INFO - 2017-10-30 12:10:11 --> Utf8 Class Initialized
INFO - 2017-10-30 12:10:11 --> URI Class Initialized
INFO - 2017-10-30 12:10:11 --> Router Class Initialized
INFO - 2017-10-30 12:10:11 --> Output Class Initialized
INFO - 2017-10-30 12:10:11 --> Security Class Initialized
DEBUG - 2017-10-30 12:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 12:10:11 --> Input Class Initialized
INFO - 2017-10-30 12:10:11 --> Language Class Initialized
INFO - 2017-10-30 12:10:11 --> Loader Class Initialized
INFO - 2017-10-30 12:10:11 --> Helper loaded: url_helper
INFO - 2017-10-30 12:10:11 --> Helper loaded: common_helper
INFO - 2017-10-30 12:10:11 --> Database Driver Class Initialized
DEBUG - 2017-10-30 12:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 12:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 12:10:11 --> Email Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Controller Class Initialized
INFO - 2017-10-30 12:10:11 --> Helper loaded: cookie_helper
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> Model Class Initialized
INFO - 2017-10-30 12:10:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 12:10:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 12:10:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-30 12:10:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 12:10:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 12:10:11 --> Final output sent to browser
DEBUG - 2017-10-30 12:10:11 --> Total execution time: 0.2144
INFO - 2017-10-30 12:10:16 --> Config Class Initialized
INFO - 2017-10-30 12:10:16 --> Hooks Class Initialized
DEBUG - 2017-10-30 12:10:16 --> UTF-8 Support Enabled
INFO - 2017-10-30 12:10:16 --> Utf8 Class Initialized
INFO - 2017-10-30 12:10:16 --> URI Class Initialized
INFO - 2017-10-30 12:10:16 --> Router Class Initialized
INFO - 2017-10-30 12:10:16 --> Output Class Initialized
INFO - 2017-10-30 12:10:16 --> Security Class Initialized
DEBUG - 2017-10-30 12:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 12:10:16 --> Input Class Initialized
INFO - 2017-10-30 12:10:16 --> Language Class Initialized
INFO - 2017-10-30 12:10:16 --> Loader Class Initialized
INFO - 2017-10-30 12:10:16 --> Helper loaded: url_helper
INFO - 2017-10-30 12:10:16 --> Helper loaded: common_helper
INFO - 2017-10-30 12:10:16 --> Database Driver Class Initialized
DEBUG - 2017-10-30 12:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 12:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 12:10:16 --> Email Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Controller Class Initialized
INFO - 2017-10-30 12:10:16 --> Helper loaded: cookie_helper
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> Model Class Initialized
INFO - 2017-10-30 12:10:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 12:10:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-30 12:10:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 12:10:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-30 12:10:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 12:10:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 12:10:17 --> Final output sent to browser
DEBUG - 2017-10-30 12:10:17 --> Total execution time: 0.4689
INFO - 2017-10-30 14:51:07 --> Config Class Initialized
INFO - 2017-10-30 14:51:07 --> Hooks Class Initialized
DEBUG - 2017-10-30 14:51:07 --> UTF-8 Support Enabled
INFO - 2017-10-30 14:51:07 --> Utf8 Class Initialized
INFO - 2017-10-30 14:51:07 --> URI Class Initialized
INFO - 2017-10-30 14:51:07 --> Router Class Initialized
INFO - 2017-10-30 14:51:07 --> Output Class Initialized
INFO - 2017-10-30 14:51:07 --> Security Class Initialized
DEBUG - 2017-10-30 14:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 14:51:07 --> Input Class Initialized
INFO - 2017-10-30 14:51:07 --> Language Class Initialized
INFO - 2017-10-30 14:51:07 --> Loader Class Initialized
INFO - 2017-10-30 14:51:07 --> Helper loaded: url_helper
INFO - 2017-10-30 14:51:07 --> Helper loaded: common_helper
INFO - 2017-10-30 14:51:07 --> Database Driver Class Initialized
DEBUG - 2017-10-30 14:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 14:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 14:51:07 --> Email Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Controller Class Initialized
INFO - 2017-10-30 14:51:07 --> Helper loaded: cookie_helper
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:07 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Config Class Initialized
INFO - 2017-10-30 14:51:08 --> Hooks Class Initialized
DEBUG - 2017-10-30 14:51:08 --> UTF-8 Support Enabled
INFO - 2017-10-30 14:51:08 --> Utf8 Class Initialized
INFO - 2017-10-30 14:51:08 --> URI Class Initialized
INFO - 2017-10-30 14:51:08 --> Router Class Initialized
INFO - 2017-10-30 14:51:08 --> Output Class Initialized
INFO - 2017-10-30 14:51:08 --> Security Class Initialized
DEBUG - 2017-10-30 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 14:51:08 --> Input Class Initialized
INFO - 2017-10-30 14:51:08 --> Language Class Initialized
INFO - 2017-10-30 14:51:08 --> Loader Class Initialized
INFO - 2017-10-30 14:51:08 --> Helper loaded: url_helper
INFO - 2017-10-30 14:51:08 --> Helper loaded: common_helper
INFO - 2017-10-30 14:51:08 --> Database Driver Class Initialized
DEBUG - 2017-10-30 14:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 14:51:08 --> Email Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Controller Class Initialized
INFO - 2017-10-30 14:51:08 --> Helper loaded: cookie_helper
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> Model Class Initialized
INFO - 2017-10-30 14:51:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 14:51:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 14:51:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-30 14:51:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 14:51:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 14:51:08 --> Final output sent to browser
DEBUG - 2017-10-30 14:51:08 --> Total execution time: 0.0229
INFO - 2017-10-30 14:51:12 --> Config Class Initialized
INFO - 2017-10-30 14:51:12 --> Hooks Class Initialized
DEBUG - 2017-10-30 14:51:12 --> UTF-8 Support Enabled
INFO - 2017-10-30 14:51:12 --> Utf8 Class Initialized
INFO - 2017-10-30 14:51:12 --> URI Class Initialized
INFO - 2017-10-30 14:51:12 --> Router Class Initialized
INFO - 2017-10-30 14:51:12 --> Output Class Initialized
INFO - 2017-10-30 14:51:12 --> Security Class Initialized
DEBUG - 2017-10-30 14:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 14:51:12 --> Input Class Initialized
INFO - 2017-10-30 14:51:12 --> Language Class Initialized
INFO - 2017-10-30 14:51:12 --> Loader Class Initialized
INFO - 2017-10-30 14:51:12 --> Helper loaded: url_helper
INFO - 2017-10-30 14:51:12 --> Helper loaded: common_helper
INFO - 2017-10-30 14:51:12 --> Database Driver Class Initialized
DEBUG - 2017-10-30 14:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 14:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 14:51:12 --> Email Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Controller Class Initialized
INFO - 2017-10-30 14:51:12 --> Helper loaded: cookie_helper
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:12 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> Model Class Initialized
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 14:51:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 14:51:13 --> Final output sent to browser
DEBUG - 2017-10-30 14:51:13 --> Total execution time: 0.1313
INFO - 2017-10-30 18:55:28 --> Config Class Initialized
INFO - 2017-10-30 18:55:28 --> Hooks Class Initialized
DEBUG - 2017-10-30 18:55:28 --> UTF-8 Support Enabled
INFO - 2017-10-30 18:55:28 --> Utf8 Class Initialized
INFO - 2017-10-30 18:55:28 --> URI Class Initialized
INFO - 2017-10-30 18:55:28 --> Router Class Initialized
INFO - 2017-10-30 18:55:28 --> Output Class Initialized
INFO - 2017-10-30 18:55:28 --> Security Class Initialized
DEBUG - 2017-10-30 18:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 18:55:28 --> Input Class Initialized
INFO - 2017-10-30 18:55:28 --> Language Class Initialized
INFO - 2017-10-30 18:55:28 --> Loader Class Initialized
INFO - 2017-10-30 18:55:28 --> Helper loaded: url_helper
INFO - 2017-10-30 18:55:28 --> Helper loaded: common_helper
INFO - 2017-10-30 18:55:28 --> Database Driver Class Initialized
DEBUG - 2017-10-30 18:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 18:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 18:55:28 --> Email Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Controller Class Initialized
INFO - 2017-10-30 18:55:28 --> Helper loaded: cookie_helper
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:28 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Config Class Initialized
INFO - 2017-10-30 18:55:29 --> Hooks Class Initialized
DEBUG - 2017-10-30 18:55:29 --> UTF-8 Support Enabled
INFO - 2017-10-30 18:55:29 --> Utf8 Class Initialized
INFO - 2017-10-30 18:55:29 --> URI Class Initialized
INFO - 2017-10-30 18:55:29 --> Router Class Initialized
INFO - 2017-10-30 18:55:29 --> Output Class Initialized
INFO - 2017-10-30 18:55:29 --> Security Class Initialized
DEBUG - 2017-10-30 18:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 18:55:29 --> Input Class Initialized
INFO - 2017-10-30 18:55:29 --> Language Class Initialized
INFO - 2017-10-30 18:55:29 --> Loader Class Initialized
INFO - 2017-10-30 18:55:29 --> Helper loaded: url_helper
INFO - 2017-10-30 18:55:29 --> Helper loaded: common_helper
INFO - 2017-10-30 18:55:29 --> Database Driver Class Initialized
DEBUG - 2017-10-30 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 18:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 18:55:29 --> Email Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Controller Class Initialized
INFO - 2017-10-30 18:55:29 --> Helper loaded: cookie_helper
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> Model Class Initialized
INFO - 2017-10-30 18:55:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 18:55:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 18:55:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-30 18:55:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 18:55:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 18:55:29 --> Final output sent to browser
DEBUG - 2017-10-30 18:55:29 --> Total execution time: 0.0216
INFO - 2017-10-30 18:55:30 --> Config Class Initialized
INFO - 2017-10-30 18:55:30 --> Hooks Class Initialized
DEBUG - 2017-10-30 18:55:30 --> UTF-8 Support Enabled
INFO - 2017-10-30 18:55:30 --> Utf8 Class Initialized
INFO - 2017-10-30 18:55:30 --> URI Class Initialized
INFO - 2017-10-30 18:55:30 --> Router Class Initialized
INFO - 2017-10-30 18:55:30 --> Output Class Initialized
INFO - 2017-10-30 18:55:30 --> Security Class Initialized
DEBUG - 2017-10-30 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 18:55:30 --> Input Class Initialized
INFO - 2017-10-30 18:55:30 --> Language Class Initialized
INFO - 2017-10-30 18:55:30 --> Loader Class Initialized
INFO - 2017-10-30 18:55:30 --> Helper loaded: url_helper
INFO - 2017-10-30 18:55:30 --> Helper loaded: common_helper
INFO - 2017-10-30 18:55:30 --> Database Driver Class Initialized
DEBUG - 2017-10-30 18:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 18:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 18:55:30 --> Email Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Controller Class Initialized
INFO - 2017-10-30 18:55:30 --> Helper loaded: cookie_helper
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> Model Class Initialized
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 18:55:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 18:55:30 --> Final output sent to browser
DEBUG - 2017-10-30 18:55:30 --> Total execution time: 0.2156
INFO - 2017-10-30 19:31:44 --> Config Class Initialized
INFO - 2017-10-30 19:31:44 --> Hooks Class Initialized
DEBUG - 2017-10-30 19:31:44 --> UTF-8 Support Enabled
INFO - 2017-10-30 19:31:44 --> Utf8 Class Initialized
INFO - 2017-10-30 19:31:44 --> URI Class Initialized
INFO - 2017-10-30 19:31:44 --> Router Class Initialized
INFO - 2017-10-30 19:31:44 --> Output Class Initialized
INFO - 2017-10-30 19:31:44 --> Security Class Initialized
DEBUG - 2017-10-30 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-30 19:31:44 --> Input Class Initialized
INFO - 2017-10-30 19:31:44 --> Language Class Initialized
INFO - 2017-10-30 19:31:44 --> Loader Class Initialized
INFO - 2017-10-30 19:31:44 --> Helper loaded: url_helper
INFO - 2017-10-30 19:31:44 --> Helper loaded: common_helper
INFO - 2017-10-30 19:31:44 --> Database Driver Class Initialized
DEBUG - 2017-10-30 19:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-30 19:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-30 19:31:44 --> Email Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Controller Class Initialized
INFO - 2017-10-30 19:31:44 --> Helper loaded: cookie_helper
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> Model Class Initialized
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-30 19:31:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-30 19:31:44 --> Final output sent to browser
DEBUG - 2017-10-30 19:31:44 --> Total execution time: 0.0273
