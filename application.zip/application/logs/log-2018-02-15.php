<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-15 14:59:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 18:56:23 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 79
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 80
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 81
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 82
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 83
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 84
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 85
ERROR - 2018-02-15 18:56:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 86
ERROR - 2018-02-15 18:56:40 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 18:56:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:18 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:25 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:25 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:09:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:48:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 19:49:22 --> Query error: Column 'subscription_type' cannot be null - Invalid query: INSERT INTO `user_subscription` (`txn_id`, `user_id`, `item_id`, `item_name`, `category_id`, `gross_amount`, `payment_mode`, `currency`, `payer_email`, `subscription_date`, `subscription_expiry`, `subscription_type`) VALUES ('ABCD123456', '8', '18', 'MEMBERSHIP C', '3', '1000', 1, 'EUR', 'test@test.com', '2018-02-15 19:49:22', '2018-03-15 19:49:22', NULL)
ERROR - 2018-02-15 19:53:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 19:53:55 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:53:55 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:53:55 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:53:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-02-15 19:54:16 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:54:16 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:54:16 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:54:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:54:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-15 19:54:20 --> 404 Page Not Found: Assets/uploads
