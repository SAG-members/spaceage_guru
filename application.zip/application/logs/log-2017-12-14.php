<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-14 13:53:53 --> Query error: Column 'device_id' cannot be null - Invalid query: INSERT INTO `user_devices` (`user_id`, `device_id`, `device_token`, `device_type`, `date_created`) VALUES ('8', NULL, NULL, NULL, '2017-12-14 13:53:53')
ERROR - 2017-12-14 13:54:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 2700
ERROR - 2017-12-14 13:54:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 2701
ERROR - 2017-12-14 13:54:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 2702
ERROR - 2017-12-14 15:24:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:24:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 79
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 80
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 81
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 82
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 83
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 84
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 85
ERROR - 2017-12-14 15:24:54 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 86
ERROR - 2017-12-14 15:24:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:24:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:25:05 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 79
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 80
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 81
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 82
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 83
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 84
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 85
ERROR - 2017-12-14 15:25:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/Faq.php 86
ERROR - 2017-12-14 15:25:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:25:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 15:27:20 --> 404 Page Not Found: Assets/admin
ERROR - 2017-12-14 17:22:09 --> Severity: Notice --> Undefined index: success /var/www/html/spaceage_guru/application/controllers/module/services/Library.php 230
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 29
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 30
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 31
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 33
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 45
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 4
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 8
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 9
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 82
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 101
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 103
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 112
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 706
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 711
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 712
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 837
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 840
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 850
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 853
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 865
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 884
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 939
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 969
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 971
ERROR - 2017-12-14 18:30:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 1182
ERROR - 2017-12-14 18:30:51 --> Severity: Warning --> Missing argument 9 for Psss_purchase_history::create_purchase_history(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 919 and defined /var/www/html/spaceage_guru/application/models/Psss_purchase_history.php 29
ERROR - 2017-12-14 18:30:51 --> Severity: Notice --> Undefined variable: paymentMode /var/www/html/spaceage_guru/application/models/Psss_purchase_history.php 45
ERROR - 2017-12-14 18:30:51 --> Query error: Column 'payment_mode' cannot be null - Invalid query: INSERT INTO `psss_purchase_history` (`txn_id`, `user_id`, `item_id`, `item_name`, `category_id`, `gross_amount`, `currency`, `payer_email`, `purchase_date`, `payment_mode`) VALUES ('PRICELESS', '27', 177, 'test2', '1', 0, 'EUR', 'hunny226@gmail.com', '2017-12-14 18:30:51', NULL)
ERROR - 2017-12-14 18:31:04 --> Severity: Warning --> Missing argument 9 for Psss_purchase_history::create_purchase_history(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 919 and defined /var/www/html/spaceage_guru/application/models/Psss_purchase_history.php 29
ERROR - 2017-12-14 18:31:04 --> Severity: Notice --> Undefined variable: paymentMode /var/www/html/spaceage_guru/application/models/Psss_purchase_history.php 45
ERROR - 2017-12-14 18:31:04 --> Query error: Column 'payment_mode' cannot be null - Invalid query: INSERT INTO `psss_purchase_history` (`txn_id`, `user_id`, `item_id`, `item_name`, `category_id`, `gross_amount`, `currency`, `payer_email`, `purchase_date`, `payment_mode`) VALUES ('PRICELESS', '27', 177, 'test2', '1', 0, 'EUR', 'hunny226@gmail.com', '2017-12-14 18:31:04', NULL)
