<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-27 10:32:13 --> Config Class Initialized
INFO - 2017-10-27 10:32:13 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:32:13 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:32:13 --> Utf8 Class Initialized
INFO - 2017-10-27 10:32:13 --> URI Class Initialized
DEBUG - 2017-10-27 10:32:13 --> No URI present. Default controller set.
INFO - 2017-10-27 10:32:13 --> Router Class Initialized
INFO - 2017-10-27 10:32:13 --> Output Class Initialized
INFO - 2017-10-27 10:32:13 --> Security Class Initialized
DEBUG - 2017-10-27 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:32:13 --> Input Class Initialized
INFO - 2017-10-27 10:32:13 --> Language Class Initialized
INFO - 2017-10-27 10:32:14 --> Loader Class Initialized
INFO - 2017-10-27 10:32:14 --> Helper loaded: url_helper
INFO - 2017-10-27 10:32:14 --> Helper loaded: common_helper
INFO - 2017-10-27 10:32:14 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:32:14 --> Email Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Controller Class Initialized
INFO - 2017-10-27 10:32:14 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> Model Class Initialized
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 10:32:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 10:32:14 --> Final output sent to browser
DEBUG - 2017-10-27 10:32:14 --> Total execution time: 1.0442
INFO - 2017-10-27 10:32:34 --> Config Class Initialized
INFO - 2017-10-27 10:32:34 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:32:34 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:32:34 --> Utf8 Class Initialized
INFO - 2017-10-27 10:32:34 --> URI Class Initialized
INFO - 2017-10-27 10:32:34 --> Router Class Initialized
INFO - 2017-10-27 10:32:34 --> Output Class Initialized
INFO - 2017-10-27 10:32:34 --> Security Class Initialized
DEBUG - 2017-10-27 10:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:32:34 --> Input Class Initialized
INFO - 2017-10-27 10:32:34 --> Language Class Initialized
INFO - 2017-10-27 10:32:34 --> Loader Class Initialized
INFO - 2017-10-27 10:32:34 --> Helper loaded: url_helper
INFO - 2017-10-27 10:32:34 --> Helper loaded: common_helper
INFO - 2017-10-27 10:32:34 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:32:34 --> Email Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Controller Class Initialized
INFO - 2017-10-27 10:32:34 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> Model Class Initialized
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 10:32:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 10:32:34 --> Final output sent to browser
DEBUG - 2017-10-27 10:32:34 --> Total execution time: 0.2464
INFO - 2017-10-27 10:32:39 --> Config Class Initialized
INFO - 2017-10-27 10:32:39 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:32:39 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:32:39 --> Utf8 Class Initialized
INFO - 2017-10-27 10:32:39 --> URI Class Initialized
INFO - 2017-10-27 10:32:39 --> Router Class Initialized
INFO - 2017-10-27 10:32:39 --> Output Class Initialized
INFO - 2017-10-27 10:32:39 --> Security Class Initialized
DEBUG - 2017-10-27 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:32:39 --> Input Class Initialized
INFO - 2017-10-27 10:32:39 --> Language Class Initialized
INFO - 2017-10-27 10:32:39 --> Loader Class Initialized
INFO - 2017-10-27 10:32:39 --> Helper loaded: url_helper
INFO - 2017-10-27 10:32:39 --> Helper loaded: common_helper
INFO - 2017-10-27 10:32:39 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:32:39 --> Email Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Controller Class Initialized
INFO - 2017-10-27 10:32:39 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> Model Class Initialized
INFO - 2017-10-27 10:32:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:32:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:32:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 10:32:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 10:32:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 10:32:39 --> Final output sent to browser
DEBUG - 2017-10-27 10:32:39 --> Total execution time: 0.3510
INFO - 2017-10-27 10:32:41 --> Config Class Initialized
INFO - 2017-10-27 10:32:41 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:32:41 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:32:41 --> Utf8 Class Initialized
INFO - 2017-10-27 10:32:41 --> URI Class Initialized
INFO - 2017-10-27 10:32:41 --> Router Class Initialized
INFO - 2017-10-27 10:32:41 --> Output Class Initialized
INFO - 2017-10-27 10:32:41 --> Security Class Initialized
DEBUG - 2017-10-27 10:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:32:41 --> Input Class Initialized
INFO - 2017-10-27 10:32:41 --> Language Class Initialized
INFO - 2017-10-27 10:32:41 --> Loader Class Initialized
INFO - 2017-10-27 10:32:41 --> Helper loaded: url_helper
INFO - 2017-10-27 10:32:41 --> Helper loaded: common_helper
INFO - 2017-10-27 10:32:41 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:32:41 --> Email Class Initialized
INFO - 2017-10-27 10:32:41 --> Model Class Initialized
INFO - 2017-10-27 10:32:41 --> Controller Class Initialized
INFO - 2017-10-27 10:32:41 --> Model Class Initialized
INFO - 2017-10-27 10:32:41 --> Final output sent to browser
DEBUG - 2017-10-27 10:32:41 --> Total execution time: 0.0516
INFO - 2017-10-27 10:32:47 --> Config Class Initialized
INFO - 2017-10-27 10:32:47 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:32:47 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:32:47 --> Utf8 Class Initialized
INFO - 2017-10-27 10:32:47 --> URI Class Initialized
INFO - 2017-10-27 10:32:47 --> Router Class Initialized
INFO - 2017-10-27 10:32:47 --> Output Class Initialized
INFO - 2017-10-27 10:32:47 --> Security Class Initialized
DEBUG - 2017-10-27 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:32:47 --> Input Class Initialized
INFO - 2017-10-27 10:32:47 --> Language Class Initialized
INFO - 2017-10-27 10:32:47 --> Loader Class Initialized
INFO - 2017-10-27 10:32:47 --> Helper loaded: url_helper
INFO - 2017-10-27 10:32:47 --> Helper loaded: common_helper
INFO - 2017-10-27 10:32:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:32:47 --> Email Class Initialized
INFO - 2017-10-27 10:32:47 --> Model Class Initialized
INFO - 2017-10-27 10:32:47 --> Controller Class Initialized
INFO - 2017-10-27 10:32:47 --> Final output sent to browser
DEBUG - 2017-10-27 10:32:47 --> Total execution time: 0.0474
INFO - 2017-10-27 10:39:11 --> Config Class Initialized
INFO - 2017-10-27 10:39:11 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:39:11 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:39:11 --> Utf8 Class Initialized
INFO - 2017-10-27 10:39:11 --> URI Class Initialized
INFO - 2017-10-27 10:39:11 --> Router Class Initialized
INFO - 2017-10-27 10:39:11 --> Output Class Initialized
INFO - 2017-10-27 10:39:11 --> Security Class Initialized
DEBUG - 2017-10-27 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:39:11 --> Input Class Initialized
INFO - 2017-10-27 10:39:11 --> Language Class Initialized
INFO - 2017-10-27 10:39:11 --> Loader Class Initialized
INFO - 2017-10-27 10:39:11 --> Helper loaded: url_helper
INFO - 2017-10-27 10:39:11 --> Helper loaded: common_helper
INFO - 2017-10-27 10:39:11 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:39:11 --> Email Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Controller Class Initialized
INFO - 2017-10-27 10:39:11 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> Model Class Initialized
INFO - 2017-10-27 10:39:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:39:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:39:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 10:39:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 10:39:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 10:39:11 --> Final output sent to browser
DEBUG - 2017-10-27 10:39:11 --> Total execution time: 0.0300
INFO - 2017-10-27 10:39:12 --> Config Class Initialized
INFO - 2017-10-27 10:39:12 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:39:12 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:39:12 --> Utf8 Class Initialized
INFO - 2017-10-27 10:39:12 --> URI Class Initialized
INFO - 2017-10-27 10:39:12 --> Router Class Initialized
INFO - 2017-10-27 10:39:12 --> Output Class Initialized
INFO - 2017-10-27 10:39:12 --> Security Class Initialized
DEBUG - 2017-10-27 10:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:39:12 --> Input Class Initialized
INFO - 2017-10-27 10:39:12 --> Language Class Initialized
INFO - 2017-10-27 10:39:12 --> Loader Class Initialized
INFO - 2017-10-27 10:39:12 --> Helper loaded: url_helper
INFO - 2017-10-27 10:39:12 --> Helper loaded: common_helper
INFO - 2017-10-27 10:39:12 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:39:12 --> Email Class Initialized
INFO - 2017-10-27 10:39:12 --> Model Class Initialized
INFO - 2017-10-27 10:39:12 --> Controller Class Initialized
INFO - 2017-10-27 10:39:12 --> Model Class Initialized
INFO - 2017-10-27 10:39:12 --> Final output sent to browser
DEBUG - 2017-10-27 10:39:12 --> Total execution time: 0.0032
INFO - 2017-10-27 10:39:13 --> Config Class Initialized
INFO - 2017-10-27 10:39:13 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:39:13 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:39:13 --> Utf8 Class Initialized
INFO - 2017-10-27 10:39:13 --> URI Class Initialized
INFO - 2017-10-27 10:39:13 --> Router Class Initialized
INFO - 2017-10-27 10:39:13 --> Output Class Initialized
INFO - 2017-10-27 10:39:13 --> Security Class Initialized
DEBUG - 2017-10-27 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:39:13 --> Input Class Initialized
INFO - 2017-10-27 10:39:13 --> Language Class Initialized
INFO - 2017-10-27 10:39:13 --> Loader Class Initialized
INFO - 2017-10-27 10:39:13 --> Helper loaded: url_helper
INFO - 2017-10-27 10:39:13 --> Helper loaded: common_helper
INFO - 2017-10-27 10:39:13 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:39:13 --> Email Class Initialized
INFO - 2017-10-27 10:39:13 --> Model Class Initialized
INFO - 2017-10-27 10:39:13 --> Controller Class Initialized
INFO - 2017-10-27 10:39:13 --> Final output sent to browser
DEBUG - 2017-10-27 10:39:13 --> Total execution time: 0.0023
INFO - 2017-10-27 10:40:20 --> Config Class Initialized
INFO - 2017-10-27 10:40:20 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:40:20 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:40:20 --> Utf8 Class Initialized
INFO - 2017-10-27 10:40:20 --> URI Class Initialized
INFO - 2017-10-27 10:40:20 --> Router Class Initialized
INFO - 2017-10-27 10:40:20 --> Output Class Initialized
INFO - 2017-10-27 10:40:20 --> Security Class Initialized
DEBUG - 2017-10-27 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:40:20 --> Input Class Initialized
INFO - 2017-10-27 10:40:20 --> Language Class Initialized
INFO - 2017-10-27 10:40:20 --> Loader Class Initialized
INFO - 2017-10-27 10:40:20 --> Helper loaded: url_helper
INFO - 2017-10-27 10:40:20 --> Helper loaded: common_helper
INFO - 2017-10-27 10:40:20 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:40:20 --> Email Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Controller Class Initialized
INFO - 2017-10-27 10:40:20 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:40:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:40:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 10:40:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 10:40:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 10:40:20 --> Final output sent to browser
DEBUG - 2017-10-27 10:40:20 --> Total execution time: 0.0291
INFO - 2017-10-27 10:40:20 --> Config Class Initialized
INFO - 2017-10-27 10:40:20 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:40:20 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:40:20 --> Utf8 Class Initialized
INFO - 2017-10-27 10:40:20 --> URI Class Initialized
INFO - 2017-10-27 10:40:20 --> Router Class Initialized
INFO - 2017-10-27 10:40:20 --> Output Class Initialized
INFO - 2017-10-27 10:40:20 --> Security Class Initialized
DEBUG - 2017-10-27 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:40:20 --> Input Class Initialized
INFO - 2017-10-27 10:40:20 --> Language Class Initialized
INFO - 2017-10-27 10:40:20 --> Loader Class Initialized
INFO - 2017-10-27 10:40:20 --> Helper loaded: url_helper
INFO - 2017-10-27 10:40:20 --> Helper loaded: common_helper
INFO - 2017-10-27 10:40:20 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:40:20 --> Email Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Controller Class Initialized
INFO - 2017-10-27 10:40:20 --> Model Class Initialized
INFO - 2017-10-27 10:40:20 --> Final output sent to browser
DEBUG - 2017-10-27 10:40:20 --> Total execution time: 0.0021
INFO - 2017-10-27 10:40:21 --> Config Class Initialized
INFO - 2017-10-27 10:40:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:40:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:40:21 --> Utf8 Class Initialized
INFO - 2017-10-27 10:40:21 --> URI Class Initialized
INFO - 2017-10-27 10:40:21 --> Router Class Initialized
INFO - 2017-10-27 10:40:21 --> Output Class Initialized
INFO - 2017-10-27 10:40:21 --> Security Class Initialized
DEBUG - 2017-10-27 10:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:40:21 --> Input Class Initialized
INFO - 2017-10-27 10:40:21 --> Language Class Initialized
INFO - 2017-10-27 10:40:21 --> Loader Class Initialized
INFO - 2017-10-27 10:40:21 --> Helper loaded: url_helper
INFO - 2017-10-27 10:40:21 --> Helper loaded: common_helper
INFO - 2017-10-27 10:40:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:40:21 --> Email Class Initialized
INFO - 2017-10-27 10:40:21 --> Model Class Initialized
INFO - 2017-10-27 10:40:21 --> Controller Class Initialized
INFO - 2017-10-27 10:40:21 --> Final output sent to browser
DEBUG - 2017-10-27 10:40:21 --> Total execution time: 0.0023
INFO - 2017-10-27 10:54:19 --> Config Class Initialized
INFO - 2017-10-27 10:54:19 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:54:19 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:54:19 --> Utf8 Class Initialized
INFO - 2017-10-27 10:54:19 --> URI Class Initialized
INFO - 2017-10-27 10:54:19 --> Router Class Initialized
INFO - 2017-10-27 10:54:19 --> Output Class Initialized
INFO - 2017-10-27 10:54:19 --> Security Class Initialized
DEBUG - 2017-10-27 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:54:19 --> Input Class Initialized
INFO - 2017-10-27 10:54:19 --> Language Class Initialized
INFO - 2017-10-27 10:54:19 --> Loader Class Initialized
INFO - 2017-10-27 10:54:19 --> Helper loaded: url_helper
INFO - 2017-10-27 10:54:19 --> Helper loaded: common_helper
INFO - 2017-10-27 10:54:19 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:54:19 --> Email Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Controller Class Initialized
INFO - 2017-10-27 10:54:19 --> Helper loaded: cookie_helper
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 10:54:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 10:54:19 --> Final output sent to browser
DEBUG - 2017-10-27 10:54:19 --> Total execution time: 0.0309
INFO - 2017-10-27 10:54:19 --> Config Class Initialized
INFO - 2017-10-27 10:54:19 --> Hooks Class Initialized
DEBUG - 2017-10-27 10:54:19 --> UTF-8 Support Enabled
INFO - 2017-10-27 10:54:19 --> Utf8 Class Initialized
INFO - 2017-10-27 10:54:19 --> URI Class Initialized
INFO - 2017-10-27 10:54:19 --> Router Class Initialized
INFO - 2017-10-27 10:54:19 --> Output Class Initialized
INFO - 2017-10-27 10:54:19 --> Security Class Initialized
DEBUG - 2017-10-27 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 10:54:19 --> Input Class Initialized
INFO - 2017-10-27 10:54:19 --> Language Class Initialized
INFO - 2017-10-27 10:54:19 --> Loader Class Initialized
INFO - 2017-10-27 10:54:19 --> Helper loaded: url_helper
INFO - 2017-10-27 10:54:19 --> Helper loaded: common_helper
INFO - 2017-10-27 10:54:19 --> Database Driver Class Initialized
DEBUG - 2017-10-27 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 10:54:19 --> Email Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Controller Class Initialized
INFO - 2017-10-27 10:54:19 --> Model Class Initialized
INFO - 2017-10-27 10:54:19 --> Final output sent to browser
DEBUG - 2017-10-27 10:54:19 --> Total execution time: 0.0028
INFO - 2017-10-27 11:09:47 --> Config Class Initialized
INFO - 2017-10-27 11:09:47 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:09:47 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:09:47 --> Utf8 Class Initialized
INFO - 2017-10-27 11:09:47 --> URI Class Initialized
INFO - 2017-10-27 11:09:47 --> Router Class Initialized
INFO - 2017-10-27 11:09:47 --> Output Class Initialized
INFO - 2017-10-27 11:09:47 --> Security Class Initialized
DEBUG - 2017-10-27 11:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:09:47 --> Input Class Initialized
INFO - 2017-10-27 11:09:47 --> Language Class Initialized
INFO - 2017-10-27 11:09:47 --> Loader Class Initialized
INFO - 2017-10-27 11:09:47 --> Helper loaded: url_helper
INFO - 2017-10-27 11:09:47 --> Helper loaded: common_helper
INFO - 2017-10-27 11:09:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:09:47 --> Email Class Initialized
INFO - 2017-10-27 11:09:47 --> Model Class Initialized
INFO - 2017-10-27 11:09:47 --> Controller Class Initialized
INFO - 2017-10-27 11:09:47 --> Final output sent to browser
DEBUG - 2017-10-27 11:09:47 --> Total execution time: 0.0017
INFO - 2017-10-27 11:36:58 --> Config Class Initialized
INFO - 2017-10-27 11:36:58 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:36:58 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:36:58 --> Utf8 Class Initialized
INFO - 2017-10-27 11:36:58 --> URI Class Initialized
INFO - 2017-10-27 11:36:58 --> Router Class Initialized
INFO - 2017-10-27 11:36:58 --> Output Class Initialized
INFO - 2017-10-27 11:36:58 --> Security Class Initialized
DEBUG - 2017-10-27 11:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:36:58 --> Input Class Initialized
INFO - 2017-10-27 11:36:58 --> Language Class Initialized
INFO - 2017-10-27 11:36:58 --> Loader Class Initialized
INFO - 2017-10-27 11:36:58 --> Helper loaded: url_helper
INFO - 2017-10-27 11:36:58 --> Helper loaded: common_helper
INFO - 2017-10-27 11:36:58 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:36:58 --> Email Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Controller Class Initialized
INFO - 2017-10-27 11:36:58 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> Model Class Initialized
INFO - 2017-10-27 11:36:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:36:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:36:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:36:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:36:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 11:36:58 --> Final output sent to browser
DEBUG - 2017-10-27 11:36:58 --> Total execution time: 0.0346
INFO - 2017-10-27 11:36:59 --> Config Class Initialized
INFO - 2017-10-27 11:36:59 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:36:59 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:36:59 --> Utf8 Class Initialized
INFO - 2017-10-27 11:36:59 --> URI Class Initialized
INFO - 2017-10-27 11:36:59 --> Router Class Initialized
INFO - 2017-10-27 11:36:59 --> Output Class Initialized
INFO - 2017-10-27 11:36:59 --> Security Class Initialized
DEBUG - 2017-10-27 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:36:59 --> Input Class Initialized
INFO - 2017-10-27 11:36:59 --> Language Class Initialized
INFO - 2017-10-27 11:36:59 --> Loader Class Initialized
INFO - 2017-10-27 11:36:59 --> Helper loaded: url_helper
INFO - 2017-10-27 11:36:59 --> Helper loaded: common_helper
INFO - 2017-10-27 11:36:59 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:36:59 --> Email Class Initialized
INFO - 2017-10-27 11:36:59 --> Model Class Initialized
INFO - 2017-10-27 11:36:59 --> Controller Class Initialized
INFO - 2017-10-27 11:36:59 --> Model Class Initialized
INFO - 2017-10-27 11:36:59 --> Final output sent to browser
DEBUG - 2017-10-27 11:36:59 --> Total execution time: 0.0046
INFO - 2017-10-27 11:37:02 --> Config Class Initialized
INFO - 2017-10-27 11:37:02 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:37:02 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:37:02 --> Utf8 Class Initialized
INFO - 2017-10-27 11:37:02 --> URI Class Initialized
INFO - 2017-10-27 11:37:02 --> Router Class Initialized
INFO - 2017-10-27 11:37:02 --> Output Class Initialized
INFO - 2017-10-27 11:37:02 --> Security Class Initialized
DEBUG - 2017-10-27 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:37:02 --> Input Class Initialized
INFO - 2017-10-27 11:37:02 --> Language Class Initialized
INFO - 2017-10-27 11:37:02 --> Loader Class Initialized
INFO - 2017-10-27 11:37:02 --> Helper loaded: url_helper
INFO - 2017-10-27 11:37:02 --> Helper loaded: common_helper
INFO - 2017-10-27 11:37:02 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:37:02 --> Email Class Initialized
INFO - 2017-10-27 11:37:02 --> Model Class Initialized
INFO - 2017-10-27 11:37:02 --> Controller Class Initialized
INFO - 2017-10-27 11:37:02 --> Final output sent to browser
DEBUG - 2017-10-27 11:37:02 --> Total execution time: 0.0025
INFO - 2017-10-27 11:37:30 --> Config Class Initialized
INFO - 2017-10-27 11:37:30 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:37:30 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:37:30 --> Utf8 Class Initialized
INFO - 2017-10-27 11:37:30 --> URI Class Initialized
INFO - 2017-10-27 11:37:30 --> Router Class Initialized
INFO - 2017-10-27 11:37:30 --> Output Class Initialized
INFO - 2017-10-27 11:37:30 --> Security Class Initialized
DEBUG - 2017-10-27 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:37:30 --> Input Class Initialized
INFO - 2017-10-27 11:37:30 --> Language Class Initialized
INFO - 2017-10-27 11:37:30 --> Loader Class Initialized
INFO - 2017-10-27 11:37:30 --> Helper loaded: url_helper
INFO - 2017-10-27 11:37:30 --> Helper loaded: common_helper
INFO - 2017-10-27 11:37:30 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:37:30 --> Email Class Initialized
INFO - 2017-10-27 11:37:30 --> Model Class Initialized
INFO - 2017-10-27 11:37:30 --> Controller Class Initialized
INFO - 2017-10-27 11:37:30 --> Model Class Initialized
ERROR - 2017-10-27 11:37:30 --> Severity: Notice --> Undefined index: escrowType /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 483
ERROR - 2017-10-27 11:37:30 --> Severity: Notice --> Use of undefined constant escrowType - assumed 'escrowType' /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 492
ERROR - 2017-10-27 11:37:30 --> Severity: Warning --> Missing argument 12 for Library_event_comment_model::createNewLibraryEventComment(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 498 and defined /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 33
ERROR - 2017-10-27 11:37:30 --> Severity: Notice --> Undefined variable: escrowType /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 50
ERROR - 2017-10-27 11:37:30 --> Query error: Column 'escrow_type' cannot be null - Invalid query: INSERT INTO `user_library_event_comment` (`event_id`, `comment`, `price`, `location`, `address`, `lat`, `lng`, `from_account`, `delivery_method`, `escrow_released`, `date_time`, `escrow_type`, `date_created`) VALUES ('3', 'Test', '2', 'Xantatech -Web Development Company, Noida, Uttar Pradesh, India', '1st Floor, Near Fortis Hospital, Sector 63, G Block, Sector 63, Noida, Uttar Pradesh 201301, India', '28.61844', '77.39083959999994', '1', '1', '1', '2017-11-10 11:37:00', NULL, '2017-10-27 11:37:30')
INFO - 2017-10-27 11:37:30 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-27 11:37:49 --> Config Class Initialized
INFO - 2017-10-27 11:37:49 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:37:49 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:37:49 --> Utf8 Class Initialized
INFO - 2017-10-27 11:37:49 --> URI Class Initialized
INFO - 2017-10-27 11:37:49 --> Router Class Initialized
INFO - 2017-10-27 11:37:49 --> Output Class Initialized
INFO - 2017-10-27 11:37:49 --> Security Class Initialized
DEBUG - 2017-10-27 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:37:49 --> Input Class Initialized
INFO - 2017-10-27 11:37:49 --> Language Class Initialized
INFO - 2017-10-27 11:37:49 --> Loader Class Initialized
INFO - 2017-10-27 11:37:49 --> Helper loaded: url_helper
INFO - 2017-10-27 11:37:49 --> Helper loaded: common_helper
INFO - 2017-10-27 11:37:49 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:37:49 --> Email Class Initialized
INFO - 2017-10-27 11:37:49 --> Model Class Initialized
INFO - 2017-10-27 11:37:49 --> Controller Class Initialized
INFO - 2017-10-27 11:37:49 --> Model Class Initialized
ERROR - 2017-10-27 11:37:49 --> Severity: Notice --> Undefined index: escrowType /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 483
ERROR - 2017-10-27 11:37:49 --> Severity: Notice --> Use of undefined constant escrowType - assumed 'escrowType' /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 492
ERROR - 2017-10-27 11:37:49 --> Severity: Warning --> Missing argument 12 for Library_event_comment_model::createNewLibraryEventComment(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 498 and defined /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 33
ERROR - 2017-10-27 11:37:49 --> Severity: Notice --> Undefined variable: escrowType /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 50
ERROR - 2017-10-27 11:37:49 --> Query error: Column 'escrow_type' cannot be null - Invalid query: INSERT INTO `user_library_event_comment` (`event_id`, `comment`, `price`, `location`, `address`, `lat`, `lng`, `from_account`, `delivery_method`, `escrow_released`, `date_time`, `escrow_type`, `date_created`) VALUES ('3', 'Test', '2', 'Xantatech -Web Development Company, Noida, Uttar Pradesh, India', '1st Floor, Near Fortis Hospital, Sector 63, G Block, Sector 63, Noida, Uttar Pradesh 201301, India', '28.61844', '77.39083959999994', '1', '1', '1', '2017-11-10 11:37:00', NULL, '2017-10-27 11:37:49')
INFO - 2017-10-27 11:37:49 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-27 11:38:04 --> Config Class Initialized
INFO - 2017-10-27 11:38:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:04 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:04 --> URI Class Initialized
INFO - 2017-10-27 11:38:04 --> Router Class Initialized
INFO - 2017-10-27 11:38:04 --> Output Class Initialized
INFO - 2017-10-27 11:38:04 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:04 --> Input Class Initialized
INFO - 2017-10-27 11:38:04 --> Language Class Initialized
INFO - 2017-10-27 11:38:04 --> Loader Class Initialized
INFO - 2017-10-27 11:38:04 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:04 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:04 --> Email Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Controller Class Initialized
INFO - 2017-10-27 11:38:04 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> Model Class Initialized
INFO - 2017-10-27 11:38:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:38:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:38:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:38:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:38:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 11:38:04 --> Final output sent to browser
DEBUG - 2017-10-27 11:38:04 --> Total execution time: 0.0372
INFO - 2017-10-27 11:38:05 --> Config Class Initialized
INFO - 2017-10-27 11:38:05 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:05 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:05 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:05 --> URI Class Initialized
INFO - 2017-10-27 11:38:05 --> Router Class Initialized
INFO - 2017-10-27 11:38:05 --> Output Class Initialized
INFO - 2017-10-27 11:38:05 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:05 --> Input Class Initialized
INFO - 2017-10-27 11:38:05 --> Language Class Initialized
INFO - 2017-10-27 11:38:05 --> Loader Class Initialized
INFO - 2017-10-27 11:38:05 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:05 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:05 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:05 --> Email Class Initialized
INFO - 2017-10-27 11:38:05 --> Model Class Initialized
INFO - 2017-10-27 11:38:05 --> Controller Class Initialized
INFO - 2017-10-27 11:38:05 --> Model Class Initialized
INFO - 2017-10-27 11:38:05 --> Final output sent to browser
DEBUG - 2017-10-27 11:38:05 --> Total execution time: 0.0033
INFO - 2017-10-27 11:38:21 --> Config Class Initialized
INFO - 2017-10-27 11:38:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:21 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:21 --> URI Class Initialized
INFO - 2017-10-27 11:38:21 --> Router Class Initialized
INFO - 2017-10-27 11:38:21 --> Output Class Initialized
INFO - 2017-10-27 11:38:21 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:21 --> Input Class Initialized
INFO - 2017-10-27 11:38:21 --> Language Class Initialized
INFO - 2017-10-27 11:38:21 --> Loader Class Initialized
INFO - 2017-10-27 11:38:21 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:21 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:21 --> Email Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Controller Class Initialized
INFO - 2017-10-27 11:38:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:38:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:38:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:38:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:38:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 11:38:21 --> Final output sent to browser
DEBUG - 2017-10-27 11:38:21 --> Total execution time: 0.0351
INFO - 2017-10-27 11:38:21 --> Config Class Initialized
INFO - 2017-10-27 11:38:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:21 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:21 --> URI Class Initialized
INFO - 2017-10-27 11:38:21 --> Router Class Initialized
INFO - 2017-10-27 11:38:21 --> Output Class Initialized
INFO - 2017-10-27 11:38:21 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:21 --> Input Class Initialized
INFO - 2017-10-27 11:38:21 --> Language Class Initialized
INFO - 2017-10-27 11:38:21 --> Loader Class Initialized
INFO - 2017-10-27 11:38:21 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:21 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:21 --> Email Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Controller Class Initialized
INFO - 2017-10-27 11:38:21 --> Model Class Initialized
INFO - 2017-10-27 11:38:21 --> Final output sent to browser
DEBUG - 2017-10-27 11:38:21 --> Total execution time: 0.0027
INFO - 2017-10-27 11:38:23 --> Config Class Initialized
INFO - 2017-10-27 11:38:23 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:23 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:23 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:23 --> URI Class Initialized
INFO - 2017-10-27 11:38:23 --> Router Class Initialized
INFO - 2017-10-27 11:38:23 --> Output Class Initialized
INFO - 2017-10-27 11:38:23 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:23 --> Input Class Initialized
INFO - 2017-10-27 11:38:23 --> Language Class Initialized
INFO - 2017-10-27 11:38:23 --> Loader Class Initialized
INFO - 2017-10-27 11:38:23 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:23 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:23 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:23 --> Email Class Initialized
INFO - 2017-10-27 11:38:23 --> Model Class Initialized
INFO - 2017-10-27 11:38:23 --> Controller Class Initialized
INFO - 2017-10-27 11:38:23 --> Final output sent to browser
DEBUG - 2017-10-27 11:38:23 --> Total execution time: 0.0017
INFO - 2017-10-27 11:38:47 --> Config Class Initialized
INFO - 2017-10-27 11:38:47 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:38:47 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:38:47 --> Utf8 Class Initialized
INFO - 2017-10-27 11:38:47 --> URI Class Initialized
INFO - 2017-10-27 11:38:47 --> Router Class Initialized
INFO - 2017-10-27 11:38:47 --> Output Class Initialized
INFO - 2017-10-27 11:38:47 --> Security Class Initialized
DEBUG - 2017-10-27 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:38:47 --> Input Class Initialized
INFO - 2017-10-27 11:38:47 --> Language Class Initialized
INFO - 2017-10-27 11:38:47 --> Loader Class Initialized
INFO - 2017-10-27 11:38:47 --> Helper loaded: url_helper
INFO - 2017-10-27 11:38:47 --> Helper loaded: common_helper
INFO - 2017-10-27 11:38:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:38:47 --> Email Class Initialized
INFO - 2017-10-27 11:38:47 --> Model Class Initialized
INFO - 2017-10-27 11:38:47 --> Controller Class Initialized
INFO - 2017-10-27 11:38:47 --> Model Class Initialized
ERROR - 2017-10-27 11:38:47 --> Severity: Notice --> Undefined index: escrowType /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 483
ERROR - 2017-10-27 11:38:47 --> Severity: Notice --> Use of undefined constant escrowType - assumed 'escrowType' /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 492
ERROR - 2017-10-27 11:38:47 --> Severity: Warning --> Missing argument 12 for Library_event_comment_model::createNewLibraryEventComment(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 498 and defined /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 33
ERROR - 2017-10-27 11:38:47 --> Severity: Notice --> Undefined variable: escrowType /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 50
ERROR - 2017-10-27 11:38:47 --> Query error: Column 'escrow_type' cannot be null - Invalid query: INSERT INTO `user_library_event_comment` (`event_id`, `comment`, `price`, `location`, `address`, `lat`, `lng`, `from_account`, `delivery_method`, `escrow_released`, `date_time`, `escrow_type`, `date_created`) VALUES ('3', 'Test', '2', 'Xantatech -Web Development Company, Noida, Uttar Pradesh, India', '1st Floor, Near Fortis Hospital, Sector 63, G Block, Sector 63, Noida, Uttar Pradesh 201301, India', '28.61844', '77.39083959999994', '1', '1', '1', '2017-11-09 11:38:00', NULL, '2017-10-27 11:38:47')
INFO - 2017-10-27 11:38:47 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-27 11:39:21 --> Config Class Initialized
INFO - 2017-10-27 11:39:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:39:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:39:21 --> Utf8 Class Initialized
INFO - 2017-10-27 11:39:21 --> URI Class Initialized
INFO - 2017-10-27 11:39:21 --> Router Class Initialized
INFO - 2017-10-27 11:39:21 --> Output Class Initialized
INFO - 2017-10-27 11:39:21 --> Security Class Initialized
DEBUG - 2017-10-27 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:39:21 --> Input Class Initialized
INFO - 2017-10-27 11:39:21 --> Language Class Initialized
INFO - 2017-10-27 11:39:21 --> Loader Class Initialized
INFO - 2017-10-27 11:39:21 --> Helper loaded: url_helper
INFO - 2017-10-27 11:39:21 --> Helper loaded: common_helper
INFO - 2017-10-27 11:39:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:39:21 --> Email Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Controller Class Initialized
INFO - 2017-10-27 11:39:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:39:21 --> Config Class Initialized
INFO - 2017-10-27 11:39:21 --> Hooks Class Initialized
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
DEBUG - 2017-10-27 11:39:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:39:21 --> Utf8 Class Initialized
INFO - 2017-10-27 11:39:21 --> URI Class Initialized
INFO - 2017-10-27 11:39:21 --> Router Class Initialized
INFO - 2017-10-27 11:39:21 --> Output Class Initialized
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:39:21 --> Security Class Initialized
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
DEBUG - 2017-10-27 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:39:21 --> Input Class Initialized
INFO - 2017-10-27 11:39:21 --> Language Class Initialized
INFO - 2017-10-27 11:39:21 --> Loader Class Initialized
INFO - 2017-10-27 11:39:21 --> Helper loaded: url_helper
INFO - 2017-10-27 11:39:21 --> Helper loaded: common_helper
INFO - 2017-10-27 11:39:21 --> Database Driver Class Initialized
INFO - 2017-10-27 11:39:21 --> Final output sent to browser
DEBUG - 2017-10-27 11:39:21 --> Total execution time: 0.0417
DEBUG - 2017-10-27 11:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:39:21 --> Email Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Controller Class Initialized
INFO - 2017-10-27 11:39:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:39:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 11:39:21 --> Final output sent to browser
DEBUG - 2017-10-27 11:39:21 --> Total execution time: 0.0298
INFO - 2017-10-27 11:39:21 --> Config Class Initialized
INFO - 2017-10-27 11:39:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:39:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:39:21 --> Utf8 Class Initialized
INFO - 2017-10-27 11:39:21 --> URI Class Initialized
INFO - 2017-10-27 11:39:21 --> Router Class Initialized
INFO - 2017-10-27 11:39:21 --> Output Class Initialized
INFO - 2017-10-27 11:39:21 --> Security Class Initialized
DEBUG - 2017-10-27 11:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:39:21 --> Input Class Initialized
INFO - 2017-10-27 11:39:21 --> Language Class Initialized
INFO - 2017-10-27 11:39:21 --> Loader Class Initialized
INFO - 2017-10-27 11:39:21 --> Helper loaded: url_helper
INFO - 2017-10-27 11:39:21 --> Helper loaded: common_helper
INFO - 2017-10-27 11:39:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:39:21 --> Email Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Controller Class Initialized
INFO - 2017-10-27 11:39:21 --> Model Class Initialized
INFO - 2017-10-27 11:39:21 --> Final output sent to browser
DEBUG - 2017-10-27 11:39:21 --> Total execution time: 0.0030
INFO - 2017-10-27 11:39:22 --> Config Class Initialized
INFO - 2017-10-27 11:39:22 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:39:22 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:39:22 --> Utf8 Class Initialized
INFO - 2017-10-27 11:39:22 --> URI Class Initialized
INFO - 2017-10-27 11:39:22 --> Router Class Initialized
INFO - 2017-10-27 11:39:22 --> Output Class Initialized
INFO - 2017-10-27 11:39:22 --> Security Class Initialized
DEBUG - 2017-10-27 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:39:22 --> Input Class Initialized
INFO - 2017-10-27 11:39:22 --> Language Class Initialized
INFO - 2017-10-27 11:39:22 --> Loader Class Initialized
INFO - 2017-10-27 11:39:22 --> Helper loaded: url_helper
INFO - 2017-10-27 11:39:22 --> Helper loaded: common_helper
INFO - 2017-10-27 11:39:22 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:39:22 --> Email Class Initialized
INFO - 2017-10-27 11:39:22 --> Model Class Initialized
INFO - 2017-10-27 11:39:22 --> Controller Class Initialized
INFO - 2017-10-27 11:39:22 --> Final output sent to browser
DEBUG - 2017-10-27 11:39:22 --> Total execution time: 0.0018
INFO - 2017-10-27 11:39:41 --> Config Class Initialized
INFO - 2017-10-27 11:39:41 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:39:41 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:39:41 --> Utf8 Class Initialized
INFO - 2017-10-27 11:39:41 --> URI Class Initialized
INFO - 2017-10-27 11:39:41 --> Router Class Initialized
INFO - 2017-10-27 11:39:41 --> Output Class Initialized
INFO - 2017-10-27 11:39:41 --> Security Class Initialized
DEBUG - 2017-10-27 11:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:39:41 --> Input Class Initialized
INFO - 2017-10-27 11:39:41 --> Language Class Initialized
INFO - 2017-10-27 11:39:41 --> Loader Class Initialized
INFO - 2017-10-27 11:39:41 --> Helper loaded: url_helper
INFO - 2017-10-27 11:39:41 --> Helper loaded: common_helper
INFO - 2017-10-27 11:39:41 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:39:41 --> Email Class Initialized
INFO - 2017-10-27 11:39:41 --> Model Class Initialized
INFO - 2017-10-27 11:39:41 --> Controller Class Initialized
INFO - 2017-10-27 11:39:41 --> Model Class Initialized
ERROR - 2017-10-27 11:39:41 --> Severity: Notice --> Use of undefined constant escrowType - assumed 'escrowType' /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php 492
ERROR - 2017-10-27 11:39:41 --> Severity: Warning --> Missing argument 12 for Library_event_comment_model::createNewLibraryEventComment(), called in /var/www/html/spaceage_guru/application/controllers/Public_ajax_controller.php on line 498 and defined /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 33
ERROR - 2017-10-27 11:39:41 --> Severity: Notice --> Undefined variable: escrowType /var/www/html/spaceage_guru/application/models/Library_event_comment_model.php 50
ERROR - 2017-10-27 11:39:41 --> Query error: Column 'escrow_type' cannot be null - Invalid query: INSERT INTO `user_library_event_comment` (`event_id`, `comment`, `price`, `location`, `address`, `lat`, `lng`, `from_account`, `delivery_method`, `escrow_released`, `date_time`, `escrow_type`, `date_created`) VALUES ('3', 'Test', '2', 'Xantatech -Web Development Company, Noida, Uttar Pradesh, India', '1st Floor, Near Fortis Hospital, Sector 63, G Block, Sector 63, Noida, Uttar Pradesh 201301, India', '28.61844', '77.39083959999994', '1', '1', '1', '2017-11-08 11:39:00', NULL, '2017-10-27 11:39:41')
INFO - 2017-10-27 11:39:41 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-27 11:40:33 --> Config Class Initialized
INFO - 2017-10-27 11:40:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:40:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:40:33 --> Utf8 Class Initialized
INFO - 2017-10-27 11:40:33 --> URI Class Initialized
INFO - 2017-10-27 11:40:33 --> Router Class Initialized
INFO - 2017-10-27 11:40:33 --> Output Class Initialized
INFO - 2017-10-27 11:40:33 --> Security Class Initialized
DEBUG - 2017-10-27 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:40:33 --> Input Class Initialized
INFO - 2017-10-27 11:40:33 --> Language Class Initialized
INFO - 2017-10-27 11:40:33 --> Loader Class Initialized
INFO - 2017-10-27 11:40:33 --> Helper loaded: url_helper
INFO - 2017-10-27 11:40:33 --> Helper loaded: common_helper
INFO - 2017-10-27 11:40:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:40:33 --> Email Class Initialized
INFO - 2017-10-27 11:40:33 --> Model Class Initialized
INFO - 2017-10-27 11:40:33 --> Controller Class Initialized
INFO - 2017-10-27 11:40:33 --> Model Class Initialized
INFO - 2017-10-27 11:40:33 --> Final output sent to browser
DEBUG - 2017-10-27 11:40:33 --> Total execution time: 0.0919
INFO - 2017-10-27 11:40:38 --> Config Class Initialized
INFO - 2017-10-27 11:40:38 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:40:38 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:40:38 --> Utf8 Class Initialized
INFO - 2017-10-27 11:40:38 --> URI Class Initialized
INFO - 2017-10-27 11:40:38 --> Router Class Initialized
INFO - 2017-10-27 11:40:38 --> Output Class Initialized
INFO - 2017-10-27 11:40:38 --> Security Class Initialized
DEBUG - 2017-10-27 11:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:40:38 --> Input Class Initialized
INFO - 2017-10-27 11:40:38 --> Language Class Initialized
INFO - 2017-10-27 11:40:38 --> Loader Class Initialized
INFO - 2017-10-27 11:40:38 --> Helper loaded: url_helper
INFO - 2017-10-27 11:40:38 --> Helper loaded: common_helper
INFO - 2017-10-27 11:40:38 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:40:38 --> Email Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Controller Class Initialized
INFO - 2017-10-27 11:40:38 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:40:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:40:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 11:40:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 11:40:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 11:40:38 --> Final output sent to browser
DEBUG - 2017-10-27 11:40:38 --> Total execution time: 0.0280
INFO - 2017-10-27 11:40:38 --> Config Class Initialized
INFO - 2017-10-27 11:40:38 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:40:38 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:40:38 --> Utf8 Class Initialized
INFO - 2017-10-27 11:40:38 --> URI Class Initialized
INFO - 2017-10-27 11:40:38 --> Router Class Initialized
INFO - 2017-10-27 11:40:38 --> Output Class Initialized
INFO - 2017-10-27 11:40:38 --> Security Class Initialized
DEBUG - 2017-10-27 11:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:40:38 --> Input Class Initialized
INFO - 2017-10-27 11:40:38 --> Language Class Initialized
INFO - 2017-10-27 11:40:38 --> Loader Class Initialized
INFO - 2017-10-27 11:40:38 --> Helper loaded: url_helper
INFO - 2017-10-27 11:40:38 --> Helper loaded: common_helper
INFO - 2017-10-27 11:40:38 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:40:38 --> Email Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Controller Class Initialized
INFO - 2017-10-27 11:40:38 --> Model Class Initialized
INFO - 2017-10-27 11:40:38 --> Final output sent to browser
DEBUG - 2017-10-27 11:40:38 --> Total execution time: 0.0026
INFO - 2017-10-27 11:42:31 --> Config Class Initialized
INFO - 2017-10-27 11:42:31 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:42:31 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:42:31 --> Utf8 Class Initialized
INFO - 2017-10-27 11:42:31 --> URI Class Initialized
INFO - 2017-10-27 11:42:31 --> Router Class Initialized
INFO - 2017-10-27 11:42:31 --> Output Class Initialized
INFO - 2017-10-27 11:42:31 --> Security Class Initialized
DEBUG - 2017-10-27 11:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:42:31 --> Input Class Initialized
INFO - 2017-10-27 11:42:31 --> Language Class Initialized
INFO - 2017-10-27 11:42:31 --> Loader Class Initialized
INFO - 2017-10-27 11:42:31 --> Helper loaded: url_helper
INFO - 2017-10-27 11:42:31 --> Helper loaded: common_helper
INFO - 2017-10-27 11:42:31 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:42:31 --> Email Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Controller Class Initialized
INFO - 2017-10-27 11:42:31 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> Model Class Initialized
INFO - 2017-10-27 11:42:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:42:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:42:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:42:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 11:42:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:42:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:42:32 --> Final output sent to browser
DEBUG - 2017-10-27 11:42:32 --> Total execution time: 0.0629
INFO - 2017-10-27 11:43:38 --> Config Class Initialized
INFO - 2017-10-27 11:43:38 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:43:38 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:43:38 --> Utf8 Class Initialized
INFO - 2017-10-27 11:43:38 --> URI Class Initialized
INFO - 2017-10-27 11:43:38 --> Router Class Initialized
INFO - 2017-10-27 11:43:38 --> Output Class Initialized
INFO - 2017-10-27 11:43:38 --> Security Class Initialized
DEBUG - 2017-10-27 11:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:43:38 --> Input Class Initialized
INFO - 2017-10-27 11:43:38 --> Language Class Initialized
INFO - 2017-10-27 11:43:38 --> Loader Class Initialized
INFO - 2017-10-27 11:43:38 --> Helper loaded: url_helper
INFO - 2017-10-27 11:43:38 --> Helper loaded: common_helper
INFO - 2017-10-27 11:43:38 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:43:38 --> Email Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Controller Class Initialized
INFO - 2017-10-27 11:43:38 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> Model Class Initialized
INFO - 2017-10-27 11:43:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:43:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:43:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-27 11:43:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:43:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:43:38 --> Final output sent to browser
DEBUG - 2017-10-27 11:43:38 --> Total execution time: 0.2242
INFO - 2017-10-27 11:43:48 --> Config Class Initialized
INFO - 2017-10-27 11:43:48 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:43:48 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:43:48 --> Utf8 Class Initialized
INFO - 2017-10-27 11:43:48 --> URI Class Initialized
INFO - 2017-10-27 11:43:48 --> Router Class Initialized
INFO - 2017-10-27 11:43:48 --> Output Class Initialized
INFO - 2017-10-27 11:43:48 --> Security Class Initialized
DEBUG - 2017-10-27 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:43:48 --> Input Class Initialized
INFO - 2017-10-27 11:43:48 --> Language Class Initialized
INFO - 2017-10-27 11:43:48 --> Loader Class Initialized
INFO - 2017-10-27 11:43:48 --> Helper loaded: url_helper
INFO - 2017-10-27 11:43:48 --> Helper loaded: common_helper
INFO - 2017-10-27 11:43:48 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:43:48 --> Email Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Controller Class Initialized
INFO - 2017-10-27 11:43:48 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:48 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Config Class Initialized
INFO - 2017-10-27 11:43:49 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:43:49 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:43:49 --> Utf8 Class Initialized
INFO - 2017-10-27 11:43:49 --> URI Class Initialized
INFO - 2017-10-27 11:43:49 --> Router Class Initialized
INFO - 2017-10-27 11:43:49 --> Output Class Initialized
INFO - 2017-10-27 11:43:49 --> Security Class Initialized
DEBUG - 2017-10-27 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:43:49 --> Input Class Initialized
INFO - 2017-10-27 11:43:49 --> Language Class Initialized
INFO - 2017-10-27 11:43:49 --> Loader Class Initialized
INFO - 2017-10-27 11:43:49 --> Helper loaded: url_helper
INFO - 2017-10-27 11:43:49 --> Helper loaded: common_helper
INFO - 2017-10-27 11:43:49 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:43:49 --> Email Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Controller Class Initialized
INFO - 2017-10-27 11:43:49 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> Model Class Initialized
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:43:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:43:49 --> Final output sent to browser
DEBUG - 2017-10-27 11:43:49 --> Total execution time: 0.0936
INFO - 2017-10-27 11:43:49 --> Config Class Initialized
INFO - 2017-10-27 11:43:49 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:43:49 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:43:49 --> Utf8 Class Initialized
INFO - 2017-10-27 11:43:49 --> URI Class Initialized
INFO - 2017-10-27 11:43:49 --> Router Class Initialized
INFO - 2017-10-27 11:43:49 --> Output Class Initialized
INFO - 2017-10-27 11:43:49 --> Security Class Initialized
DEBUG - 2017-10-27 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:43:49 --> Input Class Initialized
INFO - 2017-10-27 11:43:49 --> Language Class Initialized
ERROR - 2017-10-27 11:43:49 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 11:44:04 --> Config Class Initialized
INFO - 2017-10-27 11:44:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:04 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:04 --> URI Class Initialized
INFO - 2017-10-27 11:44:04 --> Router Class Initialized
INFO - 2017-10-27 11:44:04 --> Output Class Initialized
INFO - 2017-10-27 11:44:04 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:04 --> Input Class Initialized
INFO - 2017-10-27 11:44:04 --> Language Class Initialized
INFO - 2017-10-27 11:44:04 --> Loader Class Initialized
INFO - 2017-10-27 11:44:04 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:04 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:04 --> Email Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Controller Class Initialized
INFO - 2017-10-27 11:44:04 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> Model Class Initialized
INFO - 2017-10-27 11:44:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:44:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:44:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-27 11:44:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:44:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:44:04 --> Final output sent to browser
DEBUG - 2017-10-27 11:44:04 --> Total execution time: 0.0194
INFO - 2017-10-27 11:44:09 --> Config Class Initialized
INFO - 2017-10-27 11:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:09 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:09 --> URI Class Initialized
INFO - 2017-10-27 11:44:09 --> Router Class Initialized
INFO - 2017-10-27 11:44:09 --> Output Class Initialized
INFO - 2017-10-27 11:44:09 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:09 --> Input Class Initialized
INFO - 2017-10-27 11:44:09 --> Language Class Initialized
INFO - 2017-10-27 11:44:09 --> Loader Class Initialized
INFO - 2017-10-27 11:44:09 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:09 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:09 --> Email Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Controller Class Initialized
INFO - 2017-10-27 11:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Config Class Initialized
INFO - 2017-10-27 11:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:09 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:09 --> URI Class Initialized
INFO - 2017-10-27 11:44:09 --> Router Class Initialized
INFO - 2017-10-27 11:44:09 --> Output Class Initialized
INFO - 2017-10-27 11:44:09 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:09 --> Input Class Initialized
INFO - 2017-10-27 11:44:09 --> Language Class Initialized
INFO - 2017-10-27 11:44:09 --> Loader Class Initialized
INFO - 2017-10-27 11:44:09 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:09 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:09 --> Email Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Controller Class Initialized
INFO - 2017-10-27 11:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> Model Class Initialized
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:44:09 --> Final output sent to browser
DEBUG - 2017-10-27 11:44:09 --> Total execution time: 0.0280
INFO - 2017-10-27 11:44:30 --> Config Class Initialized
INFO - 2017-10-27 11:44:30 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:30 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:30 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:30 --> URI Class Initialized
INFO - 2017-10-27 11:44:30 --> Router Class Initialized
INFO - 2017-10-27 11:44:30 --> Output Class Initialized
INFO - 2017-10-27 11:44:30 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:30 --> Input Class Initialized
INFO - 2017-10-27 11:44:30 --> Language Class Initialized
INFO - 2017-10-27 11:44:30 --> Loader Class Initialized
INFO - 2017-10-27 11:44:30 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:30 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:30 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:30 --> Email Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Controller Class Initialized
INFO - 2017-10-27 11:44:30 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> Model Class Initialized
INFO - 2017-10-27 11:44:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:44:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:44:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-27 11:44:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:44:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:44:30 --> Final output sent to browser
DEBUG - 2017-10-27 11:44:30 --> Total execution time: 0.0188
INFO - 2017-10-27 11:44:35 --> Config Class Initialized
INFO - 2017-10-27 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:35 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:35 --> URI Class Initialized
INFO - 2017-10-27 11:44:35 --> Router Class Initialized
INFO - 2017-10-27 11:44:35 --> Output Class Initialized
INFO - 2017-10-27 11:44:35 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:35 --> Input Class Initialized
INFO - 2017-10-27 11:44:35 --> Language Class Initialized
INFO - 2017-10-27 11:44:35 --> Loader Class Initialized
INFO - 2017-10-27 11:44:35 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:35 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:35 --> Email Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Controller Class Initialized
INFO - 2017-10-27 11:44:35 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Config Class Initialized
INFO - 2017-10-27 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:35 --> Utf8 Class Initialized
INFO - 2017-10-27 11:44:35 --> URI Class Initialized
INFO - 2017-10-27 11:44:35 --> Router Class Initialized
INFO - 2017-10-27 11:44:35 --> Output Class Initialized
INFO - 2017-10-27 11:44:35 --> Security Class Initialized
DEBUG - 2017-10-27 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:44:35 --> Input Class Initialized
INFO - 2017-10-27 11:44:35 --> Language Class Initialized
INFO - 2017-10-27 11:44:35 --> Loader Class Initialized
INFO - 2017-10-27 11:44:35 --> Helper loaded: url_helper
INFO - 2017-10-27 11:44:35 --> Helper loaded: common_helper
INFO - 2017-10-27 11:44:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:44:35 --> Email Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Controller Class Initialized
INFO - 2017-10-27 11:44:35 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
INFO - 2017-10-27 11:44:35 --> Model Class Initialized
ERROR - 2017-10-27 11:44:35 --> Severity: Notice --> Undefined variable: logo /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php 22
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:44:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:44:35 --> Final output sent to browser
DEBUG - 2017-10-27 11:44:35 --> Total execution time: 0.0355
INFO - 2017-10-27 11:44:35 --> Config Class Initialized
INFO - 2017-10-27 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:44:35 --> Utf8 Class Initialized
INFO - 2017-10-27 11:53:31 --> Config Class Initialized
INFO - 2017-10-27 11:53:31 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:53:31 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:53:31 --> Utf8 Class Initialized
INFO - 2017-10-27 11:53:31 --> URI Class Initialized
INFO - 2017-10-27 11:53:31 --> Router Class Initialized
INFO - 2017-10-27 11:53:31 --> Output Class Initialized
INFO - 2017-10-27 11:53:31 --> Security Class Initialized
DEBUG - 2017-10-27 11:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:53:31 --> Input Class Initialized
INFO - 2017-10-27 11:53:31 --> Language Class Initialized
INFO - 2017-10-27 11:53:31 --> Loader Class Initialized
INFO - 2017-10-27 11:53:31 --> Helper loaded: url_helper
INFO - 2017-10-27 11:53:31 --> Helper loaded: common_helper
INFO - 2017-10-27 11:53:31 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:53:31 --> Email Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Controller Class Initialized
INFO - 2017-10-27 11:53:31 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> Model Class Initialized
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:53:31 --> Final output sent to browser
DEBUG - 2017-10-27 11:53:31 --> Total execution time: 0.0331
INFO - 2017-10-27 11:53:31 --> Config Class Initialized
INFO - 2017-10-27 11:53:31 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:53:31 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:53:31 --> Utf8 Class Initialized
INFO - 2017-10-27 11:53:31 --> URI Class Initialized
INFO - 2017-10-27 11:53:31 --> Router Class Initialized
INFO - 2017-10-27 11:53:31 --> Output Class Initialized
INFO - 2017-10-27 11:53:31 --> Security Class Initialized
DEBUG - 2017-10-27 11:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:53:31 --> Input Class Initialized
INFO - 2017-10-27 11:53:31 --> Language Class Initialized
ERROR - 2017-10-27 11:53:31 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 11:53:37 --> Config Class Initialized
INFO - 2017-10-27 11:53:37 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:53:37 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:53:37 --> Utf8 Class Initialized
INFO - 2017-10-27 11:53:37 --> URI Class Initialized
INFO - 2017-10-27 11:53:37 --> Router Class Initialized
INFO - 2017-10-27 11:53:37 --> Output Class Initialized
INFO - 2017-10-27 11:53:37 --> Security Class Initialized
DEBUG - 2017-10-27 11:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:53:37 --> Input Class Initialized
INFO - 2017-10-27 11:53:37 --> Language Class Initialized
INFO - 2017-10-27 11:53:37 --> Loader Class Initialized
INFO - 2017-10-27 11:53:37 --> Helper loaded: url_helper
INFO - 2017-10-27 11:53:37 --> Helper loaded: common_helper
INFO - 2017-10-27 11:53:37 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:53:37 --> Email Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Controller Class Initialized
INFO - 2017-10-27 11:53:37 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> Model Class Initialized
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:53:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:53:37 --> Final output sent to browser
DEBUG - 2017-10-27 11:53:37 --> Total execution time: 0.0317
INFO - 2017-10-27 11:54:47 --> Config Class Initialized
INFO - 2017-10-27 11:54:47 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:54:47 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:54:47 --> Utf8 Class Initialized
INFO - 2017-10-27 11:54:47 --> URI Class Initialized
INFO - 2017-10-27 11:54:47 --> Router Class Initialized
INFO - 2017-10-27 11:54:47 --> Output Class Initialized
INFO - 2017-10-27 11:54:47 --> Security Class Initialized
DEBUG - 2017-10-27 11:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:54:47 --> Input Class Initialized
INFO - 2017-10-27 11:54:47 --> Language Class Initialized
INFO - 2017-10-27 11:54:47 --> Loader Class Initialized
INFO - 2017-10-27 11:54:47 --> Helper loaded: url_helper
INFO - 2017-10-27 11:54:47 --> Helper loaded: common_helper
INFO - 2017-10-27 11:54:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:54:47 --> Email Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Controller Class Initialized
INFO - 2017-10-27 11:54:47 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> Model Class Initialized
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:54:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:54:47 --> Final output sent to browser
DEBUG - 2017-10-27 11:54:47 --> Total execution time: 0.0354
INFO - 2017-10-27 11:55:03 --> Config Class Initialized
INFO - 2017-10-27 11:55:03 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:55:03 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:55:03 --> Utf8 Class Initialized
INFO - 2017-10-27 11:55:03 --> URI Class Initialized
INFO - 2017-10-27 11:55:03 --> Router Class Initialized
INFO - 2017-10-27 11:55:03 --> Output Class Initialized
INFO - 2017-10-27 11:55:03 --> Security Class Initialized
DEBUG - 2017-10-27 11:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:55:03 --> Input Class Initialized
INFO - 2017-10-27 11:55:03 --> Language Class Initialized
INFO - 2017-10-27 11:55:03 --> Loader Class Initialized
INFO - 2017-10-27 11:55:03 --> Helper loaded: url_helper
INFO - 2017-10-27 11:55:03 --> Helper loaded: common_helper
INFO - 2017-10-27 11:55:03 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:55:03 --> Email Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Controller Class Initialized
INFO - 2017-10-27 11:55:03 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> Model Class Initialized
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:55:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:55:03 --> Final output sent to browser
DEBUG - 2017-10-27 11:55:03 --> Total execution time: 0.0272
INFO - 2017-10-27 11:55:03 --> Config Class Initialized
INFO - 2017-10-27 11:55:03 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:55:03 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:55:03 --> Utf8 Class Initialized
INFO - 2017-10-27 11:55:03 --> URI Class Initialized
INFO - 2017-10-27 11:55:03 --> Router Class Initialized
INFO - 2017-10-27 11:55:03 --> Output Class Initialized
INFO - 2017-10-27 11:55:03 --> Security Class Initialized
DEBUG - 2017-10-27 11:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:55:03 --> Input Class Initialized
INFO - 2017-10-27 11:55:03 --> Language Class Initialized
ERROR - 2017-10-27 11:55:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 11:57:39 --> Config Class Initialized
INFO - 2017-10-27 11:57:39 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:57:39 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:57:39 --> Utf8 Class Initialized
INFO - 2017-10-27 11:57:39 --> URI Class Initialized
INFO - 2017-10-27 11:57:39 --> Router Class Initialized
INFO - 2017-10-27 11:57:39 --> Output Class Initialized
INFO - 2017-10-27 11:57:39 --> Security Class Initialized
DEBUG - 2017-10-27 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:57:39 --> Input Class Initialized
INFO - 2017-10-27 11:57:39 --> Language Class Initialized
INFO - 2017-10-27 11:57:39 --> Loader Class Initialized
INFO - 2017-10-27 11:57:39 --> Helper loaded: url_helper
INFO - 2017-10-27 11:57:39 --> Helper loaded: common_helper
INFO - 2017-10-27 11:57:39 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:57:39 --> Email Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Controller Class Initialized
INFO - 2017-10-27 11:57:39 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> Model Class Initialized
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:57:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:57:39 --> Final output sent to browser
DEBUG - 2017-10-27 11:57:39 --> Total execution time: 0.0485
INFO - 2017-10-27 11:58:22 --> Config Class Initialized
INFO - 2017-10-27 11:58:22 --> Hooks Class Initialized
DEBUG - 2017-10-27 11:58:22 --> UTF-8 Support Enabled
INFO - 2017-10-27 11:58:22 --> Utf8 Class Initialized
INFO - 2017-10-27 11:58:22 --> URI Class Initialized
INFO - 2017-10-27 11:58:22 --> Router Class Initialized
INFO - 2017-10-27 11:58:22 --> Output Class Initialized
INFO - 2017-10-27 11:58:22 --> Security Class Initialized
DEBUG - 2017-10-27 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 11:58:22 --> Input Class Initialized
INFO - 2017-10-27 11:58:22 --> Language Class Initialized
INFO - 2017-10-27 11:58:22 --> Loader Class Initialized
INFO - 2017-10-27 11:58:22 --> Helper loaded: url_helper
INFO - 2017-10-27 11:58:22 --> Helper loaded: common_helper
INFO - 2017-10-27 11:58:22 --> Database Driver Class Initialized
DEBUG - 2017-10-27 11:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 11:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 11:58:22 --> Email Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Controller Class Initialized
INFO - 2017-10-27 11:58:22 --> Helper loaded: cookie_helper
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> Model Class Initialized
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 11:58:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 11:58:22 --> Final output sent to browser
DEBUG - 2017-10-27 11:58:22 --> Total execution time: 0.0427
INFO - 2017-10-27 12:01:12 --> Config Class Initialized
INFO - 2017-10-27 12:01:12 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:01:12 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:01:12 --> Utf8 Class Initialized
INFO - 2017-10-27 12:01:12 --> URI Class Initialized
INFO - 2017-10-27 12:01:12 --> Router Class Initialized
INFO - 2017-10-27 12:01:12 --> Output Class Initialized
INFO - 2017-10-27 12:01:12 --> Security Class Initialized
DEBUG - 2017-10-27 12:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:01:12 --> Input Class Initialized
INFO - 2017-10-27 12:01:12 --> Language Class Initialized
INFO - 2017-10-27 12:01:12 --> Loader Class Initialized
INFO - 2017-10-27 12:01:12 --> Helper loaded: url_helper
INFO - 2017-10-27 12:01:12 --> Helper loaded: common_helper
INFO - 2017-10-27 12:01:12 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:01:12 --> Email Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Controller Class Initialized
INFO - 2017-10-27 12:01:12 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> Model Class Initialized
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:01:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:01:12 --> Final output sent to browser
DEBUG - 2017-10-27 12:01:12 --> Total execution time: 0.0453
INFO - 2017-10-27 12:01:17 --> Config Class Initialized
INFO - 2017-10-27 12:01:17 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:01:17 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:01:17 --> Utf8 Class Initialized
INFO - 2017-10-27 12:01:17 --> URI Class Initialized
INFO - 2017-10-27 12:01:17 --> Router Class Initialized
INFO - 2017-10-27 12:01:17 --> Output Class Initialized
INFO - 2017-10-27 12:01:17 --> Security Class Initialized
DEBUG - 2017-10-27 12:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:01:17 --> Input Class Initialized
INFO - 2017-10-27 12:01:17 --> Language Class Initialized
INFO - 2017-10-27 12:01:17 --> Loader Class Initialized
INFO - 2017-10-27 12:01:17 --> Helper loaded: url_helper
INFO - 2017-10-27 12:01:17 --> Helper loaded: common_helper
INFO - 2017-10-27 12:01:17 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:01:17 --> Email Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Controller Class Initialized
INFO - 2017-10-27 12:01:17 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> Model Class Initialized
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:01:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:01:17 --> Final output sent to browser
DEBUG - 2017-10-27 12:01:17 --> Total execution time: 0.0293
INFO - 2017-10-27 12:01:33 --> Config Class Initialized
INFO - 2017-10-27 12:01:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:01:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:01:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:01:33 --> URI Class Initialized
INFO - 2017-10-27 12:01:33 --> Router Class Initialized
INFO - 2017-10-27 12:01:33 --> Output Class Initialized
INFO - 2017-10-27 12:01:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:01:33 --> Input Class Initialized
INFO - 2017-10-27 12:01:33 --> Language Class Initialized
INFO - 2017-10-27 12:01:33 --> Loader Class Initialized
INFO - 2017-10-27 12:01:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:01:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:01:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:01:33 --> Email Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Controller Class Initialized
INFO - 2017-10-27 12:01:33 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> Model Class Initialized
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:01:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:01:33 --> Final output sent to browser
DEBUG - 2017-10-27 12:01:33 --> Total execution time: 0.0295
INFO - 2017-10-27 12:02:20 --> Config Class Initialized
INFO - 2017-10-27 12:02:20 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:02:20 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:02:20 --> Utf8 Class Initialized
INFO - 2017-10-27 12:02:20 --> URI Class Initialized
INFO - 2017-10-27 12:02:20 --> Router Class Initialized
INFO - 2017-10-27 12:02:20 --> Output Class Initialized
INFO - 2017-10-27 12:02:20 --> Security Class Initialized
DEBUG - 2017-10-27 12:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:02:20 --> Input Class Initialized
INFO - 2017-10-27 12:02:20 --> Language Class Initialized
INFO - 2017-10-27 12:02:20 --> Loader Class Initialized
INFO - 2017-10-27 12:02:20 --> Helper loaded: url_helper
INFO - 2017-10-27 12:02:20 --> Helper loaded: common_helper
INFO - 2017-10-27 12:02:20 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:02:20 --> Email Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Controller Class Initialized
INFO - 2017-10-27 12:02:20 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> Model Class Initialized
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:02:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:02:20 --> Final output sent to browser
DEBUG - 2017-10-27 12:02:20 --> Total execution time: 0.0347
INFO - 2017-10-27 12:02:20 --> Config Class Initialized
INFO - 2017-10-27 12:02:20 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:02:20 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:02:20 --> Utf8 Class Initialized
INFO - 2017-10-27 12:02:20 --> URI Class Initialized
INFO - 2017-10-27 12:02:20 --> Router Class Initialized
INFO - 2017-10-27 12:02:20 --> Output Class Initialized
INFO - 2017-10-27 12:02:20 --> Security Class Initialized
DEBUG - 2017-10-27 12:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:02:20 --> Input Class Initialized
INFO - 2017-10-27 12:02:20 --> Language Class Initialized
ERROR - 2017-10-27 12:02:20 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:02:31 --> Config Class Initialized
INFO - 2017-10-27 12:02:31 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:02:31 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:02:31 --> Utf8 Class Initialized
INFO - 2017-10-27 12:02:31 --> URI Class Initialized
INFO - 2017-10-27 12:02:31 --> Router Class Initialized
INFO - 2017-10-27 12:02:31 --> Output Class Initialized
INFO - 2017-10-27 12:02:31 --> Security Class Initialized
DEBUG - 2017-10-27 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:02:31 --> Input Class Initialized
INFO - 2017-10-27 12:02:31 --> Language Class Initialized
INFO - 2017-10-27 12:02:31 --> Loader Class Initialized
INFO - 2017-10-27 12:02:31 --> Helper loaded: url_helper
INFO - 2017-10-27 12:02:31 --> Helper loaded: common_helper
INFO - 2017-10-27 12:02:31 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:02:31 --> Email Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Controller Class Initialized
INFO - 2017-10-27 12:02:31 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> Model Class Initialized
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:02:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:02:31 --> Final output sent to browser
DEBUG - 2017-10-27 12:02:31 --> Total execution time: 0.0431
INFO - 2017-10-27 12:02:46 --> Config Class Initialized
INFO - 2017-10-27 12:02:46 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:02:46 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:02:46 --> Utf8 Class Initialized
INFO - 2017-10-27 12:02:46 --> URI Class Initialized
INFO - 2017-10-27 12:02:46 --> Router Class Initialized
INFO - 2017-10-27 12:02:46 --> Output Class Initialized
INFO - 2017-10-27 12:02:46 --> Security Class Initialized
DEBUG - 2017-10-27 12:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:02:46 --> Input Class Initialized
INFO - 2017-10-27 12:02:46 --> Language Class Initialized
INFO - 2017-10-27 12:02:46 --> Loader Class Initialized
INFO - 2017-10-27 12:02:46 --> Helper loaded: url_helper
INFO - 2017-10-27 12:02:46 --> Helper loaded: common_helper
INFO - 2017-10-27 12:02:46 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:02:46 --> Email Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Controller Class Initialized
INFO - 2017-10-27 12:02:46 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> Model Class Initialized
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:02:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:02:46 --> Final output sent to browser
DEBUG - 2017-10-27 12:02:46 --> Total execution time: 0.0294
INFO - 2017-10-27 12:02:47 --> Config Class Initialized
INFO - 2017-10-27 12:02:47 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:02:47 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:02:47 --> Utf8 Class Initialized
INFO - 2017-10-27 12:02:47 --> URI Class Initialized
INFO - 2017-10-27 12:02:47 --> Router Class Initialized
INFO - 2017-10-27 12:02:47 --> Output Class Initialized
INFO - 2017-10-27 12:02:47 --> Security Class Initialized
DEBUG - 2017-10-27 12:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:02:47 --> Input Class Initialized
INFO - 2017-10-27 12:02:47 --> Language Class Initialized
INFO - 2017-10-27 12:02:47 --> Loader Class Initialized
INFO - 2017-10-27 12:02:47 --> Helper loaded: url_helper
INFO - 2017-10-27 12:02:47 --> Helper loaded: common_helper
INFO - 2017-10-27 12:02:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:02:47 --> Email Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Controller Class Initialized
INFO - 2017-10-27 12:02:47 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:47 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> Model Class Initialized
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:02:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:02:48 --> Final output sent to browser
DEBUG - 2017-10-27 12:02:48 --> Total execution time: 0.0300
INFO - 2017-10-27 12:15:54 --> Config Class Initialized
INFO - 2017-10-27 12:15:54 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:15:54 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:15:54 --> Utf8 Class Initialized
INFO - 2017-10-27 12:15:54 --> URI Class Initialized
INFO - 2017-10-27 12:15:54 --> Router Class Initialized
INFO - 2017-10-27 12:15:54 --> Output Class Initialized
INFO - 2017-10-27 12:15:54 --> Security Class Initialized
DEBUG - 2017-10-27 12:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:15:54 --> Input Class Initialized
INFO - 2017-10-27 12:15:54 --> Language Class Initialized
INFO - 2017-10-27 12:15:54 --> Loader Class Initialized
INFO - 2017-10-27 12:15:54 --> Helper loaded: url_helper
INFO - 2017-10-27 12:15:54 --> Helper loaded: common_helper
INFO - 2017-10-27 12:15:54 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:15:54 --> Email Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Controller Class Initialized
INFO - 2017-10-27 12:15:54 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
INFO - 2017-10-27 12:15:54 --> Model Class Initialized
ERROR - 2017-10-27 12:15:54 --> Query error: Unknown column 'B.escrow_type' in 'field list' - Invalid query: SELECT `A`.`id`, `A`.`event_id`, `A`.`comment`, `A`.`price`, `A`.`address`, `A`.`location`, `A`.`date_time`, `B`.`event_data_id`, `B`.`title`, `B`.`user_id`, `B`.`start`, `B`.`escrow_type`
FROM `user_library_event_comment` as `A`
LEFT JOIN `user_library_events` as `B` ON `A`.`event_id` = `B`.`id`
LEFT JOIN `rss_feed_subscription` as `C` ON `C`.`item_id` = `B`.`event_data_id`
WHERE `C`.`unsubscribe` =0
AND `C`.`user_id` = '28'
GROUP BY `A`.`id`
INFO - 2017-10-27 12:15:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-27 12:16:21 --> Config Class Initialized
INFO - 2017-10-27 12:16:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:16:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:16:21 --> Utf8 Class Initialized
INFO - 2017-10-27 12:16:21 --> URI Class Initialized
INFO - 2017-10-27 12:16:21 --> Router Class Initialized
INFO - 2017-10-27 12:16:21 --> Output Class Initialized
INFO - 2017-10-27 12:16:21 --> Security Class Initialized
DEBUG - 2017-10-27 12:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:16:21 --> Input Class Initialized
INFO - 2017-10-27 12:16:21 --> Language Class Initialized
INFO - 2017-10-27 12:16:21 --> Loader Class Initialized
INFO - 2017-10-27 12:16:21 --> Helper loaded: url_helper
INFO - 2017-10-27 12:16:21 --> Helper loaded: common_helper
INFO - 2017-10-27 12:16:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:16:21 --> Email Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Controller Class Initialized
INFO - 2017-10-27 12:16:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> Model Class Initialized
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:16:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:16:21 --> Final output sent to browser
DEBUG - 2017-10-27 12:16:21 --> Total execution time: 0.0446
INFO - 2017-10-27 12:17:16 --> Config Class Initialized
INFO - 2017-10-27 12:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:17:16 --> Utf8 Class Initialized
INFO - 2017-10-27 12:17:16 --> URI Class Initialized
INFO - 2017-10-27 12:17:16 --> Router Class Initialized
INFO - 2017-10-27 12:17:16 --> Output Class Initialized
INFO - 2017-10-27 12:17:16 --> Security Class Initialized
DEBUG - 2017-10-27 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:17:16 --> Input Class Initialized
INFO - 2017-10-27 12:17:16 --> Language Class Initialized
INFO - 2017-10-27 12:17:16 --> Loader Class Initialized
INFO - 2017-10-27 12:17:16 --> Helper loaded: url_helper
INFO - 2017-10-27 12:17:16 --> Helper loaded: common_helper
INFO - 2017-10-27 12:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:17:16 --> Email Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Controller Class Initialized
INFO - 2017-10-27 12:17:16 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> Model Class Initialized
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:17:16 --> Final output sent to browser
DEBUG - 2017-10-27 12:17:16 --> Total execution time: 0.0526
INFO - 2017-10-27 12:17:28 --> Config Class Initialized
INFO - 2017-10-27 12:17:28 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:17:28 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:17:28 --> Utf8 Class Initialized
INFO - 2017-10-27 12:17:28 --> URI Class Initialized
INFO - 2017-10-27 12:17:28 --> Router Class Initialized
INFO - 2017-10-27 12:17:28 --> Output Class Initialized
INFO - 2017-10-27 12:17:28 --> Security Class Initialized
DEBUG - 2017-10-27 12:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:17:28 --> Input Class Initialized
INFO - 2017-10-27 12:17:28 --> Language Class Initialized
INFO - 2017-10-27 12:17:28 --> Loader Class Initialized
INFO - 2017-10-27 12:17:28 --> Helper loaded: url_helper
INFO - 2017-10-27 12:17:28 --> Helper loaded: common_helper
INFO - 2017-10-27 12:17:28 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:17:28 --> Email Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Controller Class Initialized
INFO - 2017-10-27 12:17:28 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> Model Class Initialized
INFO - 2017-10-27 12:17:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:17:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:17:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:17:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:17:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:17:28 --> Final output sent to browser
DEBUG - 2017-10-27 12:17:28 --> Total execution time: 0.0308
INFO - 2017-10-27 12:17:29 --> Config Class Initialized
INFO - 2017-10-27 12:17:29 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:17:29 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:17:29 --> Utf8 Class Initialized
INFO - 2017-10-27 12:17:29 --> URI Class Initialized
INFO - 2017-10-27 12:17:29 --> Router Class Initialized
INFO - 2017-10-27 12:17:29 --> Output Class Initialized
INFO - 2017-10-27 12:17:29 --> Security Class Initialized
DEBUG - 2017-10-27 12:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:17:29 --> Input Class Initialized
INFO - 2017-10-27 12:17:29 --> Language Class Initialized
INFO - 2017-10-27 12:17:29 --> Loader Class Initialized
INFO - 2017-10-27 12:17:29 --> Helper loaded: url_helper
INFO - 2017-10-27 12:17:29 --> Helper loaded: common_helper
INFO - 2017-10-27 12:17:29 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:17:29 --> Email Class Initialized
INFO - 2017-10-27 12:17:29 --> Model Class Initialized
INFO - 2017-10-27 12:17:29 --> Controller Class Initialized
INFO - 2017-10-27 12:17:29 --> Model Class Initialized
INFO - 2017-10-27 12:17:29 --> Final output sent to browser
DEBUG - 2017-10-27 12:17:29 --> Total execution time: 0.0028
INFO - 2017-10-27 12:17:30 --> Config Class Initialized
INFO - 2017-10-27 12:17:30 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:17:30 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:17:30 --> Utf8 Class Initialized
INFO - 2017-10-27 12:17:30 --> URI Class Initialized
INFO - 2017-10-27 12:17:30 --> Router Class Initialized
INFO - 2017-10-27 12:17:30 --> Output Class Initialized
INFO - 2017-10-27 12:17:30 --> Security Class Initialized
DEBUG - 2017-10-27 12:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:17:30 --> Input Class Initialized
INFO - 2017-10-27 12:17:30 --> Language Class Initialized
INFO - 2017-10-27 12:17:30 --> Loader Class Initialized
INFO - 2017-10-27 12:17:30 --> Helper loaded: url_helper
INFO - 2017-10-27 12:17:30 --> Helper loaded: common_helper
INFO - 2017-10-27 12:17:30 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:17:30 --> Email Class Initialized
INFO - 2017-10-27 12:17:30 --> Model Class Initialized
INFO - 2017-10-27 12:17:30 --> Controller Class Initialized
INFO - 2017-10-27 12:17:30 --> Final output sent to browser
DEBUG - 2017-10-27 12:17:30 --> Total execution time: 0.0016
INFO - 2017-10-27 12:18:16 --> Config Class Initialized
INFO - 2017-10-27 12:18:16 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:18:16 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:18:16 --> Utf8 Class Initialized
INFO - 2017-10-27 12:18:16 --> URI Class Initialized
INFO - 2017-10-27 12:18:16 --> Router Class Initialized
INFO - 2017-10-27 12:18:16 --> Output Class Initialized
INFO - 2017-10-27 12:18:16 --> Security Class Initialized
DEBUG - 2017-10-27 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:18:16 --> Input Class Initialized
INFO - 2017-10-27 12:18:16 --> Language Class Initialized
INFO - 2017-10-27 12:18:16 --> Loader Class Initialized
INFO - 2017-10-27 12:18:16 --> Helper loaded: url_helper
INFO - 2017-10-27 12:18:16 --> Helper loaded: common_helper
INFO - 2017-10-27 12:18:16 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:18:16 --> Email Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Controller Class Initialized
INFO - 2017-10-27 12:18:16 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:18:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:18:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:18:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:18:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:18:16 --> Final output sent to browser
DEBUG - 2017-10-27 12:18:16 --> Total execution time: 0.0289
INFO - 2017-10-27 12:18:16 --> Config Class Initialized
INFO - 2017-10-27 12:18:16 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:18:16 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:18:16 --> Utf8 Class Initialized
INFO - 2017-10-27 12:18:16 --> URI Class Initialized
INFO - 2017-10-27 12:18:16 --> Router Class Initialized
INFO - 2017-10-27 12:18:16 --> Output Class Initialized
INFO - 2017-10-27 12:18:16 --> Security Class Initialized
DEBUG - 2017-10-27 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:18:16 --> Input Class Initialized
INFO - 2017-10-27 12:18:16 --> Language Class Initialized
INFO - 2017-10-27 12:18:16 --> Loader Class Initialized
INFO - 2017-10-27 12:18:16 --> Helper loaded: url_helper
INFO - 2017-10-27 12:18:16 --> Helper loaded: common_helper
INFO - 2017-10-27 12:18:16 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:18:16 --> Email Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Controller Class Initialized
INFO - 2017-10-27 12:18:16 --> Model Class Initialized
INFO - 2017-10-27 12:18:16 --> Final output sent to browser
DEBUG - 2017-10-27 12:18:16 --> Total execution time: 0.0019
INFO - 2017-10-27 12:18:19 --> Config Class Initialized
INFO - 2017-10-27 12:18:19 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:18:19 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:18:19 --> Utf8 Class Initialized
INFO - 2017-10-27 12:18:19 --> URI Class Initialized
INFO - 2017-10-27 12:18:19 --> Router Class Initialized
INFO - 2017-10-27 12:18:19 --> Output Class Initialized
INFO - 2017-10-27 12:18:19 --> Security Class Initialized
DEBUG - 2017-10-27 12:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:18:19 --> Input Class Initialized
INFO - 2017-10-27 12:18:19 --> Language Class Initialized
INFO - 2017-10-27 12:18:19 --> Loader Class Initialized
INFO - 2017-10-27 12:18:19 --> Helper loaded: url_helper
INFO - 2017-10-27 12:18:19 --> Helper loaded: common_helper
INFO - 2017-10-27 12:18:19 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:18:19 --> Email Class Initialized
INFO - 2017-10-27 12:18:19 --> Model Class Initialized
INFO - 2017-10-27 12:18:19 --> Controller Class Initialized
INFO - 2017-10-27 12:18:19 --> Final output sent to browser
DEBUG - 2017-10-27 12:18:19 --> Total execution time: 0.0024
INFO - 2017-10-27 12:19:21 --> Config Class Initialized
INFO - 2017-10-27 12:19:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:21 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:21 --> URI Class Initialized
INFO - 2017-10-27 12:19:21 --> Router Class Initialized
INFO - 2017-10-27 12:19:21 --> Output Class Initialized
INFO - 2017-10-27 12:19:21 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:21 --> Input Class Initialized
INFO - 2017-10-27 12:19:21 --> Language Class Initialized
INFO - 2017-10-27 12:19:21 --> Loader Class Initialized
INFO - 2017-10-27 12:19:21 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:21 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:21 --> Email Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Controller Class Initialized
INFO - 2017-10-27 12:19:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:19:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:19:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:19:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:19:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:19:21 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:21 --> Total execution time: 0.0299
INFO - 2017-10-27 12:19:21 --> Config Class Initialized
INFO - 2017-10-27 12:19:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:21 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:21 --> URI Class Initialized
INFO - 2017-10-27 12:19:21 --> Router Class Initialized
INFO - 2017-10-27 12:19:21 --> Output Class Initialized
INFO - 2017-10-27 12:19:21 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:21 --> Input Class Initialized
INFO - 2017-10-27 12:19:21 --> Language Class Initialized
INFO - 2017-10-27 12:19:21 --> Loader Class Initialized
INFO - 2017-10-27 12:19:21 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:21 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:21 --> Email Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Controller Class Initialized
INFO - 2017-10-27 12:19:21 --> Model Class Initialized
INFO - 2017-10-27 12:19:21 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:21 --> Total execution time: 0.0027
INFO - 2017-10-27 12:19:22 --> Config Class Initialized
INFO - 2017-10-27 12:19:22 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:22 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:22 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:22 --> URI Class Initialized
INFO - 2017-10-27 12:19:22 --> Router Class Initialized
INFO - 2017-10-27 12:19:22 --> Output Class Initialized
INFO - 2017-10-27 12:19:22 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:22 --> Input Class Initialized
INFO - 2017-10-27 12:19:22 --> Language Class Initialized
INFO - 2017-10-27 12:19:22 --> Loader Class Initialized
INFO - 2017-10-27 12:19:22 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:22 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:22 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:22 --> Email Class Initialized
INFO - 2017-10-27 12:19:22 --> Model Class Initialized
INFO - 2017-10-27 12:19:22 --> Controller Class Initialized
INFO - 2017-10-27 12:19:22 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:22 --> Total execution time: 0.0018
INFO - 2017-10-27 12:19:32 --> Config Class Initialized
INFO - 2017-10-27 12:19:32 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:32 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:32 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:32 --> URI Class Initialized
INFO - 2017-10-27 12:19:32 --> Router Class Initialized
INFO - 2017-10-27 12:19:32 --> Output Class Initialized
INFO - 2017-10-27 12:19:32 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:32 --> Input Class Initialized
INFO - 2017-10-27 12:19:32 --> Language Class Initialized
INFO - 2017-10-27 12:19:32 --> Loader Class Initialized
INFO - 2017-10-27 12:19:32 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:32 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:32 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:32 --> Email Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Controller Class Initialized
INFO - 2017-10-27 12:19:32 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:19:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:19:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:19:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:19:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:19:32 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:32 --> Total execution time: 0.0254
INFO - 2017-10-27 12:19:32 --> Config Class Initialized
INFO - 2017-10-27 12:19:32 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:32 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:32 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:32 --> URI Class Initialized
INFO - 2017-10-27 12:19:32 --> Router Class Initialized
INFO - 2017-10-27 12:19:32 --> Output Class Initialized
INFO - 2017-10-27 12:19:32 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:32 --> Input Class Initialized
INFO - 2017-10-27 12:19:32 --> Language Class Initialized
INFO - 2017-10-27 12:19:32 --> Loader Class Initialized
INFO - 2017-10-27 12:19:32 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:32 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:32 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:32 --> Email Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Controller Class Initialized
INFO - 2017-10-27 12:19:32 --> Model Class Initialized
INFO - 2017-10-27 12:19:32 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:32 --> Total execution time: 0.0029
INFO - 2017-10-27 12:19:35 --> Config Class Initialized
INFO - 2017-10-27 12:19:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:35 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:35 --> URI Class Initialized
INFO - 2017-10-27 12:19:35 --> Router Class Initialized
INFO - 2017-10-27 12:19:35 --> Output Class Initialized
INFO - 2017-10-27 12:19:35 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:35 --> Input Class Initialized
INFO - 2017-10-27 12:19:35 --> Language Class Initialized
INFO - 2017-10-27 12:19:35 --> Loader Class Initialized
INFO - 2017-10-27 12:19:35 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:35 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:35 --> Email Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Controller Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Config Class Initialized
INFO - 2017-10-27 12:19:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:35 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:35 --> URI Class Initialized
INFO - 2017-10-27 12:19:35 --> Router Class Initialized
INFO - 2017-10-27 12:19:35 --> Output Class Initialized
INFO - 2017-10-27 12:19:35 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:35 --> Input Class Initialized
INFO - 2017-10-27 12:19:35 --> Language Class Initialized
INFO - 2017-10-27 12:19:35 --> Loader Class Initialized
INFO - 2017-10-27 12:19:35 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:35 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:35 --> Total execution time: 0.0840
INFO - 2017-10-27 12:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:35 --> Email Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Controller Class Initialized
INFO - 2017-10-27 12:19:35 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:19:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:19:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:19:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:19:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:19:35 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:35 --> Total execution time: 0.0985
INFO - 2017-10-27 12:19:35 --> Config Class Initialized
INFO - 2017-10-27 12:19:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:35 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:35 --> URI Class Initialized
INFO - 2017-10-27 12:19:35 --> Router Class Initialized
INFO - 2017-10-27 12:19:35 --> Output Class Initialized
INFO - 2017-10-27 12:19:35 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:35 --> Input Class Initialized
INFO - 2017-10-27 12:19:35 --> Language Class Initialized
INFO - 2017-10-27 12:19:35 --> Loader Class Initialized
INFO - 2017-10-27 12:19:35 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:35 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:35 --> Email Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Controller Class Initialized
INFO - 2017-10-27 12:19:35 --> Model Class Initialized
INFO - 2017-10-27 12:19:35 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:35 --> Total execution time: 0.0034
INFO - 2017-10-27 12:19:36 --> Config Class Initialized
INFO - 2017-10-27 12:19:36 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:19:36 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:19:36 --> Utf8 Class Initialized
INFO - 2017-10-27 12:19:36 --> URI Class Initialized
INFO - 2017-10-27 12:19:36 --> Router Class Initialized
INFO - 2017-10-27 12:19:36 --> Output Class Initialized
INFO - 2017-10-27 12:19:36 --> Security Class Initialized
DEBUG - 2017-10-27 12:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:19:36 --> Input Class Initialized
INFO - 2017-10-27 12:19:36 --> Language Class Initialized
INFO - 2017-10-27 12:19:36 --> Loader Class Initialized
INFO - 2017-10-27 12:19:36 --> Helper loaded: url_helper
INFO - 2017-10-27 12:19:36 --> Helper loaded: common_helper
INFO - 2017-10-27 12:19:36 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:19:36 --> Email Class Initialized
INFO - 2017-10-27 12:19:36 --> Model Class Initialized
INFO - 2017-10-27 12:19:36 --> Controller Class Initialized
INFO - 2017-10-27 12:19:36 --> Final output sent to browser
DEBUG - 2017-10-27 12:19:36 --> Total execution time: 0.0016
INFO - 2017-10-27 12:21:24 --> Config Class Initialized
INFO - 2017-10-27 12:21:24 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:24 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:24 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:24 --> URI Class Initialized
INFO - 2017-10-27 12:21:24 --> Router Class Initialized
INFO - 2017-10-27 12:21:24 --> Output Class Initialized
INFO - 2017-10-27 12:21:24 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:24 --> Input Class Initialized
INFO - 2017-10-27 12:21:24 --> Language Class Initialized
INFO - 2017-10-27 12:21:24 --> Loader Class Initialized
INFO - 2017-10-27 12:21:24 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:24 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:24 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:24 --> Email Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Controller Class Initialized
INFO - 2017-10-27 12:21:24 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> Model Class Initialized
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:21:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:21:24 --> Final output sent to browser
DEBUG - 2017-10-27 12:21:24 --> Total execution time: 0.0366
INFO - 2017-10-27 12:21:33 --> Config Class Initialized
INFO - 2017-10-27 12:21:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:33 --> URI Class Initialized
INFO - 2017-10-27 12:21:33 --> Router Class Initialized
INFO - 2017-10-27 12:21:33 --> Output Class Initialized
INFO - 2017-10-27 12:21:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:33 --> Input Class Initialized
INFO - 2017-10-27 12:21:33 --> Language Class Initialized
INFO - 2017-10-27 12:21:33 --> Loader Class Initialized
INFO - 2017-10-27 12:21:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:33 --> Email Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Controller Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Final output sent to browser
DEBUG - 2017-10-27 12:21:33 --> Total execution time: 0.0170
INFO - 2017-10-27 12:21:33 --> Config Class Initialized
INFO - 2017-10-27 12:21:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:33 --> URI Class Initialized
INFO - 2017-10-27 12:21:33 --> Router Class Initialized
INFO - 2017-10-27 12:21:33 --> Output Class Initialized
INFO - 2017-10-27 12:21:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:33 --> Input Class Initialized
INFO - 2017-10-27 12:21:33 --> Language Class Initialized
INFO - 2017-10-27 12:21:33 --> Loader Class Initialized
INFO - 2017-10-27 12:21:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:33 --> Email Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Controller Class Initialized
INFO - 2017-10-27 12:21:33 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Config Class Initialized
INFO - 2017-10-27 12:21:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:33 --> URI Class Initialized
INFO - 2017-10-27 12:21:33 --> Router Class Initialized
INFO - 2017-10-27 12:21:33 --> Output Class Initialized
INFO - 2017-10-27 12:21:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:33 --> Input Class Initialized
INFO - 2017-10-27 12:21:33 --> Language Class Initialized
INFO - 2017-10-27 12:21:33 --> Loader Class Initialized
INFO - 2017-10-27 12:21:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:33 --> Email Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Controller Class Initialized
INFO - 2017-10-27 12:21:33 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> Model Class Initialized
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:21:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:21:33 --> Final output sent to browser
DEBUG - 2017-10-27 12:21:33 --> Total execution time: 0.0287
INFO - 2017-10-27 12:21:39 --> Config Class Initialized
INFO - 2017-10-27 12:21:39 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:39 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:39 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:39 --> URI Class Initialized
INFO - 2017-10-27 12:21:39 --> Router Class Initialized
INFO - 2017-10-27 12:21:39 --> Output Class Initialized
INFO - 2017-10-27 12:21:39 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:39 --> Input Class Initialized
INFO - 2017-10-27 12:21:39 --> Language Class Initialized
INFO - 2017-10-27 12:21:39 --> Loader Class Initialized
INFO - 2017-10-27 12:21:39 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:39 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:39 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:39 --> Email Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Controller Class Initialized
INFO - 2017-10-27 12:21:39 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> Model Class Initialized
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:21:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:21:39 --> Final output sent to browser
DEBUG - 2017-10-27 12:21:39 --> Total execution time: 0.0451
INFO - 2017-10-27 12:21:39 --> Config Class Initialized
INFO - 2017-10-27 12:21:39 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:39 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:39 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:39 --> URI Class Initialized
INFO - 2017-10-27 12:21:39 --> Router Class Initialized
INFO - 2017-10-27 12:21:39 --> Output Class Initialized
INFO - 2017-10-27 12:21:39 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:39 --> Input Class Initialized
INFO - 2017-10-27 12:21:39 --> Language Class Initialized
ERROR - 2017-10-27 12:21:39 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:21:43 --> Config Class Initialized
INFO - 2017-10-27 12:21:43 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:21:43 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:21:43 --> Utf8 Class Initialized
INFO - 2017-10-27 12:21:43 --> URI Class Initialized
INFO - 2017-10-27 12:21:43 --> Router Class Initialized
INFO - 2017-10-27 12:21:43 --> Output Class Initialized
INFO - 2017-10-27 12:21:43 --> Security Class Initialized
DEBUG - 2017-10-27 12:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:21:43 --> Input Class Initialized
INFO - 2017-10-27 12:21:43 --> Language Class Initialized
INFO - 2017-10-27 12:21:43 --> Loader Class Initialized
INFO - 2017-10-27 12:21:43 --> Helper loaded: url_helper
INFO - 2017-10-27 12:21:43 --> Helper loaded: common_helper
INFO - 2017-10-27 12:21:43 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:21:43 --> Email Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Controller Class Initialized
INFO - 2017-10-27 12:21:43 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> Model Class Initialized
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:21:43 --> Final output sent to browser
DEBUG - 2017-10-27 12:21:43 --> Total execution time: 0.0292
INFO - 2017-10-27 12:22:54 --> Config Class Initialized
INFO - 2017-10-27 12:22:54 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:22:54 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:22:54 --> Utf8 Class Initialized
INFO - 2017-10-27 12:22:54 --> URI Class Initialized
INFO - 2017-10-27 12:22:54 --> Router Class Initialized
INFO - 2017-10-27 12:22:54 --> Output Class Initialized
INFO - 2017-10-27 12:22:54 --> Security Class Initialized
DEBUG - 2017-10-27 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:22:54 --> Input Class Initialized
INFO - 2017-10-27 12:22:54 --> Language Class Initialized
INFO - 2017-10-27 12:22:54 --> Loader Class Initialized
INFO - 2017-10-27 12:22:54 --> Helper loaded: url_helper
INFO - 2017-10-27 12:22:54 --> Helper loaded: common_helper
INFO - 2017-10-27 12:22:54 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:22:54 --> Email Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Controller Class Initialized
INFO - 2017-10-27 12:22:54 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> Model Class Initialized
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:22:54 --> Final output sent to browser
DEBUG - 2017-10-27 12:22:54 --> Total execution time: 0.0208
INFO - 2017-10-27 12:23:02 --> Config Class Initialized
INFO - 2017-10-27 12:23:02 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:23:02 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:23:02 --> Utf8 Class Initialized
INFO - 2017-10-27 12:23:02 --> URI Class Initialized
INFO - 2017-10-27 12:23:02 --> Router Class Initialized
INFO - 2017-10-27 12:23:02 --> Output Class Initialized
INFO - 2017-10-27 12:23:02 --> Security Class Initialized
DEBUG - 2017-10-27 12:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:23:02 --> Input Class Initialized
INFO - 2017-10-27 12:23:02 --> Language Class Initialized
INFO - 2017-10-27 12:23:02 --> Loader Class Initialized
INFO - 2017-10-27 12:23:02 --> Helper loaded: url_helper
INFO - 2017-10-27 12:23:02 --> Helper loaded: common_helper
INFO - 2017-10-27 12:23:02 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:23:02 --> Email Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Controller Class Initialized
INFO - 2017-10-27 12:23:02 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> Model Class Initialized
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:23:02 --> Final output sent to browser
DEBUG - 2017-10-27 12:23:02 --> Total execution time: 0.0207
INFO - 2017-10-27 12:24:38 --> Config Class Initialized
INFO - 2017-10-27 12:24:38 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:24:38 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:24:38 --> Utf8 Class Initialized
INFO - 2017-10-27 12:24:38 --> URI Class Initialized
INFO - 2017-10-27 12:24:38 --> Router Class Initialized
INFO - 2017-10-27 12:24:38 --> Output Class Initialized
INFO - 2017-10-27 12:24:38 --> Security Class Initialized
DEBUG - 2017-10-27 12:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:24:38 --> Input Class Initialized
INFO - 2017-10-27 12:24:38 --> Language Class Initialized
INFO - 2017-10-27 12:24:38 --> Loader Class Initialized
INFO - 2017-10-27 12:24:38 --> Helper loaded: url_helper
INFO - 2017-10-27 12:24:38 --> Helper loaded: common_helper
INFO - 2017-10-27 12:24:38 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:24:38 --> Email Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Controller Class Initialized
INFO - 2017-10-27 12:24:38 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> Model Class Initialized
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:24:38 --> Final output sent to browser
DEBUG - 2017-10-27 12:24:38 --> Total execution time: 0.0258
INFO - 2017-10-27 12:24:50 --> Config Class Initialized
INFO - 2017-10-27 12:24:50 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:24:50 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:24:50 --> Utf8 Class Initialized
INFO - 2017-10-27 12:24:50 --> URI Class Initialized
INFO - 2017-10-27 12:24:50 --> Router Class Initialized
INFO - 2017-10-27 12:24:50 --> Output Class Initialized
INFO - 2017-10-27 12:24:50 --> Security Class Initialized
DEBUG - 2017-10-27 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:24:50 --> Input Class Initialized
INFO - 2017-10-27 12:24:50 --> Language Class Initialized
INFO - 2017-10-27 12:24:50 --> Loader Class Initialized
INFO - 2017-10-27 12:24:50 --> Helper loaded: url_helper
INFO - 2017-10-27 12:24:50 --> Helper loaded: common_helper
INFO - 2017-10-27 12:24:50 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:24:50 --> Email Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Controller Class Initialized
INFO - 2017-10-27 12:24:50 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> Model Class Initialized
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:24:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:24:50 --> Final output sent to browser
DEBUG - 2017-10-27 12:24:50 --> Total execution time: 0.0380
INFO - 2017-10-27 12:24:50 --> Config Class Initialized
INFO - 2017-10-27 12:24:50 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:24:50 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:24:50 --> Utf8 Class Initialized
INFO - 2017-10-27 12:24:50 --> URI Class Initialized
INFO - 2017-10-27 12:24:50 --> Router Class Initialized
INFO - 2017-10-27 12:24:50 --> Output Class Initialized
INFO - 2017-10-27 12:24:50 --> Security Class Initialized
DEBUG - 2017-10-27 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:24:50 --> Input Class Initialized
INFO - 2017-10-27 12:24:50 --> Language Class Initialized
ERROR - 2017-10-27 12:24:50 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:24:59 --> Config Class Initialized
INFO - 2017-10-27 12:24:59 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:24:59 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:24:59 --> Utf8 Class Initialized
INFO - 2017-10-27 12:24:59 --> URI Class Initialized
INFO - 2017-10-27 12:24:59 --> Router Class Initialized
INFO - 2017-10-27 12:24:59 --> Output Class Initialized
INFO - 2017-10-27 12:24:59 --> Security Class Initialized
DEBUG - 2017-10-27 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:24:59 --> Input Class Initialized
INFO - 2017-10-27 12:24:59 --> Language Class Initialized
INFO - 2017-10-27 12:24:59 --> Loader Class Initialized
INFO - 2017-10-27 12:24:59 --> Helper loaded: url_helper
INFO - 2017-10-27 12:24:59 --> Helper loaded: common_helper
INFO - 2017-10-27 12:24:59 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:24:59 --> Email Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Controller Class Initialized
INFO - 2017-10-27 12:24:59 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> Model Class Initialized
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:24:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:24:59 --> Final output sent to browser
DEBUG - 2017-10-27 12:24:59 --> Total execution time: 0.0285
INFO - 2017-10-27 12:25:53 --> Config Class Initialized
INFO - 2017-10-27 12:25:53 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:25:53 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:25:53 --> Utf8 Class Initialized
INFO - 2017-10-27 12:25:53 --> URI Class Initialized
INFO - 2017-10-27 12:25:53 --> Router Class Initialized
INFO - 2017-10-27 12:25:53 --> Output Class Initialized
INFO - 2017-10-27 12:25:53 --> Security Class Initialized
DEBUG - 2017-10-27 12:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:25:53 --> Input Class Initialized
INFO - 2017-10-27 12:25:53 --> Language Class Initialized
INFO - 2017-10-27 12:25:53 --> Loader Class Initialized
INFO - 2017-10-27 12:25:53 --> Helper loaded: url_helper
INFO - 2017-10-27 12:25:53 --> Helper loaded: common_helper
INFO - 2017-10-27 12:25:53 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:25:53 --> Email Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Controller Class Initialized
INFO - 2017-10-27 12:25:53 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> Model Class Initialized
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:25:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:25:53 --> Final output sent to browser
DEBUG - 2017-10-27 12:25:53 --> Total execution time: 0.0233
INFO - 2017-10-27 12:26:01 --> Config Class Initialized
INFO - 2017-10-27 12:26:01 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:01 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:01 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:01 --> URI Class Initialized
INFO - 2017-10-27 12:26:01 --> Router Class Initialized
INFO - 2017-10-27 12:26:01 --> Output Class Initialized
INFO - 2017-10-27 12:26:01 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:01 --> Input Class Initialized
INFO - 2017-10-27 12:26:01 --> Language Class Initialized
INFO - 2017-10-27 12:26:01 --> Loader Class Initialized
INFO - 2017-10-27 12:26:01 --> Helper loaded: url_helper
INFO - 2017-10-27 12:26:01 --> Helper loaded: common_helper
INFO - 2017-10-27 12:26:01 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:26:01 --> Email Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Controller Class Initialized
INFO - 2017-10-27 12:26:01 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> Model Class Initialized
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:26:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:26:01 --> Final output sent to browser
DEBUG - 2017-10-27 12:26:01 --> Total execution time: 0.0910
INFO - 2017-10-27 12:26:01 --> Config Class Initialized
INFO - 2017-10-27 12:26:01 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:01 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:01 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:01 --> URI Class Initialized
INFO - 2017-10-27 12:26:01 --> Router Class Initialized
INFO - 2017-10-27 12:26:01 --> Output Class Initialized
INFO - 2017-10-27 12:26:01 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:01 --> Input Class Initialized
INFO - 2017-10-27 12:26:01 --> Language Class Initialized
ERROR - 2017-10-27 12:26:01 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:26:17 --> Config Class Initialized
INFO - 2017-10-27 12:26:17 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:17 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:17 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:17 --> URI Class Initialized
INFO - 2017-10-27 12:26:17 --> Router Class Initialized
INFO - 2017-10-27 12:26:17 --> Output Class Initialized
INFO - 2017-10-27 12:26:17 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:17 --> Input Class Initialized
INFO - 2017-10-27 12:26:17 --> Language Class Initialized
INFO - 2017-10-27 12:26:17 --> Loader Class Initialized
INFO - 2017-10-27 12:26:17 --> Helper loaded: url_helper
INFO - 2017-10-27 12:26:17 --> Helper loaded: common_helper
INFO - 2017-10-27 12:26:17 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:26:17 --> Email Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Controller Class Initialized
INFO - 2017-10-27 12:26:17 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> Model Class Initialized
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:26:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:26:17 --> Final output sent to browser
DEBUG - 2017-10-27 12:26:17 --> Total execution time: 0.0306
INFO - 2017-10-27 12:26:17 --> Config Class Initialized
INFO - 2017-10-27 12:26:17 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:17 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:17 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:17 --> URI Class Initialized
INFO - 2017-10-27 12:26:17 --> Router Class Initialized
INFO - 2017-10-27 12:26:17 --> Output Class Initialized
INFO - 2017-10-27 12:26:17 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:17 --> Input Class Initialized
INFO - 2017-10-27 12:26:17 --> Language Class Initialized
ERROR - 2017-10-27 12:26:17 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:26:43 --> Config Class Initialized
INFO - 2017-10-27 12:26:43 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:43 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:43 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:43 --> URI Class Initialized
INFO - 2017-10-27 12:26:43 --> Router Class Initialized
INFO - 2017-10-27 12:26:43 --> Output Class Initialized
INFO - 2017-10-27 12:26:43 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:43 --> Input Class Initialized
INFO - 2017-10-27 12:26:43 --> Language Class Initialized
INFO - 2017-10-27 12:26:43 --> Loader Class Initialized
INFO - 2017-10-27 12:26:43 --> Helper loaded: url_helper
INFO - 2017-10-27 12:26:43 --> Helper loaded: common_helper
INFO - 2017-10-27 12:26:43 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:26:43 --> Email Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Controller Class Initialized
INFO - 2017-10-27 12:26:43 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> Model Class Initialized
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:26:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:26:43 --> Final output sent to browser
DEBUG - 2017-10-27 12:26:43 --> Total execution time: 0.0299
INFO - 2017-10-27 12:26:43 --> Config Class Initialized
INFO - 2017-10-27 12:26:43 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:26:43 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:26:43 --> Utf8 Class Initialized
INFO - 2017-10-27 12:26:43 --> URI Class Initialized
INFO - 2017-10-27 12:26:43 --> Router Class Initialized
INFO - 2017-10-27 12:26:43 --> Output Class Initialized
INFO - 2017-10-27 12:26:43 --> Security Class Initialized
DEBUG - 2017-10-27 12:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:26:43 --> Input Class Initialized
INFO - 2017-10-27 12:26:43 --> Language Class Initialized
ERROR - 2017-10-27 12:26:43 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:36:57 --> Config Class Initialized
INFO - 2017-10-27 12:36:57 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:36:57 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:36:57 --> Utf8 Class Initialized
INFO - 2017-10-27 12:36:57 --> URI Class Initialized
INFO - 2017-10-27 12:36:57 --> Router Class Initialized
INFO - 2017-10-27 12:36:57 --> Output Class Initialized
INFO - 2017-10-27 12:36:57 --> Security Class Initialized
DEBUG - 2017-10-27 12:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:36:57 --> Input Class Initialized
INFO - 2017-10-27 12:36:57 --> Language Class Initialized
INFO - 2017-10-27 12:36:57 --> Loader Class Initialized
INFO - 2017-10-27 12:36:57 --> Helper loaded: url_helper
INFO - 2017-10-27 12:36:57 --> Helper loaded: common_helper
INFO - 2017-10-27 12:36:57 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:36:57 --> Email Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Controller Class Initialized
INFO - 2017-10-27 12:36:57 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> Model Class Initialized
INFO - 2017-10-27 12:36:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:36:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:36:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:36:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:36:57 --> Severity: error --> Exception: syntax error, unexpected 'continue' (T_CONTINUE) /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php 58
INFO - 2017-10-27 12:37:33 --> Config Class Initialized
INFO - 2017-10-27 12:37:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:37:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:37:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:37:33 --> URI Class Initialized
INFO - 2017-10-27 12:37:33 --> Router Class Initialized
INFO - 2017-10-27 12:37:33 --> Output Class Initialized
INFO - 2017-10-27 12:37:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:37:33 --> Input Class Initialized
INFO - 2017-10-27 12:37:33 --> Language Class Initialized
INFO - 2017-10-27 12:37:33 --> Loader Class Initialized
INFO - 2017-10-27 12:37:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:37:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:37:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:37:33 --> Email Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Controller Class Initialized
INFO - 2017-10-27 12:37:33 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:37:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:37:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:37:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:37:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:37:33 --> Final output sent to browser
DEBUG - 2017-10-27 12:37:33 --> Total execution time: 0.0308
INFO - 2017-10-27 12:37:33 --> Config Class Initialized
INFO - 2017-10-27 12:37:33 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:37:33 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:37:33 --> Utf8 Class Initialized
INFO - 2017-10-27 12:37:33 --> URI Class Initialized
INFO - 2017-10-27 12:37:33 --> Router Class Initialized
INFO - 2017-10-27 12:37:33 --> Output Class Initialized
INFO - 2017-10-27 12:37:33 --> Security Class Initialized
DEBUG - 2017-10-27 12:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:37:33 --> Input Class Initialized
INFO - 2017-10-27 12:37:33 --> Language Class Initialized
INFO - 2017-10-27 12:37:33 --> Loader Class Initialized
INFO - 2017-10-27 12:37:33 --> Helper loaded: url_helper
INFO - 2017-10-27 12:37:33 --> Helper loaded: common_helper
INFO - 2017-10-27 12:37:33 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:37:33 --> Email Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Controller Class Initialized
INFO - 2017-10-27 12:37:33 --> Model Class Initialized
INFO - 2017-10-27 12:37:33 --> Final output sent to browser
DEBUG - 2017-10-27 12:37:33 --> Total execution time: 0.0026
INFO - 2017-10-27 12:37:39 --> Config Class Initialized
INFO - 2017-10-27 12:37:39 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:37:39 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:37:39 --> Utf8 Class Initialized
INFO - 2017-10-27 12:37:39 --> URI Class Initialized
INFO - 2017-10-27 12:37:39 --> Router Class Initialized
INFO - 2017-10-27 12:37:39 --> Output Class Initialized
INFO - 2017-10-27 12:37:39 --> Security Class Initialized
DEBUG - 2017-10-27 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:37:39 --> Input Class Initialized
INFO - 2017-10-27 12:37:39 --> Language Class Initialized
INFO - 2017-10-27 12:37:39 --> Loader Class Initialized
INFO - 2017-10-27 12:37:39 --> Helper loaded: url_helper
INFO - 2017-10-27 12:37:39 --> Helper loaded: common_helper
INFO - 2017-10-27 12:37:39 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:37:39 --> Email Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Controller Class Initialized
INFO - 2017-10-27 12:37:39 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> Model Class Initialized
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:37:39 --> Severity: Notice --> Undefined variable: userMembeship /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 75
ERROR - 2017-10-27 12:37:39 --> Severity: Notice --> Undefined variable: userMembeship /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 79
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:37:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:37:39 --> Final output sent to browser
DEBUG - 2017-10-27 12:37:39 --> Total execution time: 0.0253
INFO - 2017-10-27 12:38:24 --> Config Class Initialized
INFO - 2017-10-27 12:38:24 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:38:24 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:38:24 --> Utf8 Class Initialized
INFO - 2017-10-27 12:38:24 --> URI Class Initialized
INFO - 2017-10-27 12:38:24 --> Router Class Initialized
INFO - 2017-10-27 12:38:24 --> Output Class Initialized
INFO - 2017-10-27 12:38:24 --> Security Class Initialized
DEBUG - 2017-10-27 12:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:38:24 --> Input Class Initialized
INFO - 2017-10-27 12:38:24 --> Language Class Initialized
INFO - 2017-10-27 12:38:24 --> Loader Class Initialized
INFO - 2017-10-27 12:38:24 --> Helper loaded: url_helper
INFO - 2017-10-27 12:38:24 --> Helper loaded: common_helper
INFO - 2017-10-27 12:38:24 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:38:24 --> Email Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Controller Class Initialized
INFO - 2017-10-27 12:38:24 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> Model Class Initialized
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:38:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 79
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:38:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:38:24 --> Final output sent to browser
DEBUG - 2017-10-27 12:38:24 --> Total execution time: 0.0202
INFO - 2017-10-27 12:39:12 --> Config Class Initialized
INFO - 2017-10-27 12:39:12 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:39:12 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:39:12 --> Utf8 Class Initialized
INFO - 2017-10-27 12:39:12 --> URI Class Initialized
INFO - 2017-10-27 12:39:12 --> Router Class Initialized
INFO - 2017-10-27 12:39:12 --> Output Class Initialized
INFO - 2017-10-27 12:39:12 --> Security Class Initialized
DEBUG - 2017-10-27 12:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:39:12 --> Input Class Initialized
INFO - 2017-10-27 12:39:12 --> Language Class Initialized
INFO - 2017-10-27 12:39:12 --> Loader Class Initialized
INFO - 2017-10-27 12:39:12 --> Helper loaded: url_helper
INFO - 2017-10-27 12:39:12 --> Helper loaded: common_helper
INFO - 2017-10-27 12:39:12 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:39:12 --> Email Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Controller Class Initialized
INFO - 2017-10-27 12:39:12 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> Model Class Initialized
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:39:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 80
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:39:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:39:12 --> Final output sent to browser
DEBUG - 2017-10-27 12:39:12 --> Total execution time: 0.0196
INFO - 2017-10-27 12:40:00 --> Config Class Initialized
INFO - 2017-10-27 12:40:00 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:40:00 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:40:00 --> Utf8 Class Initialized
INFO - 2017-10-27 12:40:00 --> URI Class Initialized
INFO - 2017-10-27 12:40:00 --> Router Class Initialized
INFO - 2017-10-27 12:40:00 --> Output Class Initialized
INFO - 2017-10-27 12:40:00 --> Security Class Initialized
DEBUG - 2017-10-27 12:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:40:00 --> Input Class Initialized
INFO - 2017-10-27 12:40:00 --> Language Class Initialized
INFO - 2017-10-27 12:40:00 --> Loader Class Initialized
INFO - 2017-10-27 12:40:00 --> Helper loaded: url_helper
INFO - 2017-10-27 12:40:00 --> Helper loaded: common_helper
INFO - 2017-10-27 12:40:00 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:40:00 --> Email Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Controller Class Initialized
INFO - 2017-10-27 12:40:00 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> Model Class Initialized
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:40:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 81
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:40:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:40:00 --> Final output sent to browser
DEBUG - 2017-10-27 12:40:00 --> Total execution time: 0.0217
INFO - 2017-10-27 12:40:23 --> Config Class Initialized
INFO - 2017-10-27 12:40:23 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:40:23 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:40:23 --> Utf8 Class Initialized
INFO - 2017-10-27 12:40:23 --> URI Class Initialized
INFO - 2017-10-27 12:40:23 --> Router Class Initialized
INFO - 2017-10-27 12:40:23 --> Output Class Initialized
INFO - 2017-10-27 12:40:23 --> Security Class Initialized
DEBUG - 2017-10-27 12:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:40:23 --> Input Class Initialized
INFO - 2017-10-27 12:40:23 --> Language Class Initialized
INFO - 2017-10-27 12:40:23 --> Loader Class Initialized
INFO - 2017-10-27 12:40:23 --> Helper loaded: url_helper
INFO - 2017-10-27 12:40:23 --> Helper loaded: common_helper
INFO - 2017-10-27 12:40:23 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:40:23 --> Email Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Controller Class Initialized
INFO - 2017-10-27 12:40:23 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> Model Class Initialized
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
ERROR - 2017-10-27 12:40:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/User_library_event_escrow_model.php 81
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:40:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:40:23 --> Final output sent to browser
DEBUG - 2017-10-27 12:40:23 --> Total execution time: 0.0196
INFO - 2017-10-27 12:41:04 --> Config Class Initialized
INFO - 2017-10-27 12:41:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:41:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:41:04 --> Utf8 Class Initialized
INFO - 2017-10-27 12:41:04 --> URI Class Initialized
INFO - 2017-10-27 12:41:04 --> Router Class Initialized
INFO - 2017-10-27 12:41:04 --> Output Class Initialized
INFO - 2017-10-27 12:41:04 --> Security Class Initialized
DEBUG - 2017-10-27 12:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:41:04 --> Input Class Initialized
INFO - 2017-10-27 12:41:04 --> Language Class Initialized
INFO - 2017-10-27 12:41:04 --> Loader Class Initialized
INFO - 2017-10-27 12:41:04 --> Helper loaded: url_helper
INFO - 2017-10-27 12:41:04 --> Helper loaded: common_helper
INFO - 2017-10-27 12:41:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:41:04 --> Email Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Controller Class Initialized
INFO - 2017-10-27 12:41:04 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> Model Class Initialized
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:41:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:41:04 --> Final output sent to browser
DEBUG - 2017-10-27 12:41:04 --> Total execution time: 0.0200
INFO - 2017-10-27 12:41:09 --> Config Class Initialized
INFO - 2017-10-27 12:41:09 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:41:09 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:41:09 --> Utf8 Class Initialized
INFO - 2017-10-27 12:41:09 --> URI Class Initialized
INFO - 2017-10-27 12:41:09 --> Router Class Initialized
INFO - 2017-10-27 12:41:09 --> Output Class Initialized
INFO - 2017-10-27 12:41:09 --> Security Class Initialized
DEBUG - 2017-10-27 12:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:41:09 --> Input Class Initialized
INFO - 2017-10-27 12:41:09 --> Language Class Initialized
INFO - 2017-10-27 12:41:09 --> Loader Class Initialized
INFO - 2017-10-27 12:41:09 --> Helper loaded: url_helper
INFO - 2017-10-27 12:41:09 --> Helper loaded: common_helper
INFO - 2017-10-27 12:41:09 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:41:09 --> Email Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Controller Class Initialized
INFO - 2017-10-27 12:41:09 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:09 --> Model Class Initialized
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:41:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:41:10 --> Final output sent to browser
DEBUG - 2017-10-27 12:41:10 --> Total execution time: 0.0289
INFO - 2017-10-27 12:41:18 --> Config Class Initialized
INFO - 2017-10-27 12:41:18 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:41:18 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:41:18 --> Utf8 Class Initialized
INFO - 2017-10-27 12:41:18 --> URI Class Initialized
INFO - 2017-10-27 12:41:18 --> Router Class Initialized
INFO - 2017-10-27 12:41:18 --> Output Class Initialized
INFO - 2017-10-27 12:41:18 --> Security Class Initialized
DEBUG - 2017-10-27 12:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:41:18 --> Input Class Initialized
INFO - 2017-10-27 12:41:18 --> Language Class Initialized
INFO - 2017-10-27 12:41:18 --> Loader Class Initialized
INFO - 2017-10-27 12:41:18 --> Helper loaded: url_helper
INFO - 2017-10-27 12:41:18 --> Helper loaded: common_helper
INFO - 2017-10-27 12:41:18 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:41:18 --> Email Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Controller Class Initialized
INFO - 2017-10-27 12:41:18 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> Model Class Initialized
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:41:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:41:18 --> Final output sent to browser
DEBUG - 2017-10-27 12:41:18 --> Total execution time: 0.0284
INFO - 2017-10-27 12:41:58 --> Config Class Initialized
INFO - 2017-10-27 12:41:58 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:41:58 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:41:58 --> Utf8 Class Initialized
INFO - 2017-10-27 12:41:58 --> URI Class Initialized
INFO - 2017-10-27 12:41:58 --> Router Class Initialized
INFO - 2017-10-27 12:41:58 --> Output Class Initialized
INFO - 2017-10-27 12:41:58 --> Security Class Initialized
DEBUG - 2017-10-27 12:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:41:58 --> Input Class Initialized
INFO - 2017-10-27 12:41:58 --> Language Class Initialized
INFO - 2017-10-27 12:41:58 --> Loader Class Initialized
INFO - 2017-10-27 12:41:58 --> Helper loaded: url_helper
INFO - 2017-10-27 12:41:58 --> Helper loaded: common_helper
INFO - 2017-10-27 12:41:58 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:41:58 --> Email Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Controller Class Initialized
INFO - 2017-10-27 12:41:58 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> Model Class Initialized
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:41:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:41:58 --> Final output sent to browser
DEBUG - 2017-10-27 12:41:58 --> Total execution time: 0.0229
INFO - 2017-10-27 12:42:01 --> Config Class Initialized
INFO - 2017-10-27 12:42:01 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:01 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:01 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:01 --> URI Class Initialized
INFO - 2017-10-27 12:42:01 --> Router Class Initialized
INFO - 2017-10-27 12:42:01 --> Output Class Initialized
INFO - 2017-10-27 12:42:01 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:01 --> Input Class Initialized
INFO - 2017-10-27 12:42:01 --> Language Class Initialized
INFO - 2017-10-27 12:42:01 --> Loader Class Initialized
INFO - 2017-10-27 12:42:01 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:01 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:01 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:01 --> Email Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Controller Class Initialized
INFO - 2017-10-27 12:42:01 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> Model Class Initialized
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:42:01 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:01 --> Total execution time: 0.0430
INFO - 2017-10-27 12:42:01 --> Config Class Initialized
INFO - 2017-10-27 12:42:01 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:01 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:01 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:01 --> URI Class Initialized
INFO - 2017-10-27 12:42:01 --> Router Class Initialized
INFO - 2017-10-27 12:42:01 --> Output Class Initialized
INFO - 2017-10-27 12:42:01 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:01 --> Input Class Initialized
INFO - 2017-10-27 12:42:01 --> Language Class Initialized
ERROR - 2017-10-27 12:42:01 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-27 12:42:05 --> Config Class Initialized
INFO - 2017-10-27 12:42:05 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:05 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:05 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:05 --> URI Class Initialized
INFO - 2017-10-27 12:42:05 --> Router Class Initialized
INFO - 2017-10-27 12:42:05 --> Output Class Initialized
INFO - 2017-10-27 12:42:05 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:05 --> Input Class Initialized
INFO - 2017-10-27 12:42:05 --> Language Class Initialized
INFO - 2017-10-27 12:42:05 --> Loader Class Initialized
INFO - 2017-10-27 12:42:05 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:05 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:05 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:05 --> Email Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Controller Class Initialized
INFO - 2017-10-27 12:42:05 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> Model Class Initialized
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:42:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:42:05 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:05 --> Total execution time: 0.0330
INFO - 2017-10-27 12:42:07 --> Config Class Initialized
INFO - 2017-10-27 12:42:07 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:07 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:07 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:07 --> URI Class Initialized
INFO - 2017-10-27 12:42:07 --> Router Class Initialized
INFO - 2017-10-27 12:42:07 --> Output Class Initialized
INFO - 2017-10-27 12:42:07 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:07 --> Input Class Initialized
INFO - 2017-10-27 12:42:07 --> Language Class Initialized
INFO - 2017-10-27 12:42:07 --> Loader Class Initialized
INFO - 2017-10-27 12:42:07 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:07 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:07 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:07 --> Email Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Controller Class Initialized
INFO - 2017-10-27 12:42:07 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> Model Class Initialized
INFO - 2017-10-27 12:42:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:42:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:42:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:42:07 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:07 --> Total execution time: 0.1227
INFO - 2017-10-27 12:42:08 --> Config Class Initialized
INFO - 2017-10-27 12:42:08 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:08 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:08 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:08 --> URI Class Initialized
INFO - 2017-10-27 12:42:08 --> Router Class Initialized
INFO - 2017-10-27 12:42:08 --> Output Class Initialized
INFO - 2017-10-27 12:42:08 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:08 --> Input Class Initialized
INFO - 2017-10-27 12:42:08 --> Language Class Initialized
INFO - 2017-10-27 12:42:08 --> Loader Class Initialized
INFO - 2017-10-27 12:42:08 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:08 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:08 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:08 --> Email Class Initialized
INFO - 2017-10-27 12:42:08 --> Model Class Initialized
INFO - 2017-10-27 12:42:08 --> Controller Class Initialized
INFO - 2017-10-27 12:42:08 --> Model Class Initialized
INFO - 2017-10-27 12:42:08 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:08 --> Total execution time: 0.0025
INFO - 2017-10-27 12:42:10 --> Config Class Initialized
INFO - 2017-10-27 12:42:10 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:10 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:10 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:10 --> URI Class Initialized
INFO - 2017-10-27 12:42:10 --> Router Class Initialized
INFO - 2017-10-27 12:42:10 --> Output Class Initialized
INFO - 2017-10-27 12:42:10 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:10 --> Input Class Initialized
INFO - 2017-10-27 12:42:10 --> Language Class Initialized
INFO - 2017-10-27 12:42:10 --> Loader Class Initialized
INFO - 2017-10-27 12:42:10 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:10 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:10 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:10 --> Email Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Controller Class Initialized
INFO - 2017-10-27 12:42:10 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 12:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 12:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 12:42:10 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:10 --> Total execution time: 0.0276
INFO - 2017-10-27 12:42:10 --> Config Class Initialized
INFO - 2017-10-27 12:42:10 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:10 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:10 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:10 --> URI Class Initialized
INFO - 2017-10-27 12:42:10 --> Router Class Initialized
INFO - 2017-10-27 12:42:10 --> Output Class Initialized
INFO - 2017-10-27 12:42:10 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:10 --> Input Class Initialized
INFO - 2017-10-27 12:42:10 --> Language Class Initialized
INFO - 2017-10-27 12:42:10 --> Loader Class Initialized
INFO - 2017-10-27 12:42:10 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:10 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:10 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:10 --> Email Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Controller Class Initialized
INFO - 2017-10-27 12:42:10 --> Model Class Initialized
INFO - 2017-10-27 12:42:10 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:10 --> Total execution time: 0.0028
INFO - 2017-10-27 12:42:12 --> Config Class Initialized
INFO - 2017-10-27 12:42:12 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:12 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:12 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:12 --> URI Class Initialized
INFO - 2017-10-27 12:42:12 --> Router Class Initialized
INFO - 2017-10-27 12:42:12 --> Output Class Initialized
INFO - 2017-10-27 12:42:12 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:12 --> Input Class Initialized
INFO - 2017-10-27 12:42:12 --> Language Class Initialized
INFO - 2017-10-27 12:42:12 --> Loader Class Initialized
INFO - 2017-10-27 12:42:12 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:12 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:12 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:12 --> Email Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Controller Class Initialized
INFO - 2017-10-27 12:42:12 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> Model Class Initialized
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:42:12 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:12 --> Total execution time: 0.0420
INFO - 2017-10-27 12:42:17 --> Config Class Initialized
INFO - 2017-10-27 12:42:17 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:17 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:17 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:17 --> URI Class Initialized
INFO - 2017-10-27 12:42:17 --> Router Class Initialized
INFO - 2017-10-27 12:42:17 --> Output Class Initialized
INFO - 2017-10-27 12:42:17 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:17 --> Input Class Initialized
INFO - 2017-10-27 12:42:17 --> Language Class Initialized
INFO - 2017-10-27 12:42:18 --> Loader Class Initialized
INFO - 2017-10-27 12:42:18 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:18 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:18 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:18 --> Email Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Controller Class Initialized
INFO - 2017-10-27 12:42:18 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> Model Class Initialized
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:42:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:42:18 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:18 --> Total execution time: 0.0422
INFO - 2017-10-27 12:42:21 --> Config Class Initialized
INFO - 2017-10-27 12:42:21 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:42:21 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:42:21 --> Utf8 Class Initialized
INFO - 2017-10-27 12:42:21 --> URI Class Initialized
INFO - 2017-10-27 12:42:21 --> Router Class Initialized
INFO - 2017-10-27 12:42:21 --> Output Class Initialized
INFO - 2017-10-27 12:42:21 --> Security Class Initialized
DEBUG - 2017-10-27 12:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:42:21 --> Input Class Initialized
INFO - 2017-10-27 12:42:21 --> Language Class Initialized
INFO - 2017-10-27 12:42:21 --> Loader Class Initialized
INFO - 2017-10-27 12:42:21 --> Helper loaded: url_helper
INFO - 2017-10-27 12:42:21 --> Helper loaded: common_helper
INFO - 2017-10-27 12:42:21 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:42:21 --> Email Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Controller Class Initialized
INFO - 2017-10-27 12:42:21 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> Model Class Initialized
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:42:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:42:21 --> Final output sent to browser
DEBUG - 2017-10-27 12:42:21 --> Total execution time: 0.0301
INFO - 2017-10-27 12:43:04 --> Config Class Initialized
INFO - 2017-10-27 12:43:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:43:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:43:04 --> Utf8 Class Initialized
INFO - 2017-10-27 12:43:04 --> URI Class Initialized
INFO - 2017-10-27 12:43:04 --> Router Class Initialized
INFO - 2017-10-27 12:43:04 --> Output Class Initialized
INFO - 2017-10-27 12:43:04 --> Security Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:43:04 --> Input Class Initialized
INFO - 2017-10-27 12:43:04 --> Language Class Initialized
INFO - 2017-10-27 12:43:04 --> Loader Class Initialized
INFO - 2017-10-27 12:43:04 --> Helper loaded: url_helper
INFO - 2017-10-27 12:43:04 --> Helper loaded: common_helper
INFO - 2017-10-27 12:43:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:43:04 --> Email Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Controller Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Final output sent to browser
DEBUG - 2017-10-27 12:43:04 --> Total execution time: 0.0036
INFO - 2017-10-27 12:43:04 --> Config Class Initialized
INFO - 2017-10-27 12:43:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:43:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:43:04 --> Utf8 Class Initialized
INFO - 2017-10-27 12:43:04 --> URI Class Initialized
INFO - 2017-10-27 12:43:04 --> Router Class Initialized
INFO - 2017-10-27 12:43:04 --> Output Class Initialized
INFO - 2017-10-27 12:43:04 --> Security Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:43:04 --> Input Class Initialized
INFO - 2017-10-27 12:43:04 --> Language Class Initialized
INFO - 2017-10-27 12:43:04 --> Loader Class Initialized
INFO - 2017-10-27 12:43:04 --> Helper loaded: url_helper
INFO - 2017-10-27 12:43:04 --> Helper loaded: common_helper
INFO - 2017-10-27 12:43:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:43:04 --> Email Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Controller Class Initialized
INFO - 2017-10-27 12:43:04 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Config Class Initialized
INFO - 2017-10-27 12:43:04 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:43:04 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:43:04 --> Utf8 Class Initialized
INFO - 2017-10-27 12:43:04 --> URI Class Initialized
INFO - 2017-10-27 12:43:04 --> Router Class Initialized
INFO - 2017-10-27 12:43:04 --> Output Class Initialized
INFO - 2017-10-27 12:43:04 --> Security Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:43:04 --> Input Class Initialized
INFO - 2017-10-27 12:43:04 --> Language Class Initialized
INFO - 2017-10-27 12:43:04 --> Loader Class Initialized
INFO - 2017-10-27 12:43:04 --> Helper loaded: url_helper
INFO - 2017-10-27 12:43:04 --> Helper loaded: common_helper
INFO - 2017-10-27 12:43:04 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:43:04 --> Email Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Controller Class Initialized
INFO - 2017-10-27 12:43:04 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> Model Class Initialized
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:43:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:43:04 --> Final output sent to browser
DEBUG - 2017-10-27 12:43:04 --> Total execution time: 0.1103
INFO - 2017-10-27 12:43:10 --> Config Class Initialized
INFO - 2017-10-27 12:43:10 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:43:10 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:43:10 --> Utf8 Class Initialized
INFO - 2017-10-27 12:43:10 --> URI Class Initialized
INFO - 2017-10-27 12:43:10 --> Router Class Initialized
INFO - 2017-10-27 12:43:10 --> Output Class Initialized
INFO - 2017-10-27 12:43:10 --> Security Class Initialized
DEBUG - 2017-10-27 12:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:43:10 --> Input Class Initialized
INFO - 2017-10-27 12:43:10 --> Language Class Initialized
INFO - 2017-10-27 12:43:10 --> Loader Class Initialized
INFO - 2017-10-27 12:43:10 --> Helper loaded: url_helper
INFO - 2017-10-27 12:43:10 --> Helper loaded: common_helper
INFO - 2017-10-27 12:43:10 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:43:10 --> Email Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Controller Class Initialized
INFO - 2017-10-27 12:43:10 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> Model Class Initialized
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:43:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:43:10 --> Final output sent to browser
DEBUG - 2017-10-27 12:43:10 --> Total execution time: 0.0824
INFO - 2017-10-27 12:43:19 --> Config Class Initialized
INFO - 2017-10-27 12:43:19 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:43:19 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:43:19 --> Utf8 Class Initialized
INFO - 2017-10-27 12:43:19 --> URI Class Initialized
INFO - 2017-10-27 12:43:19 --> Router Class Initialized
INFO - 2017-10-27 12:43:19 --> Output Class Initialized
INFO - 2017-10-27 12:43:19 --> Security Class Initialized
DEBUG - 2017-10-27 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:43:19 --> Input Class Initialized
INFO - 2017-10-27 12:43:19 --> Language Class Initialized
INFO - 2017-10-27 12:43:19 --> Loader Class Initialized
INFO - 2017-10-27 12:43:19 --> Helper loaded: url_helper
INFO - 2017-10-27 12:43:19 --> Helper loaded: common_helper
INFO - 2017-10-27 12:43:19 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:43:19 --> Email Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Controller Class Initialized
INFO - 2017-10-27 12:43:19 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> Model Class Initialized
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:43:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:43:19 --> Final output sent to browser
DEBUG - 2017-10-27 12:43:19 --> Total execution time: 0.0293
INFO - 2017-10-27 12:44:06 --> Config Class Initialized
INFO - 2017-10-27 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-27 12:44:06 --> URI Class Initialized
INFO - 2017-10-27 12:44:06 --> Router Class Initialized
INFO - 2017-10-27 12:44:06 --> Output Class Initialized
INFO - 2017-10-27 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-27 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:44:06 --> Input Class Initialized
INFO - 2017-10-27 12:44:06 --> Language Class Initialized
INFO - 2017-10-27 12:44:06 --> Loader Class Initialized
INFO - 2017-10-27 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-27 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-27 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:44:06 --> Email Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Controller Class Initialized
INFO - 2017-10-27 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> Model Class Initialized
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-27 12:44:06 --> Total execution time: 0.0292
INFO - 2017-10-27 12:44:08 --> Config Class Initialized
INFO - 2017-10-27 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-27 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-27 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-27 12:44:08 --> URI Class Initialized
INFO - 2017-10-27 12:44:08 --> Router Class Initialized
INFO - 2017-10-27 12:44:08 --> Output Class Initialized
INFO - 2017-10-27 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-27 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 12:44:08 --> Input Class Initialized
INFO - 2017-10-27 12:44:08 --> Language Class Initialized
INFO - 2017-10-27 12:44:08 --> Loader Class Initialized
INFO - 2017-10-27 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-27 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-27 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-27 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 12:44:08 --> Email Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Controller Class Initialized
INFO - 2017-10-27 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> Model Class Initialized
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-27 12:44:08 --> Total execution time: 0.0282
INFO - 2017-10-27 13:02:03 --> Config Class Initialized
INFO - 2017-10-27 13:02:03 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:02:03 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:02:03 --> Utf8 Class Initialized
INFO - 2017-10-27 13:02:03 --> URI Class Initialized
INFO - 2017-10-27 13:02:03 --> Router Class Initialized
INFO - 2017-10-27 13:02:03 --> Output Class Initialized
INFO - 2017-10-27 13:02:03 --> Security Class Initialized
DEBUG - 2017-10-27 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:02:03 --> Input Class Initialized
INFO - 2017-10-27 13:02:03 --> Language Class Initialized
INFO - 2017-10-27 13:02:03 --> Loader Class Initialized
INFO - 2017-10-27 13:02:03 --> Helper loaded: url_helper
INFO - 2017-10-27 13:02:03 --> Helper loaded: common_helper
INFO - 2017-10-27 13:02:03 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:02:03 --> Email Class Initialized
INFO - 2017-10-27 13:02:03 --> Model Class Initialized
INFO - 2017-10-27 13:02:03 --> Controller Class Initialized
INFO - 2017-10-27 13:02:03 --> Model Class Initialized
INFO - 2017-10-27 13:02:03 --> Model Class Initialized
INFO - 2017-10-27 13:02:03 --> Model Class Initialized
INFO - 2017-10-27 13:02:03 --> Final output sent to browser
DEBUG - 2017-10-27 13:02:03 --> Total execution time: 0.1174
INFO - 2017-10-27 13:19:06 --> Config Class Initialized
INFO - 2017-10-27 13:19:06 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:06 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:06 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:06 --> URI Class Initialized
INFO - 2017-10-27 13:19:06 --> Router Class Initialized
INFO - 2017-10-27 13:19:06 --> Output Class Initialized
INFO - 2017-10-27 13:19:06 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:06 --> Input Class Initialized
INFO - 2017-10-27 13:19:06 --> Language Class Initialized
INFO - 2017-10-27 13:19:06 --> Loader Class Initialized
INFO - 2017-10-27 13:19:06 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:06 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:06 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:06 --> Email Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Controller Class Initialized
INFO - 2017-10-27 13:19:06 --> Helper loaded: cookie_helper
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 13:19:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 13:19:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 13:19:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 13:19:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 13:19:06 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:06 --> Total execution time: 0.0317
INFO - 2017-10-27 13:19:06 --> Config Class Initialized
INFO - 2017-10-27 13:19:06 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:06 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:06 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:06 --> URI Class Initialized
INFO - 2017-10-27 13:19:06 --> Router Class Initialized
INFO - 2017-10-27 13:19:06 --> Output Class Initialized
INFO - 2017-10-27 13:19:06 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:06 --> Input Class Initialized
INFO - 2017-10-27 13:19:06 --> Language Class Initialized
INFO - 2017-10-27 13:19:06 --> Loader Class Initialized
INFO - 2017-10-27 13:19:06 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:06 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:06 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:06 --> Email Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Controller Class Initialized
INFO - 2017-10-27 13:19:06 --> Model Class Initialized
INFO - 2017-10-27 13:19:06 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:06 --> Total execution time: 0.0041
INFO - 2017-10-27 13:19:07 --> Config Class Initialized
INFO - 2017-10-27 13:19:07 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:07 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:07 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:07 --> URI Class Initialized
INFO - 2017-10-27 13:19:07 --> Router Class Initialized
INFO - 2017-10-27 13:19:07 --> Output Class Initialized
INFO - 2017-10-27 13:19:07 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:07 --> Input Class Initialized
INFO - 2017-10-27 13:19:07 --> Language Class Initialized
INFO - 2017-10-27 13:19:07 --> Loader Class Initialized
INFO - 2017-10-27 13:19:07 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:07 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:07 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:07 --> Email Class Initialized
INFO - 2017-10-27 13:19:07 --> Model Class Initialized
INFO - 2017-10-27 13:19:07 --> Controller Class Initialized
INFO - 2017-10-27 13:19:07 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:07 --> Total execution time: 0.0031
INFO - 2017-10-27 13:19:14 --> Config Class Initialized
INFO - 2017-10-27 13:19:14 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:14 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:14 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:14 --> URI Class Initialized
INFO - 2017-10-27 13:19:14 --> Router Class Initialized
INFO - 2017-10-27 13:19:14 --> Output Class Initialized
INFO - 2017-10-27 13:19:14 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:14 --> Input Class Initialized
INFO - 2017-10-27 13:19:14 --> Language Class Initialized
INFO - 2017-10-27 13:19:14 --> Loader Class Initialized
INFO - 2017-10-27 13:19:14 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:14 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:14 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:14 --> Email Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Controller Class Initialized
INFO - 2017-10-27 13:19:14 --> Helper loaded: cookie_helper
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 13:19:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 13:19:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 13:19:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 13:19:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 13:19:14 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:14 --> Total execution time: 0.0375
INFO - 2017-10-27 13:19:14 --> Config Class Initialized
INFO - 2017-10-27 13:19:14 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:14 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:14 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:14 --> URI Class Initialized
INFO - 2017-10-27 13:19:14 --> Router Class Initialized
INFO - 2017-10-27 13:19:14 --> Output Class Initialized
INFO - 2017-10-27 13:19:14 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:14 --> Input Class Initialized
INFO - 2017-10-27 13:19:14 --> Language Class Initialized
INFO - 2017-10-27 13:19:14 --> Loader Class Initialized
INFO - 2017-10-27 13:19:14 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:14 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:14 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:14 --> Email Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Controller Class Initialized
INFO - 2017-10-27 13:19:14 --> Model Class Initialized
INFO - 2017-10-27 13:19:14 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:14 --> Total execution time: 0.0034
INFO - 2017-10-27 13:19:16 --> Config Class Initialized
INFO - 2017-10-27 13:19:16 --> Hooks Class Initialized
DEBUG - 2017-10-27 13:19:16 --> UTF-8 Support Enabled
INFO - 2017-10-27 13:19:16 --> Utf8 Class Initialized
INFO - 2017-10-27 13:19:16 --> URI Class Initialized
INFO - 2017-10-27 13:19:16 --> Router Class Initialized
INFO - 2017-10-27 13:19:16 --> Output Class Initialized
INFO - 2017-10-27 13:19:16 --> Security Class Initialized
DEBUG - 2017-10-27 13:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 13:19:16 --> Input Class Initialized
INFO - 2017-10-27 13:19:16 --> Language Class Initialized
INFO - 2017-10-27 13:19:16 --> Loader Class Initialized
INFO - 2017-10-27 13:19:16 --> Helper loaded: url_helper
INFO - 2017-10-27 13:19:16 --> Helper loaded: common_helper
INFO - 2017-10-27 13:19:16 --> Database Driver Class Initialized
DEBUG - 2017-10-27 13:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 13:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 13:19:16 --> Email Class Initialized
INFO - 2017-10-27 13:19:16 --> Model Class Initialized
INFO - 2017-10-27 13:19:16 --> Controller Class Initialized
INFO - 2017-10-27 13:19:16 --> Final output sent to browser
DEBUG - 2017-10-27 13:19:16 --> Total execution time: 0.0023
INFO - 2017-10-27 18:19:43 --> Config Class Initialized
INFO - 2017-10-27 18:19:43 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:19:44 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:19:44 --> Utf8 Class Initialized
INFO - 2017-10-27 18:19:44 --> URI Class Initialized
INFO - 2017-10-27 18:19:45 --> Router Class Initialized
INFO - 2017-10-27 18:19:45 --> Output Class Initialized
INFO - 2017-10-27 18:19:45 --> Security Class Initialized
DEBUG - 2017-10-27 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:19:45 --> Input Class Initialized
INFO - 2017-10-27 18:19:45 --> Language Class Initialized
INFO - 2017-10-27 18:19:46 --> Loader Class Initialized
INFO - 2017-10-27 18:19:46 --> Helper loaded: url_helper
INFO - 2017-10-27 18:19:46 --> Helper loaded: common_helper
INFO - 2017-10-27 18:19:47 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:19:49 --> Email Class Initialized
INFO - 2017-10-27 18:19:49 --> Model Class Initialized
INFO - 2017-10-27 18:19:49 --> Controller Class Initialized
INFO - 2017-10-27 18:19:49 --> Helper loaded: cookie_helper
INFO - 2017-10-27 18:19:49 --> Model Class Initialized
INFO - 2017-10-27 18:19:49 --> Model Class Initialized
INFO - 2017-10-27 18:19:50 --> Model Class Initialized
INFO - 2017-10-27 18:19:50 --> Model Class Initialized
INFO - 2017-10-27 18:19:53 --> Model Class Initialized
INFO - 2017-10-27 18:19:53 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Config Class Initialized
INFO - 2017-10-27 18:19:59 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:19:59 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:19:59 --> Utf8 Class Initialized
INFO - 2017-10-27 18:19:59 --> URI Class Initialized
INFO - 2017-10-27 18:19:59 --> Router Class Initialized
INFO - 2017-10-27 18:19:59 --> Output Class Initialized
INFO - 2017-10-27 18:19:59 --> Security Class Initialized
DEBUG - 2017-10-27 18:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:19:59 --> Input Class Initialized
INFO - 2017-10-27 18:19:59 --> Language Class Initialized
INFO - 2017-10-27 18:19:59 --> Loader Class Initialized
INFO - 2017-10-27 18:19:59 --> Helper loaded: url_helper
INFO - 2017-10-27 18:19:59 --> Helper loaded: common_helper
INFO - 2017-10-27 18:19:59 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:19:59 --> Email Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Controller Class Initialized
INFO - 2017-10-27 18:19:59 --> Helper loaded: cookie_helper
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:19:59 --> Model Class Initialized
INFO - 2017-10-27 18:20:00 --> Model Class Initialized
INFO - 2017-10-27 18:20:00 --> Model Class Initialized
INFO - 2017-10-27 18:20:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 18:20:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 18:20:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-27 18:20:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 18:20:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 18:20:00 --> Final output sent to browser
DEBUG - 2017-10-27 18:20:00 --> Total execution time: 1.0634
INFO - 2017-10-27 18:20:16 --> Config Class Initialized
INFO - 2017-10-27 18:20:16 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:20:16 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:20:16 --> Utf8 Class Initialized
INFO - 2017-10-27 18:20:16 --> URI Class Initialized
INFO - 2017-10-27 18:20:16 --> Router Class Initialized
INFO - 2017-10-27 18:20:16 --> Output Class Initialized
INFO - 2017-10-27 18:20:16 --> Security Class Initialized
DEBUG - 2017-10-27 18:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:20:16 --> Input Class Initialized
INFO - 2017-10-27 18:20:16 --> Language Class Initialized
INFO - 2017-10-27 18:20:16 --> Loader Class Initialized
INFO - 2017-10-27 18:20:16 --> Helper loaded: url_helper
INFO - 2017-10-27 18:20:16 --> Helper loaded: common_helper
INFO - 2017-10-27 18:20:16 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:20:16 --> Email Class Initialized
INFO - 2017-10-27 18:20:16 --> Model Class Initialized
INFO - 2017-10-27 18:20:16 --> Controller Class Initialized
INFO - 2017-10-27 18:20:16 --> Helper loaded: cookie_helper
INFO - 2017-10-27 18:20:16 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> Model Class Initialized
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 18:20:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 18:20:17 --> Final output sent to browser
DEBUG - 2017-10-27 18:20:17 --> Total execution time: 0.9488
INFO - 2017-10-27 18:20:25 --> Config Class Initialized
INFO - 2017-10-27 18:20:25 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:20:25 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:20:25 --> Utf8 Class Initialized
INFO - 2017-10-27 18:20:25 --> URI Class Initialized
INFO - 2017-10-27 18:20:25 --> Router Class Initialized
INFO - 2017-10-27 18:20:25 --> Output Class Initialized
INFO - 2017-10-27 18:20:25 --> Security Class Initialized
DEBUG - 2017-10-27 18:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:20:25 --> Input Class Initialized
INFO - 2017-10-27 18:20:25 --> Language Class Initialized
INFO - 2017-10-27 18:20:25 --> Loader Class Initialized
INFO - 2017-10-27 18:20:25 --> Helper loaded: url_helper
INFO - 2017-10-27 18:20:25 --> Helper loaded: common_helper
INFO - 2017-10-27 18:20:25 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:20:25 --> Email Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Controller Class Initialized
INFO - 2017-10-27 18:20:25 --> Helper loaded: cookie_helper
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:25 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Config Class Initialized
INFO - 2017-10-27 18:20:26 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:20:26 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:20:26 --> Utf8 Class Initialized
INFO - 2017-10-27 18:20:26 --> URI Class Initialized
INFO - 2017-10-27 18:20:26 --> Router Class Initialized
INFO - 2017-10-27 18:20:26 --> Output Class Initialized
INFO - 2017-10-27 18:20:26 --> Security Class Initialized
DEBUG - 2017-10-27 18:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:20:26 --> Input Class Initialized
INFO - 2017-10-27 18:20:26 --> Language Class Initialized
INFO - 2017-10-27 18:20:26 --> Loader Class Initialized
INFO - 2017-10-27 18:20:26 --> Helper loaded: url_helper
INFO - 2017-10-27 18:20:26 --> Helper loaded: common_helper
INFO - 2017-10-27 18:20:26 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:20:26 --> Email Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Controller Class Initialized
INFO - 2017-10-27 18:20:26 --> Helper loaded: cookie_helper
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:26 --> Model Class Initialized
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-27 18:20:27 --> Final output sent to browser
DEBUG - 2017-10-27 18:20:27 --> Total execution time: 0.7697
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-27 18:20:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-27 18:20:27 --> Final output sent to browser
DEBUG - 2017-10-27 18:20:27 --> Total execution time: 2.3888
INFO - 2017-10-27 18:20:35 --> Config Class Initialized
INFO - 2017-10-27 18:20:35 --> Hooks Class Initialized
DEBUG - 2017-10-27 18:20:35 --> UTF-8 Support Enabled
INFO - 2017-10-27 18:20:35 --> Utf8 Class Initialized
INFO - 2017-10-27 18:20:35 --> URI Class Initialized
INFO - 2017-10-27 18:20:35 --> Router Class Initialized
INFO - 2017-10-27 18:20:35 --> Output Class Initialized
INFO - 2017-10-27 18:20:35 --> Security Class Initialized
DEBUG - 2017-10-27 18:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-27 18:20:35 --> Input Class Initialized
INFO - 2017-10-27 18:20:35 --> Language Class Initialized
INFO - 2017-10-27 18:20:35 --> Loader Class Initialized
INFO - 2017-10-27 18:20:35 --> Helper loaded: url_helper
INFO - 2017-10-27 18:20:35 --> Helper loaded: common_helper
INFO - 2017-10-27 18:20:35 --> Database Driver Class Initialized
DEBUG - 2017-10-27 18:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-27 18:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-27 18:20:35 --> Email Class Initialized
INFO - 2017-10-27 18:20:35 --> Model Class Initialized
INFO - 2017-10-27 18:20:35 --> Controller Class Initialized
INFO - 2017-10-27 18:20:35 --> Model Class Initialized
INFO - 2017-10-27 18:20:35 --> Final output sent to browser
DEBUG - 2017-10-27 18:20:35 --> Total execution time: 0.0930
