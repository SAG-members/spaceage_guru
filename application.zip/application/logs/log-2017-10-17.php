<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-17 12:33:24 --> Config Class Initialized
INFO - 2017-10-17 12:33:24 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:33:24 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:33:24 --> Utf8 Class Initialized
INFO - 2017-10-17 12:33:24 --> URI Class Initialized
DEBUG - 2017-10-17 12:33:24 --> No URI present. Default controller set.
INFO - 2017-10-17 12:33:24 --> Router Class Initialized
INFO - 2017-10-17 12:33:24 --> Output Class Initialized
INFO - 2017-10-17 12:33:24 --> Security Class Initialized
DEBUG - 2017-10-17 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:33:24 --> Input Class Initialized
INFO - 2017-10-17 12:33:24 --> Language Class Initialized
INFO - 2017-10-17 12:33:24 --> Loader Class Initialized
INFO - 2017-10-17 12:33:24 --> Helper loaded: url_helper
INFO - 2017-10-17 12:33:24 --> Helper loaded: common_helper
INFO - 2017-10-17 12:33:24 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:33:24 --> Email Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Controller Class Initialized
INFO - 2017-10-17 12:33:24 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> Model Class Initialized
INFO - 2017-10-17 12:33:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:33:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:33:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:33:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-17 12:33:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:33:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:33:25 --> Final output sent to browser
DEBUG - 2017-10-17 12:33:25 --> Total execution time: 0.7017
INFO - 2017-10-17 12:42:33 --> Config Class Initialized
INFO - 2017-10-17 12:42:33 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:42:33 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:42:33 --> Utf8 Class Initialized
INFO - 2017-10-17 12:42:33 --> URI Class Initialized
INFO - 2017-10-17 12:42:33 --> Router Class Initialized
INFO - 2017-10-17 12:42:33 --> Output Class Initialized
INFO - 2017-10-17 12:42:33 --> Security Class Initialized
DEBUG - 2017-10-17 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:42:33 --> Input Class Initialized
INFO - 2017-10-17 12:42:33 --> Language Class Initialized
INFO - 2017-10-17 12:42:33 --> Loader Class Initialized
INFO - 2017-10-17 12:42:33 --> Helper loaded: url_helper
INFO - 2017-10-17 12:42:33 --> Helper loaded: common_helper
INFO - 2017-10-17 12:42:33 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:42:33 --> Email Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Controller Class Initialized
INFO - 2017-10-17 12:42:33 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:33 --> Model Class Initialized
INFO - 2017-10-17 12:42:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:42:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:42:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-17 12:42:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-17 12:42:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-17 12:42:34 --> Final output sent to browser
DEBUG - 2017-10-17 12:42:34 --> Total execution time: 0.1718
INFO - 2017-10-17 12:42:34 --> Config Class Initialized
INFO - 2017-10-17 12:42:34 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:42:34 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:42:34 --> Utf8 Class Initialized
INFO - 2017-10-17 12:42:34 --> URI Class Initialized
INFO - 2017-10-17 12:42:34 --> Router Class Initialized
INFO - 2017-10-17 12:42:34 --> Output Class Initialized
INFO - 2017-10-17 12:42:34 --> Security Class Initialized
DEBUG - 2017-10-17 12:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:42:34 --> Input Class Initialized
INFO - 2017-10-17 12:42:34 --> Language Class Initialized
INFO - 2017-10-17 12:42:34 --> Loader Class Initialized
INFO - 2017-10-17 12:42:34 --> Helper loaded: url_helper
INFO - 2017-10-17 12:42:34 --> Helper loaded: common_helper
INFO - 2017-10-17 12:42:34 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:42:34 --> Email Class Initialized
INFO - 2017-10-17 12:42:34 --> Model Class Initialized
INFO - 2017-10-17 12:42:34 --> Controller Class Initialized
INFO - 2017-10-17 12:42:34 --> Model Class Initialized
INFO - 2017-10-17 12:42:34 --> Final output sent to browser
DEBUG - 2017-10-17 12:42:34 --> Total execution time: 0.0225
INFO - 2017-10-17 12:42:35 --> Config Class Initialized
INFO - 2017-10-17 12:42:35 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:42:35 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:42:35 --> Utf8 Class Initialized
INFO - 2017-10-17 12:42:35 --> URI Class Initialized
INFO - 2017-10-17 12:42:35 --> Router Class Initialized
INFO - 2017-10-17 12:42:35 --> Output Class Initialized
INFO - 2017-10-17 12:42:35 --> Security Class Initialized
DEBUG - 2017-10-17 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:42:35 --> Input Class Initialized
INFO - 2017-10-17 12:42:35 --> Language Class Initialized
INFO - 2017-10-17 12:42:35 --> Loader Class Initialized
INFO - 2017-10-17 12:42:35 --> Helper loaded: url_helper
INFO - 2017-10-17 12:42:35 --> Helper loaded: common_helper
INFO - 2017-10-17 12:42:35 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:42:35 --> Email Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Controller Class Initialized
INFO - 2017-10-17 12:42:35 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:42:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:42:35 --> Final output sent to browser
DEBUG - 2017-10-17 12:42:35 --> Total execution time: 0.1289
INFO - 2017-10-17 12:42:35 --> Config Class Initialized
INFO - 2017-10-17 12:42:35 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:42:35 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:42:35 --> Utf8 Class Initialized
INFO - 2017-10-17 12:42:35 --> URI Class Initialized
INFO - 2017-10-17 12:42:35 --> Router Class Initialized
INFO - 2017-10-17 12:42:35 --> Output Class Initialized
INFO - 2017-10-17 12:42:35 --> Security Class Initialized
DEBUG - 2017-10-17 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:42:35 --> Input Class Initialized
INFO - 2017-10-17 12:42:35 --> Language Class Initialized
INFO - 2017-10-17 12:42:35 --> Loader Class Initialized
INFO - 2017-10-17 12:42:35 --> Helper loaded: url_helper
INFO - 2017-10-17 12:42:35 --> Helper loaded: common_helper
INFO - 2017-10-17 12:42:35 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:42:35 --> Email Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Controller Class Initialized
INFO - 2017-10-17 12:42:35 --> Model Class Initialized
INFO - 2017-10-17 12:42:35 --> Final output sent to browser
DEBUG - 2017-10-17 12:42:35 --> Total execution time: 0.0247
INFO - 2017-10-17 12:44:18 --> Config Class Initialized
INFO - 2017-10-17 12:44:18 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:44:18 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:44:18 --> Utf8 Class Initialized
INFO - 2017-10-17 12:44:18 --> URI Class Initialized
INFO - 2017-10-17 12:44:18 --> Router Class Initialized
INFO - 2017-10-17 12:44:18 --> Output Class Initialized
INFO - 2017-10-17 12:44:18 --> Security Class Initialized
DEBUG - 2017-10-17 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:44:18 --> Input Class Initialized
INFO - 2017-10-17 12:44:18 --> Language Class Initialized
INFO - 2017-10-17 12:44:18 --> Loader Class Initialized
INFO - 2017-10-17 12:44:18 --> Helper loaded: url_helper
INFO - 2017-10-17 12:44:18 --> Helper loaded: common_helper
INFO - 2017-10-17 12:44:18 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:44:18 --> Email Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Controller Class Initialized
INFO - 2017-10-17 12:44:18 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:44:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:44:18 --> Final output sent to browser
DEBUG - 2017-10-17 12:44:18 --> Total execution time: 0.0581
INFO - 2017-10-17 12:44:18 --> Config Class Initialized
INFO - 2017-10-17 12:44:18 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:44:18 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:44:18 --> Utf8 Class Initialized
INFO - 2017-10-17 12:44:18 --> URI Class Initialized
INFO - 2017-10-17 12:44:18 --> Router Class Initialized
INFO - 2017-10-17 12:44:18 --> Output Class Initialized
INFO - 2017-10-17 12:44:18 --> Security Class Initialized
DEBUG - 2017-10-17 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:44:18 --> Input Class Initialized
INFO - 2017-10-17 12:44:18 --> Language Class Initialized
INFO - 2017-10-17 12:44:18 --> Loader Class Initialized
INFO - 2017-10-17 12:44:18 --> Helper loaded: url_helper
INFO - 2017-10-17 12:44:18 --> Helper loaded: common_helper
INFO - 2017-10-17 12:44:18 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:44:18 --> Email Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Controller Class Initialized
INFO - 2017-10-17 12:44:18 --> Model Class Initialized
INFO - 2017-10-17 12:44:18 --> Final output sent to browser
DEBUG - 2017-10-17 12:44:18 --> Total execution time: 0.0058
INFO - 2017-10-17 12:44:26 --> Config Class Initialized
INFO - 2017-10-17 12:44:26 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:44:26 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:44:26 --> Utf8 Class Initialized
INFO - 2017-10-17 12:44:26 --> URI Class Initialized
INFO - 2017-10-17 12:44:26 --> Router Class Initialized
INFO - 2017-10-17 12:44:26 --> Output Class Initialized
INFO - 2017-10-17 12:44:26 --> Security Class Initialized
DEBUG - 2017-10-17 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:44:26 --> Input Class Initialized
INFO - 2017-10-17 12:44:26 --> Language Class Initialized
INFO - 2017-10-17 12:44:26 --> Loader Class Initialized
INFO - 2017-10-17 12:44:26 --> Helper loaded: url_helper
INFO - 2017-10-17 12:44:26 --> Helper loaded: common_helper
INFO - 2017-10-17 12:44:26 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:44:26 --> Email Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Controller Class Initialized
INFO - 2017-10-17 12:44:26 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-17 12:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-17 12:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-17 12:44:26 --> Final output sent to browser
DEBUG - 2017-10-17 12:44:26 --> Total execution time: 0.0768
INFO - 2017-10-17 12:44:26 --> Config Class Initialized
INFO - 2017-10-17 12:44:26 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:44:26 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:44:26 --> Utf8 Class Initialized
INFO - 2017-10-17 12:44:26 --> URI Class Initialized
INFO - 2017-10-17 12:44:26 --> Router Class Initialized
INFO - 2017-10-17 12:44:26 --> Output Class Initialized
INFO - 2017-10-17 12:44:26 --> Security Class Initialized
DEBUG - 2017-10-17 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:44:26 --> Input Class Initialized
INFO - 2017-10-17 12:44:26 --> Language Class Initialized
INFO - 2017-10-17 12:44:26 --> Loader Class Initialized
INFO - 2017-10-17 12:44:26 --> Helper loaded: url_helper
INFO - 2017-10-17 12:44:26 --> Helper loaded: common_helper
INFO - 2017-10-17 12:44:26 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:44:26 --> Email Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Controller Class Initialized
INFO - 2017-10-17 12:44:26 --> Model Class Initialized
INFO - 2017-10-17 12:44:26 --> Final output sent to browser
DEBUG - 2017-10-17 12:44:26 --> Total execution time: 0.0060
INFO - 2017-10-17 12:44:28 --> Config Class Initialized
INFO - 2017-10-17 12:44:28 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:44:28 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:44:28 --> Utf8 Class Initialized
INFO - 2017-10-17 12:44:28 --> URI Class Initialized
INFO - 2017-10-17 12:44:28 --> Router Class Initialized
INFO - 2017-10-17 12:44:28 --> Output Class Initialized
INFO - 2017-10-17 12:44:28 --> Security Class Initialized
DEBUG - 2017-10-17 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:44:28 --> Input Class Initialized
INFO - 2017-10-17 12:44:28 --> Language Class Initialized
INFO - 2017-10-17 12:44:28 --> Loader Class Initialized
INFO - 2017-10-17 12:44:28 --> Helper loaded: url_helper
INFO - 2017-10-17 12:44:28 --> Helper loaded: common_helper
INFO - 2017-10-17 12:44:28 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:44:28 --> Email Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Controller Class Initialized
INFO - 2017-10-17 12:44:28 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> Model Class Initialized
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/add_data.php
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:44:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:44:28 --> Final output sent to browser
DEBUG - 2017-10-17 12:44:28 --> Total execution time: 0.1459
INFO - 2017-10-17 12:45:19 --> Config Class Initialized
INFO - 2017-10-17 12:45:19 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:45:19 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:45:19 --> Utf8 Class Initialized
INFO - 2017-10-17 12:45:19 --> URI Class Initialized
INFO - 2017-10-17 12:45:19 --> Router Class Initialized
INFO - 2017-10-17 12:45:19 --> Output Class Initialized
INFO - 2017-10-17 12:45:19 --> Security Class Initialized
DEBUG - 2017-10-17 12:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:45:19 --> Input Class Initialized
INFO - 2017-10-17 12:45:19 --> Language Class Initialized
INFO - 2017-10-17 12:45:19 --> Loader Class Initialized
INFO - 2017-10-17 12:45:19 --> Helper loaded: url_helper
INFO - 2017-10-17 12:45:19 --> Helper loaded: common_helper
INFO - 2017-10-17 12:45:19 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:45:19 --> Email Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Controller Class Initialized
INFO - 2017-10-17 12:45:19 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:45:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:45:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-17 12:45:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-17 12:45:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-17 12:45:19 --> Final output sent to browser
DEBUG - 2017-10-17 12:45:19 --> Total execution time: 0.0255
INFO - 2017-10-17 12:45:19 --> Config Class Initialized
INFO - 2017-10-17 12:45:19 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:45:19 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:45:19 --> Utf8 Class Initialized
INFO - 2017-10-17 12:45:19 --> URI Class Initialized
INFO - 2017-10-17 12:45:19 --> Router Class Initialized
INFO - 2017-10-17 12:45:19 --> Output Class Initialized
INFO - 2017-10-17 12:45:19 --> Security Class Initialized
DEBUG - 2017-10-17 12:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:45:19 --> Input Class Initialized
INFO - 2017-10-17 12:45:19 --> Language Class Initialized
INFO - 2017-10-17 12:45:19 --> Loader Class Initialized
INFO - 2017-10-17 12:45:19 --> Helper loaded: url_helper
INFO - 2017-10-17 12:45:19 --> Helper loaded: common_helper
INFO - 2017-10-17 12:45:19 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:45:19 --> Email Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Controller Class Initialized
INFO - 2017-10-17 12:45:19 --> Model Class Initialized
INFO - 2017-10-17 12:45:19 --> Final output sent to browser
DEBUG - 2017-10-17 12:45:19 --> Total execution time: 0.0024
INFO - 2017-10-17 12:45:20 --> Config Class Initialized
INFO - 2017-10-17 12:45:20 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:45:20 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:45:20 --> Utf8 Class Initialized
INFO - 2017-10-17 12:45:20 --> URI Class Initialized
INFO - 2017-10-17 12:45:20 --> Router Class Initialized
INFO - 2017-10-17 12:45:20 --> Output Class Initialized
INFO - 2017-10-17 12:45:20 --> Security Class Initialized
DEBUG - 2017-10-17 12:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:45:20 --> Input Class Initialized
INFO - 2017-10-17 12:45:20 --> Language Class Initialized
INFO - 2017-10-17 12:45:20 --> Loader Class Initialized
INFO - 2017-10-17 12:45:20 --> Helper loaded: url_helper
INFO - 2017-10-17 12:45:20 --> Helper loaded: common_helper
INFO - 2017-10-17 12:45:20 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:45:20 --> Email Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Controller Class Initialized
INFO - 2017-10-17 12:45:20 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> Model Class Initialized
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:45:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:45:20 --> Final output sent to browser
DEBUG - 2017-10-17 12:45:20 --> Total execution time: 0.0306
INFO - 2017-10-17 12:45:21 --> Config Class Initialized
INFO - 2017-10-17 12:45:21 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:45:21 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:45:21 --> Utf8 Class Initialized
INFO - 2017-10-17 12:45:21 --> URI Class Initialized
INFO - 2017-10-17 12:45:21 --> Router Class Initialized
INFO - 2017-10-17 12:45:21 --> Output Class Initialized
INFO - 2017-10-17 12:45:21 --> Security Class Initialized
DEBUG - 2017-10-17 12:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:45:21 --> Input Class Initialized
INFO - 2017-10-17 12:45:21 --> Language Class Initialized
INFO - 2017-10-17 12:45:21 --> Loader Class Initialized
INFO - 2017-10-17 12:45:21 --> Helper loaded: url_helper
INFO - 2017-10-17 12:45:21 --> Helper loaded: common_helper
INFO - 2017-10-17 12:45:21 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:45:21 --> Email Class Initialized
INFO - 2017-10-17 12:45:21 --> Model Class Initialized
INFO - 2017-10-17 12:45:21 --> Controller Class Initialized
INFO - 2017-10-17 12:45:21 --> Model Class Initialized
INFO - 2017-10-17 12:45:21 --> Final output sent to browser
DEBUG - 2017-10-17 12:45:21 --> Total execution time: 0.0032
INFO - 2017-10-17 12:46:16 --> Config Class Initialized
INFO - 2017-10-17 12:46:16 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:46:16 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:46:16 --> Utf8 Class Initialized
INFO - 2017-10-17 12:46:16 --> URI Class Initialized
INFO - 2017-10-17 12:46:16 --> Router Class Initialized
INFO - 2017-10-17 12:46:16 --> Output Class Initialized
INFO - 2017-10-17 12:46:16 --> Security Class Initialized
DEBUG - 2017-10-17 12:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:46:16 --> Input Class Initialized
INFO - 2017-10-17 12:46:16 --> Language Class Initialized
INFO - 2017-10-17 12:46:16 --> Loader Class Initialized
INFO - 2017-10-17 12:46:16 --> Helper loaded: url_helper
INFO - 2017-10-17 12:46:16 --> Helper loaded: common_helper
INFO - 2017-10-17 12:46:16 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:46:16 --> Email Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Controller Class Initialized
INFO - 2017-10-17 12:46:16 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> Model Class Initialized
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:46:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:46:16 --> Final output sent to browser
DEBUG - 2017-10-17 12:46:16 --> Total execution time: 0.0243
INFO - 2017-10-17 12:46:17 --> Config Class Initialized
INFO - 2017-10-17 12:46:17 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:46:17 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:46:17 --> Utf8 Class Initialized
INFO - 2017-10-17 12:46:17 --> URI Class Initialized
INFO - 2017-10-17 12:46:17 --> Router Class Initialized
INFO - 2017-10-17 12:46:17 --> Output Class Initialized
INFO - 2017-10-17 12:46:17 --> Security Class Initialized
DEBUG - 2017-10-17 12:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:46:17 --> Input Class Initialized
INFO - 2017-10-17 12:46:17 --> Language Class Initialized
INFO - 2017-10-17 12:46:17 --> Loader Class Initialized
INFO - 2017-10-17 12:46:17 --> Helper loaded: url_helper
INFO - 2017-10-17 12:46:17 --> Helper loaded: common_helper
INFO - 2017-10-17 12:46:17 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:46:17 --> Email Class Initialized
INFO - 2017-10-17 12:46:17 --> Model Class Initialized
INFO - 2017-10-17 12:46:17 --> Controller Class Initialized
INFO - 2017-10-17 12:46:17 --> Model Class Initialized
INFO - 2017-10-17 12:46:17 --> Final output sent to browser
DEBUG - 2017-10-17 12:46:17 --> Total execution time: 0.0029
INFO - 2017-10-17 12:47:14 --> Config Class Initialized
INFO - 2017-10-17 12:47:14 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:47:14 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:47:14 --> Utf8 Class Initialized
INFO - 2017-10-17 12:47:14 --> URI Class Initialized
INFO - 2017-10-17 12:47:14 --> Router Class Initialized
INFO - 2017-10-17 12:47:14 --> Output Class Initialized
INFO - 2017-10-17 12:47:14 --> Security Class Initialized
DEBUG - 2017-10-17 12:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:47:14 --> Input Class Initialized
INFO - 2017-10-17 12:47:14 --> Language Class Initialized
INFO - 2017-10-17 12:47:14 --> Loader Class Initialized
INFO - 2017-10-17 12:47:14 --> Helper loaded: url_helper
INFO - 2017-10-17 12:47:14 --> Helper loaded: common_helper
INFO - 2017-10-17 12:47:14 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:47:14 --> Email Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Controller Class Initialized
INFO - 2017-10-17 12:47:14 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> Model Class Initialized
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:47:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:47:14 --> Final output sent to browser
DEBUG - 2017-10-17 12:47:14 --> Total execution time: 0.0893
INFO - 2017-10-17 12:47:15 --> Config Class Initialized
INFO - 2017-10-17 12:47:15 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:47:15 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:47:15 --> Utf8 Class Initialized
INFO - 2017-10-17 12:47:15 --> URI Class Initialized
INFO - 2017-10-17 12:47:15 --> Router Class Initialized
INFO - 2017-10-17 12:47:15 --> Output Class Initialized
INFO - 2017-10-17 12:47:15 --> Security Class Initialized
DEBUG - 2017-10-17 12:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:47:15 --> Input Class Initialized
INFO - 2017-10-17 12:47:15 --> Language Class Initialized
INFO - 2017-10-17 12:47:15 --> Loader Class Initialized
INFO - 2017-10-17 12:47:15 --> Helper loaded: url_helper
INFO - 2017-10-17 12:47:15 --> Helper loaded: common_helper
INFO - 2017-10-17 12:47:15 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:47:15 --> Email Class Initialized
INFO - 2017-10-17 12:47:15 --> Model Class Initialized
INFO - 2017-10-17 12:47:15 --> Controller Class Initialized
INFO - 2017-10-17 12:47:15 --> Model Class Initialized
INFO - 2017-10-17 12:47:15 --> Final output sent to browser
DEBUG - 2017-10-17 12:47:15 --> Total execution time: 0.0061
INFO - 2017-10-17 12:49:34 --> Config Class Initialized
INFO - 2017-10-17 12:49:34 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:49:34 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:49:34 --> Utf8 Class Initialized
INFO - 2017-10-17 12:49:34 --> URI Class Initialized
INFO - 2017-10-17 12:49:34 --> Router Class Initialized
INFO - 2017-10-17 12:49:34 --> Output Class Initialized
INFO - 2017-10-17 12:49:34 --> Security Class Initialized
DEBUG - 2017-10-17 12:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:49:34 --> Input Class Initialized
INFO - 2017-10-17 12:49:34 --> Language Class Initialized
INFO - 2017-10-17 12:49:34 --> Loader Class Initialized
INFO - 2017-10-17 12:49:34 --> Helper loaded: url_helper
INFO - 2017-10-17 12:49:34 --> Helper loaded: common_helper
INFO - 2017-10-17 12:49:34 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:49:34 --> Email Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Controller Class Initialized
INFO - 2017-10-17 12:49:34 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> Model Class Initialized
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:49:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:49:34 --> Final output sent to browser
DEBUG - 2017-10-17 12:49:34 --> Total execution time: 0.1103
INFO - 2017-10-17 12:49:35 --> Config Class Initialized
INFO - 2017-10-17 12:49:35 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:49:35 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:49:35 --> Utf8 Class Initialized
INFO - 2017-10-17 12:49:35 --> URI Class Initialized
INFO - 2017-10-17 12:49:35 --> Router Class Initialized
INFO - 2017-10-17 12:49:35 --> Output Class Initialized
INFO - 2017-10-17 12:49:35 --> Security Class Initialized
DEBUG - 2017-10-17 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:49:35 --> Input Class Initialized
INFO - 2017-10-17 12:49:35 --> Language Class Initialized
INFO - 2017-10-17 12:49:35 --> Loader Class Initialized
INFO - 2017-10-17 12:49:35 --> Helper loaded: url_helper
INFO - 2017-10-17 12:49:35 --> Helper loaded: common_helper
INFO - 2017-10-17 12:49:35 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:49:35 --> Email Class Initialized
INFO - 2017-10-17 12:49:35 --> Model Class Initialized
INFO - 2017-10-17 12:49:35 --> Controller Class Initialized
INFO - 2017-10-17 12:49:35 --> Model Class Initialized
INFO - 2017-10-17 12:49:35 --> Final output sent to browser
DEBUG - 2017-10-17 12:49:35 --> Total execution time: 0.0130
INFO - 2017-10-17 12:49:42 --> Config Class Initialized
INFO - 2017-10-17 12:49:42 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:49:42 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:49:42 --> Utf8 Class Initialized
INFO - 2017-10-17 12:49:42 --> URI Class Initialized
INFO - 2017-10-17 12:49:42 --> Router Class Initialized
INFO - 2017-10-17 12:49:42 --> Output Class Initialized
INFO - 2017-10-17 12:49:42 --> Security Class Initialized
DEBUG - 2017-10-17 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:49:42 --> Input Class Initialized
INFO - 2017-10-17 12:49:42 --> Language Class Initialized
INFO - 2017-10-17 12:49:42 --> Loader Class Initialized
INFO - 2017-10-17 12:49:42 --> Helper loaded: url_helper
INFO - 2017-10-17 12:49:42 --> Helper loaded: common_helper
INFO - 2017-10-17 12:49:42 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:49:42 --> Email Class Initialized
INFO - 2017-10-17 12:49:42 --> Model Class Initialized
INFO - 2017-10-17 12:49:42 --> Controller Class Initialized
INFO - 2017-10-17 12:49:42 --> Model Class Initialized
INFO - 2017-10-17 12:49:42 --> Model Class Initialized
INFO - 2017-10-17 12:49:42 --> Model Class Initialized
INFO - 2017-10-17 12:49:42 --> Final output sent to browser
DEBUG - 2017-10-17 12:49:42 --> Total execution time: 0.5598
INFO - 2017-10-17 12:49:44 --> Config Class Initialized
INFO - 2017-10-17 12:49:44 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:49:44 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:49:44 --> Utf8 Class Initialized
INFO - 2017-10-17 12:49:44 --> URI Class Initialized
INFO - 2017-10-17 12:49:44 --> Router Class Initialized
INFO - 2017-10-17 12:49:44 --> Output Class Initialized
INFO - 2017-10-17 12:49:44 --> Security Class Initialized
DEBUG - 2017-10-17 12:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:49:44 --> Input Class Initialized
INFO - 2017-10-17 12:49:44 --> Language Class Initialized
INFO - 2017-10-17 12:49:44 --> Loader Class Initialized
INFO - 2017-10-17 12:49:44 --> Helper loaded: url_helper
INFO - 2017-10-17 12:49:44 --> Helper loaded: common_helper
INFO - 2017-10-17 12:49:44 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:49:44 --> Email Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Controller Class Initialized
INFO - 2017-10-17 12:49:44 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> Model Class Initialized
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:49:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:49:44 --> Final output sent to browser
DEBUG - 2017-10-17 12:49:44 --> Total execution time: 0.2295
INFO - 2017-10-17 12:49:45 --> Config Class Initialized
INFO - 2017-10-17 12:49:45 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:49:45 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:49:45 --> Utf8 Class Initialized
INFO - 2017-10-17 12:49:45 --> URI Class Initialized
INFO - 2017-10-17 12:49:45 --> Router Class Initialized
INFO - 2017-10-17 12:49:45 --> Output Class Initialized
INFO - 2017-10-17 12:49:45 --> Security Class Initialized
DEBUG - 2017-10-17 12:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:49:45 --> Input Class Initialized
INFO - 2017-10-17 12:49:45 --> Language Class Initialized
INFO - 2017-10-17 12:49:45 --> Loader Class Initialized
INFO - 2017-10-17 12:49:45 --> Helper loaded: url_helper
INFO - 2017-10-17 12:49:45 --> Helper loaded: common_helper
INFO - 2017-10-17 12:49:45 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:49:45 --> Email Class Initialized
INFO - 2017-10-17 12:49:45 --> Model Class Initialized
INFO - 2017-10-17 12:49:45 --> Controller Class Initialized
INFO - 2017-10-17 12:49:45 --> Model Class Initialized
INFO - 2017-10-17 12:49:45 --> Final output sent to browser
DEBUG - 2017-10-17 12:49:45 --> Total execution time: 0.0059
INFO - 2017-10-17 12:50:40 --> Config Class Initialized
INFO - 2017-10-17 12:50:40 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:50:40 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:50:40 --> Utf8 Class Initialized
INFO - 2017-10-17 12:50:40 --> URI Class Initialized
INFO - 2017-10-17 12:50:40 --> Router Class Initialized
INFO - 2017-10-17 12:50:40 --> Output Class Initialized
INFO - 2017-10-17 12:50:40 --> Security Class Initialized
DEBUG - 2017-10-17 12:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:50:40 --> Input Class Initialized
INFO - 2017-10-17 12:50:40 --> Language Class Initialized
INFO - 2017-10-17 12:50:40 --> Loader Class Initialized
INFO - 2017-10-17 12:50:40 --> Helper loaded: url_helper
INFO - 2017-10-17 12:50:40 --> Helper loaded: common_helper
INFO - 2017-10-17 12:50:40 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:50:40 --> Email Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Controller Class Initialized
INFO - 2017-10-17 12:50:40 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:50:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:50:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:40 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-17 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:50:41 --> Final output sent to browser
DEBUG - 2017-10-17 12:50:41 --> Total execution time: 0.0644
INFO - 2017-10-17 12:50:41 --> Config Class Initialized
INFO - 2017-10-17 12:50:41 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:50:41 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:50:41 --> Utf8 Class Initialized
INFO - 2017-10-17 12:50:41 --> URI Class Initialized
INFO - 2017-10-17 12:50:41 --> Router Class Initialized
INFO - 2017-10-17 12:50:41 --> Output Class Initialized
INFO - 2017-10-17 12:50:41 --> Security Class Initialized
DEBUG - 2017-10-17 12:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:50:41 --> Input Class Initialized
INFO - 2017-10-17 12:50:41 --> Language Class Initialized
INFO - 2017-10-17 12:50:41 --> Loader Class Initialized
INFO - 2017-10-17 12:50:41 --> Helper loaded: url_helper
INFO - 2017-10-17 12:50:41 --> Helper loaded: common_helper
INFO - 2017-10-17 12:50:41 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:50:41 --> Email Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Controller Class Initialized
INFO - 2017-10-17 12:50:41 --> Model Class Initialized
INFO - 2017-10-17 12:50:41 --> Final output sent to browser
DEBUG - 2017-10-17 12:50:41 --> Total execution time: 0.0029
INFO - 2017-10-17 12:59:41 --> Config Class Initialized
INFO - 2017-10-17 12:59:41 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:59:41 --> UTF-8 Support Enabled
INFO - 2017-10-17 12:59:41 --> Utf8 Class Initialized
INFO - 2017-10-17 12:59:41 --> URI Class Initialized
INFO - 2017-10-17 12:59:41 --> Router Class Initialized
INFO - 2017-10-17 12:59:41 --> Output Class Initialized
INFO - 2017-10-17 12:59:41 --> Security Class Initialized
DEBUG - 2017-10-17 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 12:59:41 --> Input Class Initialized
INFO - 2017-10-17 12:59:41 --> Language Class Initialized
INFO - 2017-10-17 12:59:41 --> Loader Class Initialized
INFO - 2017-10-17 12:59:41 --> Helper loaded: url_helper
INFO - 2017-10-17 12:59:41 --> Helper loaded: common_helper
INFO - 2017-10-17 12:59:41 --> Database Driver Class Initialized
DEBUG - 2017-10-17 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 12:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 12:59:41 --> Email Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Controller Class Initialized
INFO - 2017-10-17 12:59:41 --> Helper loaded: cookie_helper
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> Model Class Initialized
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 12:59:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 12:59:41 --> Final output sent to browser
DEBUG - 2017-10-17 12:59:41 --> Total execution time: 0.0451
INFO - 2017-10-17 14:49:28 --> Config Class Initialized
INFO - 2017-10-17 14:49:28 --> Hooks Class Initialized
DEBUG - 2017-10-17 14:49:28 --> UTF-8 Support Enabled
INFO - 2017-10-17 14:49:28 --> Utf8 Class Initialized
INFO - 2017-10-17 14:49:28 --> URI Class Initialized
INFO - 2017-10-17 14:49:28 --> Router Class Initialized
INFO - 2017-10-17 14:49:28 --> Output Class Initialized
INFO - 2017-10-17 14:49:28 --> Security Class Initialized
DEBUG - 2017-10-17 14:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 14:49:28 --> Input Class Initialized
INFO - 2017-10-17 14:49:28 --> Language Class Initialized
INFO - 2017-10-17 14:49:28 --> Loader Class Initialized
INFO - 2017-10-17 14:49:28 --> Helper loaded: url_helper
INFO - 2017-10-17 14:49:28 --> Helper loaded: common_helper
INFO - 2017-10-17 14:49:28 --> Database Driver Class Initialized
DEBUG - 2017-10-17 14:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 14:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 14:49:28 --> Email Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Controller Class Initialized
INFO - 2017-10-17 14:49:28 --> Helper loaded: cookie_helper
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> Model Class Initialized
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 14:49:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 14:49:28 --> Final output sent to browser
DEBUG - 2017-10-17 14:49:28 --> Total execution time: 0.0477
INFO - 2017-10-17 14:49:29 --> Config Class Initialized
INFO - 2017-10-17 14:49:29 --> Hooks Class Initialized
DEBUG - 2017-10-17 14:49:29 --> UTF-8 Support Enabled
INFO - 2017-10-17 14:49:29 --> Utf8 Class Initialized
INFO - 2017-10-17 14:49:29 --> URI Class Initialized
INFO - 2017-10-17 14:49:29 --> Router Class Initialized
INFO - 2017-10-17 14:49:29 --> Output Class Initialized
INFO - 2017-10-17 14:49:29 --> Security Class Initialized
DEBUG - 2017-10-17 14:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 14:49:29 --> Input Class Initialized
INFO - 2017-10-17 14:49:29 --> Language Class Initialized
INFO - 2017-10-17 14:49:29 --> Loader Class Initialized
INFO - 2017-10-17 14:49:29 --> Helper loaded: url_helper
INFO - 2017-10-17 14:49:29 --> Helper loaded: common_helper
INFO - 2017-10-17 14:49:29 --> Database Driver Class Initialized
DEBUG - 2017-10-17 14:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 14:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 14:49:29 --> Email Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Controller Class Initialized
INFO - 2017-10-17 14:49:29 --> Helper loaded: cookie_helper
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> Model Class Initialized
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 14:49:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 14:49:29 --> Final output sent to browser
DEBUG - 2017-10-17 14:49:29 --> Total execution time: 0.0504
INFO - 2017-10-17 14:49:31 --> Config Class Initialized
INFO - 2017-10-17 14:49:31 --> Hooks Class Initialized
DEBUG - 2017-10-17 14:49:31 --> UTF-8 Support Enabled
INFO - 2017-10-17 14:49:31 --> Utf8 Class Initialized
INFO - 2017-10-17 14:49:31 --> URI Class Initialized
INFO - 2017-10-17 14:49:31 --> Router Class Initialized
INFO - 2017-10-17 14:49:31 --> Output Class Initialized
INFO - 2017-10-17 14:49:31 --> Security Class Initialized
DEBUG - 2017-10-17 14:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-17 14:49:31 --> Input Class Initialized
INFO - 2017-10-17 14:49:31 --> Language Class Initialized
INFO - 2017-10-17 14:49:31 --> Loader Class Initialized
INFO - 2017-10-17 14:49:31 --> Helper loaded: url_helper
INFO - 2017-10-17 14:49:31 --> Helper loaded: common_helper
INFO - 2017-10-17 14:49:31 --> Database Driver Class Initialized
DEBUG - 2017-10-17 14:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-17 14:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-17 14:49:31 --> Email Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Controller Class Initialized
INFO - 2017-10-17 14:49:31 --> Helper loaded: cookie_helper
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> Model Class Initialized
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-17 14:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-17 14:49:31 --> Final output sent to browser
DEBUG - 2017-10-17 14:49:31 --> Total execution time: 0.0812
