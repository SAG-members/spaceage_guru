<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined variable: subscribedItem /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 982
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined variable: subscribedItem /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 982
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:16:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 962
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Undefined variable: s /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
ERROR - 2018-01-09 19:18:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 963
