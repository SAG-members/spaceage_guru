<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-03 10:32:57 --> Config Class Initialized
INFO - 2017-11-03 10:32:57 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:32:57 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:32:57 --> Utf8 Class Initialized
INFO - 2017-11-03 10:32:57 --> URI Class Initialized
DEBUG - 2017-11-03 10:32:57 --> No URI present. Default controller set.
INFO - 2017-11-03 10:32:57 --> Router Class Initialized
INFO - 2017-11-03 10:32:57 --> Output Class Initialized
INFO - 2017-11-03 10:32:57 --> Security Class Initialized
DEBUG - 2017-11-03 10:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:32:57 --> Input Class Initialized
INFO - 2017-11-03 10:32:57 --> Language Class Initialized
INFO - 2017-11-03 10:32:57 --> Loader Class Initialized
INFO - 2017-11-03 10:32:57 --> Helper loaded: url_helper
INFO - 2017-11-03 10:32:57 --> Helper loaded: common_helper
INFO - 2017-11-03 10:32:57 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:32:57 --> Email Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Controller Class Initialized
INFO - 2017-11-03 10:32:57 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> Model Class Initialized
INFO - 2017-11-03 10:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-03 10:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:32:57 --> Final output sent to browser
DEBUG - 2017-11-03 10:32:57 --> Total execution time: 0.2427
INFO - 2017-11-03 10:33:03 --> Config Class Initialized
INFO - 2017-11-03 10:33:03 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:03 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:03 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:03 --> URI Class Initialized
INFO - 2017-11-03 10:33:03 --> Router Class Initialized
INFO - 2017-11-03 10:33:03 --> Output Class Initialized
INFO - 2017-11-03 10:33:03 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:03 --> Input Class Initialized
INFO - 2017-11-03 10:33:03 --> Language Class Initialized
INFO - 2017-11-03 10:33:03 --> Loader Class Initialized
INFO - 2017-11-03 10:33:03 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:03 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:03 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:03 --> Email Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Controller Class Initialized
INFO - 2017-11-03 10:33:03 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Config Class Initialized
INFO - 2017-11-03 10:33:03 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:03 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:03 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:03 --> URI Class Initialized
INFO - 2017-11-03 10:33:03 --> Router Class Initialized
INFO - 2017-11-03 10:33:03 --> Output Class Initialized
INFO - 2017-11-03 10:33:03 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:03 --> Input Class Initialized
INFO - 2017-11-03 10:33:03 --> Language Class Initialized
INFO - 2017-11-03 10:33:03 --> Loader Class Initialized
INFO - 2017-11-03 10:33:03 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:03 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:03 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:03 --> Email Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Controller Class Initialized
INFO - 2017-11-03 10:33:03 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-03 10:33:03 --> Model Class Initialized
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:33:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:33:03 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:03 --> Total execution time: 0.0990
INFO - 2017-11-03 10:33:03 --> Config Class Initialized
INFO - 2017-11-03 10:33:03 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:03 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:03 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:03 --> URI Class Initialized
INFO - 2017-11-03 10:33:03 --> Router Class Initialized
INFO - 2017-11-03 10:33:03 --> Output Class Initialized
INFO - 2017-11-03 10:33:03 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:03 --> Input Class Initialized
INFO - 2017-11-03 10:33:03 --> Language Class Initialized
ERROR - 2017-11-03 10:33:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:33:06 --> Config Class Initialized
INFO - 2017-11-03 10:33:06 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:06 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:06 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:06 --> URI Class Initialized
INFO - 2017-11-03 10:33:06 --> Router Class Initialized
INFO - 2017-11-03 10:33:06 --> Output Class Initialized
INFO - 2017-11-03 10:33:06 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:06 --> Input Class Initialized
INFO - 2017-11-03 10:33:06 --> Language Class Initialized
INFO - 2017-11-03 10:33:06 --> Loader Class Initialized
INFO - 2017-11-03 10:33:06 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:06 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:06 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:06 --> Email Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Controller Class Initialized
INFO - 2017-11-03 10:33:06 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:33:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:33:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:33:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-03 10:33:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-03 10:33:06 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:06 --> Total execution time: 0.1294
INFO - 2017-11-03 10:33:06 --> Config Class Initialized
INFO - 2017-11-03 10:33:06 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:06 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:06 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:06 --> URI Class Initialized
INFO - 2017-11-03 10:33:06 --> Router Class Initialized
INFO - 2017-11-03 10:33:06 --> Output Class Initialized
INFO - 2017-11-03 10:33:06 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:06 --> Input Class Initialized
INFO - 2017-11-03 10:33:06 --> Language Class Initialized
INFO - 2017-11-03 10:33:06 --> Loader Class Initialized
INFO - 2017-11-03 10:33:06 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:06 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:06 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:06 --> Email Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Controller Class Initialized
INFO - 2017-11-03 10:33:06 --> Model Class Initialized
INFO - 2017-11-03 10:33:06 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:06 --> Total execution time: 0.0242
INFO - 2017-11-03 10:33:07 --> Config Class Initialized
INFO - 2017-11-03 10:33:07 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:07 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:07 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:07 --> URI Class Initialized
INFO - 2017-11-03 10:33:07 --> Router Class Initialized
INFO - 2017-11-03 10:33:07 --> Output Class Initialized
INFO - 2017-11-03 10:33:07 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:07 --> Input Class Initialized
INFO - 2017-11-03 10:33:07 --> Language Class Initialized
INFO - 2017-11-03 10:33:07 --> Loader Class Initialized
INFO - 2017-11-03 10:33:07 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:07 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:07 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:07 --> Email Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Controller Class Initialized
INFO - 2017-11-03 10:33:07 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:33:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:33:07 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:07 --> Total execution time: 0.0597
INFO - 2017-11-03 10:33:07 --> Config Class Initialized
INFO - 2017-11-03 10:33:07 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:07 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:07 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:07 --> URI Class Initialized
INFO - 2017-11-03 10:33:07 --> Router Class Initialized
INFO - 2017-11-03 10:33:07 --> Output Class Initialized
INFO - 2017-11-03 10:33:07 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:07 --> Input Class Initialized
INFO - 2017-11-03 10:33:07 --> Language Class Initialized
INFO - 2017-11-03 10:33:07 --> Loader Class Initialized
INFO - 2017-11-03 10:33:07 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:07 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:07 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:07 --> Email Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Controller Class Initialized
INFO - 2017-11-03 10:33:07 --> Model Class Initialized
INFO - 2017-11-03 10:33:07 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:07 --> Total execution time: 0.0021
INFO - 2017-11-03 10:33:35 --> Config Class Initialized
INFO - 2017-11-03 10:33:35 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:35 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:35 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:35 --> URI Class Initialized
INFO - 2017-11-03 10:33:35 --> Router Class Initialized
INFO - 2017-11-03 10:33:35 --> Output Class Initialized
INFO - 2017-11-03 10:33:35 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:35 --> Input Class Initialized
INFO - 2017-11-03 10:33:35 --> Language Class Initialized
INFO - 2017-11-03 10:33:35 --> Loader Class Initialized
INFO - 2017-11-03 10:33:35 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:35 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:35 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:35 --> Email Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Controller Class Initialized
INFO - 2017-11-03 10:33:35 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:33:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:33:35 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:35 --> Total execution time: 0.0544
INFO - 2017-11-03 10:33:35 --> Config Class Initialized
INFO - 2017-11-03 10:33:35 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:33:35 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:33:35 --> Utf8 Class Initialized
INFO - 2017-11-03 10:33:35 --> URI Class Initialized
INFO - 2017-11-03 10:33:35 --> Router Class Initialized
INFO - 2017-11-03 10:33:35 --> Output Class Initialized
INFO - 2017-11-03 10:33:35 --> Security Class Initialized
DEBUG - 2017-11-03 10:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:33:35 --> Input Class Initialized
INFO - 2017-11-03 10:33:35 --> Language Class Initialized
INFO - 2017-11-03 10:33:35 --> Loader Class Initialized
INFO - 2017-11-03 10:33:35 --> Helper loaded: url_helper
INFO - 2017-11-03 10:33:35 --> Helper loaded: common_helper
INFO - 2017-11-03 10:33:35 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:33:35 --> Email Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Controller Class Initialized
INFO - 2017-11-03 10:33:35 --> Model Class Initialized
INFO - 2017-11-03 10:33:35 --> Final output sent to browser
DEBUG - 2017-11-03 10:33:35 --> Total execution time: 0.0020
INFO - 2017-11-03 10:40:15 --> Config Class Initialized
INFO - 2017-11-03 10:40:15 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:40:15 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:40:15 --> Utf8 Class Initialized
INFO - 2017-11-03 10:40:15 --> URI Class Initialized
INFO - 2017-11-03 10:40:15 --> Router Class Initialized
INFO - 2017-11-03 10:40:15 --> Output Class Initialized
INFO - 2017-11-03 10:40:15 --> Security Class Initialized
DEBUG - 2017-11-03 10:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:40:15 --> Input Class Initialized
INFO - 2017-11-03 10:40:15 --> Language Class Initialized
INFO - 2017-11-03 10:40:15 --> Loader Class Initialized
INFO - 2017-11-03 10:40:15 --> Helper loaded: url_helper
INFO - 2017-11-03 10:40:15 --> Helper loaded: common_helper
INFO - 2017-11-03 10:40:15 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:40:15 --> Email Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Controller Class Initialized
INFO - 2017-11-03 10:40:15 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:15 --> Model Class Initialized
INFO - 2017-11-03 10:40:16 --> Model Class Initialized
INFO - 2017-11-03 10:40:16 --> Model Class Initialized
INFO - 2017-11-03 10:40:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:40:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:40:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:40:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-03 10:40:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-03 10:40:16 --> Final output sent to browser
DEBUG - 2017-11-03 10:40:16 --> Total execution time: 0.0320
INFO - 2017-11-03 10:40:16 --> Config Class Initialized
INFO - 2017-11-03 10:40:16 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:40:16 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:40:16 --> Utf8 Class Initialized
INFO - 2017-11-03 10:40:16 --> URI Class Initialized
INFO - 2017-11-03 10:40:16 --> Router Class Initialized
INFO - 2017-11-03 10:40:16 --> Output Class Initialized
INFO - 2017-11-03 10:40:16 --> Security Class Initialized
DEBUG - 2017-11-03 10:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:40:16 --> Input Class Initialized
INFO - 2017-11-03 10:40:16 --> Language Class Initialized
INFO - 2017-11-03 10:40:16 --> Loader Class Initialized
INFO - 2017-11-03 10:40:16 --> Helper loaded: url_helper
INFO - 2017-11-03 10:40:16 --> Helper loaded: common_helper
INFO - 2017-11-03 10:40:16 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:40:16 --> Email Class Initialized
INFO - 2017-11-03 10:40:16 --> Model Class Initialized
INFO - 2017-11-03 10:40:16 --> Controller Class Initialized
INFO - 2017-11-03 10:40:16 --> Model Class Initialized
INFO - 2017-11-03 10:40:16 --> Final output sent to browser
DEBUG - 2017-11-03 10:40:16 --> Total execution time: 0.0032
INFO - 2017-11-03 10:40:17 --> Config Class Initialized
INFO - 2017-11-03 10:40:17 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:40:17 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:40:17 --> Utf8 Class Initialized
INFO - 2017-11-03 10:40:17 --> URI Class Initialized
INFO - 2017-11-03 10:40:17 --> Router Class Initialized
INFO - 2017-11-03 10:40:17 --> Output Class Initialized
INFO - 2017-11-03 10:40:17 --> Security Class Initialized
DEBUG - 2017-11-03 10:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:40:17 --> Input Class Initialized
INFO - 2017-11-03 10:40:17 --> Language Class Initialized
INFO - 2017-11-03 10:40:17 --> Loader Class Initialized
INFO - 2017-11-03 10:40:17 --> Helper loaded: url_helper
INFO - 2017-11-03 10:40:17 --> Helper loaded: common_helper
INFO - 2017-11-03 10:40:17 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:40:17 --> Email Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Controller Class Initialized
INFO - 2017-11-03 10:40:17 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/add_data.php
INFO - 2017-11-03 10:40:17 --> Model Class Initialized
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:40:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:40:17 --> Final output sent to browser
DEBUG - 2017-11-03 10:40:17 --> Total execution time: 0.0499
INFO - 2017-11-03 10:40:48 --> Config Class Initialized
INFO - 2017-11-03 10:40:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:40:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:40:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:40:48 --> URI Class Initialized
INFO - 2017-11-03 10:40:48 --> Router Class Initialized
INFO - 2017-11-03 10:40:48 --> Output Class Initialized
INFO - 2017-11-03 10:40:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:40:48 --> Input Class Initialized
INFO - 2017-11-03 10:40:48 --> Language Class Initialized
INFO - 2017-11-03 10:40:48 --> Loader Class Initialized
INFO - 2017-11-03 10:40:48 --> Helper loaded: url_helper
INFO - 2017-11-03 10:40:48 --> Helper loaded: common_helper
INFO - 2017-11-03 10:40:48 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:40:48 --> Email Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Controller Class Initialized
INFO - 2017-11-03 10:40:48 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Config Class Initialized
INFO - 2017-11-03 10:40:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:40:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:40:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:40:48 --> URI Class Initialized
INFO - 2017-11-03 10:40:48 --> Router Class Initialized
INFO - 2017-11-03 10:40:48 --> Output Class Initialized
INFO - 2017-11-03 10:40:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:40:48 --> Input Class Initialized
INFO - 2017-11-03 10:40:48 --> Language Class Initialized
INFO - 2017-11-03 10:40:48 --> Loader Class Initialized
INFO - 2017-11-03 10:40:48 --> Helper loaded: url_helper
INFO - 2017-11-03 10:40:48 --> Helper loaded: common_helper
INFO - 2017-11-03 10:40:48 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:40:48 --> Email Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Controller Class Initialized
INFO - 2017-11-03 10:40:48 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/add_data.php
INFO - 2017-11-03 10:40:48 --> Model Class Initialized
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:40:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:40:48 --> Final output sent to browser
DEBUG - 2017-11-03 10:40:48 --> Total execution time: 0.0269
INFO - 2017-11-03 10:41:13 --> Config Class Initialized
INFO - 2017-11-03 10:41:13 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:41:13 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:41:13 --> Utf8 Class Initialized
INFO - 2017-11-03 10:41:13 --> URI Class Initialized
INFO - 2017-11-03 10:41:13 --> Router Class Initialized
INFO - 2017-11-03 10:41:13 --> Output Class Initialized
INFO - 2017-11-03 10:41:13 --> Security Class Initialized
DEBUG - 2017-11-03 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:41:13 --> Input Class Initialized
INFO - 2017-11-03 10:41:13 --> Language Class Initialized
INFO - 2017-11-03 10:41:13 --> Loader Class Initialized
INFO - 2017-11-03 10:41:13 --> Helper loaded: url_helper
INFO - 2017-11-03 10:41:13 --> Helper loaded: common_helper
INFO - 2017-11-03 10:41:13 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:41:13 --> Email Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Controller Class Initialized
INFO - 2017-11-03 10:41:13 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/dashboard.php
INFO - 2017-11-03 10:41:13 --> Model Class Initialized
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:41:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:41:13 --> Final output sent to browser
DEBUG - 2017-11-03 10:41:13 --> Total execution time: 0.0730
INFO - 2017-11-03 10:41:16 --> Config Class Initialized
INFO - 2017-11-03 10:41:16 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:41:16 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:41:16 --> Utf8 Class Initialized
INFO - 2017-11-03 10:41:16 --> URI Class Initialized
INFO - 2017-11-03 10:41:16 --> Router Class Initialized
INFO - 2017-11-03 10:41:16 --> Output Class Initialized
INFO - 2017-11-03 10:41:16 --> Security Class Initialized
DEBUG - 2017-11-03 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:41:16 --> Input Class Initialized
INFO - 2017-11-03 10:41:16 --> Language Class Initialized
INFO - 2017-11-03 10:41:16 --> Loader Class Initialized
INFO - 2017-11-03 10:41:16 --> Helper loaded: url_helper
INFO - 2017-11-03 10:41:16 --> Helper loaded: common_helper
INFO - 2017-11-03 10:41:16 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:41:16 --> Email Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Controller Class Initialized
INFO - 2017-11-03 10:41:16 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:41:16 --> Model Class Initialized
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:41:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:41:16 --> Final output sent to browser
DEBUG - 2017-11-03 10:41:16 --> Total execution time: 0.0535
INFO - 2017-11-03 10:41:48 --> Config Class Initialized
INFO - 2017-11-03 10:41:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:41:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:41:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:41:48 --> URI Class Initialized
INFO - 2017-11-03 10:41:48 --> Router Class Initialized
INFO - 2017-11-03 10:41:48 --> Output Class Initialized
INFO - 2017-11-03 10:41:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:41:48 --> Input Class Initialized
INFO - 2017-11-03 10:41:48 --> Language Class Initialized
INFO - 2017-11-03 10:41:48 --> Loader Class Initialized
INFO - 2017-11-03 10:41:48 --> Helper loaded: url_helper
INFO - 2017-11-03 10:41:48 --> Helper loaded: common_helper
INFO - 2017-11-03 10:41:48 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:41:48 --> Email Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Controller Class Initialized
INFO - 2017-11-03 10:41:48 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-03 10:41:48 --> Model Class Initialized
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:41:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:41:48 --> Final output sent to browser
DEBUG - 2017-11-03 10:41:48 --> Total execution time: 0.0309
INFO - 2017-11-03 10:41:48 --> Config Class Initialized
INFO - 2017-11-03 10:41:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:41:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:41:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:41:48 --> URI Class Initialized
INFO - 2017-11-03 10:41:48 --> Router Class Initialized
INFO - 2017-11-03 10:41:48 --> Output Class Initialized
INFO - 2017-11-03 10:41:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:41:48 --> Input Class Initialized
INFO - 2017-11-03 10:41:48 --> Language Class Initialized
ERROR - 2017-11-03 10:41:48 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:43:53 --> Config Class Initialized
INFO - 2017-11-03 10:43:53 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:53 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:53 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:53 --> URI Class Initialized
INFO - 2017-11-03 10:43:53 --> Router Class Initialized
INFO - 2017-11-03 10:43:53 --> Output Class Initialized
INFO - 2017-11-03 10:43:53 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:53 --> Input Class Initialized
INFO - 2017-11-03 10:43:53 --> Language Class Initialized
INFO - 2017-11-03 10:43:53 --> Loader Class Initialized
INFO - 2017-11-03 10:43:53 --> Helper loaded: url_helper
INFO - 2017-11-03 10:43:53 --> Helper loaded: common_helper
INFO - 2017-11-03 10:43:53 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:43:53 --> Email Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Controller Class Initialized
INFO - 2017-11-03 10:43:53 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-03 10:43:53 --> Model Class Initialized
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:43:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:43:53 --> Final output sent to browser
DEBUG - 2017-11-03 10:43:53 --> Total execution time: 0.0324
INFO - 2017-11-03 10:43:53 --> Config Class Initialized
INFO - 2017-11-03 10:43:53 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:53 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:53 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:53 --> URI Class Initialized
INFO - 2017-11-03 10:43:53 --> Router Class Initialized
INFO - 2017-11-03 10:43:53 --> Output Class Initialized
INFO - 2017-11-03 10:43:53 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:53 --> Input Class Initialized
INFO - 2017-11-03 10:43:53 --> Language Class Initialized
ERROR - 2017-11-03 10:43:53 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:43:56 --> Config Class Initialized
INFO - 2017-11-03 10:43:56 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:56 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:56 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:56 --> URI Class Initialized
INFO - 2017-11-03 10:43:56 --> Router Class Initialized
INFO - 2017-11-03 10:43:56 --> Output Class Initialized
INFO - 2017-11-03 10:43:56 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:56 --> Input Class Initialized
INFO - 2017-11-03 10:43:56 --> Language Class Initialized
INFO - 2017-11-03 10:43:56 --> Loader Class Initialized
INFO - 2017-11-03 10:43:56 --> Helper loaded: url_helper
INFO - 2017-11-03 10:43:56 --> Helper loaded: common_helper
INFO - 2017-11-03 10:43:56 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:43:56 --> Email Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Controller Class Initialized
INFO - 2017-11-03 10:43:56 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:43:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:43:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:43:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-03 10:43:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-03 10:43:56 --> Final output sent to browser
DEBUG - 2017-11-03 10:43:56 --> Total execution time: 0.0291
INFO - 2017-11-03 10:43:56 --> Config Class Initialized
INFO - 2017-11-03 10:43:56 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:56 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:56 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:56 --> URI Class Initialized
INFO - 2017-11-03 10:43:56 --> Router Class Initialized
INFO - 2017-11-03 10:43:56 --> Output Class Initialized
INFO - 2017-11-03 10:43:56 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:56 --> Input Class Initialized
INFO - 2017-11-03 10:43:56 --> Language Class Initialized
INFO - 2017-11-03 10:43:56 --> Loader Class Initialized
INFO - 2017-11-03 10:43:56 --> Helper loaded: url_helper
INFO - 2017-11-03 10:43:56 --> Helper loaded: common_helper
INFO - 2017-11-03 10:43:56 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:43:56 --> Email Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Controller Class Initialized
INFO - 2017-11-03 10:43:56 --> Model Class Initialized
INFO - 2017-11-03 10:43:56 --> Final output sent to browser
DEBUG - 2017-11-03 10:43:56 --> Total execution time: 0.0020
INFO - 2017-11-03 10:43:58 --> Config Class Initialized
INFO - 2017-11-03 10:43:58 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:58 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:58 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:58 --> URI Class Initialized
INFO - 2017-11-03 10:43:58 --> Router Class Initialized
INFO - 2017-11-03 10:43:58 --> Output Class Initialized
INFO - 2017-11-03 10:43:58 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:58 --> Input Class Initialized
INFO - 2017-11-03 10:43:58 --> Language Class Initialized
INFO - 2017-11-03 10:43:58 --> Loader Class Initialized
INFO - 2017-11-03 10:43:58 --> Helper loaded: url_helper
INFO - 2017-11-03 10:43:58 --> Helper loaded: common_helper
INFO - 2017-11-03 10:43:58 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:43:58 --> Email Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Controller Class Initialized
INFO - 2017-11-03 10:43:58 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-11-03 10:43:58 --> Model Class Initialized
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:43:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:43:58 --> Final output sent to browser
DEBUG - 2017-11-03 10:43:58 --> Total execution time: 0.0218
INFO - 2017-11-03 10:43:59 --> Config Class Initialized
INFO - 2017-11-03 10:43:59 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:43:59 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:43:59 --> Utf8 Class Initialized
INFO - 2017-11-03 10:43:59 --> URI Class Initialized
INFO - 2017-11-03 10:43:59 --> Router Class Initialized
INFO - 2017-11-03 10:43:59 --> Output Class Initialized
INFO - 2017-11-03 10:43:59 --> Security Class Initialized
DEBUG - 2017-11-03 10:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:43:59 --> Input Class Initialized
INFO - 2017-11-03 10:43:59 --> Language Class Initialized
INFO - 2017-11-03 10:43:59 --> Loader Class Initialized
INFO - 2017-11-03 10:43:59 --> Helper loaded: url_helper
INFO - 2017-11-03 10:43:59 --> Helper loaded: common_helper
INFO - 2017-11-03 10:43:59 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:43:59 --> Email Class Initialized
INFO - 2017-11-03 10:43:59 --> Model Class Initialized
INFO - 2017-11-03 10:43:59 --> Controller Class Initialized
INFO - 2017-11-03 10:43:59 --> Model Class Initialized
INFO - 2017-11-03 10:43:59 --> Final output sent to browser
DEBUG - 2017-11-03 10:43:59 --> Total execution time: 0.0020
INFO - 2017-11-03 10:44:00 --> Config Class Initialized
INFO - 2017-11-03 10:44:00 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:00 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:00 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:00 --> URI Class Initialized
INFO - 2017-11-03 10:44:00 --> Router Class Initialized
INFO - 2017-11-03 10:44:00 --> Output Class Initialized
INFO - 2017-11-03 10:44:00 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:00 --> Input Class Initialized
INFO - 2017-11-03 10:44:00 --> Language Class Initialized
INFO - 2017-11-03 10:44:00 --> Loader Class Initialized
INFO - 2017-11-03 10:44:00 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:00 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:00 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:00 --> Email Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Controller Class Initialized
INFO - 2017-11-03 10:44:00 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> Model Class Initialized
INFO - 2017-11-03 10:44:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-03 10:44:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-03 10:44:00 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:00 --> Total execution time: 0.0289
INFO - 2017-11-03 10:44:01 --> Config Class Initialized
INFO - 2017-11-03 10:44:01 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:01 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:01 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:01 --> URI Class Initialized
INFO - 2017-11-03 10:44:01 --> Router Class Initialized
INFO - 2017-11-03 10:44:01 --> Output Class Initialized
INFO - 2017-11-03 10:44:01 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:01 --> Input Class Initialized
INFO - 2017-11-03 10:44:01 --> Language Class Initialized
INFO - 2017-11-03 10:44:01 --> Loader Class Initialized
INFO - 2017-11-03 10:44:01 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:01 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:01 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:01 --> Email Class Initialized
INFO - 2017-11-03 10:44:01 --> Model Class Initialized
INFO - 2017-11-03 10:44:01 --> Controller Class Initialized
INFO - 2017-11-03 10:44:01 --> Model Class Initialized
INFO - 2017-11-03 10:44:01 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:01 --> Total execution time: 0.0019
INFO - 2017-11-03 10:44:02 --> Config Class Initialized
INFO - 2017-11-03 10:44:02 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:02 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:02 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:02 --> URI Class Initialized
INFO - 2017-11-03 10:44:02 --> Router Class Initialized
INFO - 2017-11-03 10:44:02 --> Output Class Initialized
INFO - 2017-11-03 10:44:02 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:02 --> Input Class Initialized
INFO - 2017-11-03 10:44:02 --> Language Class Initialized
INFO - 2017-11-03 10:44:02 --> Loader Class Initialized
INFO - 2017-11-03 10:44:02 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:02 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:02 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:02 --> Email Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Controller Class Initialized
INFO - 2017-11-03 10:44:02 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/dashboard.php
INFO - 2017-11-03 10:44:02 --> Model Class Initialized
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:44:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:44:02 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:02 --> Total execution time: 0.0349
INFO - 2017-11-03 10:44:05 --> Config Class Initialized
INFO - 2017-11-03 10:44:05 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:05 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:05 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:05 --> URI Class Initialized
INFO - 2017-11-03 10:44:05 --> Router Class Initialized
INFO - 2017-11-03 10:44:05 --> Output Class Initialized
INFO - 2017-11-03 10:44:05 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:05 --> Input Class Initialized
INFO - 2017-11-03 10:44:05 --> Language Class Initialized
INFO - 2017-11-03 10:44:05 --> Loader Class Initialized
INFO - 2017-11-03 10:44:05 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:05 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:05 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:05 --> Email Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Controller Class Initialized
INFO - 2017-11-03 10:44:05 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:44:05 --> Model Class Initialized
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:44:05 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:05 --> Total execution time: 0.0349
INFO - 2017-11-03 10:44:26 --> Config Class Initialized
INFO - 2017-11-03 10:44:26 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:26 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:26 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:26 --> URI Class Initialized
INFO - 2017-11-03 10:44:26 --> Router Class Initialized
INFO - 2017-11-03 10:44:26 --> Output Class Initialized
INFO - 2017-11-03 10:44:26 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:26 --> Input Class Initialized
INFO - 2017-11-03 10:44:26 --> Language Class Initialized
INFO - 2017-11-03 10:44:26 --> Loader Class Initialized
INFO - 2017-11-03 10:44:26 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:26 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:26 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:26 --> Email Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Controller Class Initialized
INFO - 2017-11-03 10:44:26 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:44:26 --> Model Class Initialized
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:44:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:44:26 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:26 --> Total execution time: 0.0339
INFO - 2017-11-03 10:44:44 --> Config Class Initialized
INFO - 2017-11-03 10:44:44 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:44 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:44 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:44 --> URI Class Initialized
INFO - 2017-11-03 10:44:44 --> Router Class Initialized
INFO - 2017-11-03 10:44:44 --> Output Class Initialized
INFO - 2017-11-03 10:44:44 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:44 --> Input Class Initialized
INFO - 2017-11-03 10:44:44 --> Language Class Initialized
INFO - 2017-11-03 10:44:44 --> Loader Class Initialized
INFO - 2017-11-03 10:44:44 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:44 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:44 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:44 --> Email Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Controller Class Initialized
INFO - 2017-11-03 10:44:44 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:44 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:44:45 --> Model Class Initialized
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:44:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:44:45 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:45 --> Total execution time: 0.0507
INFO - 2017-11-03 10:44:55 --> Config Class Initialized
INFO - 2017-11-03 10:44:55 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:44:55 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:44:55 --> Utf8 Class Initialized
INFO - 2017-11-03 10:44:55 --> URI Class Initialized
INFO - 2017-11-03 10:44:55 --> Router Class Initialized
INFO - 2017-11-03 10:44:55 --> Output Class Initialized
INFO - 2017-11-03 10:44:55 --> Security Class Initialized
DEBUG - 2017-11-03 10:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:44:55 --> Input Class Initialized
INFO - 2017-11-03 10:44:55 --> Language Class Initialized
INFO - 2017-11-03 10:44:55 --> Loader Class Initialized
INFO - 2017-11-03 10:44:55 --> Helper loaded: url_helper
INFO - 2017-11-03 10:44:55 --> Helper loaded: common_helper
INFO - 2017-11-03 10:44:55 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:44:55 --> Email Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Controller Class Initialized
INFO - 2017-11-03 10:44:55 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:44:55 --> Model Class Initialized
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:44:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:44:55 --> Final output sent to browser
DEBUG - 2017-11-03 10:44:55 --> Total execution time: 0.0665
INFO - 2017-11-03 10:45:15 --> Config Class Initialized
INFO - 2017-11-03 10:45:15 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:45:15 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:45:15 --> Utf8 Class Initialized
INFO - 2017-11-03 10:45:15 --> URI Class Initialized
INFO - 2017-11-03 10:45:15 --> Router Class Initialized
INFO - 2017-11-03 10:45:15 --> Output Class Initialized
INFO - 2017-11-03 10:45:15 --> Security Class Initialized
DEBUG - 2017-11-03 10:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:45:15 --> Input Class Initialized
INFO - 2017-11-03 10:45:15 --> Language Class Initialized
INFO - 2017-11-03 10:45:15 --> Loader Class Initialized
INFO - 2017-11-03 10:45:15 --> Helper loaded: url_helper
INFO - 2017-11-03 10:45:15 --> Helper loaded: common_helper
INFO - 2017-11-03 10:45:15 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:45:15 --> Email Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Controller Class Initialized
INFO - 2017-11-03 10:45:15 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:45:15 --> Model Class Initialized
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:45:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:45:15 --> Final output sent to browser
DEBUG - 2017-11-03 10:45:15 --> Total execution time: 0.0372
INFO - 2017-11-03 10:45:45 --> Config Class Initialized
INFO - 2017-11-03 10:45:45 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:45:45 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:45:45 --> Utf8 Class Initialized
INFO - 2017-11-03 10:45:45 --> URI Class Initialized
INFO - 2017-11-03 10:45:45 --> Router Class Initialized
INFO - 2017-11-03 10:45:45 --> Output Class Initialized
INFO - 2017-11-03 10:45:45 --> Security Class Initialized
DEBUG - 2017-11-03 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:45:45 --> Input Class Initialized
INFO - 2017-11-03 10:45:45 --> Language Class Initialized
INFO - 2017-11-03 10:45:45 --> Loader Class Initialized
INFO - 2017-11-03 10:45:45 --> Helper loaded: url_helper
INFO - 2017-11-03 10:45:45 --> Helper loaded: common_helper
INFO - 2017-11-03 10:45:45 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:45:45 --> Email Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Controller Class Initialized
INFO - 2017-11-03 10:45:45 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:45:45 --> Model Class Initialized
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:45:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:45:45 --> Final output sent to browser
DEBUG - 2017-11-03 10:45:45 --> Total execution time: 0.0346
INFO - 2017-11-03 10:46:02 --> Config Class Initialized
INFO - 2017-11-03 10:46:02 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:46:02 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:46:02 --> Utf8 Class Initialized
INFO - 2017-11-03 10:46:02 --> URI Class Initialized
INFO - 2017-11-03 10:46:02 --> Router Class Initialized
INFO - 2017-11-03 10:46:02 --> Output Class Initialized
INFO - 2017-11-03 10:46:02 --> Security Class Initialized
DEBUG - 2017-11-03 10:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:46:02 --> Input Class Initialized
INFO - 2017-11-03 10:46:02 --> Language Class Initialized
INFO - 2017-11-03 10:46:02 --> Loader Class Initialized
INFO - 2017-11-03 10:46:02 --> Helper loaded: url_helper
INFO - 2017-11-03 10:46:02 --> Helper loaded: common_helper
INFO - 2017-11-03 10:46:02 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:46:02 --> Email Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Controller Class Initialized
INFO - 2017-11-03 10:46:02 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
INFO - 2017-11-03 10:46:02 --> Model Class Initialized
ERROR - 2017-11-03 10:46:02 --> Severity: Notice --> Array to string conversion /var/www/html/spaceage_guru/system/database/DB_driver.php 1524
ERROR - 2017-11-03 10:46:02 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `page` SET `page_title` = 'Test Album', `page_description` = '<p>dfasdfdsa</p>', `page_slug` = 'test-album', `visibility` = '1', `tag` = 'Test', `category_id` = '1', `country_available_in` = '11', `country_legal_in` = '14', `country_allowed_in` = Array, `price` = NULL, `priceless` = 1, `anonymous` = 0, `status` = 1, `date_modified` = '2017-11-03 10:46:02'
WHERE `id` = '158'
INFO - 2017-11-03 10:46:02 --> Language file loaded: language/english/db_lang.php
INFO - 2017-11-03 10:49:01 --> Config Class Initialized
INFO - 2017-11-03 10:49:01 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:49:01 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:49:01 --> Utf8 Class Initialized
INFO - 2017-11-03 10:49:01 --> URI Class Initialized
INFO - 2017-11-03 10:49:01 --> Router Class Initialized
INFO - 2017-11-03 10:49:01 --> Output Class Initialized
INFO - 2017-11-03 10:49:01 --> Security Class Initialized
DEBUG - 2017-11-03 10:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:49:01 --> Input Class Initialized
INFO - 2017-11-03 10:49:01 --> Language Class Initialized
INFO - 2017-11-03 10:49:01 --> Loader Class Initialized
INFO - 2017-11-03 10:49:01 --> Helper loaded: url_helper
INFO - 2017-11-03 10:49:01 --> Helper loaded: common_helper
INFO - 2017-11-03 10:49:01 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:49:01 --> Email Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Controller Class Initialized
INFO - 2017-11-03 10:49:01 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:49:01 --> Model Class Initialized
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:49:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:49:01 --> Final output sent to browser
DEBUG - 2017-11-03 10:49:01 --> Total execution time: 0.0332
INFO - 2017-11-03 10:49:04 --> Config Class Initialized
INFO - 2017-11-03 10:49:04 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:49:04 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:49:04 --> Utf8 Class Initialized
INFO - 2017-11-03 10:49:04 --> URI Class Initialized
INFO - 2017-11-03 10:49:04 --> Router Class Initialized
INFO - 2017-11-03 10:49:04 --> Output Class Initialized
INFO - 2017-11-03 10:49:04 --> Security Class Initialized
DEBUG - 2017-11-03 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:49:04 --> Input Class Initialized
INFO - 2017-11-03 10:49:04 --> Language Class Initialized
INFO - 2017-11-03 10:49:04 --> Loader Class Initialized
INFO - 2017-11-03 10:49:04 --> Helper loaded: url_helper
INFO - 2017-11-03 10:49:04 --> Helper loaded: common_helper
INFO - 2017-11-03 10:49:04 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:49:04 --> Email Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Controller Class Initialized
INFO - 2017-11-03 10:49:04 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:04 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Config Class Initialized
INFO - 2017-11-03 10:49:05 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:49:05 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:49:05 --> Utf8 Class Initialized
INFO - 2017-11-03 10:49:05 --> URI Class Initialized
INFO - 2017-11-03 10:49:05 --> Router Class Initialized
INFO - 2017-11-03 10:49:05 --> Output Class Initialized
INFO - 2017-11-03 10:49:05 --> Security Class Initialized
DEBUG - 2017-11-03 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:49:05 --> Input Class Initialized
INFO - 2017-11-03 10:49:05 --> Language Class Initialized
INFO - 2017-11-03 10:49:05 --> Loader Class Initialized
INFO - 2017-11-03 10:49:05 --> Helper loaded: url_helper
INFO - 2017-11-03 10:49:05 --> Helper loaded: common_helper
INFO - 2017-11-03 10:49:05 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:49:05 --> Email Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Controller Class Initialized
INFO - 2017-11-03 10:49:05 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/user/edit_page.php
INFO - 2017-11-03 10:49:05 --> Model Class Initialized
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 10:49:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 10:49:05 --> Final output sent to browser
DEBUG - 2017-11-03 10:49:05 --> Total execution time: 0.0296
INFO - 2017-11-03 10:58:36 --> Config Class Initialized
INFO - 2017-11-03 10:58:36 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:36 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:36 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:36 --> URI Class Initialized
INFO - 2017-11-03 10:58:36 --> Router Class Initialized
INFO - 2017-11-03 10:58:36 --> Output Class Initialized
INFO - 2017-11-03 10:58:36 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:36 --> Input Class Initialized
INFO - 2017-11-03 10:58:36 --> Language Class Initialized
INFO - 2017-11-03 10:58:36 --> Loader Class Initialized
INFO - 2017-11-03 10:58:36 --> Helper loaded: url_helper
INFO - 2017-11-03 10:58:36 --> Helper loaded: common_helper
INFO - 2017-11-03 10:58:36 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:58:36 --> Email Class Initialized
INFO - 2017-11-03 10:58:36 --> Model Class Initialized
INFO - 2017-11-03 10:58:36 --> Controller Class Initialized
INFO - 2017-11-03 10:58:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-11-03 10:58:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-11-03 10:58:36 --> Final output sent to browser
DEBUG - 2017-11-03 10:58:36 --> Total execution time: 0.0501
INFO - 2017-11-03 10:58:41 --> Config Class Initialized
INFO - 2017-11-03 10:58:41 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:41 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:41 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:41 --> URI Class Initialized
INFO - 2017-11-03 10:58:41 --> Router Class Initialized
INFO - 2017-11-03 10:58:41 --> Output Class Initialized
INFO - 2017-11-03 10:58:41 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:41 --> Input Class Initialized
INFO - 2017-11-03 10:58:41 --> Language Class Initialized
INFO - 2017-11-03 10:58:41 --> Loader Class Initialized
INFO - 2017-11-03 10:58:41 --> Helper loaded: url_helper
INFO - 2017-11-03 10:58:41 --> Helper loaded: common_helper
INFO - 2017-11-03 10:58:41 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:58:41 --> Email Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Controller Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Config Class Initialized
INFO - 2017-11-03 10:58:41 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:41 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:41 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:41 --> URI Class Initialized
INFO - 2017-11-03 10:58:41 --> Router Class Initialized
INFO - 2017-11-03 10:58:41 --> Output Class Initialized
INFO - 2017-11-03 10:58:41 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:41 --> Input Class Initialized
INFO - 2017-11-03 10:58:41 --> Language Class Initialized
INFO - 2017-11-03 10:58:41 --> Loader Class Initialized
INFO - 2017-11-03 10:58:41 --> Helper loaded: url_helper
INFO - 2017-11-03 10:58:41 --> Helper loaded: common_helper
INFO - 2017-11-03 10:58:41 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:58:41 --> Email Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Controller Class Initialized
INFO - 2017-11-03 10:58:41 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> Model Class Initialized
INFO - 2017-11-03 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-11-03 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 10:58:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 10:58:41 --> Final output sent to browser
DEBUG - 2017-11-03 10:58:41 --> Total execution time: 0.1323
INFO - 2017-11-03 10:58:41 --> Config Class Initialized
INFO - 2017-11-03 10:58:41 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:41 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:41 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:41 --> URI Class Initialized
INFO - 2017-11-03 10:58:41 --> Router Class Initialized
INFO - 2017-11-03 10:58:41 --> Output Class Initialized
INFO - 2017-11-03 10:58:41 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:41 --> Input Class Initialized
INFO - 2017-11-03 10:58:41 --> Language Class Initialized
ERROR - 2017-11-03 10:58:41 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:58:41 --> Config Class Initialized
INFO - 2017-11-03 10:58:41 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:41 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:41 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:41 --> URI Class Initialized
INFO - 2017-11-03 10:58:41 --> Router Class Initialized
INFO - 2017-11-03 10:58:41 --> Output Class Initialized
INFO - 2017-11-03 10:58:41 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:41 --> Input Class Initialized
INFO - 2017-11-03 10:58:41 --> Language Class Initialized
ERROR - 2017-11-03 10:58:41 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:58:46 --> Config Class Initialized
INFO - 2017-11-03 10:58:46 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:46 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:46 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:46 --> URI Class Initialized
INFO - 2017-11-03 10:58:46 --> Router Class Initialized
INFO - 2017-11-03 10:58:46 --> Output Class Initialized
INFO - 2017-11-03 10:58:46 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:46 --> Input Class Initialized
INFO - 2017-11-03 10:58:46 --> Language Class Initialized
INFO - 2017-11-03 10:58:46 --> Loader Class Initialized
INFO - 2017-11-03 10:58:46 --> Helper loaded: url_helper
INFO - 2017-11-03 10:58:46 --> Helper loaded: common_helper
INFO - 2017-11-03 10:58:46 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:58:46 --> Email Class Initialized
INFO - 2017-11-03 10:58:46 --> Model Class Initialized
INFO - 2017-11-03 10:58:46 --> Controller Class Initialized
INFO - 2017-11-03 10:58:46 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:58:46 --> Model Class Initialized
INFO - 2017-11-03 10:58:46 --> Model Class Initialized
INFO - 2017-11-03 10:58:46 --> Model Class Initialized
INFO - 2017-11-03 10:58:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 10:58:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-11-03 10:58:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/manage_membership.php
INFO - 2017-11-03 10:58:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 10:58:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 10:58:46 --> Final output sent to browser
DEBUG - 2017-11-03 10:58:46 --> Total execution time: 0.0297
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
INFO - 2017-11-03 10:58:47 --> Config Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> Hooks Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
DEBUG - 2017-11-03 10:58:47 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:47 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:47 --> URI Class Initialized
INFO - 2017-11-03 10:58:47 --> Router Class Initialized
INFO - 2017-11-03 10:58:47 --> Output Class Initialized
INFO - 2017-11-03 10:58:47 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:47 --> Input Class Initialized
INFO - 2017-11-03 10:58:47 --> Language Class Initialized
ERROR - 2017-11-03 10:58:47 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 10:58:48 --> Config Class Initialized
INFO - 2017-11-03 10:58:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:48 --> URI Class Initialized
INFO - 2017-11-03 10:58:48 --> Router Class Initialized
INFO - 2017-11-03 10:58:48 --> Output Class Initialized
INFO - 2017-11-03 10:58:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:48 --> Input Class Initialized
INFO - 2017-11-03 10:58:48 --> Language Class Initialized
INFO - 2017-11-03 10:58:48 --> Loader Class Initialized
INFO - 2017-11-03 10:58:48 --> Helper loaded: url_helper
INFO - 2017-11-03 10:58:48 --> Helper loaded: common_helper
INFO - 2017-11-03 10:58:48 --> Database Driver Class Initialized
DEBUG - 2017-11-03 10:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 10:58:48 --> Email Class Initialized
INFO - 2017-11-03 10:58:48 --> Model Class Initialized
INFO - 2017-11-03 10:58:48 --> Controller Class Initialized
INFO - 2017-11-03 10:58:48 --> Helper loaded: cookie_helper
INFO - 2017-11-03 10:58:48 --> Model Class Initialized
INFO - 2017-11-03 10:58:48 --> Model Class Initialized
INFO - 2017-11-03 10:58:48 --> Model Class Initialized
INFO - 2017-11-03 10:58:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 10:58:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-11-03 10:58:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
INFO - 2017-11-03 10:58:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 10:58:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 10:58:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 10:58:48 --> Final output sent to browser
DEBUG - 2017-11-03 10:58:48 --> Total execution time: 0.0120
INFO - 2017-11-03 10:58:48 --> Config Class Initialized
INFO - 2017-11-03 10:58:48 --> Hooks Class Initialized
DEBUG - 2017-11-03 10:58:48 --> UTF-8 Support Enabled
INFO - 2017-11-03 10:58:48 --> Utf8 Class Initialized
INFO - 2017-11-03 10:58:48 --> URI Class Initialized
INFO - 2017-11-03 10:58:48 --> Router Class Initialized
INFO - 2017-11-03 10:58:48 --> Output Class Initialized
INFO - 2017-11-03 10:58:48 --> Security Class Initialized
DEBUG - 2017-11-03 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 10:58:48 --> Input Class Initialized
INFO - 2017-11-03 10:58:48 --> Language Class Initialized
ERROR - 2017-11-03 10:58:48 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:00:46 --> Config Class Initialized
INFO - 2017-11-03 11:00:46 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:00:46 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:00:46 --> Utf8 Class Initialized
INFO - 2017-11-03 11:00:46 --> URI Class Initialized
INFO - 2017-11-03 11:00:46 --> Router Class Initialized
INFO - 2017-11-03 11:00:46 --> Output Class Initialized
INFO - 2017-11-03 11:00:46 --> Security Class Initialized
DEBUG - 2017-11-03 11:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:00:46 --> Input Class Initialized
INFO - 2017-11-03 11:00:46 --> Language Class Initialized
INFO - 2017-11-03 11:00:46 --> Loader Class Initialized
INFO - 2017-11-03 11:00:46 --> Helper loaded: url_helper
INFO - 2017-11-03 11:00:46 --> Helper loaded: common_helper
INFO - 2017-11-03 11:00:46 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:00:46 --> Email Class Initialized
INFO - 2017-11-03 11:00:46 --> Model Class Initialized
INFO - 2017-11-03 11:00:46 --> Controller Class Initialized
INFO - 2017-11-03 11:00:46 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:00:46 --> Model Class Initialized
INFO - 2017-11-03 11:00:46 --> Model Class Initialized
INFO - 2017-11-03 11:00:46 --> Model Class Initialized
INFO - 2017-11-03 11:00:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:00:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
ERROR - 2017-11-03 11:00:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 127
INFO - 2017-11-03 11:00:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 11:00:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:00:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:00:46 --> Final output sent to browser
DEBUG - 2017-11-03 11:00:46 --> Total execution time: 0.0097
INFO - 2017-11-03 11:00:46 --> Config Class Initialized
INFO - 2017-11-03 11:00:46 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:00:46 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:00:46 --> Utf8 Class Initialized
INFO - 2017-11-03 11:00:46 --> URI Class Initialized
INFO - 2017-11-03 11:00:46 --> Router Class Initialized
INFO - 2017-11-03 11:00:46 --> Output Class Initialized
INFO - 2017-11-03 11:00:46 --> Security Class Initialized
DEBUG - 2017-11-03 11:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:00:46 --> Input Class Initialized
INFO - 2017-11-03 11:00:46 --> Language Class Initialized
ERROR - 2017-11-03 11:00:46 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:00:46 --> Config Class Initialized
INFO - 2017-11-03 11:00:46 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:00:46 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:00:46 --> Utf8 Class Initialized
INFO - 2017-11-03 11:00:46 --> URI Class Initialized
INFO - 2017-11-03 11:00:46 --> Router Class Initialized
INFO - 2017-11-03 11:00:46 --> Output Class Initialized
INFO - 2017-11-03 11:00:46 --> Security Class Initialized
DEBUG - 2017-11-03 11:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:00:46 --> Input Class Initialized
INFO - 2017-11-03 11:00:46 --> Language Class Initialized
ERROR - 2017-11-03 11:00:46 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:04:35 --> Config Class Initialized
INFO - 2017-11-03 11:04:35 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:04:35 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:04:35 --> Utf8 Class Initialized
INFO - 2017-11-03 11:04:35 --> URI Class Initialized
INFO - 2017-11-03 11:04:35 --> Router Class Initialized
INFO - 2017-11-03 11:04:35 --> Output Class Initialized
INFO - 2017-11-03 11:04:35 --> Security Class Initialized
DEBUG - 2017-11-03 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:04:35 --> Input Class Initialized
INFO - 2017-11-03 11:04:35 --> Language Class Initialized
INFO - 2017-11-03 11:04:35 --> Loader Class Initialized
INFO - 2017-11-03 11:04:35 --> Helper loaded: url_helper
INFO - 2017-11-03 11:04:35 --> Helper loaded: common_helper
INFO - 2017-11-03 11:04:35 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:04:35 --> Email Class Initialized
INFO - 2017-11-03 11:04:35 --> Model Class Initialized
INFO - 2017-11-03 11:04:35 --> Controller Class Initialized
INFO - 2017-11-03 11:04:35 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:04:35 --> Model Class Initialized
INFO - 2017-11-03 11:04:35 --> Model Class Initialized
INFO - 2017-11-03 11:04:35 --> Model Class Initialized
INFO - 2017-11-03 11:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:04:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
INFO - 2017-11-03 11:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 11:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:04:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:04:35 --> Final output sent to browser
DEBUG - 2017-11-03 11:04:35 --> Total execution time: 0.0079
INFO - 2017-11-03 11:04:35 --> Config Class Initialized
INFO - 2017-11-03 11:04:35 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:04:35 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:04:35 --> Utf8 Class Initialized
INFO - 2017-11-03 11:04:35 --> URI Class Initialized
INFO - 2017-11-03 11:04:35 --> Router Class Initialized
INFO - 2017-11-03 11:04:35 --> Output Class Initialized
INFO - 2017-11-03 11:04:35 --> Security Class Initialized
DEBUG - 2017-11-03 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:04:35 --> Input Class Initialized
INFO - 2017-11-03 11:04:35 --> Language Class Initialized
ERROR - 2017-11-03 11:04:35 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:04:42 --> Config Class Initialized
INFO - 2017-11-03 11:04:42 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:04:42 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:04:42 --> Utf8 Class Initialized
INFO - 2017-11-03 11:04:42 --> URI Class Initialized
INFO - 2017-11-03 11:04:42 --> Router Class Initialized
INFO - 2017-11-03 11:04:42 --> Output Class Initialized
INFO - 2017-11-03 11:04:42 --> Security Class Initialized
DEBUG - 2017-11-03 11:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:04:42 --> Input Class Initialized
INFO - 2017-11-03 11:04:42 --> Language Class Initialized
ERROR - 2017-11-03 11:04:42 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 11:05:42 --> Config Class Initialized
INFO - 2017-11-03 11:05:42 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:05:42 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:05:42 --> Utf8 Class Initialized
INFO - 2017-11-03 11:05:42 --> URI Class Initialized
INFO - 2017-11-03 11:05:42 --> Router Class Initialized
INFO - 2017-11-03 11:05:42 --> Output Class Initialized
INFO - 2017-11-03 11:05:42 --> Security Class Initialized
DEBUG - 2017-11-03 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:05:42 --> Input Class Initialized
INFO - 2017-11-03 11:05:42 --> Language Class Initialized
INFO - 2017-11-03 11:05:42 --> Loader Class Initialized
INFO - 2017-11-03 11:05:42 --> Helper loaded: url_helper
INFO - 2017-11-03 11:05:42 --> Helper loaded: common_helper
INFO - 2017-11-03 11:05:42 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:05:42 --> Email Class Initialized
INFO - 2017-11-03 11:05:42 --> Model Class Initialized
INFO - 2017-11-03 11:05:42 --> Controller Class Initialized
INFO - 2017-11-03 11:05:42 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:05:42 --> Model Class Initialized
INFO - 2017-11-03 11:05:42 --> Model Class Initialized
INFO - 2017-11-03 11:05:42 --> Model Class Initialized
INFO - 2017-11-03 11:05:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:05:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:05:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
INFO - 2017-11-03 11:05:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 11:05:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:05:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:05:42 --> Final output sent to browser
DEBUG - 2017-11-03 11:05:42 --> Total execution time: 0.0058
INFO - 2017-11-03 11:05:42 --> Config Class Initialized
INFO - 2017-11-03 11:05:42 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:05:42 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:05:42 --> Utf8 Class Initialized
INFO - 2017-11-03 11:05:42 --> URI Class Initialized
INFO - 2017-11-03 11:05:42 --> Router Class Initialized
INFO - 2017-11-03 11:05:42 --> Output Class Initialized
INFO - 2017-11-03 11:05:42 --> Security Class Initialized
DEBUG - 2017-11-03 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:05:42 --> Input Class Initialized
INFO - 2017-11-03 11:05:42 --> Language Class Initialized
ERROR - 2017-11-03 11:05:42 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:05:46 --> Config Class Initialized
INFO - 2017-11-03 11:05:46 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:05:46 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:05:46 --> Utf8 Class Initialized
INFO - 2017-11-03 11:05:46 --> URI Class Initialized
INFO - 2017-11-03 11:05:46 --> Router Class Initialized
INFO - 2017-11-03 11:05:46 --> Output Class Initialized
INFO - 2017-11-03 11:05:46 --> Security Class Initialized
DEBUG - 2017-11-03 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:05:46 --> Input Class Initialized
INFO - 2017-11-03 11:05:46 --> Language Class Initialized
ERROR - 2017-11-03 11:05:46 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 11:06:58 --> Config Class Initialized
INFO - 2017-11-03 11:06:58 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:06:58 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:06:58 --> Utf8 Class Initialized
INFO - 2017-11-03 11:06:58 --> URI Class Initialized
INFO - 2017-11-03 11:06:58 --> Router Class Initialized
INFO - 2017-11-03 11:06:58 --> Output Class Initialized
INFO - 2017-11-03 11:06:58 --> Security Class Initialized
DEBUG - 2017-11-03 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:06:58 --> Input Class Initialized
INFO - 2017-11-03 11:06:58 --> Language Class Initialized
INFO - 2017-11-03 11:06:58 --> Loader Class Initialized
INFO - 2017-11-03 11:06:58 --> Helper loaded: url_helper
INFO - 2017-11-03 11:06:58 --> Helper loaded: common_helper
INFO - 2017-11-03 11:06:58 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:06:58 --> Email Class Initialized
INFO - 2017-11-03 11:06:58 --> Model Class Initialized
INFO - 2017-11-03 11:06:58 --> Controller Class Initialized
INFO - 2017-11-03 11:06:58 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:06:58 --> Model Class Initialized
INFO - 2017-11-03 11:06:58 --> Model Class Initialized
INFO - 2017-11-03 11:06:58 --> Model Class Initialized
INFO - 2017-11-03 11:06:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:06:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:06:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
INFO - 2017-11-03 11:06:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 11:06:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:06:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:06:58 --> Final output sent to browser
DEBUG - 2017-11-03 11:06:58 --> Total execution time: 0.0234
INFO - 2017-11-03 11:06:58 --> Config Class Initialized
INFO - 2017-11-03 11:06:58 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:06:58 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:06:58 --> Utf8 Class Initialized
INFO - 2017-11-03 11:06:58 --> URI Class Initialized
INFO - 2017-11-03 11:06:58 --> Router Class Initialized
INFO - 2017-11-03 11:06:58 --> Output Class Initialized
INFO - 2017-11-03 11:06:58 --> Security Class Initialized
DEBUG - 2017-11-03 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:06:58 --> Input Class Initialized
INFO - 2017-11-03 11:06:58 --> Language Class Initialized
ERROR - 2017-11-03 11:06:58 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:06:58 --> Config Class Initialized
INFO - 2017-11-03 11:06:58 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:06:58 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:06:58 --> Utf8 Class Initialized
INFO - 2017-11-03 11:06:58 --> URI Class Initialized
INFO - 2017-11-03 11:06:58 --> Router Class Initialized
INFO - 2017-11-03 11:06:58 --> Output Class Initialized
INFO - 2017-11-03 11:06:58 --> Security Class Initialized
DEBUG - 2017-11-03 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:06:58 --> Input Class Initialized
INFO - 2017-11-03 11:06:58 --> Language Class Initialized
ERROR - 2017-11-03 11:06:58 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 11:07:11 --> Config Class Initialized
INFO - 2017-11-03 11:07:11 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:07:11 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:07:11 --> Utf8 Class Initialized
INFO - 2017-11-03 11:07:11 --> URI Class Initialized
INFO - 2017-11-03 11:07:11 --> Router Class Initialized
INFO - 2017-11-03 11:07:11 --> Output Class Initialized
INFO - 2017-11-03 11:07:11 --> Security Class Initialized
DEBUG - 2017-11-03 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:07:11 --> Input Class Initialized
INFO - 2017-11-03 11:07:11 --> Language Class Initialized
INFO - 2017-11-03 11:07:11 --> Loader Class Initialized
INFO - 2017-11-03 11:07:11 --> Helper loaded: url_helper
INFO - 2017-11-03 11:07:11 --> Helper loaded: common_helper
INFO - 2017-11-03 11:07:11 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:07:11 --> Email Class Initialized
INFO - 2017-11-03 11:07:11 --> Model Class Initialized
INFO - 2017-11-03 11:07:11 --> Controller Class Initialized
INFO - 2017-11-03 11:07:11 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:07:11 --> Model Class Initialized
INFO - 2017-11-03 11:07:11 --> Model Class Initialized
INFO - 2017-11-03 11:07:11 --> Model Class Initialized
INFO - 2017-11-03 11:07:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:07:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-03 11:07:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
INFO - 2017-11-03 11:07:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-03 11:07:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:07:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:07:11 --> Final output sent to browser
DEBUG - 2017-11-03 11:07:11 --> Total execution time: 0.0078
INFO - 2017-11-03 11:07:11 --> Config Class Initialized
INFO - 2017-11-03 11:07:11 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:07:11 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:07:11 --> Utf8 Class Initialized
INFO - 2017-11-03 11:07:11 --> URI Class Initialized
INFO - 2017-11-03 11:07:11 --> Router Class Initialized
INFO - 2017-11-03 11:07:11 --> Output Class Initialized
INFO - 2017-11-03 11:07:11 --> Security Class Initialized
DEBUG - 2017-11-03 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:07:11 --> Input Class Initialized
INFO - 2017-11-03 11:07:11 --> Language Class Initialized
ERROR - 2017-11-03 11:07:11 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:07:11 --> Config Class Initialized
INFO - 2017-11-03 11:07:11 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:07:11 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:07:11 --> Utf8 Class Initialized
INFO - 2017-11-03 11:07:11 --> URI Class Initialized
INFO - 2017-11-03 11:07:11 --> Router Class Initialized
INFO - 2017-11-03 11:07:11 --> Output Class Initialized
INFO - 2017-11-03 11:07:11 --> Security Class Initialized
DEBUG - 2017-11-03 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:07:11 --> Input Class Initialized
INFO - 2017-11-03 11:07:11 --> Language Class Initialized
ERROR - 2017-11-03 11:07:11 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:07:11 --> Config Class Initialized
INFO - 2017-11-03 11:07:11 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:07:11 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:07:11 --> Utf8 Class Initialized
INFO - 2017-11-03 11:07:11 --> URI Class Initialized
INFO - 2017-11-03 11:07:11 --> Router Class Initialized
INFO - 2017-11-03 11:07:11 --> Output Class Initialized
INFO - 2017-11-03 11:07:11 --> Security Class Initialized
DEBUG - 2017-11-03 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:07:11 --> Input Class Initialized
INFO - 2017-11-03 11:07:11 --> Language Class Initialized
ERROR - 2017-11-03 11:07:11 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 11:09:08 --> Config Class Initialized
INFO - 2017-11-03 11:09:08 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:09:08 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:09:08 --> Utf8 Class Initialized
INFO - 2017-11-03 11:09:08 --> URI Class Initialized
INFO - 2017-11-03 11:09:08 --> Router Class Initialized
INFO - 2017-11-03 11:09:08 --> Output Class Initialized
INFO - 2017-11-03 11:09:08 --> Security Class Initialized
DEBUG - 2017-11-03 11:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:09:08 --> Input Class Initialized
INFO - 2017-11-03 11:09:08 --> Language Class Initialized
INFO - 2017-11-03 11:09:08 --> Loader Class Initialized
INFO - 2017-11-03 11:09:08 --> Helper loaded: url_helper
INFO - 2017-11-03 11:09:08 --> Helper loaded: common_helper
INFO - 2017-11-03 11:09:08 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:09:08 --> Email Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Controller Class Initialized
INFO - 2017-11-03 11:09:08 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> Model Class Initialized
INFO - 2017-11-03 11:09:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-03 11:09:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-03 11:09:08 --> Severity: Notice --> Undefined variable: products /var/www/html/spaceage_guru/application/views/templates/admin/module/service/manage_escrow.php 114
INFO - 2017-11-03 11:09:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/service/manage_escrow.php
INFO - 2017-11-03 11:09:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-03 11:09:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-03 11:09:08 --> Final output sent to browser
DEBUG - 2017-11-03 11:09:08 --> Total execution time: 0.0332
INFO - 2017-11-03 11:09:08 --> Config Class Initialized
INFO - 2017-11-03 11:09:08 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:09:08 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:09:08 --> Utf8 Class Initialized
INFO - 2017-11-03 11:09:08 --> URI Class Initialized
INFO - 2017-11-03 11:09:08 --> Router Class Initialized
INFO - 2017-11-03 11:09:08 --> Output Class Initialized
INFO - 2017-11-03 11:09:08 --> Security Class Initialized
DEBUG - 2017-11-03 11:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:09:08 --> Input Class Initialized
INFO - 2017-11-03 11:09:08 --> Language Class Initialized
ERROR - 2017-11-03 11:09:08 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-03 11:09:08 --> Config Class Initialized
INFO - 2017-11-03 11:09:08 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:09:08 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:09:08 --> Utf8 Class Initialized
INFO - 2017-11-03 11:09:08 --> URI Class Initialized
INFO - 2017-11-03 11:09:08 --> Router Class Initialized
INFO - 2017-11-03 11:09:08 --> Output Class Initialized
INFO - 2017-11-03 11:09:08 --> Security Class Initialized
DEBUG - 2017-11-03 11:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:09:08 --> Input Class Initialized
INFO - 2017-11-03 11:09:08 --> Language Class Initialized
ERROR - 2017-11-03 11:09:08 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-03 11:11:08 --> Config Class Initialized
INFO - 2017-11-03 11:11:08 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:11:08 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:11:08 --> Utf8 Class Initialized
INFO - 2017-11-03 11:11:08 --> URI Class Initialized
DEBUG - 2017-11-03 11:11:08 --> No URI present. Default controller set.
INFO - 2017-11-03 11:11:08 --> Router Class Initialized
INFO - 2017-11-03 11:11:08 --> Output Class Initialized
INFO - 2017-11-03 11:11:08 --> Security Class Initialized
DEBUG - 2017-11-03 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:11:08 --> Input Class Initialized
INFO - 2017-11-03 11:11:08 --> Language Class Initialized
INFO - 2017-11-03 11:11:08 --> Loader Class Initialized
INFO - 2017-11-03 11:11:08 --> Helper loaded: url_helper
INFO - 2017-11-03 11:11:08 --> Helper loaded: common_helper
INFO - 2017-11-03 11:11:08 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:11:08 --> Email Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Controller Class Initialized
INFO - 2017-11-03 11:11:08 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> Model Class Initialized
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 11:11:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 11:11:08 --> Final output sent to browser
DEBUG - 2017-11-03 11:11:08 --> Total execution time: 0.0151
INFO - 2017-11-03 11:14:13 --> Config Class Initialized
INFO - 2017-11-03 11:14:13 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:13 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:13 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:13 --> URI Class Initialized
INFO - 2017-11-03 11:14:13 --> Router Class Initialized
INFO - 2017-11-03 11:14:13 --> Output Class Initialized
INFO - 2017-11-03 11:14:13 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:13 --> Input Class Initialized
INFO - 2017-11-03 11:14:13 --> Language Class Initialized
INFO - 2017-11-03 11:14:13 --> Loader Class Initialized
INFO - 2017-11-03 11:14:13 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:13 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:13 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:13 --> Email Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Controller Class Initialized
INFO - 2017-11-03 11:14:13 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 11:14:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 11:14:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-03 11:14:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-03 11:14:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-03 11:14:13 --> Final output sent to browser
DEBUG - 2017-11-03 11:14:13 --> Total execution time: 0.0255
INFO - 2017-11-03 11:14:13 --> Config Class Initialized
INFO - 2017-11-03 11:14:13 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:13 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:13 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:13 --> URI Class Initialized
INFO - 2017-11-03 11:14:13 --> Router Class Initialized
INFO - 2017-11-03 11:14:13 --> Output Class Initialized
INFO - 2017-11-03 11:14:13 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:13 --> Input Class Initialized
INFO - 2017-11-03 11:14:13 --> Language Class Initialized
INFO - 2017-11-03 11:14:13 --> Loader Class Initialized
INFO - 2017-11-03 11:14:13 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:13 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:13 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:13 --> Email Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Controller Class Initialized
INFO - 2017-11-03 11:14:13 --> Model Class Initialized
INFO - 2017-11-03 11:14:13 --> Final output sent to browser
DEBUG - 2017-11-03 11:14:13 --> Total execution time: 0.0019
INFO - 2017-11-03 11:14:15 --> Config Class Initialized
INFO - 2017-11-03 11:14:15 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:15 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:15 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:15 --> URI Class Initialized
INFO - 2017-11-03 11:14:15 --> Router Class Initialized
INFO - 2017-11-03 11:14:15 --> Output Class Initialized
INFO - 2017-11-03 11:14:15 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:15 --> Input Class Initialized
INFO - 2017-11-03 11:14:15 --> Language Class Initialized
INFO - 2017-11-03 11:14:15 --> Loader Class Initialized
INFO - 2017-11-03 11:14:15 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:15 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:15 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:15 --> Email Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Controller Class Initialized
INFO - 2017-11-03 11:14:15 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-11-03 11:14:15 --> Model Class Initialized
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 11:14:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 11:14:15 --> Final output sent to browser
DEBUG - 2017-11-03 11:14:15 --> Total execution time: 0.0871
INFO - 2017-11-03 11:14:18 --> Config Class Initialized
INFO - 2017-11-03 11:14:18 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:18 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:18 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:18 --> URI Class Initialized
INFO - 2017-11-03 11:14:18 --> Router Class Initialized
INFO - 2017-11-03 11:14:18 --> Output Class Initialized
INFO - 2017-11-03 11:14:18 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:18 --> Input Class Initialized
INFO - 2017-11-03 11:14:18 --> Language Class Initialized
INFO - 2017-11-03 11:14:18 --> Loader Class Initialized
INFO - 2017-11-03 11:14:18 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:18 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:18 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:18 --> Email Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Controller Class Initialized
INFO - 2017-11-03 11:14:18 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Config Class Initialized
INFO - 2017-11-03 11:14:18 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:18 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:18 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:18 --> URI Class Initialized
INFO - 2017-11-03 11:14:18 --> Router Class Initialized
INFO - 2017-11-03 11:14:18 --> Output Class Initialized
INFO - 2017-11-03 11:14:18 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:18 --> Input Class Initialized
INFO - 2017-11-03 11:14:18 --> Language Class Initialized
INFO - 2017-11-03 11:14:18 --> Loader Class Initialized
INFO - 2017-11-03 11:14:18 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:18 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:18 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:18 --> Email Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Controller Class Initialized
INFO - 2017-11-03 11:14:18 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> Model Class Initialized
INFO - 2017-11-03 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-03 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 11:14:18 --> Final output sent to browser
DEBUG - 2017-11-03 11:14:18 --> Total execution time: 0.0178
INFO - 2017-11-03 11:14:22 --> Config Class Initialized
INFO - 2017-11-03 11:14:22 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:22 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:22 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:22 --> URI Class Initialized
INFO - 2017-11-03 11:14:22 --> Router Class Initialized
INFO - 2017-11-03 11:14:22 --> Output Class Initialized
INFO - 2017-11-03 11:14:22 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:22 --> Input Class Initialized
INFO - 2017-11-03 11:14:22 --> Language Class Initialized
INFO - 2017-11-03 11:14:22 --> Loader Class Initialized
INFO - 2017-11-03 11:14:22 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:22 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:22 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:22 --> Email Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Controller Class Initialized
INFO - 2017-11-03 11:14:22 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:22 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Config Class Initialized
INFO - 2017-11-03 11:14:23 --> Hooks Class Initialized
DEBUG - 2017-11-03 11:14:23 --> UTF-8 Support Enabled
INFO - 2017-11-03 11:14:23 --> Utf8 Class Initialized
INFO - 2017-11-03 11:14:23 --> URI Class Initialized
INFO - 2017-11-03 11:14:23 --> Router Class Initialized
INFO - 2017-11-03 11:14:23 --> Output Class Initialized
INFO - 2017-11-03 11:14:23 --> Security Class Initialized
DEBUG - 2017-11-03 11:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-03 11:14:23 --> Input Class Initialized
INFO - 2017-11-03 11:14:23 --> Language Class Initialized
INFO - 2017-11-03 11:14:23 --> Loader Class Initialized
INFO - 2017-11-03 11:14:23 --> Helper loaded: url_helper
INFO - 2017-11-03 11:14:23 --> Helper loaded: common_helper
INFO - 2017-11-03 11:14:23 --> Database Driver Class Initialized
DEBUG - 2017-11-03 11:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-03 11:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-03 11:14:23 --> Email Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Controller Class Initialized
INFO - 2017-11-03 11:14:23 --> Helper loaded: cookie_helper
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-03 11:14:23 --> Model Class Initialized
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-03 11:14:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-03 11:14:23 --> Final output sent to browser
DEBUG - 2017-11-03 11:14:23 --> Total execution time: 0.0271
