<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-22 18:13:18 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-11-22 18:13:27 --> 404 Page Not Found: Assets/uploads
