<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-31 13:18:25 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:18:26 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:18:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:18:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:18:31 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:18:31 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:20:10 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-31 13:20:10 --> 404 Page Not Found: Assets/uploads
