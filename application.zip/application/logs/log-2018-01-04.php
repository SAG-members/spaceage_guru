<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-04 10:42:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-01-04 10:42:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-01-04 10:42:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-04 10:42:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-04 10:42:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-04 10:42:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-04 10:42:59 --> 404 Page Not Found: Assets/admin
