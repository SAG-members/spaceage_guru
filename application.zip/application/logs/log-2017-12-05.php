<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-05 10:02:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-05 10:03:27 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-05 10:09:02 --> 404 Page Not Found: Lean-canvas-scc/index
ERROR - 2017-12-05 10:28:10 --> Severity: Notice --> Undefined variable: data /var/www/html/spaceage_guru/application/controllers/module/services/Service.php 53
ERROR - 2017-12-05 10:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/spaceage_guru/application/libraries/Template.php 122
ERROR - 2017-12-05 10:28:34 --> Severity: Notice --> Undefined variable: data /var/www/html/spaceage_guru/application/controllers/module/services/Service.php 53
ERROR - 2017-12-05 10:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/spaceage_guru/application/libraries/Template.php 122
ERROR - 2017-12-05 15:01:54 --> 404 Page Not Found: Library/index
