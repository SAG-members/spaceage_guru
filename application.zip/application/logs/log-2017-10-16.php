<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-16 10:36:03 --> Config Class Initialized
INFO - 2017-10-16 10:36:03 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:36:03 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:36:03 --> Utf8 Class Initialized
INFO - 2017-10-16 10:36:03 --> URI Class Initialized
DEBUG - 2017-10-16 10:36:03 --> No URI present. Default controller set.
INFO - 2017-10-16 10:36:03 --> Router Class Initialized
INFO - 2017-10-16 10:36:03 --> Output Class Initialized
INFO - 2017-10-16 10:36:03 --> Security Class Initialized
DEBUG - 2017-10-16 10:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:36:03 --> Input Class Initialized
INFO - 2017-10-16 10:36:03 --> Language Class Initialized
INFO - 2017-10-16 10:36:03 --> Loader Class Initialized
INFO - 2017-10-16 10:36:03 --> Helper loaded: url_helper
INFO - 2017-10-16 10:36:03 --> Helper loaded: common_helper
INFO - 2017-10-16 10:36:03 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:36:04 --> Email Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Controller Class Initialized
INFO - 2017-10-16 10:36:04 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> Model Class Initialized
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:36:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:36:04 --> Final output sent to browser
DEBUG - 2017-10-16 10:36:04 --> Total execution time: 0.7009
INFO - 2017-10-16 10:38:11 --> Config Class Initialized
INFO - 2017-10-16 10:38:11 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:38:11 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:38:11 --> Utf8 Class Initialized
INFO - 2017-10-16 10:38:11 --> URI Class Initialized
INFO - 2017-10-16 10:38:11 --> Router Class Initialized
INFO - 2017-10-16 10:38:11 --> Output Class Initialized
INFO - 2017-10-16 10:38:11 --> Security Class Initialized
DEBUG - 2017-10-16 10:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:38:11 --> Input Class Initialized
INFO - 2017-10-16 10:38:11 --> Language Class Initialized
INFO - 2017-10-16 10:38:11 --> Loader Class Initialized
INFO - 2017-10-16 10:38:11 --> Helper loaded: url_helper
INFO - 2017-10-16 10:38:11 --> Helper loaded: common_helper
INFO - 2017-10-16 10:38:11 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:38:11 --> Email Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Controller Class Initialized
INFO - 2017-10-16 10:38:11 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> Model Class Initialized
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:38:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:38:11 --> Final output sent to browser
DEBUG - 2017-10-16 10:38:11 --> Total execution time: 0.2734
INFO - 2017-10-16 10:41:20 --> Config Class Initialized
INFO - 2017-10-16 10:41:20 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:41:20 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:41:20 --> Utf8 Class Initialized
INFO - 2017-10-16 10:41:20 --> URI Class Initialized
INFO - 2017-10-16 10:41:20 --> Router Class Initialized
INFO - 2017-10-16 10:41:20 --> Output Class Initialized
INFO - 2017-10-16 10:41:20 --> Security Class Initialized
DEBUG - 2017-10-16 10:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:41:20 --> Input Class Initialized
INFO - 2017-10-16 10:41:20 --> Language Class Initialized
INFO - 2017-10-16 10:41:20 --> Loader Class Initialized
INFO - 2017-10-16 10:41:20 --> Helper loaded: url_helper
INFO - 2017-10-16 10:41:20 --> Helper loaded: common_helper
INFO - 2017-10-16 10:41:20 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:41:20 --> Email Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Controller Class Initialized
INFO - 2017-10-16 10:41:20 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> Model Class Initialized
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:41:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:41:20 --> Final output sent to browser
DEBUG - 2017-10-16 10:41:20 --> Total execution time: 0.0295
INFO - 2017-10-16 10:41:45 --> Config Class Initialized
INFO - 2017-10-16 10:41:45 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:41:45 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:41:45 --> Utf8 Class Initialized
INFO - 2017-10-16 10:41:45 --> URI Class Initialized
INFO - 2017-10-16 10:41:45 --> Router Class Initialized
INFO - 2017-10-16 10:41:45 --> Output Class Initialized
INFO - 2017-10-16 10:41:45 --> Security Class Initialized
DEBUG - 2017-10-16 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:41:45 --> Input Class Initialized
INFO - 2017-10-16 10:41:45 --> Language Class Initialized
INFO - 2017-10-16 10:41:45 --> Loader Class Initialized
INFO - 2017-10-16 10:41:45 --> Helper loaded: url_helper
INFO - 2017-10-16 10:41:45 --> Helper loaded: common_helper
INFO - 2017-10-16 10:41:45 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:41:45 --> Email Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Controller Class Initialized
INFO - 2017-10-16 10:41:45 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> Model Class Initialized
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:41:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:41:45 --> Final output sent to browser
DEBUG - 2017-10-16 10:41:45 --> Total execution time: 0.0292
INFO - 2017-10-16 10:42:01 --> Config Class Initialized
INFO - 2017-10-16 10:42:01 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:42:01 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:42:01 --> Utf8 Class Initialized
INFO - 2017-10-16 10:42:01 --> URI Class Initialized
INFO - 2017-10-16 10:42:01 --> Router Class Initialized
INFO - 2017-10-16 10:42:01 --> Output Class Initialized
INFO - 2017-10-16 10:42:01 --> Security Class Initialized
DEBUG - 2017-10-16 10:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:42:01 --> Input Class Initialized
INFO - 2017-10-16 10:42:01 --> Language Class Initialized
INFO - 2017-10-16 10:42:01 --> Loader Class Initialized
INFO - 2017-10-16 10:42:01 --> Helper loaded: url_helper
INFO - 2017-10-16 10:42:01 --> Helper loaded: common_helper
INFO - 2017-10-16 10:42:01 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:42:01 --> Email Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Controller Class Initialized
INFO - 2017-10-16 10:42:01 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> Model Class Initialized
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:42:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:42:01 --> Final output sent to browser
DEBUG - 2017-10-16 10:42:01 --> Total execution time: 0.0304
INFO - 2017-10-16 10:42:39 --> Config Class Initialized
INFO - 2017-10-16 10:42:39 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:42:39 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:42:39 --> Utf8 Class Initialized
INFO - 2017-10-16 10:42:39 --> URI Class Initialized
INFO - 2017-10-16 10:42:39 --> Router Class Initialized
INFO - 2017-10-16 10:42:39 --> Output Class Initialized
INFO - 2017-10-16 10:42:39 --> Security Class Initialized
DEBUG - 2017-10-16 10:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:42:39 --> Input Class Initialized
INFO - 2017-10-16 10:42:39 --> Language Class Initialized
INFO - 2017-10-16 10:42:39 --> Loader Class Initialized
INFO - 2017-10-16 10:42:39 --> Helper loaded: url_helper
INFO - 2017-10-16 10:42:39 --> Helper loaded: common_helper
INFO - 2017-10-16 10:42:39 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:42:39 --> Email Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Controller Class Initialized
INFO - 2017-10-16 10:42:39 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> Model Class Initialized
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:42:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:42:39 --> Final output sent to browser
DEBUG - 2017-10-16 10:42:39 --> Total execution time: 0.0303
INFO - 2017-10-16 10:43:18 --> Config Class Initialized
INFO - 2017-10-16 10:43:18 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:43:18 --> UTF-8 Support Enabled
INFO - 2017-10-16 10:43:18 --> Utf8 Class Initialized
INFO - 2017-10-16 10:43:18 --> URI Class Initialized
INFO - 2017-10-16 10:43:18 --> Router Class Initialized
INFO - 2017-10-16 10:43:18 --> Output Class Initialized
INFO - 2017-10-16 10:43:18 --> Security Class Initialized
DEBUG - 2017-10-16 10:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 10:43:18 --> Input Class Initialized
INFO - 2017-10-16 10:43:18 --> Language Class Initialized
INFO - 2017-10-16 10:43:18 --> Loader Class Initialized
INFO - 2017-10-16 10:43:18 --> Helper loaded: url_helper
INFO - 2017-10-16 10:43:18 --> Helper loaded: common_helper
INFO - 2017-10-16 10:43:18 --> Database Driver Class Initialized
DEBUG - 2017-10-16 10:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 10:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 10:43:18 --> Email Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Controller Class Initialized
INFO - 2017-10-16 10:43:18 --> Helper loaded: cookie_helper
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> Model Class Initialized
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 10:43:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 10:43:18 --> Final output sent to browser
DEBUG - 2017-10-16 10:43:18 --> Total execution time: 0.0306
INFO - 2017-10-16 11:32:02 --> Config Class Initialized
INFO - 2017-10-16 11:32:02 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:32:02 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:32:02 --> Utf8 Class Initialized
INFO - 2017-10-16 11:32:02 --> URI Class Initialized
INFO - 2017-10-16 11:32:02 --> Router Class Initialized
INFO - 2017-10-16 11:32:02 --> Output Class Initialized
INFO - 2017-10-16 11:32:02 --> Security Class Initialized
DEBUG - 2017-10-16 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:32:02 --> Input Class Initialized
INFO - 2017-10-16 11:32:02 --> Language Class Initialized
INFO - 2017-10-16 11:32:02 --> Loader Class Initialized
INFO - 2017-10-16 11:32:02 --> Helper loaded: url_helper
INFO - 2017-10-16 11:32:02 --> Helper loaded: common_helper
INFO - 2017-10-16 11:32:02 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:32:02 --> Email Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Controller Class Initialized
INFO - 2017-10-16 11:32:02 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> Model Class Initialized
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:32:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:32:02 --> Final output sent to browser
DEBUG - 2017-10-16 11:32:02 --> Total execution time: 0.0350
INFO - 2017-10-16 11:33:48 --> Config Class Initialized
INFO - 2017-10-16 11:33:48 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:33:48 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:33:48 --> Utf8 Class Initialized
INFO - 2017-10-16 11:33:48 --> URI Class Initialized
INFO - 2017-10-16 11:33:48 --> Router Class Initialized
INFO - 2017-10-16 11:33:48 --> Output Class Initialized
INFO - 2017-10-16 11:33:48 --> Security Class Initialized
DEBUG - 2017-10-16 11:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:33:48 --> Input Class Initialized
INFO - 2017-10-16 11:33:48 --> Language Class Initialized
INFO - 2017-10-16 11:33:48 --> Loader Class Initialized
INFO - 2017-10-16 11:33:48 --> Helper loaded: url_helper
INFO - 2017-10-16 11:33:48 --> Helper loaded: common_helper
INFO - 2017-10-16 11:33:48 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:33:48 --> Email Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Controller Class Initialized
INFO - 2017-10-16 11:33:48 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> Model Class Initialized
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:33:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:33:48 --> Final output sent to browser
DEBUG - 2017-10-16 11:33:48 --> Total execution time: 0.0316
INFO - 2017-10-16 11:34:09 --> Config Class Initialized
INFO - 2017-10-16 11:34:09 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:34:09 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:34:09 --> Utf8 Class Initialized
INFO - 2017-10-16 11:34:09 --> URI Class Initialized
INFO - 2017-10-16 11:34:09 --> Router Class Initialized
INFO - 2017-10-16 11:34:09 --> Output Class Initialized
INFO - 2017-10-16 11:34:09 --> Security Class Initialized
DEBUG - 2017-10-16 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:34:09 --> Input Class Initialized
INFO - 2017-10-16 11:34:09 --> Language Class Initialized
INFO - 2017-10-16 11:34:09 --> Loader Class Initialized
INFO - 2017-10-16 11:34:09 --> Helper loaded: url_helper
INFO - 2017-10-16 11:34:09 --> Helper loaded: common_helper
INFO - 2017-10-16 11:34:09 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:34:09 --> Email Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Controller Class Initialized
INFO - 2017-10-16 11:34:09 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> Model Class Initialized
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:34:09 --> Final output sent to browser
DEBUG - 2017-10-16 11:34:09 --> Total execution time: 0.0304
INFO - 2017-10-16 11:34:10 --> Config Class Initialized
INFO - 2017-10-16 11:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:34:10 --> Utf8 Class Initialized
INFO - 2017-10-16 11:34:10 --> URI Class Initialized
INFO - 2017-10-16 11:34:10 --> Router Class Initialized
INFO - 2017-10-16 11:34:10 --> Output Class Initialized
INFO - 2017-10-16 11:34:10 --> Security Class Initialized
DEBUG - 2017-10-16 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:34:10 --> Input Class Initialized
INFO - 2017-10-16 11:34:10 --> Language Class Initialized
INFO - 2017-10-16 11:34:10 --> Loader Class Initialized
INFO - 2017-10-16 11:34:10 --> Helper loaded: url_helper
INFO - 2017-10-16 11:34:10 --> Helper loaded: common_helper
INFO - 2017-10-16 11:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:34:10 --> Email Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Controller Class Initialized
INFO - 2017-10-16 11:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> Model Class Initialized
INFO - 2017-10-16 11:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:34:11 --> Final output sent to browser
DEBUG - 2017-10-16 11:34:11 --> Total execution time: 0.0384
INFO - 2017-10-16 11:34:13 --> Config Class Initialized
INFO - 2017-10-16 11:34:13 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:34:13 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:34:13 --> Utf8 Class Initialized
INFO - 2017-10-16 11:34:13 --> URI Class Initialized
INFO - 2017-10-16 11:34:13 --> Router Class Initialized
INFO - 2017-10-16 11:34:13 --> Output Class Initialized
INFO - 2017-10-16 11:34:13 --> Security Class Initialized
DEBUG - 2017-10-16 11:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:34:13 --> Input Class Initialized
INFO - 2017-10-16 11:34:13 --> Language Class Initialized
INFO - 2017-10-16 11:34:13 --> Loader Class Initialized
INFO - 2017-10-16 11:34:13 --> Helper loaded: url_helper
INFO - 2017-10-16 11:34:13 --> Helper loaded: common_helper
INFO - 2017-10-16 11:34:13 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:34:13 --> Email Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Controller Class Initialized
INFO - 2017-10-16 11:34:13 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> Model Class Initialized
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:34:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:34:13 --> Final output sent to browser
DEBUG - 2017-10-16 11:34:13 --> Total execution time: 0.0297
INFO - 2017-10-16 11:34:43 --> Config Class Initialized
INFO - 2017-10-16 11:34:43 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:34:43 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:34:43 --> Utf8 Class Initialized
INFO - 2017-10-16 11:34:43 --> URI Class Initialized
INFO - 2017-10-16 11:34:43 --> Router Class Initialized
INFO - 2017-10-16 11:34:43 --> Output Class Initialized
INFO - 2017-10-16 11:34:43 --> Security Class Initialized
DEBUG - 2017-10-16 11:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:34:43 --> Input Class Initialized
INFO - 2017-10-16 11:34:43 --> Language Class Initialized
INFO - 2017-10-16 11:34:43 --> Loader Class Initialized
INFO - 2017-10-16 11:34:43 --> Helper loaded: url_helper
INFO - 2017-10-16 11:34:43 --> Helper loaded: common_helper
INFO - 2017-10-16 11:34:43 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:34:43 --> Email Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Controller Class Initialized
INFO - 2017-10-16 11:34:43 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> Model Class Initialized
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:34:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:34:43 --> Final output sent to browser
DEBUG - 2017-10-16 11:34:43 --> Total execution time: 0.0290
INFO - 2017-10-16 11:35:36 --> Config Class Initialized
INFO - 2017-10-16 11:35:36 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:35:36 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:35:36 --> Utf8 Class Initialized
INFO - 2017-10-16 11:35:36 --> URI Class Initialized
INFO - 2017-10-16 11:35:36 --> Router Class Initialized
INFO - 2017-10-16 11:35:36 --> Output Class Initialized
INFO - 2017-10-16 11:35:36 --> Security Class Initialized
DEBUG - 2017-10-16 11:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:35:36 --> Input Class Initialized
INFO - 2017-10-16 11:35:36 --> Language Class Initialized
INFO - 2017-10-16 11:35:36 --> Loader Class Initialized
INFO - 2017-10-16 11:35:36 --> Helper loaded: url_helper
INFO - 2017-10-16 11:35:36 --> Helper loaded: common_helper
INFO - 2017-10-16 11:35:36 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:35:36 --> Email Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Controller Class Initialized
INFO - 2017-10-16 11:35:36 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> Model Class Initialized
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:35:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:35:36 --> Final output sent to browser
DEBUG - 2017-10-16 11:35:36 --> Total execution time: 0.0322
INFO - 2017-10-16 11:36:42 --> Config Class Initialized
INFO - 2017-10-16 11:36:42 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:36:42 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:36:42 --> Utf8 Class Initialized
INFO - 2017-10-16 11:36:42 --> URI Class Initialized
INFO - 2017-10-16 11:36:42 --> Router Class Initialized
INFO - 2017-10-16 11:36:42 --> Output Class Initialized
INFO - 2017-10-16 11:36:42 --> Security Class Initialized
DEBUG - 2017-10-16 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:36:42 --> Input Class Initialized
INFO - 2017-10-16 11:36:42 --> Language Class Initialized
INFO - 2017-10-16 11:36:42 --> Loader Class Initialized
INFO - 2017-10-16 11:36:42 --> Helper loaded: url_helper
INFO - 2017-10-16 11:36:42 --> Helper loaded: common_helper
INFO - 2017-10-16 11:36:42 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:36:42 --> Email Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Controller Class Initialized
INFO - 2017-10-16 11:36:42 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> Model Class Initialized
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:36:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:36:42 --> Final output sent to browser
DEBUG - 2017-10-16 11:36:42 --> Total execution time: 0.0304
INFO - 2017-10-16 11:36:47 --> Config Class Initialized
INFO - 2017-10-16 11:36:47 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:36:47 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:36:47 --> Utf8 Class Initialized
INFO - 2017-10-16 11:36:47 --> URI Class Initialized
INFO - 2017-10-16 11:36:47 --> Router Class Initialized
INFO - 2017-10-16 11:36:47 --> Output Class Initialized
INFO - 2017-10-16 11:36:47 --> Security Class Initialized
DEBUG - 2017-10-16 11:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:36:47 --> Input Class Initialized
INFO - 2017-10-16 11:36:47 --> Language Class Initialized
INFO - 2017-10-16 11:36:47 --> Loader Class Initialized
INFO - 2017-10-16 11:36:47 --> Helper loaded: url_helper
INFO - 2017-10-16 11:36:47 --> Helper loaded: common_helper
INFO - 2017-10-16 11:36:47 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:36:47 --> Email Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Controller Class Initialized
INFO - 2017-10-16 11:36:47 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> Model Class Initialized
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:36:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:36:47 --> Final output sent to browser
DEBUG - 2017-10-16 11:36:47 --> Total execution time: 0.0303
INFO - 2017-10-16 11:37:09 --> Config Class Initialized
INFO - 2017-10-16 11:37:09 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:37:09 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:37:09 --> Utf8 Class Initialized
INFO - 2017-10-16 11:37:09 --> URI Class Initialized
INFO - 2017-10-16 11:37:09 --> Router Class Initialized
INFO - 2017-10-16 11:37:09 --> Output Class Initialized
INFO - 2017-10-16 11:37:09 --> Security Class Initialized
DEBUG - 2017-10-16 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:37:09 --> Input Class Initialized
INFO - 2017-10-16 11:37:09 --> Language Class Initialized
INFO - 2017-10-16 11:37:09 --> Loader Class Initialized
INFO - 2017-10-16 11:37:09 --> Helper loaded: url_helper
INFO - 2017-10-16 11:37:09 --> Helper loaded: common_helper
INFO - 2017-10-16 11:37:09 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:37:09 --> Email Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Controller Class Initialized
INFO - 2017-10-16 11:37:09 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> Model Class Initialized
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:37:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:37:09 --> Final output sent to browser
DEBUG - 2017-10-16 11:37:09 --> Total execution time: 0.0320
INFO - 2017-10-16 11:37:28 --> Config Class Initialized
INFO - 2017-10-16 11:37:28 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:37:28 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:37:28 --> Utf8 Class Initialized
INFO - 2017-10-16 11:37:28 --> URI Class Initialized
INFO - 2017-10-16 11:37:28 --> Router Class Initialized
INFO - 2017-10-16 11:37:28 --> Output Class Initialized
INFO - 2017-10-16 11:37:28 --> Security Class Initialized
DEBUG - 2017-10-16 11:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:37:28 --> Input Class Initialized
INFO - 2017-10-16 11:37:28 --> Language Class Initialized
INFO - 2017-10-16 11:37:28 --> Loader Class Initialized
INFO - 2017-10-16 11:37:28 --> Helper loaded: url_helper
INFO - 2017-10-16 11:37:28 --> Helper loaded: common_helper
INFO - 2017-10-16 11:37:28 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:37:28 --> Email Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Controller Class Initialized
INFO - 2017-10-16 11:37:28 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> Model Class Initialized
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:37:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:37:28 --> Final output sent to browser
DEBUG - 2017-10-16 11:37:28 --> Total execution time: 0.0735
INFO - 2017-10-16 11:38:32 --> Config Class Initialized
INFO - 2017-10-16 11:38:32 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:38:32 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:38:32 --> Utf8 Class Initialized
INFO - 2017-10-16 11:38:32 --> URI Class Initialized
INFO - 2017-10-16 11:38:32 --> Router Class Initialized
INFO - 2017-10-16 11:38:32 --> Output Class Initialized
INFO - 2017-10-16 11:38:32 --> Security Class Initialized
DEBUG - 2017-10-16 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:38:32 --> Input Class Initialized
INFO - 2017-10-16 11:38:32 --> Language Class Initialized
INFO - 2017-10-16 11:38:32 --> Loader Class Initialized
INFO - 2017-10-16 11:38:32 --> Helper loaded: url_helper
INFO - 2017-10-16 11:38:32 --> Helper loaded: common_helper
INFO - 2017-10-16 11:38:32 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:38:32 --> Email Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Controller Class Initialized
INFO - 2017-10-16 11:38:32 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> Model Class Initialized
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:38:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:38:32 --> Final output sent to browser
DEBUG - 2017-10-16 11:38:32 --> Total execution time: 0.0329
INFO - 2017-10-16 11:38:41 --> Config Class Initialized
INFO - 2017-10-16 11:38:41 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:38:41 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:38:41 --> Utf8 Class Initialized
INFO - 2017-10-16 11:38:41 --> URI Class Initialized
INFO - 2017-10-16 11:38:41 --> Router Class Initialized
INFO - 2017-10-16 11:38:41 --> Output Class Initialized
INFO - 2017-10-16 11:38:41 --> Security Class Initialized
DEBUG - 2017-10-16 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:38:41 --> Input Class Initialized
INFO - 2017-10-16 11:38:41 --> Language Class Initialized
INFO - 2017-10-16 11:38:41 --> Loader Class Initialized
INFO - 2017-10-16 11:38:41 --> Helper loaded: url_helper
INFO - 2017-10-16 11:38:41 --> Helper loaded: common_helper
INFO - 2017-10-16 11:38:41 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:38:41 --> Email Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Controller Class Initialized
INFO - 2017-10-16 11:38:41 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Model Class Initialized
INFO - 2017-10-16 11:38:41 --> Final output sent to browser
DEBUG - 2017-10-16 11:38:41 --> Total execution time: 0.0217
INFO - 2017-10-16 11:39:00 --> Config Class Initialized
INFO - 2017-10-16 11:39:00 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:39:00 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:39:00 --> Utf8 Class Initialized
INFO - 2017-10-16 11:39:00 --> URI Class Initialized
INFO - 2017-10-16 11:39:00 --> Router Class Initialized
INFO - 2017-10-16 11:39:00 --> Output Class Initialized
INFO - 2017-10-16 11:39:00 --> Security Class Initialized
DEBUG - 2017-10-16 11:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:39:00 --> Input Class Initialized
INFO - 2017-10-16 11:39:00 --> Language Class Initialized
INFO - 2017-10-16 11:39:00 --> Loader Class Initialized
INFO - 2017-10-16 11:39:00 --> Helper loaded: url_helper
INFO - 2017-10-16 11:39:00 --> Helper loaded: common_helper
INFO - 2017-10-16 11:39:00 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:39:00 --> Email Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Controller Class Initialized
INFO - 2017-10-16 11:39:00 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> Model Class Initialized
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:39:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:39:00 --> Final output sent to browser
DEBUG - 2017-10-16 11:39:00 --> Total execution time: 0.0351
INFO - 2017-10-16 11:39:05 --> Config Class Initialized
INFO - 2017-10-16 11:39:05 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:39:05 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:39:05 --> Utf8 Class Initialized
INFO - 2017-10-16 11:39:05 --> URI Class Initialized
INFO - 2017-10-16 11:39:05 --> Router Class Initialized
INFO - 2017-10-16 11:39:05 --> Output Class Initialized
INFO - 2017-10-16 11:39:05 --> Security Class Initialized
DEBUG - 2017-10-16 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:39:05 --> Input Class Initialized
INFO - 2017-10-16 11:39:05 --> Language Class Initialized
INFO - 2017-10-16 11:39:05 --> Loader Class Initialized
INFO - 2017-10-16 11:39:05 --> Helper loaded: url_helper
INFO - 2017-10-16 11:39:05 --> Helper loaded: common_helper
INFO - 2017-10-16 11:39:05 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:39:05 --> Email Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Controller Class Initialized
INFO - 2017-10-16 11:39:05 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Config Class Initialized
INFO - 2017-10-16 11:39:05 --> Hooks Class Initialized
DEBUG - 2017-10-16 11:39:05 --> UTF-8 Support Enabled
INFO - 2017-10-16 11:39:05 --> Utf8 Class Initialized
INFO - 2017-10-16 11:39:05 --> URI Class Initialized
INFO - 2017-10-16 11:39:05 --> Router Class Initialized
INFO - 2017-10-16 11:39:05 --> Output Class Initialized
INFO - 2017-10-16 11:39:05 --> Security Class Initialized
DEBUG - 2017-10-16 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 11:39:05 --> Input Class Initialized
INFO - 2017-10-16 11:39:05 --> Language Class Initialized
INFO - 2017-10-16 11:39:05 --> Loader Class Initialized
INFO - 2017-10-16 11:39:05 --> Helper loaded: url_helper
INFO - 2017-10-16 11:39:05 --> Helper loaded: common_helper
INFO - 2017-10-16 11:39:05 --> Database Driver Class Initialized
DEBUG - 2017-10-16 11:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 11:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 11:39:05 --> Email Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Controller Class Initialized
INFO - 2017-10-16 11:39:05 --> Helper loaded: cookie_helper
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> Model Class Initialized
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 11:39:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 11:39:05 --> Final output sent to browser
DEBUG - 2017-10-16 11:39:05 --> Total execution time: 0.0298
INFO - 2017-10-16 14:58:29 --> Config Class Initialized
INFO - 2017-10-16 14:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-16 14:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-16 14:58:29 --> Utf8 Class Initialized
INFO - 2017-10-16 14:58:29 --> URI Class Initialized
INFO - 2017-10-16 14:58:29 --> Router Class Initialized
INFO - 2017-10-16 14:58:29 --> Output Class Initialized
INFO - 2017-10-16 14:58:29 --> Security Class Initialized
DEBUG - 2017-10-16 14:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 14:58:29 --> Input Class Initialized
INFO - 2017-10-16 14:58:29 --> Language Class Initialized
INFO - 2017-10-16 14:58:29 --> Loader Class Initialized
INFO - 2017-10-16 14:58:29 --> Helper loaded: url_helper
INFO - 2017-10-16 14:58:29 --> Helper loaded: common_helper
INFO - 2017-10-16 14:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-16 14:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 14:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 14:58:29 --> Email Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Controller Class Initialized
INFO - 2017-10-16 14:58:29 --> Helper loaded: cookie_helper
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> Model Class Initialized
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 14:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 14:58:29 --> Final output sent to browser
DEBUG - 2017-10-16 14:58:29 --> Total execution time: 0.0283
INFO - 2017-10-16 14:58:52 --> Config Class Initialized
INFO - 2017-10-16 14:58:52 --> Hooks Class Initialized
DEBUG - 2017-10-16 14:58:52 --> UTF-8 Support Enabled
INFO - 2017-10-16 14:58:52 --> Utf8 Class Initialized
INFO - 2017-10-16 14:58:52 --> URI Class Initialized
INFO - 2017-10-16 14:58:52 --> Router Class Initialized
INFO - 2017-10-16 14:58:52 --> Output Class Initialized
INFO - 2017-10-16 14:58:52 --> Security Class Initialized
DEBUG - 2017-10-16 14:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 14:58:52 --> Input Class Initialized
INFO - 2017-10-16 14:58:52 --> Language Class Initialized
INFO - 2017-10-16 14:58:52 --> Loader Class Initialized
INFO - 2017-10-16 14:58:52 --> Helper loaded: url_helper
INFO - 2017-10-16 14:58:52 --> Helper loaded: common_helper
INFO - 2017-10-16 14:58:52 --> Database Driver Class Initialized
DEBUG - 2017-10-16 14:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 14:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 14:58:52 --> Email Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Controller Class Initialized
INFO - 2017-10-16 14:58:52 --> Helper loaded: cookie_helper
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> Model Class Initialized
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 14:58:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 14:58:52 --> Final output sent to browser
DEBUG - 2017-10-16 14:58:52 --> Total execution time: 0.0360
INFO - 2017-10-16 14:59:32 --> Config Class Initialized
INFO - 2017-10-16 14:59:32 --> Hooks Class Initialized
DEBUG - 2017-10-16 14:59:32 --> UTF-8 Support Enabled
INFO - 2017-10-16 14:59:32 --> Utf8 Class Initialized
INFO - 2017-10-16 14:59:32 --> URI Class Initialized
INFO - 2017-10-16 14:59:32 --> Router Class Initialized
INFO - 2017-10-16 14:59:32 --> Output Class Initialized
INFO - 2017-10-16 14:59:32 --> Security Class Initialized
DEBUG - 2017-10-16 14:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 14:59:32 --> Input Class Initialized
INFO - 2017-10-16 14:59:32 --> Language Class Initialized
INFO - 2017-10-16 14:59:32 --> Loader Class Initialized
INFO - 2017-10-16 14:59:32 --> Helper loaded: url_helper
INFO - 2017-10-16 14:59:32 --> Helper loaded: common_helper
INFO - 2017-10-16 14:59:32 --> Database Driver Class Initialized
DEBUG - 2017-10-16 14:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 14:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 14:59:32 --> Email Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Controller Class Initialized
INFO - 2017-10-16 14:59:32 --> Helper loaded: cookie_helper
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> Model Class Initialized
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-16 14:59:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-16 14:59:32 --> Final output sent to browser
DEBUG - 2017-10-16 14:59:32 --> Total execution time: 0.0318
INFO - 2017-10-16 15:10:22 --> Config Class Initialized
INFO - 2017-10-16 15:10:22 --> Hooks Class Initialized
DEBUG - 2017-10-16 15:10:22 --> UTF-8 Support Enabled
INFO - 2017-10-16 15:10:22 --> Utf8 Class Initialized
INFO - 2017-10-16 15:10:22 --> URI Class Initialized
INFO - 2017-10-16 15:10:22 --> Router Class Initialized
INFO - 2017-10-16 15:10:22 --> Output Class Initialized
INFO - 2017-10-16 15:10:22 --> Security Class Initialized
DEBUG - 2017-10-16 15:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 15:10:22 --> Input Class Initialized
INFO - 2017-10-16 15:10:22 --> Language Class Initialized
INFO - 2017-10-16 15:10:22 --> Loader Class Initialized
INFO - 2017-10-16 15:10:22 --> Helper loaded: url_helper
INFO - 2017-10-16 15:10:22 --> Helper loaded: common_helper
INFO - 2017-10-16 15:10:22 --> Database Driver Class Initialized
DEBUG - 2017-10-16 15:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 15:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 15:10:22 --> Email Class Initialized
INFO - 2017-10-16 15:10:22 --> Model Class Initialized
INFO - 2017-10-16 15:10:22 --> Controller Class Initialized
INFO - 2017-10-16 15:10:22 --> Model Class Initialized
INFO - 2017-10-16 15:10:22 --> Final output sent to browser
DEBUG - 2017-10-16 15:10:22 --> Total execution time: 0.0330
INFO - 2017-10-16 15:19:52 --> Config Class Initialized
INFO - 2017-10-16 15:19:52 --> Hooks Class Initialized
DEBUG - 2017-10-16 15:19:52 --> UTF-8 Support Enabled
INFO - 2017-10-16 15:19:52 --> Utf8 Class Initialized
INFO - 2017-10-16 15:19:52 --> URI Class Initialized
INFO - 2017-10-16 15:19:52 --> Router Class Initialized
INFO - 2017-10-16 15:19:52 --> Output Class Initialized
INFO - 2017-10-16 15:19:52 --> Security Class Initialized
DEBUG - 2017-10-16 15:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 15:19:52 --> Input Class Initialized
INFO - 2017-10-16 15:19:52 --> Language Class Initialized
INFO - 2017-10-16 15:19:52 --> Loader Class Initialized
INFO - 2017-10-16 15:19:52 --> Helper loaded: url_helper
INFO - 2017-10-16 15:19:52 --> Helper loaded: common_helper
INFO - 2017-10-16 15:19:52 --> Database Driver Class Initialized
DEBUG - 2017-10-16 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 15:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 15:19:52 --> Email Class Initialized
INFO - 2017-10-16 15:19:52 --> Model Class Initialized
INFO - 2017-10-16 15:19:52 --> Controller Class Initialized
INFO - 2017-10-16 15:19:52 --> Model Class Initialized
INFO - 2017-10-16 15:19:52 --> Final output sent to browser
DEBUG - 2017-10-16 15:19:52 --> Total execution time: 0.0037
INFO - 2017-10-16 15:20:04 --> Config Class Initialized
INFO - 2017-10-16 15:20:04 --> Hooks Class Initialized
DEBUG - 2017-10-16 15:20:04 --> UTF-8 Support Enabled
INFO - 2017-10-16 15:20:04 --> Utf8 Class Initialized
INFO - 2017-10-16 15:20:04 --> URI Class Initialized
INFO - 2017-10-16 15:20:04 --> Router Class Initialized
INFO - 2017-10-16 15:20:04 --> Output Class Initialized
INFO - 2017-10-16 15:20:04 --> Security Class Initialized
DEBUG - 2017-10-16 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-16 15:20:04 --> Input Class Initialized
INFO - 2017-10-16 15:20:04 --> Language Class Initialized
INFO - 2017-10-16 15:20:04 --> Loader Class Initialized
INFO - 2017-10-16 15:20:04 --> Helper loaded: url_helper
INFO - 2017-10-16 15:20:04 --> Helper loaded: common_helper
INFO - 2017-10-16 15:20:04 --> Database Driver Class Initialized
DEBUG - 2017-10-16 15:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-16 15:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-16 15:20:04 --> Email Class Initialized
INFO - 2017-10-16 15:20:04 --> Model Class Initialized
INFO - 2017-10-16 15:20:04 --> Controller Class Initialized
INFO - 2017-10-16 15:20:04 --> Model Class Initialized
INFO - 2017-10-16 15:20:04 --> Model Class Initialized
INFO - 2017-10-16 15:20:04 --> Model Class Initialized
INFO - 2017-10-16 15:20:04 --> Model Class Initialized
INFO - 2017-10-16 15:20:04 --> File loaded: /var/www/html/spaceage_guru/application/views/email_templates/invite_new_user.php
INFO - 2017-10-16 15:22:06 --> Language file loaded: language/english/email_lang.php
INFO - 2017-10-16 15:22:06 --> Final output sent to browser
DEBUG - 2017-10-16 15:22:06 --> Total execution time: 121.2457
