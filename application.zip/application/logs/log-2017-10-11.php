<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-11 11:36:42 --> Config Class Initialized
INFO - 2017-10-11 11:36:42 --> Hooks Class Initialized
DEBUG - 2017-10-11 11:36:42 --> UTF-8 Support Enabled
INFO - 2017-10-11 11:36:42 --> Utf8 Class Initialized
INFO - 2017-10-11 11:36:42 --> URI Class Initialized
DEBUG - 2017-10-11 11:36:42 --> No URI present. Default controller set.
INFO - 2017-10-11 11:36:42 --> Router Class Initialized
INFO - 2017-10-11 11:36:42 --> Output Class Initialized
INFO - 2017-10-11 11:36:42 --> Security Class Initialized
DEBUG - 2017-10-11 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 11:36:42 --> Input Class Initialized
INFO - 2017-10-11 11:36:42 --> Language Class Initialized
INFO - 2017-10-11 11:36:42 --> Loader Class Initialized
INFO - 2017-10-11 11:36:42 --> Helper loaded: url_helper
INFO - 2017-10-11 11:36:42 --> Helper loaded: common_helper
INFO - 2017-10-11 11:36:43 --> Database Driver Class Initialized
DEBUG - 2017-10-11 11:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 11:36:43 --> Email Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Controller Class Initialized
INFO - 2017-10-11 11:36:43 --> Helper loaded: cookie_helper
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:43 --> Model Class Initialized
INFO - 2017-10-11 11:36:44 --> Model Class Initialized
INFO - 2017-10-11 11:36:44 --> Model Class Initialized
INFO - 2017-10-11 11:36:44 --> Model Class Initialized
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 11:36:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 11:36:45 --> Final output sent to browser
DEBUG - 2017-10-11 11:36:45 --> Total execution time: 2.5906
INFO - 2017-10-11 11:37:32 --> Config Class Initialized
INFO - 2017-10-11 11:37:32 --> Hooks Class Initialized
DEBUG - 2017-10-11 11:37:32 --> UTF-8 Support Enabled
INFO - 2017-10-11 11:37:32 --> Utf8 Class Initialized
INFO - 2017-10-11 11:37:32 --> URI Class Initialized
DEBUG - 2017-10-11 11:37:32 --> No URI present. Default controller set.
INFO - 2017-10-11 11:37:32 --> Router Class Initialized
INFO - 2017-10-11 11:37:32 --> Output Class Initialized
INFO - 2017-10-11 11:37:32 --> Security Class Initialized
DEBUG - 2017-10-11 11:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 11:37:32 --> Input Class Initialized
INFO - 2017-10-11 11:37:32 --> Language Class Initialized
INFO - 2017-10-11 11:37:32 --> Loader Class Initialized
INFO - 2017-10-11 11:37:32 --> Helper loaded: url_helper
INFO - 2017-10-11 11:37:32 --> Helper loaded: common_helper
INFO - 2017-10-11 11:37:32 --> Database Driver Class Initialized
DEBUG - 2017-10-11 11:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 11:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 11:37:32 --> Email Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Controller Class Initialized
INFO - 2017-10-11 11:37:32 --> Helper loaded: cookie_helper
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> Model Class Initialized
INFO - 2017-10-11 11:37:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 11:37:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 11:37:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 11:37:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 11:37:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 11:37:32 --> Final output sent to browser
DEBUG - 2017-10-11 11:37:32 --> Total execution time: 0.0205
INFO - 2017-10-11 11:37:43 --> Config Class Initialized
INFO - 2017-10-11 11:37:43 --> Hooks Class Initialized
DEBUG - 2017-10-11 11:37:43 --> UTF-8 Support Enabled
INFO - 2017-10-11 11:37:43 --> Utf8 Class Initialized
INFO - 2017-10-11 11:37:43 --> URI Class Initialized
INFO - 2017-10-11 11:37:43 --> Router Class Initialized
INFO - 2017-10-11 11:37:43 --> Output Class Initialized
INFO - 2017-10-11 11:37:43 --> Security Class Initialized
DEBUG - 2017-10-11 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 11:37:43 --> Input Class Initialized
INFO - 2017-10-11 11:37:43 --> Language Class Initialized
INFO - 2017-10-11 11:37:43 --> Loader Class Initialized
INFO - 2017-10-11 11:37:43 --> Helper loaded: url_helper
INFO - 2017-10-11 11:37:43 --> Helper loaded: common_helper
INFO - 2017-10-11 11:37:43 --> Database Driver Class Initialized
DEBUG - 2017-10-11 11:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 11:37:43 --> Email Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Controller Class Initialized
INFO - 2017-10-11 11:37:43 --> Helper loaded: cookie_helper
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Config Class Initialized
INFO - 2017-10-11 11:37:43 --> Hooks Class Initialized
DEBUG - 2017-10-11 11:37:43 --> UTF-8 Support Enabled
INFO - 2017-10-11 11:37:43 --> Utf8 Class Initialized
INFO - 2017-10-11 11:37:43 --> URI Class Initialized
INFO - 2017-10-11 11:37:43 --> Router Class Initialized
INFO - 2017-10-11 11:37:43 --> Output Class Initialized
INFO - 2017-10-11 11:37:43 --> Security Class Initialized
DEBUG - 2017-10-11 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 11:37:43 --> Input Class Initialized
INFO - 2017-10-11 11:37:43 --> Language Class Initialized
INFO - 2017-10-11 11:37:43 --> Loader Class Initialized
INFO - 2017-10-11 11:37:43 --> Helper loaded: url_helper
INFO - 2017-10-11 11:37:43 --> Helper loaded: common_helper
INFO - 2017-10-11 11:37:43 --> Database Driver Class Initialized
DEBUG - 2017-10-11 11:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 11:37:43 --> Email Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Controller Class Initialized
INFO - 2017-10-11 11:37:43 --> Helper loaded: cookie_helper
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:43 --> Model Class Initialized
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 11:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 11:37:44 --> Final output sent to browser
DEBUG - 2017-10-11 11:37:44 --> Total execution time: 0.2031
INFO - 2017-10-11 11:37:54 --> Config Class Initialized
INFO - 2017-10-11 11:37:54 --> Hooks Class Initialized
DEBUG - 2017-10-11 11:37:54 --> UTF-8 Support Enabled
INFO - 2017-10-11 11:37:54 --> Utf8 Class Initialized
INFO - 2017-10-11 11:37:54 --> URI Class Initialized
DEBUG - 2017-10-11 11:37:54 --> No URI present. Default controller set.
INFO - 2017-10-11 11:37:54 --> Router Class Initialized
INFO - 2017-10-11 11:37:54 --> Output Class Initialized
INFO - 2017-10-11 11:37:54 --> Security Class Initialized
DEBUG - 2017-10-11 11:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 11:37:54 --> Input Class Initialized
INFO - 2017-10-11 11:37:54 --> Language Class Initialized
INFO - 2017-10-11 11:37:54 --> Loader Class Initialized
INFO - 2017-10-11 11:37:54 --> Helper loaded: url_helper
INFO - 2017-10-11 11:37:54 --> Helper loaded: common_helper
INFO - 2017-10-11 11:37:54 --> Database Driver Class Initialized
DEBUG - 2017-10-11 11:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 11:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 11:37:54 --> Email Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Controller Class Initialized
INFO - 2017-10-11 11:37:54 --> Helper loaded: cookie_helper
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> Model Class Initialized
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 11:37:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 11:37:54 --> Final output sent to browser
DEBUG - 2017-10-11 11:37:54 --> Total execution time: 0.0381
INFO - 2017-10-11 13:33:22 --> Config Class Initialized
INFO - 2017-10-11 13:33:22 --> Hooks Class Initialized
DEBUG - 2017-10-11 13:33:22 --> UTF-8 Support Enabled
INFO - 2017-10-11 13:33:22 --> Utf8 Class Initialized
INFO - 2017-10-11 13:33:22 --> URI Class Initialized
INFO - 2017-10-11 13:33:22 --> Router Class Initialized
INFO - 2017-10-11 13:33:22 --> Output Class Initialized
INFO - 2017-10-11 13:33:22 --> Security Class Initialized
DEBUG - 2017-10-11 13:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 13:33:22 --> Input Class Initialized
INFO - 2017-10-11 13:33:22 --> Language Class Initialized
INFO - 2017-10-11 13:33:22 --> Loader Class Initialized
INFO - 2017-10-11 13:33:22 --> Helper loaded: url_helper
INFO - 2017-10-11 13:33:22 --> Helper loaded: common_helper
INFO - 2017-10-11 13:33:22 --> Database Driver Class Initialized
DEBUG - 2017-10-11 13:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 13:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 13:33:22 --> Email Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Controller Class Initialized
INFO - 2017-10-11 13:33:22 --> Helper loaded: cookie_helper
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> Model Class Initialized
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 13:33:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 13:33:22 --> Final output sent to browser
DEBUG - 2017-10-11 13:33:22 --> Total execution time: 0.1729
INFO - 2017-10-11 15:14:20 --> Config Class Initialized
INFO - 2017-10-11 15:14:20 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:14:20 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:14:20 --> Utf8 Class Initialized
INFO - 2017-10-11 15:14:20 --> URI Class Initialized
DEBUG - 2017-10-11 15:14:20 --> No URI present. Default controller set.
INFO - 2017-10-11 15:14:20 --> Router Class Initialized
INFO - 2017-10-11 15:14:20 --> Output Class Initialized
INFO - 2017-10-11 15:14:20 --> Security Class Initialized
DEBUG - 2017-10-11 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:14:20 --> Input Class Initialized
INFO - 2017-10-11 15:14:20 --> Language Class Initialized
INFO - 2017-10-11 15:14:20 --> Loader Class Initialized
INFO - 2017-10-11 15:14:20 --> Helper loaded: url_helper
INFO - 2017-10-11 15:14:20 --> Helper loaded: common_helper
INFO - 2017-10-11 15:14:20 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:14:20 --> Email Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Controller Class Initialized
INFO - 2017-10-11 15:14:20 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> Model Class Initialized
INFO - 2017-10-11 15:14:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:14:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:14:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 15:14:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:14:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:14:20 --> Final output sent to browser
DEBUG - 2017-10-11 15:14:20 --> Total execution time: 0.2209
INFO - 2017-10-11 15:14:27 --> Config Class Initialized
INFO - 2017-10-11 15:14:27 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:14:27 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:14:27 --> Utf8 Class Initialized
INFO - 2017-10-11 15:14:27 --> URI Class Initialized
INFO - 2017-10-11 15:14:27 --> Router Class Initialized
INFO - 2017-10-11 15:14:27 --> Output Class Initialized
INFO - 2017-10-11 15:14:27 --> Security Class Initialized
DEBUG - 2017-10-11 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:14:27 --> Input Class Initialized
INFO - 2017-10-11 15:14:27 --> Language Class Initialized
INFO - 2017-10-11 15:14:27 --> Loader Class Initialized
INFO - 2017-10-11 15:14:27 --> Helper loaded: url_helper
INFO - 2017-10-11 15:14:27 --> Helper loaded: common_helper
INFO - 2017-10-11 15:14:27 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:14:27 --> Email Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Controller Class Initialized
INFO - 2017-10-11 15:14:27 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:27 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Config Class Initialized
INFO - 2017-10-11 15:14:28 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:14:28 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:14:28 --> Utf8 Class Initialized
INFO - 2017-10-11 15:14:28 --> URI Class Initialized
INFO - 2017-10-11 15:14:28 --> Router Class Initialized
INFO - 2017-10-11 15:14:28 --> Output Class Initialized
INFO - 2017-10-11 15:14:28 --> Security Class Initialized
DEBUG - 2017-10-11 15:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:14:28 --> Input Class Initialized
INFO - 2017-10-11 15:14:28 --> Language Class Initialized
INFO - 2017-10-11 15:14:28 --> Loader Class Initialized
INFO - 2017-10-11 15:14:28 --> Helper loaded: url_helper
INFO - 2017-10-11 15:14:28 --> Helper loaded: common_helper
INFO - 2017-10-11 15:14:28 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:14:28 --> Email Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Controller Class Initialized
INFO - 2017-10-11 15:14:28 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> Model Class Initialized
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:14:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:14:28 --> Final output sent to browser
DEBUG - 2017-10-11 15:14:28 --> Total execution time: 0.1097
INFO - 2017-10-11 15:15:01 --> Config Class Initialized
INFO - 2017-10-11 15:15:01 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:15:01 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:15:01 --> Utf8 Class Initialized
INFO - 2017-10-11 15:15:01 --> URI Class Initialized
DEBUG - 2017-10-11 15:15:01 --> No URI present. Default controller set.
INFO - 2017-10-11 15:15:01 --> Router Class Initialized
INFO - 2017-10-11 15:15:01 --> Output Class Initialized
INFO - 2017-10-11 15:15:01 --> Security Class Initialized
DEBUG - 2017-10-11 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:15:01 --> Input Class Initialized
INFO - 2017-10-11 15:15:01 --> Language Class Initialized
INFO - 2017-10-11 15:15:01 --> Loader Class Initialized
INFO - 2017-10-11 15:15:01 --> Helper loaded: url_helper
INFO - 2017-10-11 15:15:01 --> Helper loaded: common_helper
INFO - 2017-10-11 15:15:01 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:15:01 --> Email Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Controller Class Initialized
INFO - 2017-10-11 15:15:01 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> Model Class Initialized
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:15:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:15:01 --> Final output sent to browser
DEBUG - 2017-10-11 15:15:01 --> Total execution time: 0.0205
INFO - 2017-10-11 15:15:05 --> Config Class Initialized
INFO - 2017-10-11 15:15:05 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:15:05 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:15:05 --> Utf8 Class Initialized
INFO - 2017-10-11 15:15:05 --> URI Class Initialized
INFO - 2017-10-11 15:15:05 --> Router Class Initialized
INFO - 2017-10-11 15:15:05 --> Output Class Initialized
INFO - 2017-10-11 15:15:05 --> Security Class Initialized
DEBUG - 2017-10-11 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:15:05 --> Input Class Initialized
INFO - 2017-10-11 15:15:05 --> Language Class Initialized
INFO - 2017-10-11 15:15:05 --> Loader Class Initialized
INFO - 2017-10-11 15:15:05 --> Helper loaded: url_helper
INFO - 2017-10-11 15:15:05 --> Helper loaded: common_helper
INFO - 2017-10-11 15:15:05 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:15:05 --> Email Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Controller Class Initialized
INFO - 2017-10-11 15:15:05 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Config Class Initialized
INFO - 2017-10-11 15:15:05 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:15:05 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:15:05 --> Utf8 Class Initialized
INFO - 2017-10-11 15:15:05 --> URI Class Initialized
INFO - 2017-10-11 15:15:05 --> Router Class Initialized
INFO - 2017-10-11 15:15:05 --> Output Class Initialized
INFO - 2017-10-11 15:15:05 --> Security Class Initialized
DEBUG - 2017-10-11 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:15:05 --> Input Class Initialized
INFO - 2017-10-11 15:15:05 --> Language Class Initialized
INFO - 2017-10-11 15:15:05 --> Loader Class Initialized
INFO - 2017-10-11 15:15:05 --> Helper loaded: url_helper
INFO - 2017-10-11 15:15:05 --> Helper loaded: common_helper
INFO - 2017-10-11 15:15:05 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:15:05 --> Email Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Controller Class Initialized
INFO - 2017-10-11 15:15:05 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> Model Class Initialized
INFO - 2017-10-11 15:15:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:15:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:15:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 15:15:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:15:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:15:05 --> Final output sent to browser
DEBUG - 2017-10-11 15:15:05 --> Total execution time: 0.0545
INFO - 2017-10-11 15:15:11 --> Config Class Initialized
INFO - 2017-10-11 15:15:11 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:15:11 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:15:11 --> Utf8 Class Initialized
INFO - 2017-10-11 15:15:11 --> URI Class Initialized
INFO - 2017-10-11 15:15:11 --> Router Class Initialized
INFO - 2017-10-11 15:15:11 --> Output Class Initialized
INFO - 2017-10-11 15:15:11 --> Security Class Initialized
DEBUG - 2017-10-11 15:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:15:11 --> Input Class Initialized
INFO - 2017-10-11 15:15:11 --> Language Class Initialized
INFO - 2017-10-11 15:15:11 --> Loader Class Initialized
INFO - 2017-10-11 15:15:11 --> Helper loaded: url_helper
INFO - 2017-10-11 15:15:11 --> Helper loaded: common_helper
INFO - 2017-10-11 15:15:11 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:15:11 --> Email Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Controller Class Initialized
INFO - 2017-10-11 15:15:11 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Config Class Initialized
INFO - 2017-10-11 15:15:11 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:15:11 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:15:11 --> Utf8 Class Initialized
INFO - 2017-10-11 15:15:11 --> URI Class Initialized
INFO - 2017-10-11 15:15:11 --> Router Class Initialized
INFO - 2017-10-11 15:15:11 --> Output Class Initialized
INFO - 2017-10-11 15:15:11 --> Security Class Initialized
DEBUG - 2017-10-11 15:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:15:11 --> Input Class Initialized
INFO - 2017-10-11 15:15:11 --> Language Class Initialized
INFO - 2017-10-11 15:15:11 --> Loader Class Initialized
INFO - 2017-10-11 15:15:11 --> Helper loaded: url_helper
INFO - 2017-10-11 15:15:11 --> Helper loaded: common_helper
INFO - 2017-10-11 15:15:11 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:15:11 --> Email Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Controller Class Initialized
INFO - 2017-10-11 15:15:11 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> Model Class Initialized
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:15:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:15:11 --> Final output sent to browser
DEBUG - 2017-10-11 15:15:11 --> Total execution time: 0.0283
INFO - 2017-10-11 15:33:44 --> Config Class Initialized
INFO - 2017-10-11 15:33:44 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:33:44 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:33:44 --> Utf8 Class Initialized
INFO - 2017-10-11 15:33:44 --> URI Class Initialized
DEBUG - 2017-10-11 15:33:44 --> No URI present. Default controller set.
INFO - 2017-10-11 15:33:44 --> Router Class Initialized
INFO - 2017-10-11 15:33:44 --> Output Class Initialized
INFO - 2017-10-11 15:33:44 --> Security Class Initialized
DEBUG - 2017-10-11 15:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:33:44 --> Input Class Initialized
INFO - 2017-10-11 15:33:44 --> Language Class Initialized
INFO - 2017-10-11 15:33:44 --> Loader Class Initialized
INFO - 2017-10-11 15:33:44 --> Helper loaded: url_helper
INFO - 2017-10-11 15:33:44 --> Helper loaded: common_helper
INFO - 2017-10-11 15:33:44 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:33:44 --> Email Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Controller Class Initialized
INFO - 2017-10-11 15:33:44 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> Model Class Initialized
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:33:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:33:44 --> Final output sent to browser
DEBUG - 2017-10-11 15:33:44 --> Total execution time: 0.1320
INFO - 2017-10-11 15:37:44 --> Config Class Initialized
INFO - 2017-10-11 15:37:44 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:37:44 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:37:44 --> Utf8 Class Initialized
INFO - 2017-10-11 15:37:44 --> URI Class Initialized
DEBUG - 2017-10-11 15:37:44 --> No URI present. Default controller set.
INFO - 2017-10-11 15:37:44 --> Router Class Initialized
INFO - 2017-10-11 15:37:44 --> Output Class Initialized
INFO - 2017-10-11 15:37:44 --> Security Class Initialized
DEBUG - 2017-10-11 15:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:37:44 --> Input Class Initialized
INFO - 2017-10-11 15:37:44 --> Language Class Initialized
INFO - 2017-10-11 15:37:44 --> Loader Class Initialized
INFO - 2017-10-11 15:37:44 --> Helper loaded: url_helper
INFO - 2017-10-11 15:37:44 --> Helper loaded: common_helper
INFO - 2017-10-11 15:37:44 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:37:44 --> Email Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Controller Class Initialized
INFO - 2017-10-11 15:37:44 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> Model Class Initialized
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:37:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:37:44 --> Final output sent to browser
DEBUG - 2017-10-11 15:37:44 --> Total execution time: 0.0607
INFO - 2017-10-11 15:42:22 --> Config Class Initialized
INFO - 2017-10-11 15:42:22 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:42:22 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:42:22 --> Utf8 Class Initialized
INFO - 2017-10-11 15:42:22 --> URI Class Initialized
INFO - 2017-10-11 15:42:22 --> Router Class Initialized
INFO - 2017-10-11 15:42:22 --> Output Class Initialized
INFO - 2017-10-11 15:42:22 --> Security Class Initialized
DEBUG - 2017-10-11 15:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:42:22 --> Input Class Initialized
INFO - 2017-10-11 15:42:22 --> Language Class Initialized
INFO - 2017-10-11 15:42:22 --> Loader Class Initialized
INFO - 2017-10-11 15:42:22 --> Helper loaded: url_helper
INFO - 2017-10-11 15:42:22 --> Helper loaded: common_helper
INFO - 2017-10-11 15:42:22 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:42:22 --> Email Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Controller Class Initialized
INFO - 2017-10-11 15:42:22 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> Model Class Initialized
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:42:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:42:22 --> Final output sent to browser
DEBUG - 2017-10-11 15:42:22 --> Total execution time: 0.1601
INFO - 2017-10-11 15:43:26 --> Config Class Initialized
INFO - 2017-10-11 15:43:26 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:43:26 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:43:26 --> Utf8 Class Initialized
INFO - 2017-10-11 15:43:26 --> URI Class Initialized
INFO - 2017-10-11 15:43:26 --> Router Class Initialized
INFO - 2017-10-11 15:43:26 --> Output Class Initialized
INFO - 2017-10-11 15:43:26 --> Security Class Initialized
DEBUG - 2017-10-11 15:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:43:26 --> Input Class Initialized
INFO - 2017-10-11 15:43:26 --> Language Class Initialized
INFO - 2017-10-11 15:43:26 --> Loader Class Initialized
INFO - 2017-10-11 15:43:26 --> Helper loaded: url_helper
INFO - 2017-10-11 15:43:26 --> Helper loaded: common_helper
INFO - 2017-10-11 15:43:26 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:43:26 --> Email Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Controller Class Initialized
INFO - 2017-10-11 15:43:26 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> Model Class Initialized
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:43:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:43:26 --> Final output sent to browser
DEBUG - 2017-10-11 15:43:26 --> Total execution time: 0.0309
INFO - 2017-10-11 15:44:28 --> Config Class Initialized
INFO - 2017-10-11 15:44:28 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:44:28 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:44:28 --> Utf8 Class Initialized
INFO - 2017-10-11 15:44:28 --> URI Class Initialized
INFO - 2017-10-11 15:44:28 --> Router Class Initialized
INFO - 2017-10-11 15:44:28 --> Output Class Initialized
INFO - 2017-10-11 15:44:28 --> Security Class Initialized
DEBUG - 2017-10-11 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:44:28 --> Input Class Initialized
INFO - 2017-10-11 15:44:28 --> Language Class Initialized
INFO - 2017-10-11 15:44:28 --> Loader Class Initialized
INFO - 2017-10-11 15:44:28 --> Helper loaded: url_helper
INFO - 2017-10-11 15:44:28 --> Helper loaded: common_helper
INFO - 2017-10-11 15:44:28 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:44:28 --> Email Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Controller Class Initialized
INFO - 2017-10-11 15:44:28 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:28 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Config Class Initialized
INFO - 2017-10-11 15:44:29 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:44:29 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:44:29 --> Utf8 Class Initialized
INFO - 2017-10-11 15:44:29 --> URI Class Initialized
INFO - 2017-10-11 15:44:29 --> Router Class Initialized
INFO - 2017-10-11 15:44:29 --> Output Class Initialized
INFO - 2017-10-11 15:44:29 --> Security Class Initialized
DEBUG - 2017-10-11 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:44:29 --> Input Class Initialized
INFO - 2017-10-11 15:44:29 --> Language Class Initialized
INFO - 2017-10-11 15:44:29 --> Loader Class Initialized
INFO - 2017-10-11 15:44:29 --> Helper loaded: url_helper
INFO - 2017-10-11 15:44:29 --> Helper loaded: common_helper
INFO - 2017-10-11 15:44:29 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:44:29 --> Email Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Controller Class Initialized
INFO - 2017-10-11 15:44:29 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> Model Class Initialized
INFO - 2017-10-11 15:44:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:44:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:44:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 15:44:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:44:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:44:29 --> Final output sent to browser
DEBUG - 2017-10-11 15:44:29 --> Total execution time: 0.0165
INFO - 2017-10-11 15:44:48 --> Config Class Initialized
INFO - 2017-10-11 15:44:48 --> Hooks Class Initialized
DEBUG - 2017-10-11 15:44:48 --> UTF-8 Support Enabled
INFO - 2017-10-11 15:44:48 --> Utf8 Class Initialized
INFO - 2017-10-11 15:44:48 --> URI Class Initialized
INFO - 2017-10-11 15:44:48 --> Router Class Initialized
INFO - 2017-10-11 15:44:48 --> Output Class Initialized
INFO - 2017-10-11 15:44:48 --> Security Class Initialized
DEBUG - 2017-10-11 15:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 15:44:48 --> Input Class Initialized
INFO - 2017-10-11 15:44:48 --> Language Class Initialized
INFO - 2017-10-11 15:44:48 --> Loader Class Initialized
INFO - 2017-10-11 15:44:48 --> Helper loaded: url_helper
INFO - 2017-10-11 15:44:48 --> Helper loaded: common_helper
INFO - 2017-10-11 15:44:48 --> Database Driver Class Initialized
DEBUG - 2017-10-11 15:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 15:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 15:44:48 --> Email Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Controller Class Initialized
INFO - 2017-10-11 15:44:48 --> Helper loaded: cookie_helper
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> Model Class Initialized
INFO - 2017-10-11 15:44:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 15:44:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 15:44:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 15:44:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 15:44:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 15:44:48 --> Final output sent to browser
DEBUG - 2017-10-11 15:44:48 --> Total execution time: 0.0199
INFO - 2017-10-11 16:05:02 --> Config Class Initialized
INFO - 2017-10-11 16:05:02 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:05:02 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:05:02 --> Utf8 Class Initialized
INFO - 2017-10-11 16:05:02 --> URI Class Initialized
INFO - 2017-10-11 16:05:02 --> Router Class Initialized
INFO - 2017-10-11 16:05:02 --> Output Class Initialized
INFO - 2017-10-11 16:05:02 --> Security Class Initialized
DEBUG - 2017-10-11 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:05:02 --> Input Class Initialized
INFO - 2017-10-11 16:05:02 --> Language Class Initialized
INFO - 2017-10-11 16:05:02 --> Loader Class Initialized
INFO - 2017-10-11 16:05:02 --> Helper loaded: url_helper
INFO - 2017-10-11 16:05:02 --> Helper loaded: common_helper
INFO - 2017-10-11 16:05:02 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:05:02 --> Email Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Controller Class Initialized
INFO - 2017-10-11 16:05:02 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Config Class Initialized
INFO - 2017-10-11 16:05:02 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:05:02 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:05:02 --> Utf8 Class Initialized
INFO - 2017-10-11 16:05:02 --> URI Class Initialized
INFO - 2017-10-11 16:05:02 --> Router Class Initialized
INFO - 2017-10-11 16:05:02 --> Output Class Initialized
INFO - 2017-10-11 16:05:02 --> Security Class Initialized
DEBUG - 2017-10-11 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:05:02 --> Input Class Initialized
INFO - 2017-10-11 16:05:02 --> Language Class Initialized
INFO - 2017-10-11 16:05:02 --> Loader Class Initialized
INFO - 2017-10-11 16:05:02 --> Helper loaded: url_helper
INFO - 2017-10-11 16:05:02 --> Helper loaded: common_helper
INFO - 2017-10-11 16:05:02 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:05:02 --> Email Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Controller Class Initialized
INFO - 2017-10-11 16:05:02 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> Model Class Initialized
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 16:05:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 16:05:02 --> Final output sent to browser
DEBUG - 2017-10-11 16:05:02 --> Total execution time: 0.1255
INFO - 2017-10-11 16:05:02 --> Config Class Initialized
INFO - 2017-10-11 16:05:02 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:05:02 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:05:02 --> Utf8 Class Initialized
INFO - 2017-10-11 16:05:02 --> URI Class Initialized
INFO - 2017-10-11 16:05:02 --> Router Class Initialized
INFO - 2017-10-11 16:05:02 --> Output Class Initialized
INFO - 2017-10-11 16:05:02 --> Security Class Initialized
DEBUG - 2017-10-11 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:05:02 --> Input Class Initialized
INFO - 2017-10-11 16:05:02 --> Language Class Initialized
ERROR - 2017-10-11 16:05:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-11 16:05:19 --> Config Class Initialized
INFO - 2017-10-11 16:05:19 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:05:19 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:05:19 --> Utf8 Class Initialized
INFO - 2017-10-11 16:05:19 --> URI Class Initialized
INFO - 2017-10-11 16:05:19 --> Router Class Initialized
INFO - 2017-10-11 16:05:19 --> Output Class Initialized
INFO - 2017-10-11 16:05:19 --> Security Class Initialized
DEBUG - 2017-10-11 16:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:05:19 --> Input Class Initialized
INFO - 2017-10-11 16:05:19 --> Language Class Initialized
INFO - 2017-10-11 16:05:19 --> Loader Class Initialized
INFO - 2017-10-11 16:05:19 --> Helper loaded: url_helper
INFO - 2017-10-11 16:05:19 --> Helper loaded: common_helper
INFO - 2017-10-11 16:05:19 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:05:19 --> Email Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Controller Class Initialized
INFO - 2017-10-11 16:05:19 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:19 --> Model Class Initialized
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 16:05:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 16:05:20 --> Final output sent to browser
DEBUG - 2017-10-11 16:05:20 --> Total execution time: 0.1140
INFO - 2017-10-11 16:05:20 --> Config Class Initialized
INFO - 2017-10-11 16:05:20 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:05:20 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:05:20 --> Utf8 Class Initialized
INFO - 2017-10-11 16:05:20 --> URI Class Initialized
INFO - 2017-10-11 16:05:20 --> Router Class Initialized
INFO - 2017-10-11 16:05:20 --> Output Class Initialized
INFO - 2017-10-11 16:05:20 --> Security Class Initialized
DEBUG - 2017-10-11 16:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:05:20 --> Input Class Initialized
INFO - 2017-10-11 16:05:20 --> Language Class Initialized
ERROR - 2017-10-11 16:05:20 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-11 16:07:51 --> Config Class Initialized
INFO - 2017-10-11 16:07:51 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:07:51 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:07:51 --> Utf8 Class Initialized
INFO - 2017-10-11 16:07:51 --> URI Class Initialized
INFO - 2017-10-11 16:07:51 --> Router Class Initialized
INFO - 2017-10-11 16:07:51 --> Output Class Initialized
INFO - 2017-10-11 16:07:51 --> Security Class Initialized
DEBUG - 2017-10-11 16:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:07:51 --> Input Class Initialized
INFO - 2017-10-11 16:07:51 --> Language Class Initialized
INFO - 2017-10-11 16:07:51 --> Loader Class Initialized
INFO - 2017-10-11 16:07:51 --> Helper loaded: url_helper
INFO - 2017-10-11 16:07:51 --> Helper loaded: common_helper
INFO - 2017-10-11 16:07:51 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:07:51 --> Email Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Controller Class Initialized
INFO - 2017-10-11 16:07:51 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:51 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Config Class Initialized
INFO - 2017-10-11 16:07:52 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:07:52 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:07:52 --> Utf8 Class Initialized
INFO - 2017-10-11 16:07:52 --> URI Class Initialized
INFO - 2017-10-11 16:07:52 --> Router Class Initialized
INFO - 2017-10-11 16:07:52 --> Output Class Initialized
INFO - 2017-10-11 16:07:52 --> Security Class Initialized
DEBUG - 2017-10-11 16:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:07:52 --> Input Class Initialized
INFO - 2017-10-11 16:07:52 --> Language Class Initialized
INFO - 2017-10-11 16:07:52 --> Loader Class Initialized
INFO - 2017-10-11 16:07:52 --> Helper loaded: url_helper
INFO - 2017-10-11 16:07:52 --> Helper loaded: common_helper
INFO - 2017-10-11 16:07:52 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:07:52 --> Email Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Controller Class Initialized
INFO - 2017-10-11 16:07:52 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> Model Class Initialized
INFO - 2017-10-11 16:07:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 16:07:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 16:07:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 16:07:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 16:07:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 16:07:52 --> Final output sent to browser
DEBUG - 2017-10-11 16:07:52 --> Total execution time: 0.0276
INFO - 2017-10-11 16:07:57 --> Config Class Initialized
INFO - 2017-10-11 16:07:57 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:07:57 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:07:57 --> Utf8 Class Initialized
INFO - 2017-10-11 16:07:57 --> URI Class Initialized
INFO - 2017-10-11 16:07:57 --> Router Class Initialized
INFO - 2017-10-11 16:07:57 --> Output Class Initialized
INFO - 2017-10-11 16:07:57 --> Security Class Initialized
DEBUG - 2017-10-11 16:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:07:57 --> Input Class Initialized
INFO - 2017-10-11 16:07:57 --> Language Class Initialized
INFO - 2017-10-11 16:07:57 --> Loader Class Initialized
INFO - 2017-10-11 16:07:57 --> Helper loaded: url_helper
INFO - 2017-10-11 16:07:57 --> Helper loaded: common_helper
INFO - 2017-10-11 16:07:57 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:07:57 --> Email Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Controller Class Initialized
INFO - 2017-10-11 16:07:57 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Config Class Initialized
INFO - 2017-10-11 16:07:57 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:07:57 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:07:57 --> Utf8 Class Initialized
INFO - 2017-10-11 16:07:57 --> URI Class Initialized
INFO - 2017-10-11 16:07:57 --> Router Class Initialized
INFO - 2017-10-11 16:07:57 --> Output Class Initialized
INFO - 2017-10-11 16:07:57 --> Security Class Initialized
DEBUG - 2017-10-11 16:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 16:07:57 --> Input Class Initialized
INFO - 2017-10-11 16:07:57 --> Language Class Initialized
INFO - 2017-10-11 16:07:57 --> Loader Class Initialized
INFO - 2017-10-11 16:07:57 --> Helper loaded: url_helper
INFO - 2017-10-11 16:07:57 --> Helper loaded: common_helper
INFO - 2017-10-11 16:07:57 --> Database Driver Class Initialized
DEBUG - 2017-10-11 16:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 16:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 16:07:57 --> Email Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Controller Class Initialized
INFO - 2017-10-11 16:07:57 --> Helper loaded: cookie_helper
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
INFO - 2017-10-11 16:07:57 --> Model Class Initialized
ERROR - 2017-10-11 16:07:57 --> Severity: Notice --> Undefined variable: logo /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php 22
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 16:07:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 16:07:57 --> Final output sent to browser
DEBUG - 2017-10-11 16:07:57 --> Total execution time: 0.0704
INFO - 2017-10-11 16:07:57 --> Config Class Initialized
INFO - 2017-10-11 16:07:57 --> Hooks Class Initialized
DEBUG - 2017-10-11 16:07:57 --> UTF-8 Support Enabled
INFO - 2017-10-11 16:07:57 --> Utf8 Class Initialized
INFO - 2017-10-11 17:06:59 --> Config Class Initialized
INFO - 2017-10-11 17:06:59 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:06:59 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:06:59 --> Utf8 Class Initialized
INFO - 2017-10-11 17:06:59 --> URI Class Initialized
INFO - 2017-10-11 17:06:59 --> Router Class Initialized
INFO - 2017-10-11 17:06:59 --> Output Class Initialized
INFO - 2017-10-11 17:06:59 --> Security Class Initialized
DEBUG - 2017-10-11 17:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:06:59 --> Input Class Initialized
INFO - 2017-10-11 17:06:59 --> Language Class Initialized
INFO - 2017-10-11 17:06:59 --> Loader Class Initialized
INFO - 2017-10-11 17:06:59 --> Helper loaded: url_helper
INFO - 2017-10-11 17:06:59 --> Helper loaded: common_helper
INFO - 2017-10-11 17:06:59 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:06:59 --> Email Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Controller Class Initialized
INFO - 2017-10-11 17:06:59 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Config Class Initialized
INFO - 2017-10-11 17:06:59 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:06:59 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:06:59 --> Utf8 Class Initialized
INFO - 2017-10-11 17:06:59 --> URI Class Initialized
INFO - 2017-10-11 17:06:59 --> Router Class Initialized
INFO - 2017-10-11 17:06:59 --> Output Class Initialized
INFO - 2017-10-11 17:06:59 --> Security Class Initialized
DEBUG - 2017-10-11 17:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:06:59 --> Input Class Initialized
INFO - 2017-10-11 17:06:59 --> Language Class Initialized
INFO - 2017-10-11 17:06:59 --> Loader Class Initialized
INFO - 2017-10-11 17:06:59 --> Helper loaded: url_helper
INFO - 2017-10-11 17:06:59 --> Helper loaded: common_helper
INFO - 2017-10-11 17:06:59 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:06:59 --> Email Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Controller Class Initialized
INFO - 2017-10-11 17:06:59 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> Model Class Initialized
INFO - 2017-10-11 17:06:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:06:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:06:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 17:06:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:06:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:06:59 --> Final output sent to browser
DEBUG - 2017-10-11 17:06:59 --> Total execution time: 0.0164
INFO - 2017-10-11 17:07:08 --> Config Class Initialized
INFO - 2017-10-11 17:07:08 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:07:08 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:07:08 --> Utf8 Class Initialized
INFO - 2017-10-11 17:07:08 --> URI Class Initialized
INFO - 2017-10-11 17:07:08 --> Router Class Initialized
INFO - 2017-10-11 17:07:08 --> Output Class Initialized
INFO - 2017-10-11 17:07:08 --> Security Class Initialized
DEBUG - 2017-10-11 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:07:08 --> Input Class Initialized
INFO - 2017-10-11 17:07:08 --> Language Class Initialized
INFO - 2017-10-11 17:07:08 --> Loader Class Initialized
INFO - 2017-10-11 17:07:08 --> Helper loaded: url_helper
INFO - 2017-10-11 17:07:08 --> Helper loaded: common_helper
INFO - 2017-10-11 17:07:08 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:07:08 --> Email Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Controller Class Initialized
INFO - 2017-10-11 17:07:08 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Config Class Initialized
INFO - 2017-10-11 17:07:08 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:07:08 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:07:08 --> Utf8 Class Initialized
INFO - 2017-10-11 17:07:08 --> URI Class Initialized
INFO - 2017-10-11 17:07:08 --> Router Class Initialized
INFO - 2017-10-11 17:07:08 --> Output Class Initialized
INFO - 2017-10-11 17:07:08 --> Security Class Initialized
DEBUG - 2017-10-11 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:07:08 --> Input Class Initialized
INFO - 2017-10-11 17:07:08 --> Language Class Initialized
INFO - 2017-10-11 17:07:08 --> Loader Class Initialized
INFO - 2017-10-11 17:07:08 --> Helper loaded: url_helper
INFO - 2017-10-11 17:07:08 --> Helper loaded: common_helper
INFO - 2017-10-11 17:07:08 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:07:08 --> Email Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Controller Class Initialized
INFO - 2017-10-11 17:07:08 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> Model Class Initialized
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:07:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:07:08 --> Final output sent to browser
DEBUG - 2017-10-11 17:07:08 --> Total execution time: 0.0279
INFO - 2017-10-11 17:07:21 --> Config Class Initialized
INFO - 2017-10-11 17:07:21 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:07:21 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:07:21 --> Utf8 Class Initialized
INFO - 2017-10-11 17:07:21 --> URI Class Initialized
INFO - 2017-10-11 17:07:21 --> Router Class Initialized
INFO - 2017-10-11 17:07:21 --> Output Class Initialized
INFO - 2017-10-11 17:07:21 --> Security Class Initialized
DEBUG - 2017-10-11 17:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:07:21 --> Input Class Initialized
INFO - 2017-10-11 17:07:21 --> Language Class Initialized
INFO - 2017-10-11 17:07:21 --> Loader Class Initialized
INFO - 2017-10-11 17:07:21 --> Helper loaded: url_helper
INFO - 2017-10-11 17:07:21 --> Helper loaded: common_helper
INFO - 2017-10-11 17:07:21 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:07:21 --> Email Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Controller Class Initialized
INFO - 2017-10-11 17:07:21 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> Model Class Initialized
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:07:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:07:21 --> Final output sent to browser
DEBUG - 2017-10-11 17:07:21 --> Total execution time: 0.0297
INFO - 2017-10-11 17:10:09 --> Config Class Initialized
INFO - 2017-10-11 17:10:09 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:10:09 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:10:09 --> Utf8 Class Initialized
INFO - 2017-10-11 17:10:09 --> URI Class Initialized
INFO - 2017-10-11 17:10:09 --> Router Class Initialized
INFO - 2017-10-11 17:10:09 --> Output Class Initialized
INFO - 2017-10-11 17:10:09 --> Security Class Initialized
DEBUG - 2017-10-11 17:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:10:09 --> Input Class Initialized
INFO - 2017-10-11 17:10:09 --> Language Class Initialized
INFO - 2017-10-11 17:10:09 --> Loader Class Initialized
INFO - 2017-10-11 17:10:09 --> Helper loaded: url_helper
INFO - 2017-10-11 17:10:09 --> Helper loaded: common_helper
INFO - 2017-10-11 17:10:09 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:10:09 --> Email Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Controller Class Initialized
INFO - 2017-10-11 17:10:09 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> Model Class Initialized
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:10:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:10:09 --> Final output sent to browser
DEBUG - 2017-10-11 17:10:09 --> Total execution time: 0.0290
INFO - 2017-10-11 17:22:42 --> Config Class Initialized
INFO - 2017-10-11 17:22:42 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:22:42 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:22:42 --> Utf8 Class Initialized
INFO - 2017-10-11 17:22:42 --> URI Class Initialized
INFO - 2017-10-11 17:22:42 --> Router Class Initialized
INFO - 2017-10-11 17:22:42 --> Output Class Initialized
INFO - 2017-10-11 17:22:42 --> Security Class Initialized
DEBUG - 2017-10-11 17:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:22:42 --> Input Class Initialized
INFO - 2017-10-11 17:22:42 --> Language Class Initialized
INFO - 2017-10-11 17:22:42 --> Loader Class Initialized
INFO - 2017-10-11 17:22:42 --> Helper loaded: url_helper
INFO - 2017-10-11 17:22:42 --> Helper loaded: common_helper
INFO - 2017-10-11 17:22:42 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:22:42 --> Email Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Controller Class Initialized
INFO - 2017-10-11 17:22:42 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> Model Class Initialized
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:22:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:22:42 --> Final output sent to browser
DEBUG - 2017-10-11 17:22:42 --> Total execution time: 0.0311
INFO - 2017-10-11 17:22:48 --> Config Class Initialized
INFO - 2017-10-11 17:22:48 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:22:48 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:22:48 --> Utf8 Class Initialized
INFO - 2017-10-11 17:22:48 --> URI Class Initialized
INFO - 2017-10-11 17:22:48 --> Router Class Initialized
INFO - 2017-10-11 17:22:48 --> Output Class Initialized
INFO - 2017-10-11 17:22:48 --> Security Class Initialized
DEBUG - 2017-10-11 17:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:22:48 --> Input Class Initialized
INFO - 2017-10-11 17:22:48 --> Language Class Initialized
INFO - 2017-10-11 17:22:48 --> Loader Class Initialized
INFO - 2017-10-11 17:22:48 --> Helper loaded: url_helper
INFO - 2017-10-11 17:22:48 --> Helper loaded: common_helper
INFO - 2017-10-11 17:22:48 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:22:48 --> Email Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Controller Class Initialized
INFO - 2017-10-11 17:22:48 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> Model Class Initialized
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:22:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:22:48 --> Final output sent to browser
DEBUG - 2017-10-11 17:22:48 --> Total execution time: 0.0314
INFO - 2017-10-11 17:23:19 --> Config Class Initialized
INFO - 2017-10-11 17:23:19 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:23:19 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:23:19 --> Utf8 Class Initialized
INFO - 2017-10-11 17:23:19 --> URI Class Initialized
INFO - 2017-10-11 17:23:19 --> Router Class Initialized
INFO - 2017-10-11 17:23:19 --> Output Class Initialized
INFO - 2017-10-11 17:23:19 --> Security Class Initialized
DEBUG - 2017-10-11 17:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:23:19 --> Input Class Initialized
INFO - 2017-10-11 17:23:19 --> Language Class Initialized
INFO - 2017-10-11 17:23:19 --> Loader Class Initialized
INFO - 2017-10-11 17:23:19 --> Helper loaded: url_helper
INFO - 2017-10-11 17:23:19 --> Helper loaded: common_helper
INFO - 2017-10-11 17:23:19 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:23:19 --> Email Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Controller Class Initialized
INFO - 2017-10-11 17:23:19 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> Model Class Initialized
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:23:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:23:19 --> Final output sent to browser
DEBUG - 2017-10-11 17:23:19 --> Total execution time: 0.1911
INFO - 2017-10-11 17:25:17 --> Config Class Initialized
INFO - 2017-10-11 17:25:17 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:25:17 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:25:17 --> Utf8 Class Initialized
INFO - 2017-10-11 17:25:17 --> URI Class Initialized
INFO - 2017-10-11 17:25:17 --> Router Class Initialized
INFO - 2017-10-11 17:25:17 --> Output Class Initialized
INFO - 2017-10-11 17:25:17 --> Security Class Initialized
DEBUG - 2017-10-11 17:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:25:17 --> Input Class Initialized
INFO - 2017-10-11 17:25:17 --> Language Class Initialized
INFO - 2017-10-11 17:25:17 --> Loader Class Initialized
INFO - 2017-10-11 17:25:17 --> Helper loaded: url_helper
INFO - 2017-10-11 17:25:17 --> Helper loaded: common_helper
INFO - 2017-10-11 17:25:17 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:25:17 --> Email Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Controller Class Initialized
INFO - 2017-10-11 17:25:17 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> Model Class Initialized
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:25:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:25:17 --> Final output sent to browser
DEBUG - 2017-10-11 17:25:17 --> Total execution time: 0.0436
INFO - 2017-10-11 17:26:58 --> Config Class Initialized
INFO - 2017-10-11 17:26:58 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:26:58 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:26:58 --> Utf8 Class Initialized
INFO - 2017-10-11 17:26:58 --> URI Class Initialized
INFO - 2017-10-11 17:26:58 --> Router Class Initialized
INFO - 2017-10-11 17:26:58 --> Output Class Initialized
INFO - 2017-10-11 17:26:58 --> Security Class Initialized
DEBUG - 2017-10-11 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:26:58 --> Input Class Initialized
INFO - 2017-10-11 17:26:58 --> Language Class Initialized
INFO - 2017-10-11 17:26:58 --> Loader Class Initialized
INFO - 2017-10-11 17:26:58 --> Helper loaded: url_helper
INFO - 2017-10-11 17:26:58 --> Helper loaded: common_helper
INFO - 2017-10-11 17:26:58 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:26:58 --> Email Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Controller Class Initialized
INFO - 2017-10-11 17:26:58 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> Model Class Initialized
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:26:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:26:58 --> Final output sent to browser
DEBUG - 2017-10-11 17:26:58 --> Total execution time: 0.1515
INFO - 2017-10-11 17:27:43 --> Config Class Initialized
INFO - 2017-10-11 17:27:43 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:27:43 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:27:43 --> Utf8 Class Initialized
INFO - 2017-10-11 17:27:43 --> URI Class Initialized
INFO - 2017-10-11 17:27:43 --> Router Class Initialized
INFO - 2017-10-11 17:27:43 --> Output Class Initialized
INFO - 2017-10-11 17:27:43 --> Security Class Initialized
DEBUG - 2017-10-11 17:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:27:43 --> Input Class Initialized
INFO - 2017-10-11 17:27:43 --> Language Class Initialized
INFO - 2017-10-11 17:27:43 --> Loader Class Initialized
INFO - 2017-10-11 17:27:43 --> Helper loaded: url_helper
INFO - 2017-10-11 17:27:43 --> Helper loaded: common_helper
INFO - 2017-10-11 17:27:43 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:27:43 --> Email Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Controller Class Initialized
INFO - 2017-10-11 17:27:43 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> Model Class Initialized
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:27:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:27:43 --> Final output sent to browser
DEBUG - 2017-10-11 17:27:43 --> Total execution time: 0.0532
INFO - 2017-10-11 17:27:58 --> Config Class Initialized
INFO - 2017-10-11 17:27:58 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:27:58 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:27:58 --> Utf8 Class Initialized
INFO - 2017-10-11 17:27:58 --> URI Class Initialized
INFO - 2017-10-11 17:27:58 --> Router Class Initialized
INFO - 2017-10-11 17:27:58 --> Output Class Initialized
INFO - 2017-10-11 17:27:58 --> Security Class Initialized
DEBUG - 2017-10-11 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:27:58 --> Input Class Initialized
INFO - 2017-10-11 17:27:58 --> Language Class Initialized
INFO - 2017-10-11 17:27:58 --> Loader Class Initialized
INFO - 2017-10-11 17:27:58 --> Helper loaded: url_helper
INFO - 2017-10-11 17:27:58 --> Helper loaded: common_helper
INFO - 2017-10-11 17:27:58 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:27:58 --> Email Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Controller Class Initialized
INFO - 2017-10-11 17:27:58 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> Model Class Initialized
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:27:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:27:58 --> Final output sent to browser
DEBUG - 2017-10-11 17:27:58 --> Total execution time: 0.1591
INFO - 2017-10-11 17:28:11 --> Config Class Initialized
INFO - 2017-10-11 17:28:11 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:11 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:11 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:11 --> URI Class Initialized
INFO - 2017-10-11 17:28:11 --> Router Class Initialized
INFO - 2017-10-11 17:28:11 --> Output Class Initialized
INFO - 2017-10-11 17:28:11 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:11 --> Input Class Initialized
INFO - 2017-10-11 17:28:11 --> Language Class Initialized
INFO - 2017-10-11 17:28:11 --> Loader Class Initialized
INFO - 2017-10-11 17:28:11 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:11 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:11 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:11 --> Email Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Controller Class Initialized
INFO - 2017-10-11 17:28:11 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Config Class Initialized
INFO - 2017-10-11 17:28:11 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:11 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:11 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:11 --> URI Class Initialized
INFO - 2017-10-11 17:28:11 --> Router Class Initialized
INFO - 2017-10-11 17:28:11 --> Output Class Initialized
INFO - 2017-10-11 17:28:11 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:11 --> Input Class Initialized
INFO - 2017-10-11 17:28:11 --> Language Class Initialized
INFO - 2017-10-11 17:28:11 --> Loader Class Initialized
INFO - 2017-10-11 17:28:11 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:11 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:11 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:11 --> Email Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Controller Class Initialized
INFO - 2017-10-11 17:28:11 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> Model Class Initialized
INFO - 2017-10-11 17:28:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:28:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:28:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 17:28:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:28:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:28:11 --> Final output sent to browser
DEBUG - 2017-10-11 17:28:11 --> Total execution time: 0.0895
INFO - 2017-10-11 17:28:16 --> Config Class Initialized
INFO - 2017-10-11 17:28:16 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:16 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:16 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:16 --> URI Class Initialized
INFO - 2017-10-11 17:28:16 --> Router Class Initialized
INFO - 2017-10-11 17:28:16 --> Output Class Initialized
INFO - 2017-10-11 17:28:16 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:16 --> Input Class Initialized
INFO - 2017-10-11 17:28:16 --> Language Class Initialized
INFO - 2017-10-11 17:28:16 --> Loader Class Initialized
INFO - 2017-10-11 17:28:16 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:16 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:16 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:16 --> Email Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Controller Class Initialized
INFO - 2017-10-11 17:28:16 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Config Class Initialized
INFO - 2017-10-11 17:28:16 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:16 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:16 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:16 --> URI Class Initialized
INFO - 2017-10-11 17:28:16 --> Router Class Initialized
INFO - 2017-10-11 17:28:16 --> Output Class Initialized
INFO - 2017-10-11 17:28:16 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:16 --> Input Class Initialized
INFO - 2017-10-11 17:28:16 --> Language Class Initialized
INFO - 2017-10-11 17:28:16 --> Loader Class Initialized
INFO - 2017-10-11 17:28:16 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:16 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:16 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:16 --> Email Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Controller Class Initialized
INFO - 2017-10-11 17:28:16 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> Model Class Initialized
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:28:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:28:16 --> Final output sent to browser
DEBUG - 2017-10-11 17:28:16 --> Total execution time: 0.1264
INFO - 2017-10-11 17:28:17 --> Config Class Initialized
INFO - 2017-10-11 17:28:17 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:17 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:17 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:17 --> URI Class Initialized
INFO - 2017-10-11 17:28:17 --> Router Class Initialized
INFO - 2017-10-11 17:28:17 --> Output Class Initialized
INFO - 2017-10-11 17:28:17 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:17 --> Input Class Initialized
INFO - 2017-10-11 17:28:17 --> Language Class Initialized
ERROR - 2017-10-11 17:28:17 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-11 17:28:17 --> Config Class Initialized
INFO - 2017-10-11 17:28:17 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:17 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:17 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:17 --> URI Class Initialized
INFO - 2017-10-11 17:28:17 --> Router Class Initialized
INFO - 2017-10-11 17:28:17 --> Output Class Initialized
INFO - 2017-10-11 17:28:17 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:17 --> Input Class Initialized
INFO - 2017-10-11 17:28:17 --> Language Class Initialized
ERROR - 2017-10-11 17:28:17 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-11 17:28:25 --> Config Class Initialized
INFO - 2017-10-11 17:28:25 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:25 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:25 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:25 --> URI Class Initialized
INFO - 2017-10-11 17:28:25 --> Router Class Initialized
INFO - 2017-10-11 17:28:25 --> Output Class Initialized
INFO - 2017-10-11 17:28:25 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:25 --> Input Class Initialized
INFO - 2017-10-11 17:28:25 --> Language Class Initialized
INFO - 2017-10-11 17:28:25 --> Loader Class Initialized
INFO - 2017-10-11 17:28:25 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:25 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:25 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:25 --> Email Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Controller Class Initialized
INFO - 2017-10-11 17:28:25 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> Model Class Initialized
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:28:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:28:25 --> Final output sent to browser
DEBUG - 2017-10-11 17:28:25 --> Total execution time: 0.1212
INFO - 2017-10-11 17:28:55 --> Config Class Initialized
INFO - 2017-10-11 17:28:55 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:28:55 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:28:55 --> Utf8 Class Initialized
INFO - 2017-10-11 17:28:55 --> URI Class Initialized
INFO - 2017-10-11 17:28:55 --> Router Class Initialized
INFO - 2017-10-11 17:28:55 --> Output Class Initialized
INFO - 2017-10-11 17:28:55 --> Security Class Initialized
DEBUG - 2017-10-11 17:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:28:55 --> Input Class Initialized
INFO - 2017-10-11 17:28:55 --> Language Class Initialized
INFO - 2017-10-11 17:28:55 --> Loader Class Initialized
INFO - 2017-10-11 17:28:55 --> Helper loaded: url_helper
INFO - 2017-10-11 17:28:55 --> Helper loaded: common_helper
INFO - 2017-10-11 17:28:55 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:28:55 --> Email Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Controller Class Initialized
INFO - 2017-10-11 17:28:55 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> Model Class Initialized
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:28:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:28:55 --> Final output sent to browser
DEBUG - 2017-10-11 17:28:55 --> Total execution time: 0.0441
INFO - 2017-10-11 17:29:09 --> Config Class Initialized
INFO - 2017-10-11 17:29:09 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:29:09 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:29:09 --> Utf8 Class Initialized
INFO - 2017-10-11 17:29:09 --> URI Class Initialized
INFO - 2017-10-11 17:29:09 --> Router Class Initialized
INFO - 2017-10-11 17:29:09 --> Output Class Initialized
INFO - 2017-10-11 17:29:09 --> Security Class Initialized
DEBUG - 2017-10-11 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:29:09 --> Input Class Initialized
INFO - 2017-10-11 17:29:09 --> Language Class Initialized
INFO - 2017-10-11 17:29:09 --> Loader Class Initialized
INFO - 2017-10-11 17:29:09 --> Helper loaded: url_helper
INFO - 2017-10-11 17:29:09 --> Helper loaded: common_helper
INFO - 2017-10-11 17:29:09 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:29:09 --> Email Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Controller Class Initialized
INFO - 2017-10-11 17:29:09 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> Model Class Initialized
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:29:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:29:09 --> Final output sent to browser
DEBUG - 2017-10-11 17:29:09 --> Total execution time: 0.0593
INFO - 2017-10-11 17:29:32 --> Config Class Initialized
INFO - 2017-10-11 17:29:32 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:29:32 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:29:32 --> Utf8 Class Initialized
INFO - 2017-10-11 17:29:32 --> URI Class Initialized
INFO - 2017-10-11 17:29:32 --> Router Class Initialized
INFO - 2017-10-11 17:29:32 --> Output Class Initialized
INFO - 2017-10-11 17:29:32 --> Security Class Initialized
DEBUG - 2017-10-11 17:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:29:32 --> Input Class Initialized
INFO - 2017-10-11 17:29:32 --> Language Class Initialized
INFO - 2017-10-11 17:29:32 --> Loader Class Initialized
INFO - 2017-10-11 17:29:32 --> Helper loaded: url_helper
INFO - 2017-10-11 17:29:32 --> Helper loaded: common_helper
INFO - 2017-10-11 17:29:32 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:29:32 --> Email Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Controller Class Initialized
INFO - 2017-10-11 17:29:32 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> Model Class Initialized
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:29:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:29:32 --> Final output sent to browser
DEBUG - 2017-10-11 17:29:32 --> Total execution time: 0.0728
INFO - 2017-10-11 17:30:09 --> Config Class Initialized
INFO - 2017-10-11 17:30:09 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:30:09 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:30:09 --> Utf8 Class Initialized
INFO - 2017-10-11 17:30:09 --> URI Class Initialized
INFO - 2017-10-11 17:30:09 --> Router Class Initialized
INFO - 2017-10-11 17:30:09 --> Output Class Initialized
INFO - 2017-10-11 17:30:09 --> Security Class Initialized
DEBUG - 2017-10-11 17:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:30:09 --> Input Class Initialized
INFO - 2017-10-11 17:30:09 --> Language Class Initialized
INFO - 2017-10-11 17:30:09 --> Loader Class Initialized
INFO - 2017-10-11 17:30:09 --> Helper loaded: url_helper
INFO - 2017-10-11 17:30:09 --> Helper loaded: common_helper
INFO - 2017-10-11 17:30:09 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:30:09 --> Email Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Controller Class Initialized
INFO - 2017-10-11 17:30:09 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:09 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Config Class Initialized
INFO - 2017-10-11 17:30:10 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:30:10 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:30:10 --> Utf8 Class Initialized
INFO - 2017-10-11 17:30:10 --> URI Class Initialized
INFO - 2017-10-11 17:30:10 --> Router Class Initialized
INFO - 2017-10-11 17:30:10 --> Output Class Initialized
INFO - 2017-10-11 17:30:10 --> Security Class Initialized
DEBUG - 2017-10-11 17:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:30:10 --> Input Class Initialized
INFO - 2017-10-11 17:30:10 --> Language Class Initialized
INFO - 2017-10-11 17:30:10 --> Loader Class Initialized
INFO - 2017-10-11 17:30:10 --> Helper loaded: url_helper
INFO - 2017-10-11 17:30:10 --> Helper loaded: common_helper
INFO - 2017-10-11 17:30:10 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:30:10 --> Email Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Controller Class Initialized
INFO - 2017-10-11 17:30:10 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> Model Class Initialized
INFO - 2017-10-11 17:30:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:30:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:30:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 17:30:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:30:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:30:10 --> Final output sent to browser
DEBUG - 2017-10-11 17:30:10 --> Total execution time: 0.0161
INFO - 2017-10-11 17:30:14 --> Config Class Initialized
INFO - 2017-10-11 17:30:14 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:30:14 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:30:14 --> Utf8 Class Initialized
INFO - 2017-10-11 17:30:14 --> URI Class Initialized
INFO - 2017-10-11 17:30:14 --> Router Class Initialized
INFO - 2017-10-11 17:30:14 --> Output Class Initialized
INFO - 2017-10-11 17:30:14 --> Security Class Initialized
DEBUG - 2017-10-11 17:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:30:14 --> Input Class Initialized
INFO - 2017-10-11 17:30:14 --> Language Class Initialized
INFO - 2017-10-11 17:30:14 --> Loader Class Initialized
INFO - 2017-10-11 17:30:14 --> Helper loaded: url_helper
INFO - 2017-10-11 17:30:14 --> Helper loaded: common_helper
INFO - 2017-10-11 17:30:14 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:30:14 --> Email Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Controller Class Initialized
INFO - 2017-10-11 17:30:14 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:14 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Config Class Initialized
INFO - 2017-10-11 17:30:15 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:30:15 --> Utf8 Class Initialized
INFO - 2017-10-11 17:30:15 --> URI Class Initialized
INFO - 2017-10-11 17:30:15 --> Router Class Initialized
INFO - 2017-10-11 17:30:15 --> Output Class Initialized
INFO - 2017-10-11 17:30:15 --> Security Class Initialized
DEBUG - 2017-10-11 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:30:15 --> Input Class Initialized
INFO - 2017-10-11 17:30:15 --> Language Class Initialized
INFO - 2017-10-11 17:30:15 --> Loader Class Initialized
INFO - 2017-10-11 17:30:15 --> Helper loaded: url_helper
INFO - 2017-10-11 17:30:15 --> Helper loaded: common_helper
INFO - 2017-10-11 17:30:15 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:30:15 --> Email Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Controller Class Initialized
INFO - 2017-10-11 17:30:15 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> Model Class Initialized
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:30:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:30:15 --> Final output sent to browser
DEBUG - 2017-10-11 17:30:15 --> Total execution time: 0.0288
INFO - 2017-10-11 17:30:25 --> Config Class Initialized
INFO - 2017-10-11 17:30:25 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:30:25 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:30:25 --> Utf8 Class Initialized
INFO - 2017-10-11 17:30:25 --> URI Class Initialized
INFO - 2017-10-11 17:30:25 --> Router Class Initialized
INFO - 2017-10-11 17:30:25 --> Output Class Initialized
INFO - 2017-10-11 17:30:25 --> Security Class Initialized
DEBUG - 2017-10-11 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:30:25 --> Input Class Initialized
INFO - 2017-10-11 17:30:25 --> Language Class Initialized
INFO - 2017-10-11 17:30:25 --> Loader Class Initialized
INFO - 2017-10-11 17:30:25 --> Helper loaded: url_helper
INFO - 2017-10-11 17:30:25 --> Helper loaded: common_helper
INFO - 2017-10-11 17:30:25 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:30:25 --> Email Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Controller Class Initialized
INFO - 2017-10-11 17:30:25 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> Model Class Initialized
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:30:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:30:25 --> Final output sent to browser
DEBUG - 2017-10-11 17:30:25 --> Total execution time: 0.0335
INFO - 2017-10-11 17:34:00 --> Config Class Initialized
INFO - 2017-10-11 17:34:00 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:00 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:00 --> Utf8 Class Initialized
INFO - 2017-10-11 17:34:00 --> URI Class Initialized
INFO - 2017-10-11 17:34:00 --> Router Class Initialized
INFO - 2017-10-11 17:34:00 --> Output Class Initialized
INFO - 2017-10-11 17:34:00 --> Security Class Initialized
DEBUG - 2017-10-11 17:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:34:00 --> Input Class Initialized
INFO - 2017-10-11 17:34:00 --> Language Class Initialized
INFO - 2017-10-11 17:34:00 --> Loader Class Initialized
INFO - 2017-10-11 17:34:00 --> Helper loaded: url_helper
INFO - 2017-10-11 17:34:00 --> Helper loaded: common_helper
INFO - 2017-10-11 17:34:00 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:34:00 --> Email Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Controller Class Initialized
INFO - 2017-10-11 17:34:00 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Config Class Initialized
INFO - 2017-10-11 17:34:00 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:00 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:00 --> Utf8 Class Initialized
INFO - 2017-10-11 17:34:00 --> URI Class Initialized
INFO - 2017-10-11 17:34:00 --> Router Class Initialized
INFO - 2017-10-11 17:34:00 --> Output Class Initialized
INFO - 2017-10-11 17:34:00 --> Security Class Initialized
DEBUG - 2017-10-11 17:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:34:00 --> Input Class Initialized
INFO - 2017-10-11 17:34:00 --> Language Class Initialized
INFO - 2017-10-11 17:34:00 --> Loader Class Initialized
INFO - 2017-10-11 17:34:00 --> Helper loaded: url_helper
INFO - 2017-10-11 17:34:00 --> Helper loaded: common_helper
INFO - 2017-10-11 17:34:00 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:34:00 --> Email Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Controller Class Initialized
INFO - 2017-10-11 17:34:00 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> Model Class Initialized
INFO - 2017-10-11 17:34:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:34:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:34:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 17:34:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:34:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:34:00 --> Final output sent to browser
DEBUG - 2017-10-11 17:34:00 --> Total execution time: 0.0338
INFO - 2017-10-11 17:34:07 --> Config Class Initialized
INFO - 2017-10-11 17:34:07 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:07 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:07 --> Utf8 Class Initialized
INFO - 2017-10-11 17:34:07 --> URI Class Initialized
INFO - 2017-10-11 17:34:07 --> Router Class Initialized
INFO - 2017-10-11 17:34:07 --> Output Class Initialized
INFO - 2017-10-11 17:34:07 --> Security Class Initialized
DEBUG - 2017-10-11 17:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:34:07 --> Input Class Initialized
INFO - 2017-10-11 17:34:07 --> Language Class Initialized
INFO - 2017-10-11 17:34:07 --> Loader Class Initialized
INFO - 2017-10-11 17:34:07 --> Helper loaded: url_helper
INFO - 2017-10-11 17:34:07 --> Helper loaded: common_helper
INFO - 2017-10-11 17:34:07 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:34:07 --> Email Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Controller Class Initialized
INFO - 2017-10-11 17:34:07 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Config Class Initialized
INFO - 2017-10-11 17:34:07 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:07 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:07 --> Utf8 Class Initialized
INFO - 2017-10-11 17:34:07 --> URI Class Initialized
INFO - 2017-10-11 17:34:07 --> Router Class Initialized
INFO - 2017-10-11 17:34:07 --> Output Class Initialized
INFO - 2017-10-11 17:34:07 --> Security Class Initialized
DEBUG - 2017-10-11 17:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:34:07 --> Input Class Initialized
INFO - 2017-10-11 17:34:07 --> Language Class Initialized
INFO - 2017-10-11 17:34:07 --> Loader Class Initialized
INFO - 2017-10-11 17:34:07 --> Helper loaded: url_helper
INFO - 2017-10-11 17:34:07 --> Helper loaded: common_helper
INFO - 2017-10-11 17:34:07 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:34:07 --> Email Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Controller Class Initialized
INFO - 2017-10-11 17:34:07 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
INFO - 2017-10-11 17:34:07 --> Model Class Initialized
ERROR - 2017-10-11 17:34:07 --> Severity: Notice --> Undefined variable: logo /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php 22
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:34:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:34:07 --> Final output sent to browser
DEBUG - 2017-10-11 17:34:07 --> Total execution time: 0.0388
INFO - 2017-10-11 17:34:07 --> Config Class Initialized
INFO - 2017-10-11 17:34:07 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:07 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:07 --> Utf8 Class Initialized
INFO - 2017-10-11 17:34:08 --> Config Class Initialized
INFO - 2017-10-11 17:34:08 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:34:08 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:34:08 --> Utf8 Class Initialized
INFO - 2017-10-11 17:35:30 --> Config Class Initialized
INFO - 2017-10-11 17:35:30 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:35:30 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:35:30 --> Utf8 Class Initialized
INFO - 2017-10-11 17:35:30 --> URI Class Initialized
INFO - 2017-10-11 17:35:30 --> Router Class Initialized
INFO - 2017-10-11 17:35:30 --> Output Class Initialized
INFO - 2017-10-11 17:35:30 --> Security Class Initialized
DEBUG - 2017-10-11 17:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:35:30 --> Input Class Initialized
INFO - 2017-10-11 17:35:30 --> Language Class Initialized
INFO - 2017-10-11 17:35:30 --> Loader Class Initialized
INFO - 2017-10-11 17:35:30 --> Helper loaded: url_helper
INFO - 2017-10-11 17:35:30 --> Helper loaded: common_helper
INFO - 2017-10-11 17:35:30 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:35:30 --> Email Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Controller Class Initialized
INFO - 2017-10-11 17:35:30 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
INFO - 2017-10-11 17:35:30 --> Model Class Initialized
ERROR - 2017-10-11 17:35:30 --> Severity: Notice --> Undefined variable: logo /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php 22
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:35:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:35:30 --> Final output sent to browser
DEBUG - 2017-10-11 17:35:30 --> Total execution time: 0.0294
INFO - 2017-10-11 17:35:30 --> Config Class Initialized
INFO - 2017-10-11 17:35:30 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:35:30 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:35:30 --> Utf8 Class Initialized
INFO - 2017-10-11 17:35:30 --> Config Class Initialized
INFO - 2017-10-11 17:35:30 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:35:30 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:35:30 --> Utf8 Class Initialized
INFO - 2017-10-11 17:35:38 --> Config Class Initialized
INFO - 2017-10-11 17:35:38 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:35:38 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:35:38 --> Utf8 Class Initialized
INFO - 2017-10-11 17:35:38 --> URI Class Initialized
INFO - 2017-10-11 17:35:38 --> Router Class Initialized
INFO - 2017-10-11 17:35:38 --> Output Class Initialized
INFO - 2017-10-11 17:35:38 --> Security Class Initialized
DEBUG - 2017-10-11 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:35:38 --> Input Class Initialized
INFO - 2017-10-11 17:35:38 --> Language Class Initialized
INFO - 2017-10-11 17:35:38 --> Loader Class Initialized
INFO - 2017-10-11 17:35:38 --> Helper loaded: url_helper
INFO - 2017-10-11 17:35:38 --> Helper loaded: common_helper
INFO - 2017-10-11 17:35:38 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:35:38 --> Email Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Controller Class Initialized
INFO - 2017-10-11 17:35:38 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> Model Class Initialized
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:35:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:35:38 --> Final output sent to browser
DEBUG - 2017-10-11 17:35:38 --> Total execution time: 0.0362
INFO - 2017-10-11 17:41:08 --> Config Class Initialized
INFO - 2017-10-11 17:41:08 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:41:08 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:41:08 --> Utf8 Class Initialized
INFO - 2017-10-11 17:41:08 --> URI Class Initialized
INFO - 2017-10-11 17:41:08 --> Router Class Initialized
INFO - 2017-10-11 17:41:08 --> Output Class Initialized
INFO - 2017-10-11 17:41:08 --> Security Class Initialized
DEBUG - 2017-10-11 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:41:08 --> Input Class Initialized
INFO - 2017-10-11 17:41:08 --> Language Class Initialized
INFO - 2017-10-11 17:41:08 --> Loader Class Initialized
INFO - 2017-10-11 17:41:08 --> Helper loaded: url_helper
INFO - 2017-10-11 17:41:08 --> Helper loaded: common_helper
INFO - 2017-10-11 17:41:08 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:41:08 --> Email Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Controller Class Initialized
INFO - 2017-10-11 17:41:08 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> Model Class Initialized
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:41:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:41:08 --> Final output sent to browser
DEBUG - 2017-10-11 17:41:08 --> Total execution time: 0.2171
INFO - 2017-10-11 17:48:42 --> Config Class Initialized
INFO - 2017-10-11 17:48:42 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:48:42 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:48:42 --> Utf8 Class Initialized
INFO - 2017-10-11 17:48:42 --> URI Class Initialized
INFO - 2017-10-11 17:48:42 --> Router Class Initialized
INFO - 2017-10-11 17:48:42 --> Output Class Initialized
INFO - 2017-10-11 17:48:42 --> Security Class Initialized
DEBUG - 2017-10-11 17:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:48:42 --> Input Class Initialized
INFO - 2017-10-11 17:48:42 --> Language Class Initialized
INFO - 2017-10-11 17:48:42 --> Loader Class Initialized
INFO - 2017-10-11 17:48:42 --> Helper loaded: url_helper
INFO - 2017-10-11 17:48:42 --> Helper loaded: common_helper
INFO - 2017-10-11 17:48:42 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:48:42 --> Email Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Controller Class Initialized
INFO - 2017-10-11 17:48:42 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Config Class Initialized
INFO - 2017-10-11 17:48:42 --> Hooks Class Initialized
DEBUG - 2017-10-11 17:48:42 --> UTF-8 Support Enabled
INFO - 2017-10-11 17:48:42 --> Utf8 Class Initialized
INFO - 2017-10-11 17:48:42 --> URI Class Initialized
INFO - 2017-10-11 17:48:42 --> Router Class Initialized
INFO - 2017-10-11 17:48:42 --> Output Class Initialized
INFO - 2017-10-11 17:48:42 --> Security Class Initialized
DEBUG - 2017-10-11 17:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-11 17:48:42 --> Input Class Initialized
INFO - 2017-10-11 17:48:42 --> Language Class Initialized
INFO - 2017-10-11 17:48:42 --> Loader Class Initialized
INFO - 2017-10-11 17:48:42 --> Helper loaded: url_helper
INFO - 2017-10-11 17:48:42 --> Helper loaded: common_helper
INFO - 2017-10-11 17:48:42 --> Database Driver Class Initialized
DEBUG - 2017-10-11 17:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-11 17:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-11 17:48:42 --> Email Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Controller Class Initialized
INFO - 2017-10-11 17:48:42 --> Helper loaded: cookie_helper
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> Model Class Initialized
INFO - 2017-10-11 17:48:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-11 17:48:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-11 17:48:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-11 17:48:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-11 17:48:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-11 17:48:42 --> Final output sent to browser
DEBUG - 2017-10-11 17:48:42 --> Total execution time: 0.0787
