<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-19 10:45:06 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 10:45:14 --> Severity: Notice --> Undefined index: country /var/www/html/spaceage_guru/application/controllers/module/auth/Profile.php 142
ERROR - 2018-01-19 10:45:15 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 10:45:43 --> Severity: Notice --> Undefined index: country /var/www/html/spaceage_guru/application/controllers/module/auth/Profile.php 142
ERROR - 2018-01-19 10:45:44 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 11:03:50 --> 404 Page Not Found: Public/api_down
ERROR - 2018-01-19 11:04:08 --> 404 Page Not Found: Public/api_down
ERROR - 2018-01-19 11:04:29 --> 404 Page Not Found: Public/api_down
ERROR - 2018-01-19 11:04:36 --> 404 Page Not Found: Public/api_down
ERROR - 2018-01-19 11:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-01-19 11:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-01-19 11:16:35 --> Severity: Notice --> Undefined index: country /var/www/html/spaceage_guru/application/controllers/module/auth/Profile.php 142
ERROR - 2018-01-19 11:16:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 11:57:35 --> Severity: error --> Exception: syntax error, unexpected ')' /var/www/html/spaceage_guru/application/controllers/module/auth/Profile.php 244
ERROR - 2018-01-19 12:03:11 --> Severity: Notice --> Undefined index: country /var/www/html/spaceage_guru/application/controllers/Welcome.php 38
ERROR - 2018-01-19 12:09:07 --> 404 Page Not Found: Public/api_down
ERROR - 2018-01-19 15:09:10 --> Severity: Notice --> Undefined index: country /var/www/html/spaceage_guru/application/controllers/Welcome.php 38
ERROR - 2018-01-19 15:13:41 --> Severity: Warning --> Missing argument 1 for Webservice_controller::rpq_for_ios(), called in /var/www/html/spaceage_guru/system/core/CodeIgniter.php on line 514 and defined /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3442
ERROR - 2018-01-19 15:13:41 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3454
ERROR - 2018-01-19 15:13:41 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:13:49 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3454
ERROR - 2018-01-19 15:13:49 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:14:18 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3454
ERROR - 2018-01-19 15:14:18 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:15:11 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3454
ERROR - 2018-01-19 15:15:11 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:16:23 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:16:23 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:16:26 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:16:26 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:16:53 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:16:53 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:16:55 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:16:55 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:17:07 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:17:07 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:17:16 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3453
ERROR - 2018-01-19 15:17:16 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:23:33 --> 404 Page Not Found: Profile/update-rpq-ios
ERROR - 2018-01-19 15:25:50 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 15:29:33 --> Severity: Warning --> Missing argument 1 for Webservice_controller::wpq_for_ios(), called in /var/www/html/spaceage_guru/system/core/CodeIgniter.php on line 514 and defined /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3469
ERROR - 2018-01-19 15:29:33 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3482
ERROR - 2018-01-19 15:29:33 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:29:41 --> Severity: 4096 --> Object of class Webservice_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3482
ERROR - 2018-01-19 15:29:41 --> Severity: error --> Exception: Cannot access empty property /var/www/html/spaceage_guru/system/core/Model.php 77
ERROR - 2018-01-19 15:32:09 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3482
ERROR - 2018-01-19 15:34:15 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 15:39:30 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 14
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 43
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 46
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 59
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 62
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 67
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 106
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 141
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 191
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 194
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 199
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 234
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 267
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 294
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 332
ERROR - 2018-01-19 15:42:10 --> Severity: Notice --> Undefined variable: wpq /var/www/html/spaceage_guru/application/views/templates/public/module/ios/ios_wpq.php 374
ERROR - 2018-01-19 15:46:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Welcome.php 154
ERROR - 2018-01-19 15:46:31 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `user_questionnaire` (`user_id`, `question_id`, `question_group`, `answer`) VALUES (NULL, 1, 3, 'a,b')
