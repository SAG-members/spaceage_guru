<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-27 10:09:05 --> Severity: Notice --> Undefined variable: lockIcon /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_sidebar.php 6
