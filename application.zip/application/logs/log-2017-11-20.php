<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-20 15:36:09 --> Config Class Initialized
INFO - 2017-11-20 15:36:09 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:36:09 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:36:09 --> Utf8 Class Initialized
INFO - 2017-11-20 15:36:09 --> URI Class Initialized
DEBUG - 2017-11-20 15:36:09 --> No URI present. Default controller set.
INFO - 2017-11-20 15:36:09 --> Router Class Initialized
INFO - 2017-11-20 15:36:09 --> Output Class Initialized
INFO - 2017-11-20 15:36:09 --> Security Class Initialized
DEBUG - 2017-11-20 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:36:09 --> Input Class Initialized
INFO - 2017-11-20 15:36:09 --> Language Class Initialized
INFO - 2017-11-20 15:36:09 --> Loader Class Initialized
INFO - 2017-11-20 15:36:09 --> Helper loaded: url_helper
INFO - 2017-11-20 15:36:09 --> Helper loaded: common_helper
INFO - 2017-11-20 15:36:09 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:36:09 --> Email Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Controller Class Initialized
INFO - 2017-11-20 15:36:09 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> Model Class Initialized
INFO - 2017-11-20 15:36:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:36:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:36:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-20 15:36:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:36:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:36:09 --> Final output sent to browser
DEBUG - 2017-11-20 15:36:09 --> Total execution time: 0.3012
INFO - 2017-11-20 15:36:16 --> Config Class Initialized
INFO - 2017-11-20 15:36:16 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:36:16 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:36:16 --> Utf8 Class Initialized
INFO - 2017-11-20 15:36:16 --> URI Class Initialized
INFO - 2017-11-20 15:36:16 --> Router Class Initialized
INFO - 2017-11-20 15:36:16 --> Output Class Initialized
INFO - 2017-11-20 15:36:16 --> Security Class Initialized
DEBUG - 2017-11-20 15:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:36:16 --> Input Class Initialized
INFO - 2017-11-20 15:36:16 --> Language Class Initialized
INFO - 2017-11-20 15:36:16 --> Loader Class Initialized
INFO - 2017-11-20 15:36:16 --> Helper loaded: url_helper
INFO - 2017-11-20 15:36:16 --> Helper loaded: common_helper
INFO - 2017-11-20 15:36:16 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:36:16 --> Email Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Controller Class Initialized
INFO - 2017-11-20 15:36:16 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:16 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Config Class Initialized
INFO - 2017-11-20 15:36:25 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:36:25 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:36:25 --> Utf8 Class Initialized
INFO - 2017-11-20 15:36:25 --> URI Class Initialized
DEBUG - 2017-11-20 15:36:25 --> No URI present. Default controller set.
INFO - 2017-11-20 15:36:25 --> Router Class Initialized
INFO - 2017-11-20 15:36:25 --> Output Class Initialized
INFO - 2017-11-20 15:36:25 --> Security Class Initialized
DEBUG - 2017-11-20 15:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:36:25 --> Input Class Initialized
INFO - 2017-11-20 15:36:25 --> Language Class Initialized
INFO - 2017-11-20 15:36:25 --> Loader Class Initialized
INFO - 2017-11-20 15:36:25 --> Helper loaded: url_helper
INFO - 2017-11-20 15:36:25 --> Helper loaded: common_helper
INFO - 2017-11-20 15:36:25 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:36:25 --> Email Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Controller Class Initialized
INFO - 2017-11-20 15:36:25 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> Model Class Initialized
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:36:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:36:25 --> Final output sent to browser
DEBUG - 2017-11-20 15:36:25 --> Total execution time: 0.0405
INFO - 2017-11-20 15:37:05 --> Config Class Initialized
INFO - 2017-11-20 15:37:05 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:05 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:05 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:05 --> URI Class Initialized
DEBUG - 2017-11-20 15:37:05 --> No URI present. Default controller set.
INFO - 2017-11-20 15:37:05 --> Router Class Initialized
INFO - 2017-11-20 15:37:05 --> Output Class Initialized
INFO - 2017-11-20 15:37:05 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:05 --> Input Class Initialized
INFO - 2017-11-20 15:37:05 --> Language Class Initialized
INFO - 2017-11-20 15:37:05 --> Loader Class Initialized
INFO - 2017-11-20 15:37:05 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:05 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:05 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:05 --> Email Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Controller Class Initialized
INFO - 2017-11-20 15:37:05 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> Model Class Initialized
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:37:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:37:05 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:05 --> Total execution time: 0.0190
INFO - 2017-11-20 15:37:52 --> Config Class Initialized
INFO - 2017-11-20 15:37:52 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:52 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:52 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:52 --> URI Class Initialized
INFO - 2017-11-20 15:37:52 --> Router Class Initialized
INFO - 2017-11-20 15:37:52 --> Output Class Initialized
INFO - 2017-11-20 15:37:52 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:52 --> Input Class Initialized
INFO - 2017-11-20 15:37:52 --> Language Class Initialized
INFO - 2017-11-20 15:37:52 --> Loader Class Initialized
INFO - 2017-11-20 15:37:52 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:52 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:52 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:52 --> Email Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Controller Class Initialized
INFO - 2017-11-20 15:37:52 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:37:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:37:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:37:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:37:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:37:52 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:52 --> Total execution time: 0.1497
INFO - 2017-11-20 15:37:52 --> Config Class Initialized
INFO - 2017-11-20 15:37:52 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:52 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:52 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:52 --> URI Class Initialized
INFO - 2017-11-20 15:37:52 --> Router Class Initialized
INFO - 2017-11-20 15:37:52 --> Output Class Initialized
INFO - 2017-11-20 15:37:52 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:52 --> Input Class Initialized
INFO - 2017-11-20 15:37:52 --> Language Class Initialized
INFO - 2017-11-20 15:37:52 --> Loader Class Initialized
INFO - 2017-11-20 15:37:52 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:52 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:52 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:52 --> Email Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Controller Class Initialized
INFO - 2017-11-20 15:37:52 --> Model Class Initialized
INFO - 2017-11-20 15:37:52 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:52 --> Total execution time: 0.0180
INFO - 2017-11-20 15:37:55 --> Config Class Initialized
INFO - 2017-11-20 15:37:55 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:55 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:55 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:55 --> URI Class Initialized
INFO - 2017-11-20 15:37:55 --> Router Class Initialized
INFO - 2017-11-20 15:37:55 --> Output Class Initialized
INFO - 2017-11-20 15:37:55 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:55 --> Input Class Initialized
INFO - 2017-11-20 15:37:55 --> Language Class Initialized
INFO - 2017-11-20 15:37:55 --> Loader Class Initialized
INFO - 2017-11-20 15:37:55 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:55 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:55 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:55 --> Email Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Controller Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Config Class Initialized
INFO - 2017-11-20 15:37:55 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:55 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:55 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:55 --> URI Class Initialized
INFO - 2017-11-20 15:37:55 --> Router Class Initialized
INFO - 2017-11-20 15:37:55 --> Output Class Initialized
INFO - 2017-11-20 15:37:55 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:55 --> Input Class Initialized
INFO - 2017-11-20 15:37:55 --> Language Class Initialized
INFO - 2017-11-20 15:37:55 --> Loader Class Initialized
INFO - 2017-11-20 15:37:55 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:55 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:55 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:55 --> Total execution time: 0.1019
INFO - 2017-11-20 15:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:55 --> Email Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Controller Class Initialized
INFO - 2017-11-20 15:37:55 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> Model Class Initialized
INFO - 2017-11-20 15:37:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:37:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:37:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:37:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:37:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:37:55 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:55 --> Total execution time: 0.1169
INFO - 2017-11-20 15:37:56 --> Config Class Initialized
INFO - 2017-11-20 15:37:56 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:56 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:56 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:56 --> URI Class Initialized
INFO - 2017-11-20 15:37:56 --> Router Class Initialized
INFO - 2017-11-20 15:37:56 --> Output Class Initialized
INFO - 2017-11-20 15:37:56 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:56 --> Input Class Initialized
INFO - 2017-11-20 15:37:56 --> Language Class Initialized
INFO - 2017-11-20 15:37:56 --> Loader Class Initialized
INFO - 2017-11-20 15:37:56 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:56 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:56 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:56 --> Email Class Initialized
INFO - 2017-11-20 15:37:56 --> Model Class Initialized
INFO - 2017-11-20 15:37:56 --> Controller Class Initialized
INFO - 2017-11-20 15:37:56 --> Model Class Initialized
INFO - 2017-11-20 15:37:56 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:56 --> Total execution time: 0.0021
INFO - 2017-11-20 15:37:56 --> Config Class Initialized
INFO - 2017-11-20 15:37:56 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:37:56 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:37:56 --> Utf8 Class Initialized
INFO - 2017-11-20 15:37:56 --> URI Class Initialized
INFO - 2017-11-20 15:37:56 --> Router Class Initialized
INFO - 2017-11-20 15:37:56 --> Output Class Initialized
INFO - 2017-11-20 15:37:56 --> Security Class Initialized
DEBUG - 2017-11-20 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:37:56 --> Input Class Initialized
INFO - 2017-11-20 15:37:56 --> Language Class Initialized
INFO - 2017-11-20 15:37:56 --> Loader Class Initialized
INFO - 2017-11-20 15:37:56 --> Helper loaded: url_helper
INFO - 2017-11-20 15:37:56 --> Helper loaded: common_helper
INFO - 2017-11-20 15:37:56 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:37:56 --> Email Class Initialized
INFO - 2017-11-20 15:37:56 --> Model Class Initialized
INFO - 2017-11-20 15:37:56 --> Controller Class Initialized
INFO - 2017-11-20 15:37:56 --> Final output sent to browser
DEBUG - 2017-11-20 15:37:56 --> Total execution time: 0.0015
INFO - 2017-11-20 15:38:56 --> Config Class Initialized
INFO - 2017-11-20 15:38:56 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:56 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:56 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:56 --> URI Class Initialized
INFO - 2017-11-20 15:38:56 --> Router Class Initialized
INFO - 2017-11-20 15:38:56 --> Output Class Initialized
INFO - 2017-11-20 15:38:56 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:56 --> Input Class Initialized
INFO - 2017-11-20 15:38:56 --> Language Class Initialized
INFO - 2017-11-20 15:38:56 --> Loader Class Initialized
INFO - 2017-11-20 15:38:56 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:56 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:56 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:56 --> Email Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Controller Class Initialized
INFO - 2017-11-20 15:38:56 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> Model Class Initialized
INFO - 2017-11-20 15:38:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:56 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:56 --> Total execution time: 0.0303
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0033
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0352
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0473
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0482
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0600
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0464
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Config Class Initialized
INFO - 2017-11-20 15:38:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:57 --> URI Class Initialized
INFO - 2017-11-20 15:38:57 --> Router Class Initialized
INFO - 2017-11-20 15:38:57 --> Output Class Initialized
INFO - 2017-11-20 15:38:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:57 --> Input Class Initialized
INFO - 2017-11-20 15:38:57 --> Language Class Initialized
INFO - 2017-11-20 15:38:57 --> Loader Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0501
INFO - 2017-11-20 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:57 --> Email Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Controller Class Initialized
INFO - 2017-11-20 15:38:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> Model Class Initialized
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:38:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:38:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:57 --> Total execution time: 0.0590
INFO - 2017-11-20 15:38:58 --> Config Class Initialized
INFO - 2017-11-20 15:38:58 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:38:58 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:38:58 --> Utf8 Class Initialized
INFO - 2017-11-20 15:38:58 --> URI Class Initialized
INFO - 2017-11-20 15:38:58 --> Router Class Initialized
INFO - 2017-11-20 15:38:58 --> Output Class Initialized
INFO - 2017-11-20 15:38:58 --> Security Class Initialized
DEBUG - 2017-11-20 15:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:38:58 --> Input Class Initialized
INFO - 2017-11-20 15:38:58 --> Language Class Initialized
INFO - 2017-11-20 15:38:58 --> Loader Class Initialized
INFO - 2017-11-20 15:38:58 --> Helper loaded: url_helper
INFO - 2017-11-20 15:38:58 --> Helper loaded: common_helper
INFO - 2017-11-20 15:38:58 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:38:58 --> Email Class Initialized
INFO - 2017-11-20 15:38:58 --> Model Class Initialized
INFO - 2017-11-20 15:38:58 --> Controller Class Initialized
INFO - 2017-11-20 15:38:58 --> Model Class Initialized
INFO - 2017-11-20 15:38:58 --> Final output sent to browser
DEBUG - 2017-11-20 15:38:58 --> Total execution time: 0.0018
INFO - 2017-11-20 15:39:01 --> Config Class Initialized
INFO - 2017-11-20 15:39:01 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:39:01 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:39:01 --> Utf8 Class Initialized
INFO - 2017-11-20 15:39:01 --> URI Class Initialized
INFO - 2017-11-20 15:39:01 --> Router Class Initialized
INFO - 2017-11-20 15:39:01 --> Output Class Initialized
INFO - 2017-11-20 15:39:01 --> Security Class Initialized
DEBUG - 2017-11-20 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:39:01 --> Input Class Initialized
INFO - 2017-11-20 15:39:01 --> Language Class Initialized
INFO - 2017-11-20 15:39:01 --> Loader Class Initialized
INFO - 2017-11-20 15:39:01 --> Helper loaded: url_helper
INFO - 2017-11-20 15:39:01 --> Helper loaded: common_helper
INFO - 2017-11-20 15:39:01 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:39:01 --> Email Class Initialized
INFO - 2017-11-20 15:39:01 --> Model Class Initialized
INFO - 2017-11-20 15:39:01 --> Controller Class Initialized
INFO - 2017-11-20 15:39:01 --> Final output sent to browser
DEBUG - 2017-11-20 15:39:01 --> Total execution time: 0.0022
INFO - 2017-11-20 15:41:54 --> Config Class Initialized
INFO - 2017-11-20 15:41:54 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:41:54 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:41:54 --> Utf8 Class Initialized
INFO - 2017-11-20 15:41:54 --> URI Class Initialized
INFO - 2017-11-20 15:41:54 --> Router Class Initialized
INFO - 2017-11-20 15:41:54 --> Output Class Initialized
INFO - 2017-11-20 15:41:54 --> Security Class Initialized
DEBUG - 2017-11-20 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:41:54 --> Input Class Initialized
INFO - 2017-11-20 15:41:54 --> Language Class Initialized
INFO - 2017-11-20 15:41:54 --> Loader Class Initialized
INFO - 2017-11-20 15:41:54 --> Helper loaded: url_helper
INFO - 2017-11-20 15:41:54 --> Helper loaded: common_helper
INFO - 2017-11-20 15:41:54 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:41:54 --> Email Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Controller Class Initialized
INFO - 2017-11-20 15:41:54 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> Model Class Initialized
INFO - 2017-11-20 15:41:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:41:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:41:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:41:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:41:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:41:54 --> Final output sent to browser
DEBUG - 2017-11-20 15:41:54 --> Total execution time: 0.0271
INFO - 2017-11-20 15:41:55 --> Config Class Initialized
INFO - 2017-11-20 15:41:55 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:41:55 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:41:55 --> Utf8 Class Initialized
INFO - 2017-11-20 15:41:55 --> URI Class Initialized
INFO - 2017-11-20 15:41:55 --> Router Class Initialized
INFO - 2017-11-20 15:41:55 --> Output Class Initialized
INFO - 2017-11-20 15:41:55 --> Security Class Initialized
DEBUG - 2017-11-20 15:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:41:55 --> Input Class Initialized
INFO - 2017-11-20 15:41:55 --> Language Class Initialized
INFO - 2017-11-20 15:41:55 --> Loader Class Initialized
INFO - 2017-11-20 15:41:55 --> Helper loaded: url_helper
INFO - 2017-11-20 15:41:55 --> Helper loaded: common_helper
INFO - 2017-11-20 15:41:55 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:41:55 --> Email Class Initialized
INFO - 2017-11-20 15:41:55 --> Model Class Initialized
INFO - 2017-11-20 15:41:55 --> Controller Class Initialized
INFO - 2017-11-20 15:41:55 --> Model Class Initialized
INFO - 2017-11-20 15:41:55 --> Final output sent to browser
DEBUG - 2017-11-20 15:41:55 --> Total execution time: 0.0032
INFO - 2017-11-20 15:41:58 --> Config Class Initialized
INFO - 2017-11-20 15:41:58 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:41:58 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:41:58 --> Utf8 Class Initialized
INFO - 2017-11-20 15:41:58 --> URI Class Initialized
INFO - 2017-11-20 15:41:58 --> Router Class Initialized
INFO - 2017-11-20 15:41:58 --> Output Class Initialized
INFO - 2017-11-20 15:41:58 --> Security Class Initialized
DEBUG - 2017-11-20 15:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:41:58 --> Input Class Initialized
INFO - 2017-11-20 15:41:58 --> Language Class Initialized
INFO - 2017-11-20 15:41:58 --> Loader Class Initialized
INFO - 2017-11-20 15:41:58 --> Helper loaded: url_helper
INFO - 2017-11-20 15:41:58 --> Helper loaded: common_helper
INFO - 2017-11-20 15:41:58 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:41:58 --> Email Class Initialized
INFO - 2017-11-20 15:41:58 --> Model Class Initialized
INFO - 2017-11-20 15:41:58 --> Controller Class Initialized
INFO - 2017-11-20 15:41:58 --> Final output sent to browser
DEBUG - 2017-11-20 15:41:58 --> Total execution time: 0.0023
INFO - 2017-11-20 15:42:14 --> Config Class Initialized
INFO - 2017-11-20 15:42:14 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:42:14 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:42:14 --> Utf8 Class Initialized
INFO - 2017-11-20 15:42:14 --> URI Class Initialized
INFO - 2017-11-20 15:42:14 --> Router Class Initialized
INFO - 2017-11-20 15:42:14 --> Output Class Initialized
INFO - 2017-11-20 15:42:14 --> Security Class Initialized
DEBUG - 2017-11-20 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:42:14 --> Input Class Initialized
INFO - 2017-11-20 15:42:14 --> Language Class Initialized
INFO - 2017-11-20 15:42:14 --> Loader Class Initialized
INFO - 2017-11-20 15:42:14 --> Helper loaded: url_helper
INFO - 2017-11-20 15:42:14 --> Helper loaded: common_helper
INFO - 2017-11-20 15:42:14 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:42:14 --> Email Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Controller Class Initialized
INFO - 2017-11-20 15:42:14 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:42:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:42:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:42:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:42:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:42:14 --> Final output sent to browser
DEBUG - 2017-11-20 15:42:14 --> Total execution time: 0.0291
INFO - 2017-11-20 15:42:14 --> Config Class Initialized
INFO - 2017-11-20 15:42:14 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:42:14 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:42:14 --> Utf8 Class Initialized
INFO - 2017-11-20 15:42:14 --> URI Class Initialized
INFO - 2017-11-20 15:42:14 --> Router Class Initialized
INFO - 2017-11-20 15:42:14 --> Output Class Initialized
INFO - 2017-11-20 15:42:14 --> Security Class Initialized
DEBUG - 2017-11-20 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:42:14 --> Input Class Initialized
INFO - 2017-11-20 15:42:14 --> Language Class Initialized
INFO - 2017-11-20 15:42:14 --> Loader Class Initialized
INFO - 2017-11-20 15:42:14 --> Helper loaded: url_helper
INFO - 2017-11-20 15:42:14 --> Helper loaded: common_helper
INFO - 2017-11-20 15:42:14 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:42:14 --> Email Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Controller Class Initialized
INFO - 2017-11-20 15:42:14 --> Model Class Initialized
INFO - 2017-11-20 15:42:14 --> Final output sent to browser
DEBUG - 2017-11-20 15:42:14 --> Total execution time: 0.0036
INFO - 2017-11-20 15:46:20 --> Config Class Initialized
INFO - 2017-11-20 15:46:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:46:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:46:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:46:20 --> URI Class Initialized
INFO - 2017-11-20 15:46:20 --> Router Class Initialized
INFO - 2017-11-20 15:46:20 --> Output Class Initialized
INFO - 2017-11-20 15:46:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:46:20 --> Input Class Initialized
INFO - 2017-11-20 15:46:20 --> Language Class Initialized
INFO - 2017-11-20 15:46:20 --> Loader Class Initialized
INFO - 2017-11-20 15:46:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:46:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:46:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:46:20 --> Email Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Controller Class Initialized
INFO - 2017-11-20 15:46:20 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:46:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:46:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:46:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:46:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:46:20 --> Final output sent to browser
DEBUG - 2017-11-20 15:46:20 --> Total execution time: 0.0355
INFO - 2017-11-20 15:46:20 --> Config Class Initialized
INFO - 2017-11-20 15:46:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:46:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:46:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:46:20 --> URI Class Initialized
INFO - 2017-11-20 15:46:20 --> Router Class Initialized
INFO - 2017-11-20 15:46:20 --> Output Class Initialized
INFO - 2017-11-20 15:46:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:46:20 --> Input Class Initialized
INFO - 2017-11-20 15:46:20 --> Language Class Initialized
INFO - 2017-11-20 15:46:20 --> Loader Class Initialized
INFO - 2017-11-20 15:46:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:46:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:46:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:46:20 --> Email Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Controller Class Initialized
INFO - 2017-11-20 15:46:20 --> Model Class Initialized
INFO - 2017-11-20 15:46:20 --> Final output sent to browser
DEBUG - 2017-11-20 15:46:20 --> Total execution time: 0.0038
INFO - 2017-11-20 15:46:29 --> Config Class Initialized
INFO - 2017-11-20 15:46:29 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:46:29 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:46:29 --> Utf8 Class Initialized
INFO - 2017-11-20 15:46:29 --> URI Class Initialized
INFO - 2017-11-20 15:46:29 --> Router Class Initialized
INFO - 2017-11-20 15:46:29 --> Output Class Initialized
INFO - 2017-11-20 15:46:29 --> Security Class Initialized
DEBUG - 2017-11-20 15:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:46:29 --> Input Class Initialized
INFO - 2017-11-20 15:46:29 --> Language Class Initialized
INFO - 2017-11-20 15:46:29 --> Loader Class Initialized
INFO - 2017-11-20 15:46:29 --> Helper loaded: url_helper
INFO - 2017-11-20 15:46:29 --> Helper loaded: common_helper
INFO - 2017-11-20 15:46:29 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:46:29 --> Email Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Controller Class Initialized
INFO - 2017-11-20 15:46:29 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:46:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:46:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:46:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:46:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:46:29 --> Final output sent to browser
DEBUG - 2017-11-20 15:46:29 --> Total execution time: 0.0344
INFO - 2017-11-20 15:46:29 --> Config Class Initialized
INFO - 2017-11-20 15:46:29 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:46:29 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:46:29 --> Utf8 Class Initialized
INFO - 2017-11-20 15:46:29 --> URI Class Initialized
INFO - 2017-11-20 15:46:29 --> Router Class Initialized
INFO - 2017-11-20 15:46:29 --> Output Class Initialized
INFO - 2017-11-20 15:46:29 --> Security Class Initialized
DEBUG - 2017-11-20 15:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:46:29 --> Input Class Initialized
INFO - 2017-11-20 15:46:29 --> Language Class Initialized
INFO - 2017-11-20 15:46:29 --> Loader Class Initialized
INFO - 2017-11-20 15:46:29 --> Helper loaded: url_helper
INFO - 2017-11-20 15:46:29 --> Helper loaded: common_helper
INFO - 2017-11-20 15:46:29 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:46:29 --> Email Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Controller Class Initialized
INFO - 2017-11-20 15:46:29 --> Model Class Initialized
INFO - 2017-11-20 15:46:29 --> Final output sent to browser
DEBUG - 2017-11-20 15:46:29 --> Total execution time: 0.0026
INFO - 2017-11-20 15:50:04 --> Config Class Initialized
INFO - 2017-11-20 15:50:04 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:50:04 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:50:04 --> Utf8 Class Initialized
INFO - 2017-11-20 15:50:04 --> URI Class Initialized
INFO - 2017-11-20 15:50:04 --> Router Class Initialized
INFO - 2017-11-20 15:50:04 --> Output Class Initialized
INFO - 2017-11-20 15:50:04 --> Security Class Initialized
DEBUG - 2017-11-20 15:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:50:04 --> Input Class Initialized
INFO - 2017-11-20 15:50:04 --> Language Class Initialized
INFO - 2017-11-20 15:50:04 --> Loader Class Initialized
INFO - 2017-11-20 15:50:04 --> Helper loaded: url_helper
INFO - 2017-11-20 15:50:04 --> Helper loaded: common_helper
INFO - 2017-11-20 15:50:04 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:50:04 --> Email Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Controller Class Initialized
INFO - 2017-11-20 15:50:04 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:50:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:50:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:50:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:50:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:50:04 --> Final output sent to browser
DEBUG - 2017-11-20 15:50:04 --> Total execution time: 0.0299
INFO - 2017-11-20 15:50:04 --> Config Class Initialized
INFO - 2017-11-20 15:50:04 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:50:04 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:50:04 --> Utf8 Class Initialized
INFO - 2017-11-20 15:50:04 --> URI Class Initialized
INFO - 2017-11-20 15:50:04 --> Router Class Initialized
INFO - 2017-11-20 15:50:04 --> Output Class Initialized
INFO - 2017-11-20 15:50:04 --> Security Class Initialized
DEBUG - 2017-11-20 15:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:50:04 --> Input Class Initialized
INFO - 2017-11-20 15:50:04 --> Language Class Initialized
INFO - 2017-11-20 15:50:04 --> Loader Class Initialized
INFO - 2017-11-20 15:50:04 --> Helper loaded: url_helper
INFO - 2017-11-20 15:50:04 --> Helper loaded: common_helper
INFO - 2017-11-20 15:50:04 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:50:04 --> Email Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Controller Class Initialized
INFO - 2017-11-20 15:50:04 --> Model Class Initialized
INFO - 2017-11-20 15:50:04 --> Final output sent to browser
DEBUG - 2017-11-20 15:50:04 --> Total execution time: 0.0019
INFO - 2017-11-20 15:50:05 --> Config Class Initialized
INFO - 2017-11-20 15:50:05 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:50:05 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:50:05 --> Utf8 Class Initialized
INFO - 2017-11-20 15:50:05 --> URI Class Initialized
INFO - 2017-11-20 15:50:05 --> Router Class Initialized
INFO - 2017-11-20 15:50:05 --> Output Class Initialized
INFO - 2017-11-20 15:50:05 --> Security Class Initialized
DEBUG - 2017-11-20 15:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:50:05 --> Input Class Initialized
INFO - 2017-11-20 15:50:05 --> Language Class Initialized
INFO - 2017-11-20 15:50:05 --> Loader Class Initialized
INFO - 2017-11-20 15:50:05 --> Helper loaded: url_helper
INFO - 2017-11-20 15:50:05 --> Helper loaded: common_helper
INFO - 2017-11-20 15:50:05 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:50:05 --> Email Class Initialized
INFO - 2017-11-20 15:50:05 --> Model Class Initialized
INFO - 2017-11-20 15:50:05 --> Controller Class Initialized
INFO - 2017-11-20 15:50:05 --> Final output sent to browser
DEBUG - 2017-11-20 15:50:05 --> Total execution time: 0.0016
INFO - 2017-11-20 15:51:20 --> Config Class Initialized
INFO - 2017-11-20 15:51:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:20 --> URI Class Initialized
INFO - 2017-11-20 15:51:20 --> Router Class Initialized
INFO - 2017-11-20 15:51:20 --> Output Class Initialized
INFO - 2017-11-20 15:51:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:20 --> Input Class Initialized
INFO - 2017-11-20 15:51:20 --> Language Class Initialized
INFO - 2017-11-20 15:51:20 --> Loader Class Initialized
INFO - 2017-11-20 15:51:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:20 --> Email Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Controller Class Initialized
INFO - 2017-11-20 15:51:20 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Config Class Initialized
INFO - 2017-11-20 15:51:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:20 --> URI Class Initialized
INFO - 2017-11-20 15:51:20 --> Router Class Initialized
INFO - 2017-11-20 15:51:20 --> Output Class Initialized
INFO - 2017-11-20 15:51:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:20 --> Input Class Initialized
INFO - 2017-11-20 15:51:20 --> Language Class Initialized
INFO - 2017-11-20 15:51:20 --> Loader Class Initialized
INFO - 2017-11-20 15:51:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:20 --> Email Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Controller Class Initialized
INFO - 2017-11-20 15:51:20 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> Model Class Initialized
INFO - 2017-11-20 15:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-20 15:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:51:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:51:20 --> Final output sent to browser
DEBUG - 2017-11-20 15:51:20 --> Total execution time: 0.0396
INFO - 2017-11-20 15:51:26 --> Config Class Initialized
INFO - 2017-11-20 15:51:26 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:26 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:26 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:26 --> URI Class Initialized
INFO - 2017-11-20 15:51:26 --> Router Class Initialized
INFO - 2017-11-20 15:51:26 --> Output Class Initialized
INFO - 2017-11-20 15:51:26 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:26 --> Input Class Initialized
INFO - 2017-11-20 15:51:26 --> Language Class Initialized
INFO - 2017-11-20 15:51:26 --> Loader Class Initialized
INFO - 2017-11-20 15:51:26 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:26 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:26 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:26 --> Email Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Controller Class Initialized
INFO - 2017-11-20 15:51:26 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Config Class Initialized
INFO - 2017-11-20 15:51:26 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:26 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:26 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:26 --> URI Class Initialized
INFO - 2017-11-20 15:51:26 --> Router Class Initialized
INFO - 2017-11-20 15:51:26 --> Output Class Initialized
INFO - 2017-11-20 15:51:26 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:26 --> Input Class Initialized
INFO - 2017-11-20 15:51:26 --> Language Class Initialized
INFO - 2017-11-20 15:51:26 --> Loader Class Initialized
INFO - 2017-11-20 15:51:26 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:26 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:26 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:26 --> Email Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Controller Class Initialized
INFO - 2017-11-20 15:51:26 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> Model Class Initialized
INFO - 2017-11-20 15:51:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:51:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:51:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-20 15:51:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:51:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:51:26 --> Final output sent to browser
DEBUG - 2017-11-20 15:51:26 --> Total execution time: 0.0191
INFO - 2017-11-20 15:51:33 --> Config Class Initialized
INFO - 2017-11-20 15:51:33 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:33 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:33 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:33 --> URI Class Initialized
INFO - 2017-11-20 15:51:33 --> Router Class Initialized
INFO - 2017-11-20 15:51:33 --> Output Class Initialized
INFO - 2017-11-20 15:51:33 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:33 --> Input Class Initialized
INFO - 2017-11-20 15:51:33 --> Language Class Initialized
INFO - 2017-11-20 15:51:33 --> Loader Class Initialized
INFO - 2017-11-20 15:51:33 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:33 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:33 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:33 --> Email Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Controller Class Initialized
INFO - 2017-11-20 15:51:33 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Config Class Initialized
INFO - 2017-11-20 15:51:33 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:33 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:33 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:33 --> URI Class Initialized
INFO - 2017-11-20 15:51:33 --> Router Class Initialized
INFO - 2017-11-20 15:51:33 --> Output Class Initialized
INFO - 2017-11-20 15:51:33 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:33 --> Input Class Initialized
INFO - 2017-11-20 15:51:33 --> Language Class Initialized
INFO - 2017-11-20 15:51:33 --> Loader Class Initialized
INFO - 2017-11-20 15:51:33 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:33 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:33 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:33 --> Email Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Controller Class Initialized
INFO - 2017-11-20 15:51:33 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> Model Class Initialized
INFO - 2017-11-20 15:51:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:51:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:51:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-20 15:51:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:51:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:51:33 --> Final output sent to browser
DEBUG - 2017-11-20 15:51:33 --> Total execution time: 0.0269
INFO - 2017-11-20 15:51:59 --> Config Class Initialized
INFO - 2017-11-20 15:51:59 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:51:59 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:51:59 --> Utf8 Class Initialized
INFO - 2017-11-20 15:51:59 --> URI Class Initialized
INFO - 2017-11-20 15:51:59 --> Router Class Initialized
INFO - 2017-11-20 15:51:59 --> Output Class Initialized
INFO - 2017-11-20 15:51:59 --> Security Class Initialized
DEBUG - 2017-11-20 15:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:51:59 --> Input Class Initialized
INFO - 2017-11-20 15:51:59 --> Language Class Initialized
INFO - 2017-11-20 15:51:59 --> Loader Class Initialized
INFO - 2017-11-20 15:51:59 --> Helper loaded: url_helper
INFO - 2017-11-20 15:51:59 --> Helper loaded: common_helper
INFO - 2017-11-20 15:51:59 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:51:59 --> Email Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Controller Class Initialized
INFO - 2017-11-20 15:51:59 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:51:59 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Config Class Initialized
INFO - 2017-11-20 15:52:00 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:00 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:00 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:00 --> URI Class Initialized
INFO - 2017-11-20 15:52:00 --> Router Class Initialized
INFO - 2017-11-20 15:52:00 --> Output Class Initialized
INFO - 2017-11-20 15:52:00 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:00 --> Input Class Initialized
INFO - 2017-11-20 15:52:00 --> Language Class Initialized
INFO - 2017-11-20 15:52:00 --> Loader Class Initialized
INFO - 2017-11-20 15:52:00 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:00 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:00 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:00 --> Email Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Controller Class Initialized
INFO - 2017-11-20 15:52:00 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> Model Class Initialized
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:52:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:52:00 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:00 --> Total execution time: 0.0700
INFO - 2017-11-20 15:52:00 --> Config Class Initialized
INFO - 2017-11-20 15:52:00 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:00 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:00 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:00 --> URI Class Initialized
INFO - 2017-11-20 15:52:00 --> Router Class Initialized
INFO - 2017-11-20 15:52:00 --> Output Class Initialized
INFO - 2017-11-20 15:52:00 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:00 --> Input Class Initialized
INFO - 2017-11-20 15:52:00 --> Language Class Initialized
ERROR - 2017-11-20 15:52:00 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:06 --> Config Class Initialized
INFO - 2017-11-20 15:52:06 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:06 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:06 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:06 --> URI Class Initialized
INFO - 2017-11-20 15:52:06 --> Router Class Initialized
INFO - 2017-11-20 15:52:06 --> Output Class Initialized
INFO - 2017-11-20 15:52:06 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:06 --> Input Class Initialized
INFO - 2017-11-20 15:52:06 --> Language Class Initialized
INFO - 2017-11-20 15:52:06 --> Loader Class Initialized
INFO - 2017-11-20 15:52:06 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:06 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:06 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:06 --> Email Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Controller Class Initialized
INFO - 2017-11-20 15:52:06 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:52:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:52:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:52:06 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:06 --> Total execution time: 0.0330
INFO - 2017-11-20 15:52:06 --> Config Class Initialized
INFO - 2017-11-20 15:52:06 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:06 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:06 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:06 --> URI Class Initialized
INFO - 2017-11-20 15:52:06 --> Router Class Initialized
INFO - 2017-11-20 15:52:06 --> Output Class Initialized
INFO - 2017-11-20 15:52:06 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:06 --> Input Class Initialized
INFO - 2017-11-20 15:52:06 --> Language Class Initialized
ERROR - 2017-11-20 15:52:06 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:06 --> Config Class Initialized
INFO - 2017-11-20 15:52:06 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:06 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:06 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:06 --> URI Class Initialized
INFO - 2017-11-20 15:52:06 --> Router Class Initialized
INFO - 2017-11-20 15:52:06 --> Output Class Initialized
INFO - 2017-11-20 15:52:06 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:06 --> Input Class Initialized
INFO - 2017-11-20 15:52:06 --> Language Class Initialized
INFO - 2017-11-20 15:52:06 --> Loader Class Initialized
INFO - 2017-11-20 15:52:06 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:06 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:06 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:06 --> Email Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Controller Class Initialized
INFO - 2017-11-20 15:52:06 --> Model Class Initialized
INFO - 2017-11-20 15:52:06 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:06 --> Total execution time: 0.0034
INFO - 2017-11-20 15:52:17 --> Config Class Initialized
INFO - 2017-11-20 15:52:17 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:17 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:17 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:17 --> URI Class Initialized
INFO - 2017-11-20 15:52:17 --> Router Class Initialized
INFO - 2017-11-20 15:52:17 --> Output Class Initialized
INFO - 2017-11-20 15:52:17 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:17 --> Input Class Initialized
INFO - 2017-11-20 15:52:17 --> Language Class Initialized
INFO - 2017-11-20 15:52:17 --> Loader Class Initialized
INFO - 2017-11-20 15:52:17 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:17 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:17 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:17 --> Email Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Controller Class Initialized
INFO - 2017-11-20 15:52:17 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> Model Class Initialized
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/public_library.php
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:52:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:52:17 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:17 --> Total execution time: 0.0643
INFO - 2017-11-20 15:52:17 --> Config Class Initialized
INFO - 2017-11-20 15:52:17 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:17 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:17 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:17 --> URI Class Initialized
INFO - 2017-11-20 15:52:17 --> Router Class Initialized
INFO - 2017-11-20 15:52:17 --> Output Class Initialized
INFO - 2017-11-20 15:52:17 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:17 --> Input Class Initialized
INFO - 2017-11-20 15:52:17 --> Language Class Initialized
ERROR - 2017-11-20 15:52:17 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:19 --> Config Class Initialized
INFO - 2017-11-20 15:52:19 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:19 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:19 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:19 --> URI Class Initialized
INFO - 2017-11-20 15:52:19 --> Router Class Initialized
INFO - 2017-11-20 15:52:19 --> Output Class Initialized
INFO - 2017-11-20 15:52:19 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:19 --> Input Class Initialized
INFO - 2017-11-20 15:52:19 --> Language Class Initialized
INFO - 2017-11-20 15:52:19 --> Loader Class Initialized
INFO - 2017-11-20 15:52:19 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:19 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:19 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:19 --> Email Class Initialized
INFO - 2017-11-20 15:52:19 --> Model Class Initialized
INFO - 2017-11-20 15:52:19 --> Controller Class Initialized
INFO - 2017-11-20 15:52:19 --> Model Class Initialized
INFO - 2017-11-20 15:52:19 --> Model Class Initialized
INFO - 2017-11-20 15:52:19 --> Model Class Initialized
INFO - 2017-11-20 15:52:19 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:19 --> Total execution time: 0.1184
INFO - 2017-11-20 15:52:20 --> Config Class Initialized
INFO - 2017-11-20 15:52:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:20 --> URI Class Initialized
INFO - 2017-11-20 15:52:20 --> Router Class Initialized
INFO - 2017-11-20 15:52:20 --> Output Class Initialized
INFO - 2017-11-20 15:52:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:20 --> Input Class Initialized
INFO - 2017-11-20 15:52:20 --> Language Class Initialized
INFO - 2017-11-20 15:52:20 --> Loader Class Initialized
INFO - 2017-11-20 15:52:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:20 --> Email Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Controller Class Initialized
INFO - 2017-11-20 15:52:20 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:52:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:52:20 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:20 --> Total execution time: 0.0985
INFO - 2017-11-20 15:52:20 --> Config Class Initialized
INFO - 2017-11-20 15:52:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:20 --> URI Class Initialized
INFO - 2017-11-20 15:52:20 --> Router Class Initialized
INFO - 2017-11-20 15:52:20 --> Output Class Initialized
INFO - 2017-11-20 15:52:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:20 --> Input Class Initialized
INFO - 2017-11-20 15:52:20 --> Language Class Initialized
ERROR - 2017-11-20 15:52:20 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:20 --> Config Class Initialized
INFO - 2017-11-20 15:52:20 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:20 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:20 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:20 --> URI Class Initialized
INFO - 2017-11-20 15:52:20 --> Router Class Initialized
INFO - 2017-11-20 15:52:20 --> Output Class Initialized
INFO - 2017-11-20 15:52:20 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:20 --> Input Class Initialized
INFO - 2017-11-20 15:52:20 --> Language Class Initialized
INFO - 2017-11-20 15:52:20 --> Loader Class Initialized
INFO - 2017-11-20 15:52:20 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:20 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:20 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:20 --> Email Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Controller Class Initialized
INFO - 2017-11-20 15:52:20 --> Model Class Initialized
INFO - 2017-11-20 15:52:20 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:20 --> Total execution time: 0.0022
INFO - 2017-11-20 15:52:28 --> Config Class Initialized
INFO - 2017-11-20 15:52:28 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:28 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:28 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:28 --> URI Class Initialized
INFO - 2017-11-20 15:52:28 --> Router Class Initialized
INFO - 2017-11-20 15:52:28 --> Output Class Initialized
INFO - 2017-11-20 15:52:28 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:28 --> Input Class Initialized
INFO - 2017-11-20 15:52:28 --> Language Class Initialized
INFO - 2017-11-20 15:52:28 --> Loader Class Initialized
INFO - 2017-11-20 15:52:28 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:28 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:28 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:28 --> Email Class Initialized
INFO - 2017-11-20 15:52:28 --> Model Class Initialized
INFO - 2017-11-20 15:52:28 --> Controller Class Initialized
INFO - 2017-11-20 15:52:28 --> Model Class Initialized
INFO - 2017-11-20 15:52:28 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:28 --> Total execution time: 0.0020
INFO - 2017-11-20 15:52:29 --> Config Class Initialized
INFO - 2017-11-20 15:52:29 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:29 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:29 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:29 --> URI Class Initialized
INFO - 2017-11-20 15:52:29 --> Router Class Initialized
INFO - 2017-11-20 15:52:29 --> Output Class Initialized
INFO - 2017-11-20 15:52:29 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:29 --> Input Class Initialized
INFO - 2017-11-20 15:52:29 --> Language Class Initialized
INFO - 2017-11-20 15:52:29 --> Loader Class Initialized
INFO - 2017-11-20 15:52:29 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:29 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:29 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:29 --> Email Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Controller Class Initialized
INFO - 2017-11-20 15:52:29 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Config Class Initialized
INFO - 2017-11-20 15:52:29 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:29 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:29 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:29 --> URI Class Initialized
DEBUG - 2017-11-20 15:52:29 --> No URI present. Default controller set.
INFO - 2017-11-20 15:52:29 --> Router Class Initialized
INFO - 2017-11-20 15:52:29 --> Output Class Initialized
INFO - 2017-11-20 15:52:29 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:29 --> Input Class Initialized
INFO - 2017-11-20 15:52:29 --> Language Class Initialized
INFO - 2017-11-20 15:52:29 --> Loader Class Initialized
INFO - 2017-11-20 15:52:29 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:29 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:29 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:29 --> Email Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Controller Class Initialized
INFO - 2017-11-20 15:52:29 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> Model Class Initialized
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:52:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:52:29 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:29 --> Total execution time: 0.0172
INFO - 2017-11-20 15:52:29 --> Config Class Initialized
INFO - 2017-11-20 15:52:29 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:29 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:29 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:29 --> URI Class Initialized
INFO - 2017-11-20 15:52:29 --> Router Class Initialized
INFO - 2017-11-20 15:52:29 --> Output Class Initialized
INFO - 2017-11-20 15:52:29 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:29 --> Input Class Initialized
INFO - 2017-11-20 15:52:29 --> Language Class Initialized
ERROR - 2017-11-20 15:52:29 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:31 --> Config Class Initialized
INFO - 2017-11-20 15:52:31 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:31 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:31 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:31 --> URI Class Initialized
INFO - 2017-11-20 15:52:31 --> Router Class Initialized
INFO - 2017-11-20 15:52:31 --> Output Class Initialized
INFO - 2017-11-20 15:52:31 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:31 --> Input Class Initialized
INFO - 2017-11-20 15:52:31 --> Language Class Initialized
INFO - 2017-11-20 15:52:31 --> Loader Class Initialized
INFO - 2017-11-20 15:52:31 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:31 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:31 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:31 --> Email Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Controller Class Initialized
INFO - 2017-11-20 15:52:31 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:52:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:52:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:52:31 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:31 --> Total execution time: 0.0236
INFO - 2017-11-20 15:52:31 --> Config Class Initialized
INFO - 2017-11-20 15:52:31 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:31 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:31 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:31 --> URI Class Initialized
INFO - 2017-11-20 15:52:31 --> Router Class Initialized
INFO - 2017-11-20 15:52:31 --> Output Class Initialized
INFO - 2017-11-20 15:52:31 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:31 --> Input Class Initialized
INFO - 2017-11-20 15:52:31 --> Language Class Initialized
ERROR - 2017-11-20 15:52:31 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:31 --> Config Class Initialized
INFO - 2017-11-20 15:52:31 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:31 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:31 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:31 --> URI Class Initialized
INFO - 2017-11-20 15:52:31 --> Router Class Initialized
INFO - 2017-11-20 15:52:31 --> Output Class Initialized
INFO - 2017-11-20 15:52:31 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:31 --> Input Class Initialized
INFO - 2017-11-20 15:52:31 --> Language Class Initialized
INFO - 2017-11-20 15:52:31 --> Loader Class Initialized
INFO - 2017-11-20 15:52:31 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:31 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:31 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:31 --> Email Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Controller Class Initialized
INFO - 2017-11-20 15:52:31 --> Model Class Initialized
INFO - 2017-11-20 15:52:31 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:31 --> Total execution time: 0.0020
INFO - 2017-11-20 15:52:34 --> Config Class Initialized
INFO - 2017-11-20 15:52:34 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:34 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:34 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:34 --> URI Class Initialized
INFO - 2017-11-20 15:52:34 --> Router Class Initialized
INFO - 2017-11-20 15:52:34 --> Output Class Initialized
INFO - 2017-11-20 15:52:34 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:34 --> Input Class Initialized
INFO - 2017-11-20 15:52:34 --> Language Class Initialized
INFO - 2017-11-20 15:52:34 --> Loader Class Initialized
INFO - 2017-11-20 15:52:34 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:34 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:34 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:34 --> Email Class Initialized
INFO - 2017-11-20 15:52:34 --> Model Class Initialized
INFO - 2017-11-20 15:52:34 --> Controller Class Initialized
INFO - 2017-11-20 15:52:34 --> Model Class Initialized
INFO - 2017-11-20 15:52:34 --> Config Class Initialized
INFO - 2017-11-20 15:52:34 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:34 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:34 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:34 --> URI Class Initialized
INFO - 2017-11-20 15:52:34 --> Router Class Initialized
INFO - 2017-11-20 15:52:34 --> Output Class Initialized
INFO - 2017-11-20 15:52:34 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:34 --> Input Class Initialized
INFO - 2017-11-20 15:52:34 --> Language Class Initialized
INFO - 2017-11-20 15:52:34 --> Loader Class Initialized
INFO - 2017-11-20 15:52:34 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:34 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:34 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:34 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:35 --> Total execution time: 0.1719
INFO - 2017-11-20 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:35 --> Email Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Controller Class Initialized
INFO - 2017-11-20 15:52:35 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:52:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:52:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:52:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:52:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:52:35 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:35 --> Total execution time: 0.2168
INFO - 2017-11-20 15:52:35 --> Config Class Initialized
INFO - 2017-11-20 15:52:35 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:35 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:35 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:35 --> URI Class Initialized
INFO - 2017-11-20 15:52:35 --> Router Class Initialized
INFO - 2017-11-20 15:52:35 --> Output Class Initialized
INFO - 2017-11-20 15:52:35 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:35 --> Input Class Initialized
INFO - 2017-11-20 15:52:35 --> Language Class Initialized
ERROR - 2017-11-20 15:52:35 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:52:35 --> Config Class Initialized
INFO - 2017-11-20 15:52:35 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:35 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:35 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:35 --> URI Class Initialized
INFO - 2017-11-20 15:52:35 --> Router Class Initialized
INFO - 2017-11-20 15:52:35 --> Output Class Initialized
INFO - 2017-11-20 15:52:35 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:35 --> Input Class Initialized
INFO - 2017-11-20 15:52:35 --> Language Class Initialized
INFO - 2017-11-20 15:52:35 --> Loader Class Initialized
INFO - 2017-11-20 15:52:35 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:35 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:35 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:35 --> Email Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Controller Class Initialized
INFO - 2017-11-20 15:52:35 --> Model Class Initialized
INFO - 2017-11-20 15:52:35 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:35 --> Total execution time: 0.0028
INFO - 2017-11-20 15:52:39 --> Config Class Initialized
INFO - 2017-11-20 15:52:39 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:52:39 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:52:39 --> Utf8 Class Initialized
INFO - 2017-11-20 15:52:39 --> URI Class Initialized
INFO - 2017-11-20 15:52:39 --> Router Class Initialized
INFO - 2017-11-20 15:52:39 --> Output Class Initialized
INFO - 2017-11-20 15:52:39 --> Security Class Initialized
DEBUG - 2017-11-20 15:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:52:39 --> Input Class Initialized
INFO - 2017-11-20 15:52:39 --> Language Class Initialized
INFO - 2017-11-20 15:52:39 --> Loader Class Initialized
INFO - 2017-11-20 15:52:39 --> Helper loaded: url_helper
INFO - 2017-11-20 15:52:39 --> Helper loaded: common_helper
INFO - 2017-11-20 15:52:39 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:52:39 --> Email Class Initialized
INFO - 2017-11-20 15:52:39 --> Model Class Initialized
INFO - 2017-11-20 15:52:39 --> Controller Class Initialized
INFO - 2017-11-20 15:52:39 --> Final output sent to browser
DEBUG - 2017-11-20 15:52:39 --> Total execution time: 0.0024
INFO - 2017-11-20 15:55:05 --> Config Class Initialized
INFO - 2017-11-20 15:55:05 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:05 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:05 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:05 --> URI Class Initialized
INFO - 2017-11-20 15:55:05 --> Router Class Initialized
INFO - 2017-11-20 15:55:05 --> Output Class Initialized
INFO - 2017-11-20 15:55:05 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:05 --> Input Class Initialized
INFO - 2017-11-20 15:55:05 --> Language Class Initialized
INFO - 2017-11-20 15:55:05 --> Loader Class Initialized
INFO - 2017-11-20 15:55:05 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:05 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:05 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:05 --> Email Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Controller Class Initialized
INFO - 2017-11-20 15:55:05 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> Model Class Initialized
INFO - 2017-11-20 15:55:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:55:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:55:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:55:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:55:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:55:05 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:05 --> Total execution time: 0.0270
INFO - 2017-11-20 15:55:05 --> Config Class Initialized
INFO - 2017-11-20 15:55:05 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:05 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:05 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:05 --> URI Class Initialized
INFO - 2017-11-20 15:55:05 --> Router Class Initialized
INFO - 2017-11-20 15:55:05 --> Output Class Initialized
INFO - 2017-11-20 15:55:05 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:05 --> Input Class Initialized
INFO - 2017-11-20 15:55:05 --> Language Class Initialized
ERROR - 2017-11-20 15:55:05 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:55:06 --> Config Class Initialized
INFO - 2017-11-20 15:55:06 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:06 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:06 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:06 --> URI Class Initialized
INFO - 2017-11-20 15:55:06 --> Router Class Initialized
INFO - 2017-11-20 15:55:06 --> Output Class Initialized
INFO - 2017-11-20 15:55:06 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:06 --> Input Class Initialized
INFO - 2017-11-20 15:55:06 --> Language Class Initialized
INFO - 2017-11-20 15:55:06 --> Loader Class Initialized
INFO - 2017-11-20 15:55:06 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:06 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:06 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:06 --> Email Class Initialized
INFO - 2017-11-20 15:55:06 --> Model Class Initialized
INFO - 2017-11-20 15:55:06 --> Controller Class Initialized
INFO - 2017-11-20 15:55:06 --> Model Class Initialized
INFO - 2017-11-20 15:55:06 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:06 --> Total execution time: 0.0017
INFO - 2017-11-20 15:55:07 --> Config Class Initialized
INFO - 2017-11-20 15:55:07 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:07 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:07 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:07 --> URI Class Initialized
INFO - 2017-11-20 15:55:07 --> Router Class Initialized
INFO - 2017-11-20 15:55:07 --> Output Class Initialized
INFO - 2017-11-20 15:55:07 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:07 --> Input Class Initialized
INFO - 2017-11-20 15:55:07 --> Language Class Initialized
INFO - 2017-11-20 15:55:07 --> Loader Class Initialized
INFO - 2017-11-20 15:55:07 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:07 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:07 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:07 --> Email Class Initialized
INFO - 2017-11-20 15:55:07 --> Model Class Initialized
INFO - 2017-11-20 15:55:07 --> Controller Class Initialized
INFO - 2017-11-20 15:55:07 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:07 --> Total execution time: 0.0022
INFO - 2017-11-20 15:55:23 --> Config Class Initialized
INFO - 2017-11-20 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:23 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:23 --> URI Class Initialized
INFO - 2017-11-20 15:55:23 --> Router Class Initialized
INFO - 2017-11-20 15:55:23 --> Output Class Initialized
INFO - 2017-11-20 15:55:23 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:23 --> Input Class Initialized
INFO - 2017-11-20 15:55:23 --> Language Class Initialized
INFO - 2017-11-20 15:55:23 --> Loader Class Initialized
INFO - 2017-11-20 15:55:23 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:23 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:23 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:23 --> Email Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Controller Class Initialized
INFO - 2017-11-20 15:55:23 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:55:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:55:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:55:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:55:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:55:23 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:23 --> Total execution time: 0.0284
INFO - 2017-11-20 15:55:23 --> Config Class Initialized
INFO - 2017-11-20 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:23 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:23 --> URI Class Initialized
INFO - 2017-11-20 15:55:23 --> Router Class Initialized
INFO - 2017-11-20 15:55:23 --> Output Class Initialized
INFO - 2017-11-20 15:55:23 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:23 --> Input Class Initialized
INFO - 2017-11-20 15:55:23 --> Language Class Initialized
ERROR - 2017-11-20 15:55:23 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:55:23 --> Config Class Initialized
INFO - 2017-11-20 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:23 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:23 --> URI Class Initialized
INFO - 2017-11-20 15:55:23 --> Router Class Initialized
INFO - 2017-11-20 15:55:23 --> Output Class Initialized
INFO - 2017-11-20 15:55:23 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:23 --> Input Class Initialized
INFO - 2017-11-20 15:55:23 --> Language Class Initialized
INFO - 2017-11-20 15:55:23 --> Loader Class Initialized
INFO - 2017-11-20 15:55:23 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:23 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:23 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:23 --> Email Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Controller Class Initialized
INFO - 2017-11-20 15:55:23 --> Model Class Initialized
INFO - 2017-11-20 15:55:23 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:23 --> Total execution time: 0.0035
INFO - 2017-11-20 15:55:25 --> Config Class Initialized
INFO - 2017-11-20 15:55:25 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:25 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:25 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:25 --> URI Class Initialized
INFO - 2017-11-20 15:55:25 --> Router Class Initialized
INFO - 2017-11-20 15:55:25 --> Output Class Initialized
INFO - 2017-11-20 15:55:25 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:25 --> Input Class Initialized
INFO - 2017-11-20 15:55:25 --> Language Class Initialized
INFO - 2017-11-20 15:55:25 --> Loader Class Initialized
INFO - 2017-11-20 15:55:25 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:25 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:25 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:25 --> Email Class Initialized
INFO - 2017-11-20 15:55:25 --> Model Class Initialized
INFO - 2017-11-20 15:55:25 --> Controller Class Initialized
INFO - 2017-11-20 15:55:25 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:25 --> Total execution time: 0.0031
INFO - 2017-11-20 15:55:41 --> Config Class Initialized
INFO - 2017-11-20 15:55:41 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:41 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:41 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:41 --> URI Class Initialized
INFO - 2017-11-20 15:55:41 --> Router Class Initialized
INFO - 2017-11-20 15:55:41 --> Output Class Initialized
INFO - 2017-11-20 15:55:41 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:41 --> Input Class Initialized
INFO - 2017-11-20 15:55:41 --> Language Class Initialized
INFO - 2017-11-20 15:55:41 --> Loader Class Initialized
INFO - 2017-11-20 15:55:41 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:41 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:41 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:41 --> Email Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Controller Class Initialized
INFO - 2017-11-20 15:55:41 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> Model Class Initialized
INFO - 2017-11-20 15:55:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:55:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:55:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:55:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:55:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:55:41 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:41 --> Total execution time: 0.1104
INFO - 2017-11-20 15:55:41 --> Config Class Initialized
INFO - 2017-11-20 15:55:41 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:41 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:41 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:41 --> URI Class Initialized
INFO - 2017-11-20 15:55:41 --> Router Class Initialized
INFO - 2017-11-20 15:55:41 --> Output Class Initialized
INFO - 2017-11-20 15:55:41 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:41 --> Input Class Initialized
INFO - 2017-11-20 15:55:41 --> Language Class Initialized
ERROR - 2017-11-20 15:55:41 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:55:42 --> Config Class Initialized
INFO - 2017-11-20 15:55:42 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:42 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:42 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:42 --> URI Class Initialized
INFO - 2017-11-20 15:55:42 --> Router Class Initialized
INFO - 2017-11-20 15:55:42 --> Output Class Initialized
INFO - 2017-11-20 15:55:42 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:42 --> Input Class Initialized
INFO - 2017-11-20 15:55:42 --> Language Class Initialized
INFO - 2017-11-20 15:55:42 --> Loader Class Initialized
INFO - 2017-11-20 15:55:42 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:42 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:42 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:42 --> Email Class Initialized
INFO - 2017-11-20 15:55:42 --> Model Class Initialized
INFO - 2017-11-20 15:55:42 --> Controller Class Initialized
INFO - 2017-11-20 15:55:42 --> Model Class Initialized
INFO - 2017-11-20 15:55:42 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:42 --> Total execution time: 0.0083
INFO - 2017-11-20 15:55:45 --> Config Class Initialized
INFO - 2017-11-20 15:55:45 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:45 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:45 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:45 --> URI Class Initialized
INFO - 2017-11-20 15:55:45 --> Router Class Initialized
INFO - 2017-11-20 15:55:45 --> Output Class Initialized
INFO - 2017-11-20 15:55:45 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:45 --> Input Class Initialized
INFO - 2017-11-20 15:55:45 --> Language Class Initialized
INFO - 2017-11-20 15:55:45 --> Loader Class Initialized
INFO - 2017-11-20 15:55:45 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:45 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:45 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:45 --> Email Class Initialized
INFO - 2017-11-20 15:55:45 --> Model Class Initialized
INFO - 2017-11-20 15:55:45 --> Controller Class Initialized
INFO - 2017-11-20 15:55:45 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:45 --> Total execution time: 0.0079
INFO - 2017-11-20 15:55:57 --> Config Class Initialized
INFO - 2017-11-20 15:55:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:57 --> URI Class Initialized
INFO - 2017-11-20 15:55:57 --> Router Class Initialized
INFO - 2017-11-20 15:55:57 --> Output Class Initialized
INFO - 2017-11-20 15:55:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:57 --> Input Class Initialized
INFO - 2017-11-20 15:55:57 --> Language Class Initialized
INFO - 2017-11-20 15:55:57 --> Loader Class Initialized
INFO - 2017-11-20 15:55:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:57 --> Email Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Controller Class Initialized
INFO - 2017-11-20 15:55:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Config Class Initialized
INFO - 2017-11-20 15:55:57 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:55:57 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:55:57 --> Utf8 Class Initialized
INFO - 2017-11-20 15:55:57 --> URI Class Initialized
INFO - 2017-11-20 15:55:57 --> Router Class Initialized
INFO - 2017-11-20 15:55:57 --> Output Class Initialized
INFO - 2017-11-20 15:55:57 --> Security Class Initialized
DEBUG - 2017-11-20 15:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:55:57 --> Input Class Initialized
INFO - 2017-11-20 15:55:57 --> Language Class Initialized
INFO - 2017-11-20 15:55:57 --> Loader Class Initialized
INFO - 2017-11-20 15:55:57 --> Helper loaded: url_helper
INFO - 2017-11-20 15:55:57 --> Helper loaded: common_helper
INFO - 2017-11-20 15:55:57 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:55:57 --> Email Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Controller Class Initialized
INFO - 2017-11-20 15:55:57 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> Model Class Initialized
INFO - 2017-11-20 15:55:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:55:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:55:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-11-20 15:55:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:55:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:55:57 --> Final output sent to browser
DEBUG - 2017-11-20 15:55:57 --> Total execution time: 0.0302
INFO - 2017-11-20 15:56:03 --> Config Class Initialized
INFO - 2017-11-20 15:56:03 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:03 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:03 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:03 --> URI Class Initialized
INFO - 2017-11-20 15:56:03 --> Router Class Initialized
INFO - 2017-11-20 15:56:03 --> Output Class Initialized
INFO - 2017-11-20 15:56:03 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:03 --> Input Class Initialized
INFO - 2017-11-20 15:56:03 --> Language Class Initialized
INFO - 2017-11-20 15:56:03 --> Loader Class Initialized
INFO - 2017-11-20 15:56:03 --> Helper loaded: url_helper
INFO - 2017-11-20 15:56:03 --> Helper loaded: common_helper
INFO - 2017-11-20 15:56:03 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:56:03 --> Email Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Controller Class Initialized
INFO - 2017-11-20 15:56:03 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Config Class Initialized
INFO - 2017-11-20 15:56:03 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:03 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:03 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:03 --> URI Class Initialized
INFO - 2017-11-20 15:56:03 --> Router Class Initialized
INFO - 2017-11-20 15:56:03 --> Output Class Initialized
INFO - 2017-11-20 15:56:03 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:03 --> Input Class Initialized
INFO - 2017-11-20 15:56:03 --> Language Class Initialized
INFO - 2017-11-20 15:56:03 --> Loader Class Initialized
INFO - 2017-11-20 15:56:03 --> Helper loaded: url_helper
INFO - 2017-11-20 15:56:03 --> Helper loaded: common_helper
INFO - 2017-11-20 15:56:03 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:56:03 --> Email Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Controller Class Initialized
INFO - 2017-11-20 15:56:03 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> Model Class Initialized
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-20 15:56:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-20 15:56:03 --> Final output sent to browser
DEBUG - 2017-11-20 15:56:03 --> Total execution time: 0.0465
INFO - 2017-11-20 15:56:03 --> Config Class Initialized
INFO - 2017-11-20 15:56:03 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:03 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:03 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:03 --> URI Class Initialized
INFO - 2017-11-20 15:56:03 --> Router Class Initialized
INFO - 2017-11-20 15:56:03 --> Output Class Initialized
INFO - 2017-11-20 15:56:03 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:03 --> Input Class Initialized
INFO - 2017-11-20 15:56:03 --> Language Class Initialized
ERROR - 2017-11-20 15:56:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-20 15:56:05 --> Config Class Initialized
INFO - 2017-11-20 15:56:05 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:05 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:05 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:05 --> URI Class Initialized
INFO - 2017-11-20 15:56:05 --> Router Class Initialized
INFO - 2017-11-20 15:56:05 --> Output Class Initialized
INFO - 2017-11-20 15:56:05 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:05 --> Input Class Initialized
INFO - 2017-11-20 15:56:05 --> Language Class Initialized
INFO - 2017-11-20 15:56:05 --> Loader Class Initialized
INFO - 2017-11-20 15:56:05 --> Helper loaded: url_helper
INFO - 2017-11-20 15:56:05 --> Helper loaded: common_helper
INFO - 2017-11-20 15:56:05 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:56:05 --> Email Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Controller Class Initialized
INFO - 2017-11-20 15:56:05 --> Helper loaded: cookie_helper
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> Model Class Initialized
INFO - 2017-11-20 15:56:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-20 15:56:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-20 15:56:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-11-20 15:56:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-11-20 15:56:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-11-20 15:56:05 --> Final output sent to browser
DEBUG - 2017-11-20 15:56:05 --> Total execution time: 0.0535
INFO - 2017-11-20 15:56:06 --> Config Class Initialized
INFO - 2017-11-20 15:56:06 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:06 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:06 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:06 --> URI Class Initialized
INFO - 2017-11-20 15:56:06 --> Router Class Initialized
INFO - 2017-11-20 15:56:06 --> Output Class Initialized
INFO - 2017-11-20 15:56:06 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:06 --> Input Class Initialized
INFO - 2017-11-20 15:56:06 --> Language Class Initialized
INFO - 2017-11-20 15:56:06 --> Loader Class Initialized
INFO - 2017-11-20 15:56:06 --> Helper loaded: url_helper
INFO - 2017-11-20 15:56:06 --> Helper loaded: common_helper
INFO - 2017-11-20 15:56:06 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:56:06 --> Email Class Initialized
INFO - 2017-11-20 15:56:06 --> Model Class Initialized
INFO - 2017-11-20 15:56:06 --> Controller Class Initialized
INFO - 2017-11-20 15:56:06 --> Model Class Initialized
INFO - 2017-11-20 15:56:06 --> Final output sent to browser
DEBUG - 2017-11-20 15:56:06 --> Total execution time: 0.0047
INFO - 2017-11-20 15:56:08 --> Config Class Initialized
INFO - 2017-11-20 15:56:08 --> Hooks Class Initialized
DEBUG - 2017-11-20 15:56:08 --> UTF-8 Support Enabled
INFO - 2017-11-20 15:56:08 --> Utf8 Class Initialized
INFO - 2017-11-20 15:56:08 --> URI Class Initialized
INFO - 2017-11-20 15:56:08 --> Router Class Initialized
INFO - 2017-11-20 15:56:08 --> Output Class Initialized
INFO - 2017-11-20 15:56:08 --> Security Class Initialized
DEBUG - 2017-11-20 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-20 15:56:08 --> Input Class Initialized
INFO - 2017-11-20 15:56:08 --> Language Class Initialized
INFO - 2017-11-20 15:56:08 --> Loader Class Initialized
INFO - 2017-11-20 15:56:08 --> Helper loaded: url_helper
INFO - 2017-11-20 15:56:08 --> Helper loaded: common_helper
INFO - 2017-11-20 15:56:08 --> Database Driver Class Initialized
DEBUG - 2017-11-20 15:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-20 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-20 15:56:08 --> Email Class Initialized
INFO - 2017-11-20 15:56:08 --> Model Class Initialized
INFO - 2017-11-20 15:56:08 --> Controller Class Initialized
INFO - 2017-11-20 15:56:08 --> Final output sent to browser
DEBUG - 2017-11-20 15:56:08 --> Total execution time: 0.0042
