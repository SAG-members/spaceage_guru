<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-04 18:11:53 --> Config Class Initialized
INFO - 2017-11-04 18:11:53 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:11:53 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:11:53 --> Utf8 Class Initialized
INFO - 2017-11-04 18:11:53 --> URI Class Initialized
INFO - 2017-11-04 18:11:53 --> Router Class Initialized
INFO - 2017-11-04 18:11:53 --> Output Class Initialized
INFO - 2017-11-04 18:11:53 --> Security Class Initialized
DEBUG - 2017-11-04 18:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:11:53 --> Input Class Initialized
INFO - 2017-11-04 18:11:53 --> Language Class Initialized
INFO - 2017-11-04 18:11:53 --> Loader Class Initialized
INFO - 2017-11-04 18:11:53 --> Helper loaded: url_helper
INFO - 2017-11-04 18:11:53 --> Helper loaded: common_helper
INFO - 2017-11-04 18:11:53 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:11:53 --> Email Class Initialized
INFO - 2017-11-04 18:11:53 --> Model Class Initialized
INFO - 2017-11-04 18:11:53 --> Controller Class Initialized
INFO - 2017-11-04 18:11:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-11-04 18:11:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-11-04 18:11:53 --> Final output sent to browser
DEBUG - 2017-11-04 18:11:53 --> Total execution time: 0.1845
INFO - 2017-11-04 18:11:58 --> Config Class Initialized
INFO - 2017-11-04 18:11:58 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:11:58 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:11:58 --> Utf8 Class Initialized
INFO - 2017-11-04 18:11:58 --> URI Class Initialized
INFO - 2017-11-04 18:11:58 --> Router Class Initialized
INFO - 2017-11-04 18:11:58 --> Output Class Initialized
INFO - 2017-11-04 18:11:58 --> Security Class Initialized
DEBUG - 2017-11-04 18:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:11:58 --> Input Class Initialized
INFO - 2017-11-04 18:11:58 --> Language Class Initialized
INFO - 2017-11-04 18:11:58 --> Loader Class Initialized
INFO - 2017-11-04 18:11:58 --> Helper loaded: url_helper
INFO - 2017-11-04 18:11:58 --> Helper loaded: common_helper
INFO - 2017-11-04 18:11:58 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:11:58 --> Email Class Initialized
INFO - 2017-11-04 18:11:58 --> Model Class Initialized
INFO - 2017-11-04 18:11:58 --> Controller Class Initialized
INFO - 2017-11-04 18:11:58 --> Model Class Initialized
INFO - 2017-11-04 18:11:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-11-04 18:11:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-11-04 18:11:58 --> Final output sent to browser
DEBUG - 2017-11-04 18:11:58 --> Total execution time: 0.3846
INFO - 2017-11-04 18:12:03 --> Config Class Initialized
INFO - 2017-11-04 18:12:03 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:03 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:03 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:03 --> URI Class Initialized
INFO - 2017-11-04 18:12:03 --> Router Class Initialized
INFO - 2017-11-04 18:12:03 --> Output Class Initialized
INFO - 2017-11-04 18:12:03 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:03 --> Input Class Initialized
INFO - 2017-11-04 18:12:03 --> Language Class Initialized
INFO - 2017-11-04 18:12:03 --> Loader Class Initialized
INFO - 2017-11-04 18:12:03 --> Helper loaded: url_helper
INFO - 2017-11-04 18:12:03 --> Helper loaded: common_helper
INFO - 2017-11-04 18:12:03 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:12:03 --> Email Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Controller Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Config Class Initialized
INFO - 2017-11-04 18:12:03 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:03 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:03 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:03 --> URI Class Initialized
INFO - 2017-11-04 18:12:03 --> Router Class Initialized
INFO - 2017-11-04 18:12:03 --> Output Class Initialized
INFO - 2017-11-04 18:12:03 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:03 --> Input Class Initialized
INFO - 2017-11-04 18:12:03 --> Language Class Initialized
INFO - 2017-11-04 18:12:03 --> Loader Class Initialized
INFO - 2017-11-04 18:12:03 --> Helper loaded: url_helper
INFO - 2017-11-04 18:12:03 --> Helper loaded: common_helper
INFO - 2017-11-04 18:12:03 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:12:03 --> Email Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Controller Class Initialized
INFO - 2017-11-04 18:12:03 --> Helper loaded: cookie_helper
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-04 18:12:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> Model Class Initialized
INFO - 2017-11-04 18:12:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-11-04 18:12:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-04 18:12:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-04 18:12:03 --> Final output sent to browser
DEBUG - 2017-11-04 18:12:03 --> Total execution time: 0.2187
INFO - 2017-11-04 18:12:03 --> Config Class Initialized
INFO - 2017-11-04 18:12:03 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:03 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:03 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:03 --> URI Class Initialized
INFO - 2017-11-04 18:12:03 --> Router Class Initialized
INFO - 2017-11-04 18:12:03 --> Output Class Initialized
INFO - 2017-11-04 18:12:03 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:03 --> Input Class Initialized
INFO - 2017-11-04 18:12:03 --> Language Class Initialized
ERROR - 2017-11-04 18:12:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-04 18:12:03 --> Config Class Initialized
INFO - 2017-11-04 18:12:03 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:03 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:03 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:03 --> URI Class Initialized
INFO - 2017-11-04 18:12:03 --> Router Class Initialized
INFO - 2017-11-04 18:12:03 --> Output Class Initialized
INFO - 2017-11-04 18:12:03 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:03 --> Input Class Initialized
INFO - 2017-11-04 18:12:03 --> Language Class Initialized
ERROR - 2017-11-04 18:12:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
INFO - 2017-11-04 18:12:07 --> Loader Class Initialized
INFO - 2017-11-04 18:12:07 --> Helper loaded: url_helper
INFO - 2017-11-04 18:12:07 --> Helper loaded: common_helper
INFO - 2017-11-04 18:12:07 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:12:07 --> Email Class Initialized
INFO - 2017-11-04 18:12:07 --> Model Class Initialized
INFO - 2017-11-04 18:12:07 --> Controller Class Initialized
INFO - 2017-11-04 18:12:07 --> Helper loaded: cookie_helper
INFO - 2017-11-04 18:12:07 --> Model Class Initialized
INFO - 2017-11-04 18:12:07 --> Model Class Initialized
INFO - 2017-11-04 18:12:07 --> Model Class Initialized
INFO - 2017-11-04 18:12:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-04 18:12:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-11-04 18:12:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/manage_membership.php
INFO - 2017-11-04 18:12:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-04 18:12:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-04 18:12:07 --> Final output sent to browser
DEBUG - 2017-11-04 18:12:07 --> Total execution time: 0.0380
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:07 --> Config Class Initialized
INFO - 2017-11-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:07 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:07 --> URI Class Initialized
INFO - 2017-11-04 18:12:07 --> Router Class Initialized
INFO - 2017-11-04 18:12:07 --> Output Class Initialized
INFO - 2017-11-04 18:12:07 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:07 --> Input Class Initialized
INFO - 2017-11-04 18:12:07 --> Language Class Initialized
ERROR - 2017-11-04 18:12:07 --> 404 Page Not Found: Assets/admin
INFO - 2017-11-04 18:12:08 --> Config Class Initialized
INFO - 2017-11-04 18:12:08 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:08 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:08 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:08 --> URI Class Initialized
INFO - 2017-11-04 18:12:08 --> Router Class Initialized
INFO - 2017-11-04 18:12:08 --> Output Class Initialized
INFO - 2017-11-04 18:12:08 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:08 --> Input Class Initialized
INFO - 2017-11-04 18:12:08 --> Language Class Initialized
INFO - 2017-11-04 18:12:08 --> Loader Class Initialized
INFO - 2017-11-04 18:12:08 --> Helper loaded: url_helper
INFO - 2017-11-04 18:12:08 --> Helper loaded: common_helper
INFO - 2017-11-04 18:12:08 --> Database Driver Class Initialized
DEBUG - 2017-11-04 18:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-04 18:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-04 18:12:08 --> Email Class Initialized
INFO - 2017-11-04 18:12:08 --> Model Class Initialized
INFO - 2017-11-04 18:12:08 --> Controller Class Initialized
INFO - 2017-11-04 18:12:08 --> Helper loaded: cookie_helper
INFO - 2017-11-04 18:12:08 --> Model Class Initialized
INFO - 2017-11-04 18:12:08 --> Model Class Initialized
INFO - 2017-11-04 18:12:08 --> Model Class Initialized
INFO - 2017-11-04 18:12:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-11-04 18:12:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
ERROR - 2017-11-04 18:12:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 129
INFO - 2017-11-04 18:12:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-11-04 18:12:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-11-04 18:12:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-11-04 18:12:08 --> Final output sent to browser
DEBUG - 2017-11-04 18:12:08 --> Total execution time: 0.0148
INFO - 2017-11-04 18:12:08 --> Config Class Initialized
INFO - 2017-11-04 18:12:08 --> Hooks Class Initialized
DEBUG - 2017-11-04 18:12:08 --> UTF-8 Support Enabled
INFO - 2017-11-04 18:12:08 --> Utf8 Class Initialized
INFO - 2017-11-04 18:12:08 --> URI Class Initialized
INFO - 2017-11-04 18:12:08 --> Router Class Initialized
INFO - 2017-11-04 18:12:08 --> Output Class Initialized
INFO - 2017-11-04 18:12:08 --> Security Class Initialized
DEBUG - 2017-11-04 18:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-04 18:12:08 --> Input Class Initialized
INFO - 2017-11-04 18:12:08 --> Language Class Initialized
ERROR - 2017-11-04 18:12:08 --> 404 Page Not Found: Assets/uploads
