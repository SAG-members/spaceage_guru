<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-23 11:39:34 --> 404 Page Not Found: Assets/uploads
