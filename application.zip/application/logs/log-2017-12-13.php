<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 29
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 30
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 31
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 33
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 45
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 4
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 8
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 9
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 82
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 101
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 103
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 112
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 706
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 711
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 712
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 837
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 840
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 850
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 853
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 865
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 884
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 939
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 969
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 971
ERROR - 2017-12-13 10:01:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 1182
ERROR - 2017-12-13 10:01:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 10:02:27 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 10:02:58 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 29
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 30
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 31
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 33
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 45
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 4
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 8
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 9
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 82
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 101
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 103
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 112
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 706
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 711
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 712
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 837
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 840
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 850
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 853
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 865
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 884
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 896
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 939
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 969
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 971
ERROR - 2017-12-13 10:19:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/page.php 1182
ERROR - 2017-12-13 11:20:00 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file /var/www/html/spaceage_guru/application/views/templates/public/layouts/right_sidebar.php 248
ERROR - 2017-12-13 11:20:44 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 11:21:56 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 11:22:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 11:23:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-13 11:23:55 --> 404 Page Not Found: Assets/uploads
