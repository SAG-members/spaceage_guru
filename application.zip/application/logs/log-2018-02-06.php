<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 16:20:18 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:20:18 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:20:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:20:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:20:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:20:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:24:04 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 16:24:05 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-06 17:04:19 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php 9
