<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-12 10:23:53 --> 404 Page Not Found: Assets/uploads
