<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-08 11:15:17 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:16:58 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:17:17 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:17:41 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:17:57 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:39 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:49 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:49 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:51 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:23:51 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:26:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:26:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:27:44 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:27:44 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:28:08 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:28:08 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:28:35 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:28:35 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:29:22 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:29:22 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:29:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:29:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:30:47 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-12-08 11:30:47 --> 404 Page Not Found: Assets/uploads
