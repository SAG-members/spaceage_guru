<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-17 11:00:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-17 11:16:12 --> Severity: Notice --> Undefined property: Webservice_controller::$ques /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3425
ERROR - 2018-01-17 11:16:12 --> Severity: error --> Exception: Call to a member function get_user_questionnaire() on null /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3425
ERROR - 2018-01-17 11:25:39 --> Severity: Notice --> Undefined property: Webservice_controller::$ques /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3425
ERROR - 2018-01-17 11:25:39 --> Severity: error --> Exception: Call to a member function get_user_questionnaire() on null /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 3425
ERROR - 2018-01-17 11:26:02 --> Severity: Notice --> Undefined variable: countries /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php 12
ERROR - 2018-01-17 11:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php 12
ERROR - 2018-01-17 11:26:22 --> Severity: Notice --> Undefined variable: countries /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php 12
ERROR - 2018-01-17 11:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php 12
ERROR - 2018-01-17 13:39:11 --> 404 Page Not Found: Assets/uploads
