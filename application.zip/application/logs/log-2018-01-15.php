<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-15 10:03:52 --> Query error: Table 'spaceage_guru.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `id` = '27'
