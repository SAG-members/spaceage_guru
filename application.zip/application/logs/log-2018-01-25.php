<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-25 10:05:37 --> Severity: Notice --> Undefined variable: response /var/www/html/spaceage_guru/application/controllers/module/services/Page_controller.php 344
ERROR - 2018-01-25 10:05:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/spaceage_guru/application/libraries/Template.php 122
