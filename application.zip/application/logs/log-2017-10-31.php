<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-31 10:19:08 --> Config Class Initialized
INFO - 2017-10-31 10:19:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:19:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:19:08 --> Utf8 Class Initialized
INFO - 2017-10-31 10:19:08 --> URI Class Initialized
DEBUG - 2017-10-31 10:19:08 --> No URI present. Default controller set.
INFO - 2017-10-31 10:19:08 --> Router Class Initialized
INFO - 2017-10-31 10:19:08 --> Output Class Initialized
INFO - 2017-10-31 10:19:08 --> Security Class Initialized
DEBUG - 2017-10-31 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:19:08 --> Input Class Initialized
INFO - 2017-10-31 10:19:08 --> Language Class Initialized
INFO - 2017-10-31 10:19:08 --> Loader Class Initialized
INFO - 2017-10-31 10:19:08 --> Helper loaded: url_helper
INFO - 2017-10-31 10:19:08 --> Helper loaded: common_helper
INFO - 2017-10-31 10:19:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:19:08 --> Email Class Initialized
INFO - 2017-10-31 10:19:08 --> Model Class Initialized
INFO - 2017-10-31 10:19:08 --> Controller Class Initialized
INFO - 2017-10-31 10:19:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 10:19:08 --> Model Class Initialized
INFO - 2017-10-31 10:19:08 --> Model Class Initialized
INFO - 2017-10-31 10:19:08 --> Model Class Initialized
INFO - 2017-10-31 10:19:08 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> Model Class Initialized
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-31 10:19:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-31 10:19:09 --> Final output sent to browser
DEBUG - 2017-10-31 10:19:09 --> Total execution time: 0.9139
INFO - 2017-10-31 10:24:19 --> Config Class Initialized
INFO - 2017-10-31 10:24:19 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:24:19 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:24:19 --> Utf8 Class Initialized
INFO - 2017-10-31 10:24:19 --> URI Class Initialized
INFO - 2017-10-31 10:24:19 --> Router Class Initialized
INFO - 2017-10-31 10:24:19 --> Output Class Initialized
INFO - 2017-10-31 10:24:19 --> Security Class Initialized
DEBUG - 2017-10-31 10:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:24:19 --> Input Class Initialized
INFO - 2017-10-31 10:24:19 --> Language Class Initialized
INFO - 2017-10-31 10:24:19 --> Loader Class Initialized
INFO - 2017-10-31 10:24:19 --> Helper loaded: url_helper
INFO - 2017-10-31 10:24:19 --> Helper loaded: common_helper
INFO - 2017-10-31 10:24:19 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:24:19 --> Email Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Controller Class Initialized
INFO - 2017-10-31 10:24:19 --> Helper loaded: cookie_helper
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> Model Class Initialized
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-31 10:24:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-31 10:24:19 --> Final output sent to browser
DEBUG - 2017-10-31 10:24:19 --> Total execution time: 0.0899
INFO - 2017-10-31 10:24:22 --> Config Class Initialized
INFO - 2017-10-31 10:24:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:24:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:24:22 --> Utf8 Class Initialized
INFO - 2017-10-31 10:24:22 --> URI Class Initialized
INFO - 2017-10-31 10:24:22 --> Router Class Initialized
INFO - 2017-10-31 10:24:22 --> Output Class Initialized
INFO - 2017-10-31 10:24:22 --> Security Class Initialized
DEBUG - 2017-10-31 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:24:22 --> Input Class Initialized
INFO - 2017-10-31 10:24:22 --> Language Class Initialized
INFO - 2017-10-31 10:24:22 --> Loader Class Initialized
INFO - 2017-10-31 10:24:22 --> Helper loaded: url_helper
INFO - 2017-10-31 10:24:22 --> Helper loaded: common_helper
INFO - 2017-10-31 10:24:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:24:22 --> Email Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Controller Class Initialized
INFO - 2017-10-31 10:24:22 --> Helper loaded: cookie_helper
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:22 --> Model Class Initialized
INFO - 2017-10-31 10:24:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 10:24:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 10:24:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 10:24:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 10:24:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 10:24:23 --> Final output sent to browser
DEBUG - 2017-10-31 10:24:23 --> Total execution time: 0.0987
INFO - 2017-10-31 10:24:23 --> Config Class Initialized
INFO - 2017-10-31 10:24:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:24:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:24:23 --> Utf8 Class Initialized
INFO - 2017-10-31 10:24:23 --> URI Class Initialized
INFO - 2017-10-31 10:24:23 --> Router Class Initialized
INFO - 2017-10-31 10:24:23 --> Output Class Initialized
INFO - 2017-10-31 10:24:23 --> Security Class Initialized
DEBUG - 2017-10-31 10:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:24:23 --> Input Class Initialized
INFO - 2017-10-31 10:24:23 --> Language Class Initialized
INFO - 2017-10-31 10:24:23 --> Loader Class Initialized
INFO - 2017-10-31 10:24:23 --> Helper loaded: url_helper
INFO - 2017-10-31 10:24:23 --> Helper loaded: common_helper
INFO - 2017-10-31 10:24:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:24:23 --> Email Class Initialized
INFO - 2017-10-31 10:24:23 --> Model Class Initialized
INFO - 2017-10-31 10:24:23 --> Controller Class Initialized
INFO - 2017-10-31 10:24:23 --> Model Class Initialized
INFO - 2017-10-31 10:24:23 --> Final output sent to browser
DEBUG - 2017-10-31 10:24:23 --> Total execution time: 0.0213
INFO - 2017-10-31 10:35:46 --> Config Class Initialized
INFO - 2017-10-31 10:35:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:35:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:35:46 --> Utf8 Class Initialized
INFO - 2017-10-31 10:35:46 --> URI Class Initialized
INFO - 2017-10-31 10:35:46 --> Router Class Initialized
INFO - 2017-10-31 10:35:46 --> Output Class Initialized
INFO - 2017-10-31 10:35:46 --> Security Class Initialized
DEBUG - 2017-10-31 10:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:35:46 --> Input Class Initialized
INFO - 2017-10-31 10:35:46 --> Language Class Initialized
INFO - 2017-10-31 10:35:46 --> Loader Class Initialized
INFO - 2017-10-31 10:35:46 --> Helper loaded: url_helper
INFO - 2017-10-31 10:35:46 --> Helper loaded: common_helper
INFO - 2017-10-31 10:35:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:35:46 --> Email Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Controller Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Config Class Initialized
INFO - 2017-10-31 10:35:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:35:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:35:46 --> Utf8 Class Initialized
INFO - 2017-10-31 10:35:46 --> URI Class Initialized
INFO - 2017-10-31 10:35:46 --> Router Class Initialized
INFO - 2017-10-31 10:35:46 --> Output Class Initialized
INFO - 2017-10-31 10:35:46 --> Security Class Initialized
DEBUG - 2017-10-31 10:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:35:46 --> Input Class Initialized
INFO - 2017-10-31 10:35:46 --> Language Class Initialized
INFO - 2017-10-31 10:35:46 --> Loader Class Initialized
INFO - 2017-10-31 10:35:46 --> Helper loaded: url_helper
INFO - 2017-10-31 10:35:46 --> Helper loaded: common_helper
INFO - 2017-10-31 10:35:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Final output sent to browser
DEBUG - 2017-10-31 10:35:46 --> Total execution time: 0.1065
INFO - 2017-10-31 10:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:35:46 --> Email Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Controller Class Initialized
INFO - 2017-10-31 10:35:46 --> Helper loaded: cookie_helper
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> Model Class Initialized
INFO - 2017-10-31 10:35:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 10:35:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 10:35:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 10:35:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 10:35:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 10:35:46 --> Final output sent to browser
DEBUG - 2017-10-31 10:35:46 --> Total execution time: 0.1224
INFO - 2017-10-31 10:35:47 --> Config Class Initialized
INFO - 2017-10-31 10:35:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:35:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:35:47 --> Utf8 Class Initialized
INFO - 2017-10-31 10:35:47 --> URI Class Initialized
INFO - 2017-10-31 10:35:47 --> Router Class Initialized
INFO - 2017-10-31 10:35:47 --> Output Class Initialized
INFO - 2017-10-31 10:35:47 --> Security Class Initialized
DEBUG - 2017-10-31 10:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:35:47 --> Input Class Initialized
INFO - 2017-10-31 10:35:47 --> Language Class Initialized
INFO - 2017-10-31 10:35:47 --> Loader Class Initialized
INFO - 2017-10-31 10:35:47 --> Helper loaded: url_helper
INFO - 2017-10-31 10:35:47 --> Helper loaded: common_helper
INFO - 2017-10-31 10:35:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:35:47 --> Email Class Initialized
INFO - 2017-10-31 10:35:47 --> Model Class Initialized
INFO - 2017-10-31 10:35:47 --> Controller Class Initialized
INFO - 2017-10-31 10:35:47 --> Model Class Initialized
INFO - 2017-10-31 10:35:47 --> Final output sent to browser
DEBUG - 2017-10-31 10:35:47 --> Total execution time: 0.0023
INFO - 2017-10-31 10:35:47 --> Config Class Initialized
INFO - 2017-10-31 10:35:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 10:35:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 10:35:47 --> Utf8 Class Initialized
INFO - 2017-10-31 10:35:47 --> URI Class Initialized
INFO - 2017-10-31 10:35:47 --> Router Class Initialized
INFO - 2017-10-31 10:35:47 --> Output Class Initialized
INFO - 2017-10-31 10:35:47 --> Security Class Initialized
DEBUG - 2017-10-31 10:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 10:35:47 --> Input Class Initialized
INFO - 2017-10-31 10:35:47 --> Language Class Initialized
INFO - 2017-10-31 10:35:47 --> Loader Class Initialized
INFO - 2017-10-31 10:35:47 --> Helper loaded: url_helper
INFO - 2017-10-31 10:35:47 --> Helper loaded: common_helper
INFO - 2017-10-31 10:35:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 10:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 10:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 10:35:47 --> Email Class Initialized
INFO - 2017-10-31 10:35:47 --> Model Class Initialized
INFO - 2017-10-31 10:35:47 --> Controller Class Initialized
INFO - 2017-10-31 10:35:47 --> Final output sent to browser
DEBUG - 2017-10-31 10:35:47 --> Total execution time: 0.0017
INFO - 2017-10-31 11:11:22 --> Config Class Initialized
INFO - 2017-10-31 11:11:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:11:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:11:22 --> Utf8 Class Initialized
INFO - 2017-10-31 11:11:22 --> URI Class Initialized
INFO - 2017-10-31 11:11:22 --> Router Class Initialized
INFO - 2017-10-31 11:11:22 --> Output Class Initialized
INFO - 2017-10-31 11:11:22 --> Security Class Initialized
DEBUG - 2017-10-31 11:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:11:22 --> Input Class Initialized
INFO - 2017-10-31 11:11:22 --> Language Class Initialized
INFO - 2017-10-31 11:11:22 --> Loader Class Initialized
INFO - 2017-10-31 11:11:22 --> Helper loaded: url_helper
INFO - 2017-10-31 11:11:22 --> Helper loaded: common_helper
INFO - 2017-10-31 11:11:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:11:22 --> Email Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Controller Class Initialized
INFO - 2017-10-31 11:11:22 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:11:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:11:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:11:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:11:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:11:22 --> Final output sent to browser
DEBUG - 2017-10-31 11:11:22 --> Total execution time: 0.0296
INFO - 2017-10-31 11:11:22 --> Config Class Initialized
INFO - 2017-10-31 11:11:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:11:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:11:22 --> Utf8 Class Initialized
INFO - 2017-10-31 11:11:22 --> URI Class Initialized
INFO - 2017-10-31 11:11:22 --> Router Class Initialized
INFO - 2017-10-31 11:11:22 --> Output Class Initialized
INFO - 2017-10-31 11:11:22 --> Security Class Initialized
DEBUG - 2017-10-31 11:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:11:22 --> Input Class Initialized
INFO - 2017-10-31 11:11:22 --> Language Class Initialized
INFO - 2017-10-31 11:11:22 --> Loader Class Initialized
INFO - 2017-10-31 11:11:22 --> Helper loaded: url_helper
INFO - 2017-10-31 11:11:22 --> Helper loaded: common_helper
INFO - 2017-10-31 11:11:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:11:22 --> Email Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Controller Class Initialized
INFO - 2017-10-31 11:11:22 --> Model Class Initialized
INFO - 2017-10-31 11:11:22 --> Final output sent to browser
DEBUG - 2017-10-31 11:11:22 --> Total execution time: 0.0024
INFO - 2017-10-31 11:11:23 --> Config Class Initialized
INFO - 2017-10-31 11:11:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:11:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:11:23 --> Utf8 Class Initialized
INFO - 2017-10-31 11:11:23 --> URI Class Initialized
INFO - 2017-10-31 11:11:23 --> Router Class Initialized
INFO - 2017-10-31 11:11:23 --> Output Class Initialized
INFO - 2017-10-31 11:11:23 --> Security Class Initialized
DEBUG - 2017-10-31 11:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:11:23 --> Input Class Initialized
INFO - 2017-10-31 11:11:23 --> Language Class Initialized
INFO - 2017-10-31 11:11:23 --> Loader Class Initialized
INFO - 2017-10-31 11:11:23 --> Helper loaded: url_helper
INFO - 2017-10-31 11:11:23 --> Helper loaded: common_helper
INFO - 2017-10-31 11:11:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:11:23 --> Email Class Initialized
INFO - 2017-10-31 11:11:23 --> Model Class Initialized
INFO - 2017-10-31 11:11:23 --> Controller Class Initialized
INFO - 2017-10-31 11:11:23 --> Final output sent to browser
DEBUG - 2017-10-31 11:11:23 --> Total execution time: 0.0023
INFO - 2017-10-31 11:13:40 --> Config Class Initialized
INFO - 2017-10-31 11:13:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:40 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:40 --> URI Class Initialized
INFO - 2017-10-31 11:13:40 --> Router Class Initialized
INFO - 2017-10-31 11:13:40 --> Output Class Initialized
INFO - 2017-10-31 11:13:40 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:40 --> Input Class Initialized
INFO - 2017-10-31 11:13:40 --> Language Class Initialized
INFO - 2017-10-31 11:13:40 --> Loader Class Initialized
INFO - 2017-10-31 11:13:40 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:40 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:40 --> Email Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Controller Class Initialized
INFO - 2017-10-31 11:13:40 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Config Class Initialized
INFO - 2017-10-31 11:13:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:40 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:40 --> URI Class Initialized
INFO - 2017-10-31 11:13:40 --> Router Class Initialized
INFO - 2017-10-31 11:13:40 --> Output Class Initialized
INFO - 2017-10-31 11:13:40 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:40 --> Input Class Initialized
INFO - 2017-10-31 11:13:40 --> Language Class Initialized
INFO - 2017-10-31 11:13:40 --> Loader Class Initialized
INFO - 2017-10-31 11:13:40 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:40 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:40 --> Email Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Controller Class Initialized
INFO - 2017-10-31 11:13:40 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> Model Class Initialized
INFO - 2017-10-31 11:13:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:13:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-31 11:13:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-31 11:13:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-31 11:13:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-31 11:13:40 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:40 --> Total execution time: 0.0170
INFO - 2017-10-31 11:13:45 --> Config Class Initialized
INFO - 2017-10-31 11:13:45 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:45 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:45 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:45 --> URI Class Initialized
INFO - 2017-10-31 11:13:45 --> Router Class Initialized
INFO - 2017-10-31 11:13:45 --> Output Class Initialized
INFO - 2017-10-31 11:13:45 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:45 --> Input Class Initialized
INFO - 2017-10-31 11:13:45 --> Language Class Initialized
INFO - 2017-10-31 11:13:45 --> Loader Class Initialized
INFO - 2017-10-31 11:13:45 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:45 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:45 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:45 --> Email Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Controller Class Initialized
INFO - 2017-10-31 11:13:45 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Config Class Initialized
INFO - 2017-10-31 11:13:45 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:45 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:45 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:45 --> URI Class Initialized
INFO - 2017-10-31 11:13:45 --> Router Class Initialized
INFO - 2017-10-31 11:13:45 --> Output Class Initialized
INFO - 2017-10-31 11:13:45 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:45 --> Input Class Initialized
INFO - 2017-10-31 11:13:45 --> Language Class Initialized
INFO - 2017-10-31 11:13:45 --> Loader Class Initialized
INFO - 2017-10-31 11:13:45 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:45 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:45 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:45 --> Email Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Controller Class Initialized
INFO - 2017-10-31 11:13:45 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> Model Class Initialized
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-31 11:13:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-31 11:13:45 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:45 --> Total execution time: 0.1162
INFO - 2017-10-31 11:13:48 --> Config Class Initialized
INFO - 2017-10-31 11:13:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:48 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:48 --> URI Class Initialized
INFO - 2017-10-31 11:13:48 --> Router Class Initialized
INFO - 2017-10-31 11:13:48 --> Output Class Initialized
INFO - 2017-10-31 11:13:48 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:48 --> Input Class Initialized
INFO - 2017-10-31 11:13:48 --> Language Class Initialized
INFO - 2017-10-31 11:13:48 --> Loader Class Initialized
INFO - 2017-10-31 11:13:48 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:48 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:48 --> Email Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Controller Class Initialized
INFO - 2017-10-31 11:13:48 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:13:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:13:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:13:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:13:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:13:48 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:48 --> Total execution time: 0.0221
INFO - 2017-10-31 11:13:48 --> Config Class Initialized
INFO - 2017-10-31 11:13:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:48 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:48 --> URI Class Initialized
INFO - 2017-10-31 11:13:48 --> Router Class Initialized
INFO - 2017-10-31 11:13:48 --> Output Class Initialized
INFO - 2017-10-31 11:13:48 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:48 --> Input Class Initialized
INFO - 2017-10-31 11:13:48 --> Language Class Initialized
INFO - 2017-10-31 11:13:48 --> Loader Class Initialized
INFO - 2017-10-31 11:13:48 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:48 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:48 --> Email Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Controller Class Initialized
INFO - 2017-10-31 11:13:48 --> Model Class Initialized
INFO - 2017-10-31 11:13:48 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:48 --> Total execution time: 0.0034
INFO - 2017-10-31 11:13:51 --> Config Class Initialized
INFO - 2017-10-31 11:13:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:51 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:51 --> URI Class Initialized
INFO - 2017-10-31 11:13:51 --> Router Class Initialized
INFO - 2017-10-31 11:13:51 --> Output Class Initialized
INFO - 2017-10-31 11:13:51 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:51 --> Input Class Initialized
INFO - 2017-10-31 11:13:51 --> Language Class Initialized
INFO - 2017-10-31 11:13:51 --> Loader Class Initialized
INFO - 2017-10-31 11:13:51 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:51 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:51 --> Email Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Controller Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Config Class Initialized
INFO - 2017-10-31 11:13:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:51 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:51 --> URI Class Initialized
INFO - 2017-10-31 11:13:51 --> Router Class Initialized
INFO - 2017-10-31 11:13:51 --> Output Class Initialized
INFO - 2017-10-31 11:13:51 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:51 --> Input Class Initialized
INFO - 2017-10-31 11:13:51 --> Language Class Initialized
INFO - 2017-10-31 11:13:51 --> Loader Class Initialized
INFO - 2017-10-31 11:13:51 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:51 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:51 --> Total execution time: 0.1748
INFO - 2017-10-31 11:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:51 --> Email Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Controller Class Initialized
INFO - 2017-10-31 11:13:51 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:13:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:13:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:13:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:13:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:13:51 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:51 --> Total execution time: 0.1813
INFO - 2017-10-31 11:13:51 --> Config Class Initialized
INFO - 2017-10-31 11:13:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:51 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:51 --> URI Class Initialized
INFO - 2017-10-31 11:13:51 --> Router Class Initialized
INFO - 2017-10-31 11:13:51 --> Output Class Initialized
INFO - 2017-10-31 11:13:51 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:51 --> Input Class Initialized
INFO - 2017-10-31 11:13:51 --> Language Class Initialized
INFO - 2017-10-31 11:13:51 --> Loader Class Initialized
INFO - 2017-10-31 11:13:51 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:51 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:51 --> Email Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Controller Class Initialized
INFO - 2017-10-31 11:13:51 --> Model Class Initialized
INFO - 2017-10-31 11:13:51 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:51 --> Total execution time: 0.0034
INFO - 2017-10-31 11:13:52 --> Config Class Initialized
INFO - 2017-10-31 11:13:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:13:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:13:52 --> Utf8 Class Initialized
INFO - 2017-10-31 11:13:52 --> URI Class Initialized
INFO - 2017-10-31 11:13:52 --> Router Class Initialized
INFO - 2017-10-31 11:13:52 --> Output Class Initialized
INFO - 2017-10-31 11:13:52 --> Security Class Initialized
DEBUG - 2017-10-31 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:13:52 --> Input Class Initialized
INFO - 2017-10-31 11:13:52 --> Language Class Initialized
INFO - 2017-10-31 11:13:52 --> Loader Class Initialized
INFO - 2017-10-31 11:13:52 --> Helper loaded: url_helper
INFO - 2017-10-31 11:13:52 --> Helper loaded: common_helper
INFO - 2017-10-31 11:13:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:13:52 --> Email Class Initialized
INFO - 2017-10-31 11:13:52 --> Model Class Initialized
INFO - 2017-10-31 11:13:52 --> Controller Class Initialized
INFO - 2017-10-31 11:13:52 --> Final output sent to browser
DEBUG - 2017-10-31 11:13:52 --> Total execution time: 0.0023
INFO - 2017-10-31 11:14:18 --> Config Class Initialized
INFO - 2017-10-31 11:14:18 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:14:18 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:14:18 --> Utf8 Class Initialized
INFO - 2017-10-31 11:14:18 --> URI Class Initialized
INFO - 2017-10-31 11:14:18 --> Router Class Initialized
INFO - 2017-10-31 11:14:18 --> Output Class Initialized
INFO - 2017-10-31 11:14:18 --> Security Class Initialized
DEBUG - 2017-10-31 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:14:18 --> Input Class Initialized
INFO - 2017-10-31 11:14:18 --> Language Class Initialized
INFO - 2017-10-31 11:14:18 --> Loader Class Initialized
INFO - 2017-10-31 11:14:18 --> Helper loaded: url_helper
INFO - 2017-10-31 11:14:18 --> Helper loaded: common_helper
INFO - 2017-10-31 11:14:18 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:14:18 --> Email Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Controller Class Initialized
INFO - 2017-10-31 11:14:18 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:14:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:14:18 --> Final output sent to browser
DEBUG - 2017-10-31 11:14:18 --> Total execution time: 0.0255
INFO - 2017-10-31 11:14:18 --> Config Class Initialized
INFO - 2017-10-31 11:14:18 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:14:18 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:14:18 --> Utf8 Class Initialized
INFO - 2017-10-31 11:14:18 --> URI Class Initialized
INFO - 2017-10-31 11:14:18 --> Router Class Initialized
INFO - 2017-10-31 11:14:18 --> Output Class Initialized
INFO - 2017-10-31 11:14:18 --> Security Class Initialized
DEBUG - 2017-10-31 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:14:18 --> Input Class Initialized
INFO - 2017-10-31 11:14:18 --> Language Class Initialized
INFO - 2017-10-31 11:14:18 --> Loader Class Initialized
INFO - 2017-10-31 11:14:18 --> Helper loaded: url_helper
INFO - 2017-10-31 11:14:18 --> Helper loaded: common_helper
INFO - 2017-10-31 11:14:18 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:14:18 --> Email Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Controller Class Initialized
INFO - 2017-10-31 11:14:18 --> Model Class Initialized
INFO - 2017-10-31 11:14:18 --> Final output sent to browser
DEBUG - 2017-10-31 11:14:18 --> Total execution time: 0.0022
INFO - 2017-10-31 11:14:20 --> Config Class Initialized
INFO - 2017-10-31 11:14:20 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:14:20 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:14:20 --> Utf8 Class Initialized
INFO - 2017-10-31 11:14:20 --> URI Class Initialized
INFO - 2017-10-31 11:14:20 --> Router Class Initialized
INFO - 2017-10-31 11:14:20 --> Output Class Initialized
INFO - 2017-10-31 11:14:20 --> Security Class Initialized
DEBUG - 2017-10-31 11:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:14:20 --> Input Class Initialized
INFO - 2017-10-31 11:14:20 --> Language Class Initialized
INFO - 2017-10-31 11:14:20 --> Loader Class Initialized
INFO - 2017-10-31 11:14:20 --> Helper loaded: url_helper
INFO - 2017-10-31 11:14:20 --> Helper loaded: common_helper
INFO - 2017-10-31 11:14:20 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:14:20 --> Email Class Initialized
INFO - 2017-10-31 11:14:20 --> Model Class Initialized
INFO - 2017-10-31 11:14:20 --> Controller Class Initialized
INFO - 2017-10-31 11:14:20 --> Final output sent to browser
DEBUG - 2017-10-31 11:14:20 --> Total execution time: 0.0023
INFO - 2017-10-31 11:16:02 --> Config Class Initialized
INFO - 2017-10-31 11:16:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:16:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:16:02 --> Utf8 Class Initialized
INFO - 2017-10-31 11:16:02 --> URI Class Initialized
INFO - 2017-10-31 11:16:02 --> Router Class Initialized
INFO - 2017-10-31 11:16:02 --> Output Class Initialized
INFO - 2017-10-31 11:16:02 --> Security Class Initialized
DEBUG - 2017-10-31 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:16:02 --> Input Class Initialized
INFO - 2017-10-31 11:16:02 --> Language Class Initialized
INFO - 2017-10-31 11:16:02 --> Loader Class Initialized
INFO - 2017-10-31 11:16:02 --> Helper loaded: url_helper
INFO - 2017-10-31 11:16:02 --> Helper loaded: common_helper
INFO - 2017-10-31 11:16:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:16:02 --> Email Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Controller Class Initialized
INFO - 2017-10-31 11:16:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> Model Class Initialized
INFO - 2017-10-31 11:16:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:16:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:16:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:16:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:16:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:16:02 --> Final output sent to browser
DEBUG - 2017-10-31 11:16:02 --> Total execution time: 0.0264
INFO - 2017-10-31 11:16:03 --> Config Class Initialized
INFO - 2017-10-31 11:16:03 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:16:03 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:16:03 --> Utf8 Class Initialized
INFO - 2017-10-31 11:16:03 --> URI Class Initialized
INFO - 2017-10-31 11:16:03 --> Router Class Initialized
INFO - 2017-10-31 11:16:03 --> Output Class Initialized
INFO - 2017-10-31 11:16:03 --> Security Class Initialized
DEBUG - 2017-10-31 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:16:03 --> Input Class Initialized
INFO - 2017-10-31 11:16:03 --> Language Class Initialized
INFO - 2017-10-31 11:16:03 --> Loader Class Initialized
INFO - 2017-10-31 11:16:03 --> Helper loaded: url_helper
INFO - 2017-10-31 11:16:03 --> Helper loaded: common_helper
INFO - 2017-10-31 11:16:03 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:16:03 --> Email Class Initialized
INFO - 2017-10-31 11:16:03 --> Model Class Initialized
INFO - 2017-10-31 11:16:03 --> Controller Class Initialized
INFO - 2017-10-31 11:16:03 --> Model Class Initialized
INFO - 2017-10-31 11:16:03 --> Final output sent to browser
DEBUG - 2017-10-31 11:16:03 --> Total execution time: 0.0023
INFO - 2017-10-31 11:16:05 --> Config Class Initialized
INFO - 2017-10-31 11:16:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:16:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:16:05 --> Utf8 Class Initialized
INFO - 2017-10-31 11:16:05 --> URI Class Initialized
INFO - 2017-10-31 11:16:05 --> Router Class Initialized
INFO - 2017-10-31 11:16:05 --> Output Class Initialized
INFO - 2017-10-31 11:16:05 --> Security Class Initialized
DEBUG - 2017-10-31 11:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:16:05 --> Input Class Initialized
INFO - 2017-10-31 11:16:05 --> Language Class Initialized
INFO - 2017-10-31 11:16:05 --> Loader Class Initialized
INFO - 2017-10-31 11:16:05 --> Helper loaded: url_helper
INFO - 2017-10-31 11:16:05 --> Helper loaded: common_helper
INFO - 2017-10-31 11:16:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:16:05 --> Email Class Initialized
INFO - 2017-10-31 11:16:05 --> Model Class Initialized
INFO - 2017-10-31 11:16:05 --> Controller Class Initialized
INFO - 2017-10-31 11:16:05 --> Final output sent to browser
DEBUG - 2017-10-31 11:16:05 --> Total execution time: 0.0028
INFO - 2017-10-31 11:36:21 --> Config Class Initialized
INFO - 2017-10-31 11:36:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:36:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:36:21 --> Utf8 Class Initialized
INFO - 2017-10-31 11:36:21 --> URI Class Initialized
INFO - 2017-10-31 11:36:21 --> Router Class Initialized
INFO - 2017-10-31 11:36:21 --> Output Class Initialized
INFO - 2017-10-31 11:36:21 --> Security Class Initialized
DEBUG - 2017-10-31 11:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:36:21 --> Input Class Initialized
INFO - 2017-10-31 11:36:21 --> Language Class Initialized
INFO - 2017-10-31 11:36:21 --> Loader Class Initialized
INFO - 2017-10-31 11:36:21 --> Helper loaded: url_helper
INFO - 2017-10-31 11:36:21 --> Helper loaded: common_helper
INFO - 2017-10-31 11:36:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:36:21 --> Email Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Controller Class Initialized
INFO - 2017-10-31 11:36:21 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:36:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:36:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:36:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:36:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:36:21 --> Final output sent to browser
DEBUG - 2017-10-31 11:36:21 --> Total execution time: 0.0273
INFO - 2017-10-31 11:36:21 --> Config Class Initialized
INFO - 2017-10-31 11:36:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:36:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:36:21 --> Utf8 Class Initialized
INFO - 2017-10-31 11:36:21 --> URI Class Initialized
INFO - 2017-10-31 11:36:21 --> Router Class Initialized
INFO - 2017-10-31 11:36:21 --> Output Class Initialized
INFO - 2017-10-31 11:36:21 --> Security Class Initialized
DEBUG - 2017-10-31 11:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:36:21 --> Input Class Initialized
INFO - 2017-10-31 11:36:21 --> Language Class Initialized
INFO - 2017-10-31 11:36:21 --> Loader Class Initialized
INFO - 2017-10-31 11:36:21 --> Helper loaded: url_helper
INFO - 2017-10-31 11:36:21 --> Helper loaded: common_helper
INFO - 2017-10-31 11:36:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:36:21 --> Email Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Controller Class Initialized
INFO - 2017-10-31 11:36:21 --> Model Class Initialized
INFO - 2017-10-31 11:36:21 --> Final output sent to browser
DEBUG - 2017-10-31 11:36:21 --> Total execution time: 0.0059
INFO - 2017-10-31 11:36:22 --> Config Class Initialized
INFO - 2017-10-31 11:36:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:36:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:36:22 --> Utf8 Class Initialized
INFO - 2017-10-31 11:36:22 --> URI Class Initialized
INFO - 2017-10-31 11:36:22 --> Router Class Initialized
INFO - 2017-10-31 11:36:22 --> Output Class Initialized
INFO - 2017-10-31 11:36:22 --> Security Class Initialized
DEBUG - 2017-10-31 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:36:22 --> Input Class Initialized
INFO - 2017-10-31 11:36:22 --> Language Class Initialized
INFO - 2017-10-31 11:36:22 --> Loader Class Initialized
INFO - 2017-10-31 11:36:22 --> Helper loaded: url_helper
INFO - 2017-10-31 11:36:22 --> Helper loaded: common_helper
INFO - 2017-10-31 11:36:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:36:22 --> Email Class Initialized
INFO - 2017-10-31 11:36:22 --> Model Class Initialized
INFO - 2017-10-31 11:36:22 --> Controller Class Initialized
INFO - 2017-10-31 11:36:22 --> Final output sent to browser
DEBUG - 2017-10-31 11:36:22 --> Total execution time: 0.0017
INFO - 2017-10-31 11:43:40 --> Config Class Initialized
INFO - 2017-10-31 11:43:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:40 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:40 --> URI Class Initialized
INFO - 2017-10-31 11:43:40 --> Router Class Initialized
INFO - 2017-10-31 11:43:40 --> Output Class Initialized
INFO - 2017-10-31 11:43:40 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:40 --> Input Class Initialized
INFO - 2017-10-31 11:43:40 --> Language Class Initialized
INFO - 2017-10-31 11:43:40 --> Loader Class Initialized
INFO - 2017-10-31 11:43:40 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:40 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:40 --> Email Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Controller Class Initialized
INFO - 2017-10-31 11:43:40 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> Model Class Initialized
INFO - 2017-10-31 11:43:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:43:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:43:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:43:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:43:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:43:40 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:40 --> Total execution time: 0.0246
INFO - 2017-10-31 11:43:41 --> Config Class Initialized
INFO - 2017-10-31 11:43:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:41 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:41 --> URI Class Initialized
INFO - 2017-10-31 11:43:41 --> Router Class Initialized
INFO - 2017-10-31 11:43:41 --> Output Class Initialized
INFO - 2017-10-31 11:43:41 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:41 --> Input Class Initialized
INFO - 2017-10-31 11:43:41 --> Language Class Initialized
INFO - 2017-10-31 11:43:41 --> Loader Class Initialized
INFO - 2017-10-31 11:43:41 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:41 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:41 --> Email Class Initialized
INFO - 2017-10-31 11:43:41 --> Model Class Initialized
INFO - 2017-10-31 11:43:41 --> Controller Class Initialized
INFO - 2017-10-31 11:43:41 --> Model Class Initialized
INFO - 2017-10-31 11:43:41 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:41 --> Total execution time: 0.0021
INFO - 2017-10-31 11:43:43 --> Config Class Initialized
INFO - 2017-10-31 11:43:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:43 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:43 --> URI Class Initialized
INFO - 2017-10-31 11:43:43 --> Router Class Initialized
INFO - 2017-10-31 11:43:43 --> Output Class Initialized
INFO - 2017-10-31 11:43:43 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:43 --> Input Class Initialized
INFO - 2017-10-31 11:43:43 --> Language Class Initialized
INFO - 2017-10-31 11:43:43 --> Loader Class Initialized
INFO - 2017-10-31 11:43:43 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:43 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:43 --> Email Class Initialized
INFO - 2017-10-31 11:43:43 --> Model Class Initialized
INFO - 2017-10-31 11:43:43 --> Controller Class Initialized
INFO - 2017-10-31 11:43:43 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:43 --> Total execution time: 0.0022
INFO - 2017-10-31 11:43:47 --> Config Class Initialized
INFO - 2017-10-31 11:43:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:47 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:47 --> URI Class Initialized
INFO - 2017-10-31 11:43:47 --> Router Class Initialized
INFO - 2017-10-31 11:43:47 --> Output Class Initialized
INFO - 2017-10-31 11:43:47 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:47 --> Input Class Initialized
INFO - 2017-10-31 11:43:47 --> Language Class Initialized
INFO - 2017-10-31 11:43:47 --> Loader Class Initialized
INFO - 2017-10-31 11:43:47 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:47 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:47 --> Email Class Initialized
INFO - 2017-10-31 11:43:47 --> Model Class Initialized
INFO - 2017-10-31 11:43:47 --> Controller Class Initialized
INFO - 2017-10-31 11:43:47 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:47 --> Total execution time: 0.0018
INFO - 2017-10-31 11:43:47 --> Config Class Initialized
INFO - 2017-10-31 11:43:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:47 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:47 --> URI Class Initialized
INFO - 2017-10-31 11:43:47 --> Router Class Initialized
INFO - 2017-10-31 11:43:47 --> Output Class Initialized
INFO - 2017-10-31 11:43:47 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:47 --> Input Class Initialized
INFO - 2017-10-31 11:43:47 --> Language Class Initialized
INFO - 2017-10-31 11:43:47 --> Loader Class Initialized
INFO - 2017-10-31 11:43:47 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:47 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:47 --> Email Class Initialized
INFO - 2017-10-31 11:43:47 --> Model Class Initialized
INFO - 2017-10-31 11:43:47 --> Controller Class Initialized
INFO - 2017-10-31 11:43:47 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:47 --> Total execution time: 0.0016
INFO - 2017-10-31 11:43:48 --> Config Class Initialized
INFO - 2017-10-31 11:43:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:43:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:43:48 --> Utf8 Class Initialized
INFO - 2017-10-31 11:43:48 --> URI Class Initialized
INFO - 2017-10-31 11:43:48 --> Router Class Initialized
INFO - 2017-10-31 11:43:48 --> Output Class Initialized
INFO - 2017-10-31 11:43:48 --> Security Class Initialized
DEBUG - 2017-10-31 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:43:48 --> Input Class Initialized
INFO - 2017-10-31 11:43:48 --> Language Class Initialized
INFO - 2017-10-31 11:43:48 --> Loader Class Initialized
INFO - 2017-10-31 11:43:48 --> Helper loaded: url_helper
INFO - 2017-10-31 11:43:48 --> Helper loaded: common_helper
INFO - 2017-10-31 11:43:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:43:48 --> Email Class Initialized
INFO - 2017-10-31 11:43:48 --> Model Class Initialized
INFO - 2017-10-31 11:43:48 --> Controller Class Initialized
INFO - 2017-10-31 11:43:48 --> Final output sent to browser
DEBUG - 2017-10-31 11:43:48 --> Total execution time: 0.0017
INFO - 2017-10-31 11:44:25 --> Config Class Initialized
INFO - 2017-10-31 11:44:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:44:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:44:25 --> Utf8 Class Initialized
INFO - 2017-10-31 11:44:25 --> URI Class Initialized
INFO - 2017-10-31 11:44:25 --> Router Class Initialized
INFO - 2017-10-31 11:44:25 --> Output Class Initialized
INFO - 2017-10-31 11:44:25 --> Security Class Initialized
DEBUG - 2017-10-31 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:44:25 --> Input Class Initialized
INFO - 2017-10-31 11:44:25 --> Language Class Initialized
INFO - 2017-10-31 11:44:25 --> Loader Class Initialized
INFO - 2017-10-31 11:44:25 --> Helper loaded: url_helper
INFO - 2017-10-31 11:44:25 --> Helper loaded: common_helper
INFO - 2017-10-31 11:44:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:44:25 --> Email Class Initialized
INFO - 2017-10-31 11:44:25 --> Model Class Initialized
INFO - 2017-10-31 11:44:25 --> Controller Class Initialized
INFO - 2017-10-31 11:44:25 --> Final output sent to browser
DEBUG - 2017-10-31 11:44:25 --> Total execution time: 0.0050
INFO - 2017-10-31 11:45:12 --> Config Class Initialized
INFO - 2017-10-31 11:45:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:12 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:12 --> URI Class Initialized
INFO - 2017-10-31 11:45:12 --> Router Class Initialized
INFO - 2017-10-31 11:45:12 --> Output Class Initialized
INFO - 2017-10-31 11:45:12 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:12 --> Input Class Initialized
INFO - 2017-10-31 11:45:12 --> Language Class Initialized
INFO - 2017-10-31 11:45:12 --> Loader Class Initialized
INFO - 2017-10-31 11:45:12 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:12 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:12 --> Email Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Controller Class Initialized
INFO - 2017-10-31 11:45:12 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> Model Class Initialized
INFO - 2017-10-31 11:45:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:45:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:45:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:45:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:45:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:45:12 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:12 --> Total execution time: 0.0277
INFO - 2017-10-31 11:45:13 --> Config Class Initialized
INFO - 2017-10-31 11:45:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:13 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:13 --> URI Class Initialized
INFO - 2017-10-31 11:45:13 --> Router Class Initialized
INFO - 2017-10-31 11:45:13 --> Output Class Initialized
INFO - 2017-10-31 11:45:13 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:13 --> Input Class Initialized
INFO - 2017-10-31 11:45:13 --> Language Class Initialized
INFO - 2017-10-31 11:45:13 --> Loader Class Initialized
INFO - 2017-10-31 11:45:13 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:13 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:13 --> Email Class Initialized
INFO - 2017-10-31 11:45:13 --> Model Class Initialized
INFO - 2017-10-31 11:45:13 --> Controller Class Initialized
INFO - 2017-10-31 11:45:13 --> Model Class Initialized
INFO - 2017-10-31 11:45:13 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:13 --> Total execution time: 0.0028
INFO - 2017-10-31 11:45:14 --> Config Class Initialized
INFO - 2017-10-31 11:45:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:14 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:14 --> URI Class Initialized
INFO - 2017-10-31 11:45:14 --> Router Class Initialized
INFO - 2017-10-31 11:45:14 --> Output Class Initialized
INFO - 2017-10-31 11:45:14 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:14 --> Input Class Initialized
INFO - 2017-10-31 11:45:14 --> Language Class Initialized
INFO - 2017-10-31 11:45:14 --> Loader Class Initialized
INFO - 2017-10-31 11:45:14 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:14 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:14 --> Email Class Initialized
INFO - 2017-10-31 11:45:14 --> Model Class Initialized
INFO - 2017-10-31 11:45:14 --> Controller Class Initialized
INFO - 2017-10-31 11:45:14 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:14 --> Total execution time: 0.0026
INFO - 2017-10-31 11:45:17 --> Config Class Initialized
INFO - 2017-10-31 11:45:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:17 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:17 --> URI Class Initialized
INFO - 2017-10-31 11:45:17 --> Router Class Initialized
INFO - 2017-10-31 11:45:17 --> Output Class Initialized
INFO - 2017-10-31 11:45:17 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:17 --> Input Class Initialized
INFO - 2017-10-31 11:45:17 --> Language Class Initialized
INFO - 2017-10-31 11:45:17 --> Loader Class Initialized
INFO - 2017-10-31 11:45:17 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:17 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:17 --> Email Class Initialized
INFO - 2017-10-31 11:45:17 --> Model Class Initialized
INFO - 2017-10-31 11:45:17 --> Controller Class Initialized
INFO - 2017-10-31 11:45:17 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:17 --> Total execution time: 0.0016
INFO - 2017-10-31 11:45:17 --> Config Class Initialized
INFO - 2017-10-31 11:45:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:17 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:17 --> URI Class Initialized
INFO - 2017-10-31 11:45:17 --> Router Class Initialized
INFO - 2017-10-31 11:45:17 --> Output Class Initialized
INFO - 2017-10-31 11:45:17 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:17 --> Input Class Initialized
INFO - 2017-10-31 11:45:17 --> Language Class Initialized
INFO - 2017-10-31 11:45:17 --> Loader Class Initialized
INFO - 2017-10-31 11:45:17 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:17 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:17 --> Email Class Initialized
INFO - 2017-10-31 11:45:17 --> Model Class Initialized
INFO - 2017-10-31 11:45:17 --> Controller Class Initialized
INFO - 2017-10-31 11:45:17 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:17 --> Total execution time: 0.0018
INFO - 2017-10-31 11:45:17 --> Config Class Initialized
INFO - 2017-10-31 11:45:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:17 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:17 --> URI Class Initialized
INFO - 2017-10-31 11:45:17 --> Router Class Initialized
INFO - 2017-10-31 11:45:17 --> Output Class Initialized
INFO - 2017-10-31 11:45:17 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:17 --> Input Class Initialized
INFO - 2017-10-31 11:45:17 --> Language Class Initialized
INFO - 2017-10-31 11:45:17 --> Loader Class Initialized
INFO - 2017-10-31 11:45:17 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:17 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:17 --> Email Class Initialized
INFO - 2017-10-31 11:45:17 --> Model Class Initialized
INFO - 2017-10-31 11:45:17 --> Controller Class Initialized
INFO - 2017-10-31 11:45:17 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:17 --> Total execution time: 0.0023
INFO - 2017-10-31 11:45:17 --> Config Class Initialized
INFO - 2017-10-31 11:45:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:45:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:45:17 --> Utf8 Class Initialized
INFO - 2017-10-31 11:45:17 --> URI Class Initialized
INFO - 2017-10-31 11:45:17 --> Router Class Initialized
INFO - 2017-10-31 11:45:17 --> Output Class Initialized
INFO - 2017-10-31 11:45:17 --> Security Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:45:17 --> Input Class Initialized
INFO - 2017-10-31 11:45:17 --> Language Class Initialized
INFO - 2017-10-31 11:45:17 --> Loader Class Initialized
INFO - 2017-10-31 11:45:17 --> Helper loaded: url_helper
INFO - 2017-10-31 11:45:17 --> Helper loaded: common_helper
INFO - 2017-10-31 11:45:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:45:17 --> Email Class Initialized
INFO - 2017-10-31 11:45:17 --> Model Class Initialized
INFO - 2017-10-31 11:45:17 --> Controller Class Initialized
INFO - 2017-10-31 11:45:17 --> Final output sent to browser
DEBUG - 2017-10-31 11:45:17 --> Total execution time: 0.0022
INFO - 2017-10-31 11:50:30 --> Config Class Initialized
INFO - 2017-10-31 11:50:30 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:30 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:30 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:30 --> URI Class Initialized
INFO - 2017-10-31 11:50:30 --> Router Class Initialized
INFO - 2017-10-31 11:50:30 --> Output Class Initialized
INFO - 2017-10-31 11:50:30 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:30 --> Input Class Initialized
INFO - 2017-10-31 11:50:30 --> Language Class Initialized
INFO - 2017-10-31 11:50:30 --> Loader Class Initialized
INFO - 2017-10-31 11:50:30 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:30 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:30 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:30 --> Email Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Controller Class Initialized
INFO - 2017-10-31 11:50:30 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:50:30 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:30 --> Total execution time: 0.0272
INFO - 2017-10-31 11:50:30 --> Config Class Initialized
INFO - 2017-10-31 11:50:30 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:30 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:30 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:30 --> URI Class Initialized
INFO - 2017-10-31 11:50:30 --> Router Class Initialized
INFO - 2017-10-31 11:50:30 --> Output Class Initialized
INFO - 2017-10-31 11:50:30 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:30 --> Input Class Initialized
INFO - 2017-10-31 11:50:30 --> Language Class Initialized
INFO - 2017-10-31 11:50:30 --> Loader Class Initialized
INFO - 2017-10-31 11:50:30 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:30 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:30 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:30 --> Email Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Controller Class Initialized
INFO - 2017-10-31 11:50:30 --> Model Class Initialized
INFO - 2017-10-31 11:50:30 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:30 --> Total execution time: 0.0034
INFO - 2017-10-31 11:50:31 --> Config Class Initialized
INFO - 2017-10-31 11:50:31 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:31 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:31 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:31 --> URI Class Initialized
INFO - 2017-10-31 11:50:31 --> Router Class Initialized
INFO - 2017-10-31 11:50:31 --> Output Class Initialized
INFO - 2017-10-31 11:50:31 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:31 --> Input Class Initialized
INFO - 2017-10-31 11:50:31 --> Language Class Initialized
INFO - 2017-10-31 11:50:31 --> Loader Class Initialized
INFO - 2017-10-31 11:50:31 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:31 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:31 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:31 --> Email Class Initialized
INFO - 2017-10-31 11:50:31 --> Model Class Initialized
INFO - 2017-10-31 11:50:31 --> Controller Class Initialized
INFO - 2017-10-31 11:50:31 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:31 --> Total execution time: 0.0019
INFO - 2017-10-31 11:50:37 --> Config Class Initialized
INFO - 2017-10-31 11:50:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:37 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:37 --> URI Class Initialized
INFO - 2017-10-31 11:50:37 --> Router Class Initialized
INFO - 2017-10-31 11:50:37 --> Output Class Initialized
INFO - 2017-10-31 11:50:37 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:37 --> Input Class Initialized
INFO - 2017-10-31 11:50:37 --> Language Class Initialized
INFO - 2017-10-31 11:50:37 --> Loader Class Initialized
INFO - 2017-10-31 11:50:37 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:37 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:37 --> Email Class Initialized
INFO - 2017-10-31 11:50:37 --> Model Class Initialized
INFO - 2017-10-31 11:50:37 --> Controller Class Initialized
INFO - 2017-10-31 11:50:37 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:37 --> Total execution time: 0.0055
INFO - 2017-10-31 11:50:38 --> Config Class Initialized
INFO - 2017-10-31 11:50:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:38 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:38 --> URI Class Initialized
INFO - 2017-10-31 11:50:38 --> Router Class Initialized
INFO - 2017-10-31 11:50:38 --> Output Class Initialized
INFO - 2017-10-31 11:50:38 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:38 --> Input Class Initialized
INFO - 2017-10-31 11:50:38 --> Language Class Initialized
INFO - 2017-10-31 11:50:38 --> Loader Class Initialized
INFO - 2017-10-31 11:50:38 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:38 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:38 --> Email Class Initialized
INFO - 2017-10-31 11:50:38 --> Model Class Initialized
INFO - 2017-10-31 11:50:38 --> Controller Class Initialized
INFO - 2017-10-31 11:50:38 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:38 --> Total execution time: 0.0016
INFO - 2017-10-31 11:50:38 --> Config Class Initialized
INFO - 2017-10-31 11:50:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:38 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:38 --> URI Class Initialized
INFO - 2017-10-31 11:50:38 --> Router Class Initialized
INFO - 2017-10-31 11:50:38 --> Output Class Initialized
INFO - 2017-10-31 11:50:38 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:38 --> Input Class Initialized
INFO - 2017-10-31 11:50:38 --> Language Class Initialized
INFO - 2017-10-31 11:50:38 --> Loader Class Initialized
INFO - 2017-10-31 11:50:38 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:38 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:38 --> Email Class Initialized
INFO - 2017-10-31 11:50:38 --> Model Class Initialized
INFO - 2017-10-31 11:50:38 --> Controller Class Initialized
INFO - 2017-10-31 11:50:38 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:38 --> Total execution time: 0.0017
INFO - 2017-10-31 11:50:45 --> Config Class Initialized
INFO - 2017-10-31 11:50:45 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:45 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:45 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:45 --> URI Class Initialized
INFO - 2017-10-31 11:50:45 --> Router Class Initialized
INFO - 2017-10-31 11:50:45 --> Output Class Initialized
INFO - 2017-10-31 11:50:45 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:45 --> Input Class Initialized
INFO - 2017-10-31 11:50:45 --> Language Class Initialized
INFO - 2017-10-31 11:50:45 --> Loader Class Initialized
INFO - 2017-10-31 11:50:45 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:45 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:45 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:45 --> Email Class Initialized
INFO - 2017-10-31 11:50:45 --> Model Class Initialized
INFO - 2017-10-31 11:50:45 --> Controller Class Initialized
INFO - 2017-10-31 11:50:45 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:45 --> Total execution time: 0.0017
INFO - 2017-10-31 11:50:48 --> Config Class Initialized
INFO - 2017-10-31 11:50:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:50:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:50:48 --> Utf8 Class Initialized
INFO - 2017-10-31 11:50:48 --> URI Class Initialized
INFO - 2017-10-31 11:50:48 --> Router Class Initialized
INFO - 2017-10-31 11:50:48 --> Output Class Initialized
INFO - 2017-10-31 11:50:48 --> Security Class Initialized
DEBUG - 2017-10-31 11:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:50:48 --> Input Class Initialized
INFO - 2017-10-31 11:50:48 --> Language Class Initialized
INFO - 2017-10-31 11:50:48 --> Loader Class Initialized
INFO - 2017-10-31 11:50:48 --> Helper loaded: url_helper
INFO - 2017-10-31 11:50:48 --> Helper loaded: common_helper
INFO - 2017-10-31 11:50:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:50:48 --> Email Class Initialized
INFO - 2017-10-31 11:50:48 --> Model Class Initialized
INFO - 2017-10-31 11:50:48 --> Controller Class Initialized
INFO - 2017-10-31 11:50:48 --> Final output sent to browser
DEBUG - 2017-10-31 11:50:48 --> Total execution time: 0.0017
INFO - 2017-10-31 11:58:23 --> Config Class Initialized
INFO - 2017-10-31 11:58:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:23 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:23 --> URI Class Initialized
INFO - 2017-10-31 11:58:23 --> Router Class Initialized
INFO - 2017-10-31 11:58:23 --> Output Class Initialized
INFO - 2017-10-31 11:58:23 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:23 --> Input Class Initialized
INFO - 2017-10-31 11:58:23 --> Language Class Initialized
INFO - 2017-10-31 11:58:23 --> Loader Class Initialized
INFO - 2017-10-31 11:58:23 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:23 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:23 --> Email Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Controller Class Initialized
INFO - 2017-10-31 11:58:23 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> Model Class Initialized
INFO - 2017-10-31 11:58:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:58:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:58:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:58:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:58:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:58:23 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:23 --> Total execution time: 0.0264
INFO - 2017-10-31 11:58:24 --> Config Class Initialized
INFO - 2017-10-31 11:58:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:24 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:24 --> URI Class Initialized
INFO - 2017-10-31 11:58:24 --> Router Class Initialized
INFO - 2017-10-31 11:58:24 --> Output Class Initialized
INFO - 2017-10-31 11:58:24 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:24 --> Input Class Initialized
INFO - 2017-10-31 11:58:24 --> Language Class Initialized
INFO - 2017-10-31 11:58:24 --> Loader Class Initialized
INFO - 2017-10-31 11:58:24 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:24 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:24 --> Email Class Initialized
INFO - 2017-10-31 11:58:24 --> Model Class Initialized
INFO - 2017-10-31 11:58:24 --> Controller Class Initialized
INFO - 2017-10-31 11:58:24 --> Model Class Initialized
INFO - 2017-10-31 11:58:24 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:24 --> Total execution time: 0.0024
INFO - 2017-10-31 11:58:26 --> Config Class Initialized
INFO - 2017-10-31 11:58:26 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:26 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:26 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:26 --> URI Class Initialized
INFO - 2017-10-31 11:58:26 --> Router Class Initialized
INFO - 2017-10-31 11:58:26 --> Output Class Initialized
INFO - 2017-10-31 11:58:26 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:26 --> Input Class Initialized
INFO - 2017-10-31 11:58:26 --> Language Class Initialized
INFO - 2017-10-31 11:58:26 --> Loader Class Initialized
INFO - 2017-10-31 11:58:26 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:26 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:26 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:26 --> Email Class Initialized
INFO - 2017-10-31 11:58:26 --> Model Class Initialized
INFO - 2017-10-31 11:58:26 --> Controller Class Initialized
INFO - 2017-10-31 11:58:26 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:26 --> Total execution time: 0.0017
INFO - 2017-10-31 11:58:29 --> Config Class Initialized
INFO - 2017-10-31 11:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:29 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:29 --> URI Class Initialized
INFO - 2017-10-31 11:58:29 --> Router Class Initialized
INFO - 2017-10-31 11:58:29 --> Output Class Initialized
INFO - 2017-10-31 11:58:29 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:29 --> Input Class Initialized
INFO - 2017-10-31 11:58:29 --> Language Class Initialized
INFO - 2017-10-31 11:58:29 --> Loader Class Initialized
INFO - 2017-10-31 11:58:29 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:29 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:29 --> Email Class Initialized
INFO - 2017-10-31 11:58:29 --> Model Class Initialized
INFO - 2017-10-31 11:58:29 --> Controller Class Initialized
INFO - 2017-10-31 11:58:29 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:29 --> Total execution time: 0.0027
INFO - 2017-10-31 11:58:29 --> Config Class Initialized
INFO - 2017-10-31 11:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:29 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:29 --> URI Class Initialized
INFO - 2017-10-31 11:58:29 --> Router Class Initialized
INFO - 2017-10-31 11:58:29 --> Output Class Initialized
INFO - 2017-10-31 11:58:29 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:29 --> Input Class Initialized
INFO - 2017-10-31 11:58:29 --> Language Class Initialized
INFO - 2017-10-31 11:58:29 --> Loader Class Initialized
INFO - 2017-10-31 11:58:29 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:29 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:29 --> Email Class Initialized
INFO - 2017-10-31 11:58:29 --> Model Class Initialized
INFO - 2017-10-31 11:58:29 --> Controller Class Initialized
INFO - 2017-10-31 11:58:29 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:29 --> Total execution time: 0.0023
INFO - 2017-10-31 11:58:29 --> Config Class Initialized
INFO - 2017-10-31 11:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:29 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:29 --> URI Class Initialized
INFO - 2017-10-31 11:58:29 --> Router Class Initialized
INFO - 2017-10-31 11:58:29 --> Output Class Initialized
INFO - 2017-10-31 11:58:29 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:29 --> Input Class Initialized
INFO - 2017-10-31 11:58:29 --> Language Class Initialized
INFO - 2017-10-31 11:58:29 --> Loader Class Initialized
INFO - 2017-10-31 11:58:29 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:29 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:29 --> Email Class Initialized
INFO - 2017-10-31 11:58:29 --> Model Class Initialized
INFO - 2017-10-31 11:58:29 --> Controller Class Initialized
INFO - 2017-10-31 11:58:29 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:29 --> Total execution time: 0.0017
INFO - 2017-10-31 11:58:30 --> Config Class Initialized
INFO - 2017-10-31 11:58:30 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:30 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:30 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:30 --> URI Class Initialized
INFO - 2017-10-31 11:58:30 --> Router Class Initialized
INFO - 2017-10-31 11:58:30 --> Output Class Initialized
INFO - 2017-10-31 11:58:30 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:30 --> Input Class Initialized
INFO - 2017-10-31 11:58:30 --> Language Class Initialized
INFO - 2017-10-31 11:58:30 --> Loader Class Initialized
INFO - 2017-10-31 11:58:30 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:30 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:30 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:30 --> Email Class Initialized
INFO - 2017-10-31 11:58:30 --> Model Class Initialized
INFO - 2017-10-31 11:58:30 --> Controller Class Initialized
INFO - 2017-10-31 11:58:30 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:30 --> Total execution time: 0.0018
INFO - 2017-10-31 11:58:39 --> Config Class Initialized
INFO - 2017-10-31 11:58:39 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:58:39 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:58:39 --> Utf8 Class Initialized
INFO - 2017-10-31 11:58:39 --> URI Class Initialized
INFO - 2017-10-31 11:58:39 --> Router Class Initialized
INFO - 2017-10-31 11:58:39 --> Output Class Initialized
INFO - 2017-10-31 11:58:39 --> Security Class Initialized
DEBUG - 2017-10-31 11:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:58:39 --> Input Class Initialized
INFO - 2017-10-31 11:58:39 --> Language Class Initialized
INFO - 2017-10-31 11:58:39 --> Loader Class Initialized
INFO - 2017-10-31 11:58:39 --> Helper loaded: url_helper
INFO - 2017-10-31 11:58:39 --> Helper loaded: common_helper
INFO - 2017-10-31 11:58:39 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:58:39 --> Email Class Initialized
INFO - 2017-10-31 11:58:39 --> Model Class Initialized
INFO - 2017-10-31 11:58:39 --> Controller Class Initialized
INFO - 2017-10-31 11:58:39 --> Final output sent to browser
DEBUG - 2017-10-31 11:58:39 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:10 --> Config Class Initialized
INFO - 2017-10-31 11:59:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:10 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:10 --> URI Class Initialized
INFO - 2017-10-31 11:59:10 --> Router Class Initialized
INFO - 2017-10-31 11:59:10 --> Output Class Initialized
INFO - 2017-10-31 11:59:10 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:10 --> Input Class Initialized
INFO - 2017-10-31 11:59:10 --> Language Class Initialized
INFO - 2017-10-31 11:59:10 --> Loader Class Initialized
INFO - 2017-10-31 11:59:10 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:10 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:10 --> Email Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Controller Class Initialized
INFO - 2017-10-31 11:59:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:59:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:59:10 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:10 --> Total execution time: 0.0333
INFO - 2017-10-31 11:59:10 --> Config Class Initialized
INFO - 2017-10-31 11:59:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:10 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:10 --> URI Class Initialized
INFO - 2017-10-31 11:59:10 --> Router Class Initialized
INFO - 2017-10-31 11:59:10 --> Output Class Initialized
INFO - 2017-10-31 11:59:10 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:10 --> Input Class Initialized
INFO - 2017-10-31 11:59:10 --> Language Class Initialized
INFO - 2017-10-31 11:59:10 --> Loader Class Initialized
INFO - 2017-10-31 11:59:10 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:10 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:10 --> Email Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Controller Class Initialized
INFO - 2017-10-31 11:59:10 --> Model Class Initialized
INFO - 2017-10-31 11:59:10 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:10 --> Total execution time: 0.0027
INFO - 2017-10-31 11:59:11 --> Config Class Initialized
INFO - 2017-10-31 11:59:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:11 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:11 --> URI Class Initialized
INFO - 2017-10-31 11:59:11 --> Router Class Initialized
INFO - 2017-10-31 11:59:11 --> Output Class Initialized
INFO - 2017-10-31 11:59:11 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:11 --> Input Class Initialized
INFO - 2017-10-31 11:59:11 --> Language Class Initialized
INFO - 2017-10-31 11:59:11 --> Loader Class Initialized
INFO - 2017-10-31 11:59:11 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:11 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:11 --> Email Class Initialized
INFO - 2017-10-31 11:59:11 --> Model Class Initialized
INFO - 2017-10-31 11:59:11 --> Controller Class Initialized
INFO - 2017-10-31 11:59:11 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:11 --> Total execution time: 0.0017
INFO - 2017-10-31 11:59:15 --> Config Class Initialized
INFO - 2017-10-31 11:59:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:15 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:15 --> URI Class Initialized
INFO - 2017-10-31 11:59:15 --> Router Class Initialized
INFO - 2017-10-31 11:59:15 --> Output Class Initialized
INFO - 2017-10-31 11:59:15 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:15 --> Input Class Initialized
INFO - 2017-10-31 11:59:15 --> Language Class Initialized
INFO - 2017-10-31 11:59:15 --> Loader Class Initialized
INFO - 2017-10-31 11:59:15 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:15 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:15 --> Email Class Initialized
INFO - 2017-10-31 11:59:15 --> Model Class Initialized
INFO - 2017-10-31 11:59:15 --> Controller Class Initialized
INFO - 2017-10-31 11:59:15 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:15 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:15 --> Config Class Initialized
INFO - 2017-10-31 11:59:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:15 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:15 --> URI Class Initialized
INFO - 2017-10-31 11:59:15 --> Router Class Initialized
INFO - 2017-10-31 11:59:15 --> Output Class Initialized
INFO - 2017-10-31 11:59:15 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:15 --> Input Class Initialized
INFO - 2017-10-31 11:59:15 --> Language Class Initialized
INFO - 2017-10-31 11:59:15 --> Loader Class Initialized
INFO - 2017-10-31 11:59:15 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:15 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:15 --> Email Class Initialized
INFO - 2017-10-31 11:59:15 --> Model Class Initialized
INFO - 2017-10-31 11:59:15 --> Controller Class Initialized
INFO - 2017-10-31 11:59:15 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:15 --> Total execution time: 0.0016
INFO - 2017-10-31 11:59:15 --> Config Class Initialized
INFO - 2017-10-31 11:59:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:15 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:15 --> URI Class Initialized
INFO - 2017-10-31 11:59:15 --> Router Class Initialized
INFO - 2017-10-31 11:59:15 --> Output Class Initialized
INFO - 2017-10-31 11:59:15 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:15 --> Input Class Initialized
INFO - 2017-10-31 11:59:15 --> Language Class Initialized
INFO - 2017-10-31 11:59:15 --> Loader Class Initialized
INFO - 2017-10-31 11:59:15 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:15 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:15 --> Email Class Initialized
INFO - 2017-10-31 11:59:15 --> Model Class Initialized
INFO - 2017-10-31 11:59:15 --> Controller Class Initialized
INFO - 2017-10-31 11:59:15 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:15 --> Total execution time: 0.0015
INFO - 2017-10-31 11:59:16 --> Config Class Initialized
INFO - 2017-10-31 11:59:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:16 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:16 --> URI Class Initialized
INFO - 2017-10-31 11:59:16 --> Router Class Initialized
INFO - 2017-10-31 11:59:16 --> Output Class Initialized
INFO - 2017-10-31 11:59:16 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:16 --> Input Class Initialized
INFO - 2017-10-31 11:59:16 --> Language Class Initialized
INFO - 2017-10-31 11:59:16 --> Loader Class Initialized
INFO - 2017-10-31 11:59:16 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:16 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:16 --> Email Class Initialized
INFO - 2017-10-31 11:59:16 --> Model Class Initialized
INFO - 2017-10-31 11:59:16 --> Controller Class Initialized
INFO - 2017-10-31 11:59:16 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:16 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:16 --> Config Class Initialized
INFO - 2017-10-31 11:59:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:16 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:16 --> URI Class Initialized
INFO - 2017-10-31 11:59:16 --> Router Class Initialized
INFO - 2017-10-31 11:59:16 --> Output Class Initialized
INFO - 2017-10-31 11:59:16 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:16 --> Input Class Initialized
INFO - 2017-10-31 11:59:16 --> Language Class Initialized
INFO - 2017-10-31 11:59:16 --> Loader Class Initialized
INFO - 2017-10-31 11:59:16 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:16 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:16 --> Email Class Initialized
INFO - 2017-10-31 11:59:16 --> Model Class Initialized
INFO - 2017-10-31 11:59:16 --> Controller Class Initialized
INFO - 2017-10-31 11:59:16 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:16 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:24 --> Config Class Initialized
INFO - 2017-10-31 11:59:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:24 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:24 --> URI Class Initialized
INFO - 2017-10-31 11:59:24 --> Router Class Initialized
INFO - 2017-10-31 11:59:24 --> Output Class Initialized
INFO - 2017-10-31 11:59:24 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:24 --> Input Class Initialized
INFO - 2017-10-31 11:59:24 --> Language Class Initialized
INFO - 2017-10-31 11:59:24 --> Loader Class Initialized
INFO - 2017-10-31 11:59:24 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:24 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:24 --> Email Class Initialized
INFO - 2017-10-31 11:59:24 --> Model Class Initialized
INFO - 2017-10-31 11:59:24 --> Controller Class Initialized
INFO - 2017-10-31 11:59:24 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:24 --> Total execution time: 0.0029
INFO - 2017-10-31 11:59:25 --> Config Class Initialized
INFO - 2017-10-31 11:59:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:25 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:25 --> URI Class Initialized
INFO - 2017-10-31 11:59:25 --> Router Class Initialized
INFO - 2017-10-31 11:59:25 --> Output Class Initialized
INFO - 2017-10-31 11:59:25 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:25 --> Input Class Initialized
INFO - 2017-10-31 11:59:25 --> Language Class Initialized
INFO - 2017-10-31 11:59:25 --> Loader Class Initialized
INFO - 2017-10-31 11:59:25 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:25 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:25 --> Email Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Controller Class Initialized
INFO - 2017-10-31 11:59:25 --> Helper loaded: cookie_helper
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 11:59:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 11:59:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 11:59:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 11:59:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 11:59:25 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:25 --> Total execution time: 0.0239
INFO - 2017-10-31 11:59:25 --> Config Class Initialized
INFO - 2017-10-31 11:59:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:25 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:25 --> URI Class Initialized
INFO - 2017-10-31 11:59:25 --> Router Class Initialized
INFO - 2017-10-31 11:59:25 --> Output Class Initialized
INFO - 2017-10-31 11:59:25 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:25 --> Input Class Initialized
INFO - 2017-10-31 11:59:25 --> Language Class Initialized
INFO - 2017-10-31 11:59:25 --> Loader Class Initialized
INFO - 2017-10-31 11:59:25 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:25 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:25 --> Email Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Controller Class Initialized
INFO - 2017-10-31 11:59:25 --> Model Class Initialized
INFO - 2017-10-31 11:59:25 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:25 --> Total execution time: 0.0020
INFO - 2017-10-31 11:59:26 --> Config Class Initialized
INFO - 2017-10-31 11:59:26 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:26 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:26 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:26 --> URI Class Initialized
INFO - 2017-10-31 11:59:26 --> Router Class Initialized
INFO - 2017-10-31 11:59:26 --> Output Class Initialized
INFO - 2017-10-31 11:59:26 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:26 --> Input Class Initialized
INFO - 2017-10-31 11:59:26 --> Language Class Initialized
INFO - 2017-10-31 11:59:26 --> Loader Class Initialized
INFO - 2017-10-31 11:59:26 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:26 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:26 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:26 --> Email Class Initialized
INFO - 2017-10-31 11:59:26 --> Model Class Initialized
INFO - 2017-10-31 11:59:26 --> Controller Class Initialized
INFO - 2017-10-31 11:59:26 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:26 --> Total execution time: 0.0017
INFO - 2017-10-31 11:59:33 --> Config Class Initialized
INFO - 2017-10-31 11:59:33 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:33 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:33 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:33 --> URI Class Initialized
INFO - 2017-10-31 11:59:33 --> Router Class Initialized
INFO - 2017-10-31 11:59:33 --> Output Class Initialized
INFO - 2017-10-31 11:59:33 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:33 --> Input Class Initialized
INFO - 2017-10-31 11:59:33 --> Language Class Initialized
INFO - 2017-10-31 11:59:33 --> Loader Class Initialized
INFO - 2017-10-31 11:59:33 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:33 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:33 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:33 --> Email Class Initialized
INFO - 2017-10-31 11:59:33 --> Model Class Initialized
INFO - 2017-10-31 11:59:33 --> Controller Class Initialized
INFO - 2017-10-31 11:59:33 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:33 --> Total execution time: 0.0025
INFO - 2017-10-31 11:59:33 --> Config Class Initialized
INFO - 2017-10-31 11:59:33 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:33 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:33 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:33 --> URI Class Initialized
INFO - 2017-10-31 11:59:33 --> Router Class Initialized
INFO - 2017-10-31 11:59:33 --> Output Class Initialized
INFO - 2017-10-31 11:59:33 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:33 --> Input Class Initialized
INFO - 2017-10-31 11:59:33 --> Language Class Initialized
INFO - 2017-10-31 11:59:33 --> Loader Class Initialized
INFO - 2017-10-31 11:59:33 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:33 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:33 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:33 --> Email Class Initialized
INFO - 2017-10-31 11:59:33 --> Model Class Initialized
INFO - 2017-10-31 11:59:33 --> Controller Class Initialized
INFO - 2017-10-31 11:59:33 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:33 --> Total execution time: 0.0017
INFO - 2017-10-31 11:59:34 --> Config Class Initialized
INFO - 2017-10-31 11:59:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:34 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:34 --> URI Class Initialized
INFO - 2017-10-31 11:59:34 --> Router Class Initialized
INFO - 2017-10-31 11:59:34 --> Output Class Initialized
INFO - 2017-10-31 11:59:34 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:34 --> Input Class Initialized
INFO - 2017-10-31 11:59:34 --> Language Class Initialized
INFO - 2017-10-31 11:59:34 --> Loader Class Initialized
INFO - 2017-10-31 11:59:34 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:34 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:34 --> Email Class Initialized
INFO - 2017-10-31 11:59:34 --> Model Class Initialized
INFO - 2017-10-31 11:59:34 --> Controller Class Initialized
INFO - 2017-10-31 11:59:34 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:34 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:34 --> Config Class Initialized
INFO - 2017-10-31 11:59:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:34 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:34 --> URI Class Initialized
INFO - 2017-10-31 11:59:34 --> Router Class Initialized
INFO - 2017-10-31 11:59:34 --> Output Class Initialized
INFO - 2017-10-31 11:59:34 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:34 --> Input Class Initialized
INFO - 2017-10-31 11:59:34 --> Language Class Initialized
INFO - 2017-10-31 11:59:34 --> Loader Class Initialized
INFO - 2017-10-31 11:59:34 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:34 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:34 --> Email Class Initialized
INFO - 2017-10-31 11:59:34 --> Model Class Initialized
INFO - 2017-10-31 11:59:34 --> Controller Class Initialized
INFO - 2017-10-31 11:59:34 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:34 --> Total execution time: 0.0018
INFO - 2017-10-31 11:59:34 --> Config Class Initialized
INFO - 2017-10-31 11:59:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:34 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:34 --> URI Class Initialized
INFO - 2017-10-31 11:59:34 --> Router Class Initialized
INFO - 2017-10-31 11:59:34 --> Output Class Initialized
INFO - 2017-10-31 11:59:34 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:34 --> Input Class Initialized
INFO - 2017-10-31 11:59:34 --> Language Class Initialized
INFO - 2017-10-31 11:59:34 --> Loader Class Initialized
INFO - 2017-10-31 11:59:34 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:34 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:34 --> Email Class Initialized
INFO - 2017-10-31 11:59:34 --> Model Class Initialized
INFO - 2017-10-31 11:59:34 --> Controller Class Initialized
INFO - 2017-10-31 11:59:34 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:34 --> Total execution time: 0.0015
INFO - 2017-10-31 11:59:35 --> Config Class Initialized
INFO - 2017-10-31 11:59:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:35 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:35 --> URI Class Initialized
INFO - 2017-10-31 11:59:35 --> Router Class Initialized
INFO - 2017-10-31 11:59:35 --> Output Class Initialized
INFO - 2017-10-31 11:59:35 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:35 --> Input Class Initialized
INFO - 2017-10-31 11:59:35 --> Language Class Initialized
INFO - 2017-10-31 11:59:35 --> Loader Class Initialized
INFO - 2017-10-31 11:59:35 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:35 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:35 --> Email Class Initialized
INFO - 2017-10-31 11:59:35 --> Model Class Initialized
INFO - 2017-10-31 11:59:35 --> Controller Class Initialized
INFO - 2017-10-31 11:59:35 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:35 --> Total execution time: 0.0016
INFO - 2017-10-31 11:59:36 --> Config Class Initialized
INFO - 2017-10-31 11:59:36 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:36 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:36 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:36 --> URI Class Initialized
INFO - 2017-10-31 11:59:36 --> Router Class Initialized
INFO - 2017-10-31 11:59:36 --> Output Class Initialized
INFO - 2017-10-31 11:59:36 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:36 --> Input Class Initialized
INFO - 2017-10-31 11:59:36 --> Language Class Initialized
INFO - 2017-10-31 11:59:36 --> Loader Class Initialized
INFO - 2017-10-31 11:59:36 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:36 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:36 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:36 --> Email Class Initialized
INFO - 2017-10-31 11:59:36 --> Model Class Initialized
INFO - 2017-10-31 11:59:36 --> Controller Class Initialized
INFO - 2017-10-31 11:59:36 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:36 --> Total execution time: 0.0016
INFO - 2017-10-31 11:59:36 --> Config Class Initialized
INFO - 2017-10-31 11:59:36 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:36 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:36 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:36 --> URI Class Initialized
INFO - 2017-10-31 11:59:36 --> Router Class Initialized
INFO - 2017-10-31 11:59:36 --> Output Class Initialized
INFO - 2017-10-31 11:59:36 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:36 --> Input Class Initialized
INFO - 2017-10-31 11:59:36 --> Language Class Initialized
INFO - 2017-10-31 11:59:36 --> Loader Class Initialized
INFO - 2017-10-31 11:59:36 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:36 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:36 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:36 --> Email Class Initialized
INFO - 2017-10-31 11:59:36 --> Model Class Initialized
INFO - 2017-10-31 11:59:36 --> Controller Class Initialized
INFO - 2017-10-31 11:59:36 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:36 --> Total execution time: 0.0020
INFO - 2017-10-31 11:59:37 --> Config Class Initialized
INFO - 2017-10-31 11:59:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 11:59:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 11:59:37 --> Utf8 Class Initialized
INFO - 2017-10-31 11:59:37 --> URI Class Initialized
INFO - 2017-10-31 11:59:37 --> Router Class Initialized
INFO - 2017-10-31 11:59:37 --> Output Class Initialized
INFO - 2017-10-31 11:59:37 --> Security Class Initialized
DEBUG - 2017-10-31 11:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 11:59:37 --> Input Class Initialized
INFO - 2017-10-31 11:59:37 --> Language Class Initialized
INFO - 2017-10-31 11:59:37 --> Loader Class Initialized
INFO - 2017-10-31 11:59:37 --> Helper loaded: url_helper
INFO - 2017-10-31 11:59:37 --> Helper loaded: common_helper
INFO - 2017-10-31 11:59:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 11:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 11:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 11:59:37 --> Email Class Initialized
INFO - 2017-10-31 11:59:37 --> Model Class Initialized
INFO - 2017-10-31 11:59:37 --> Controller Class Initialized
INFO - 2017-10-31 11:59:37 --> Final output sent to browser
DEBUG - 2017-10-31 11:59:37 --> Total execution time: 0.0016
INFO - 2017-10-31 12:05:40 --> Config Class Initialized
INFO - 2017-10-31 12:05:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:40 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:40 --> URI Class Initialized
INFO - 2017-10-31 12:05:40 --> Router Class Initialized
INFO - 2017-10-31 12:05:40 --> Output Class Initialized
INFO - 2017-10-31 12:05:40 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:40 --> Input Class Initialized
INFO - 2017-10-31 12:05:40 --> Language Class Initialized
INFO - 2017-10-31 12:05:40 --> Loader Class Initialized
INFO - 2017-10-31 12:05:40 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:40 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:40 --> Email Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Controller Class Initialized
INFO - 2017-10-31 12:05:40 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> Model Class Initialized
INFO - 2017-10-31 12:05:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:05:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:05:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:05:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:05:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:05:40 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:40 --> Total execution time: 0.0326
INFO - 2017-10-31 12:05:41 --> Config Class Initialized
INFO - 2017-10-31 12:05:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:41 --> URI Class Initialized
INFO - 2017-10-31 12:05:41 --> Router Class Initialized
INFO - 2017-10-31 12:05:41 --> Output Class Initialized
INFO - 2017-10-31 12:05:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:41 --> Input Class Initialized
INFO - 2017-10-31 12:05:41 --> Language Class Initialized
INFO - 2017-10-31 12:05:41 --> Loader Class Initialized
INFO - 2017-10-31 12:05:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:41 --> Email Class Initialized
INFO - 2017-10-31 12:05:41 --> Model Class Initialized
INFO - 2017-10-31 12:05:41 --> Controller Class Initialized
INFO - 2017-10-31 12:05:41 --> Model Class Initialized
INFO - 2017-10-31 12:05:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:41 --> Total execution time: 0.0020
INFO - 2017-10-31 12:05:42 --> Config Class Initialized
INFO - 2017-10-31 12:05:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:42 --> URI Class Initialized
INFO - 2017-10-31 12:05:42 --> Router Class Initialized
INFO - 2017-10-31 12:05:42 --> Output Class Initialized
INFO - 2017-10-31 12:05:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:42 --> Input Class Initialized
INFO - 2017-10-31 12:05:42 --> Language Class Initialized
INFO - 2017-10-31 12:05:42 --> Loader Class Initialized
INFO - 2017-10-31 12:05:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:42 --> Email Class Initialized
INFO - 2017-10-31 12:05:42 --> Model Class Initialized
INFO - 2017-10-31 12:05:42 --> Controller Class Initialized
INFO - 2017-10-31 12:05:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:42 --> Total execution time: 0.0017
INFO - 2017-10-31 12:05:46 --> Config Class Initialized
INFO - 2017-10-31 12:05:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:46 --> URI Class Initialized
INFO - 2017-10-31 12:05:46 --> Router Class Initialized
INFO - 2017-10-31 12:05:46 --> Output Class Initialized
INFO - 2017-10-31 12:05:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:46 --> Input Class Initialized
INFO - 2017-10-31 12:05:46 --> Language Class Initialized
INFO - 2017-10-31 12:05:46 --> Loader Class Initialized
INFO - 2017-10-31 12:05:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:46 --> Email Class Initialized
INFO - 2017-10-31 12:05:46 --> Model Class Initialized
INFO - 2017-10-31 12:05:46 --> Controller Class Initialized
INFO - 2017-10-31 12:05:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:46 --> Total execution time: 0.0016
INFO - 2017-10-31 12:05:46 --> Config Class Initialized
INFO - 2017-10-31 12:05:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:46 --> URI Class Initialized
INFO - 2017-10-31 12:05:46 --> Router Class Initialized
INFO - 2017-10-31 12:05:46 --> Output Class Initialized
INFO - 2017-10-31 12:05:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:46 --> Input Class Initialized
INFO - 2017-10-31 12:05:46 --> Language Class Initialized
INFO - 2017-10-31 12:05:46 --> Loader Class Initialized
INFO - 2017-10-31 12:05:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:46 --> Email Class Initialized
INFO - 2017-10-31 12:05:46 --> Model Class Initialized
INFO - 2017-10-31 12:05:46 --> Controller Class Initialized
INFO - 2017-10-31 12:05:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:46 --> Total execution time: 0.0017
INFO - 2017-10-31 12:05:46 --> Config Class Initialized
INFO - 2017-10-31 12:05:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:46 --> URI Class Initialized
INFO - 2017-10-31 12:05:46 --> Router Class Initialized
INFO - 2017-10-31 12:05:46 --> Output Class Initialized
INFO - 2017-10-31 12:05:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:46 --> Input Class Initialized
INFO - 2017-10-31 12:05:46 --> Language Class Initialized
INFO - 2017-10-31 12:05:46 --> Loader Class Initialized
INFO - 2017-10-31 12:05:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:46 --> Email Class Initialized
INFO - 2017-10-31 12:05:46 --> Model Class Initialized
INFO - 2017-10-31 12:05:46 --> Controller Class Initialized
INFO - 2017-10-31 12:05:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:46 --> Total execution time: 0.0016
INFO - 2017-10-31 12:05:47 --> Config Class Initialized
INFO - 2017-10-31 12:05:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:47 --> URI Class Initialized
INFO - 2017-10-31 12:05:47 --> Router Class Initialized
INFO - 2017-10-31 12:05:47 --> Output Class Initialized
INFO - 2017-10-31 12:05:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:47 --> Input Class Initialized
INFO - 2017-10-31 12:05:47 --> Language Class Initialized
INFO - 2017-10-31 12:05:47 --> Loader Class Initialized
INFO - 2017-10-31 12:05:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:47 --> Email Class Initialized
INFO - 2017-10-31 12:05:47 --> Model Class Initialized
INFO - 2017-10-31 12:05:47 --> Controller Class Initialized
INFO - 2017-10-31 12:05:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:47 --> Total execution time: 0.0017
INFO - 2017-10-31 12:05:47 --> Config Class Initialized
INFO - 2017-10-31 12:05:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:47 --> URI Class Initialized
INFO - 2017-10-31 12:05:47 --> Router Class Initialized
INFO - 2017-10-31 12:05:47 --> Output Class Initialized
INFO - 2017-10-31 12:05:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:47 --> Input Class Initialized
INFO - 2017-10-31 12:05:47 --> Language Class Initialized
INFO - 2017-10-31 12:05:47 --> Loader Class Initialized
INFO - 2017-10-31 12:05:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:47 --> Email Class Initialized
INFO - 2017-10-31 12:05:47 --> Model Class Initialized
INFO - 2017-10-31 12:05:47 --> Controller Class Initialized
INFO - 2017-10-31 12:05:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:47 --> Total execution time: 0.0016
INFO - 2017-10-31 12:05:47 --> Config Class Initialized
INFO - 2017-10-31 12:05:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:47 --> URI Class Initialized
INFO - 2017-10-31 12:05:47 --> Router Class Initialized
INFO - 2017-10-31 12:05:47 --> Output Class Initialized
INFO - 2017-10-31 12:05:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:47 --> Input Class Initialized
INFO - 2017-10-31 12:05:47 --> Language Class Initialized
INFO - 2017-10-31 12:05:47 --> Loader Class Initialized
INFO - 2017-10-31 12:05:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:47 --> Email Class Initialized
INFO - 2017-10-31 12:05:47 --> Model Class Initialized
INFO - 2017-10-31 12:05:47 --> Controller Class Initialized
INFO - 2017-10-31 12:05:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:47 --> Total execution time: 0.0016
INFO - 2017-10-31 12:05:48 --> Config Class Initialized
INFO - 2017-10-31 12:05:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:05:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:05:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:05:48 --> URI Class Initialized
INFO - 2017-10-31 12:05:48 --> Router Class Initialized
INFO - 2017-10-31 12:05:48 --> Output Class Initialized
INFO - 2017-10-31 12:05:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:05:48 --> Input Class Initialized
INFO - 2017-10-31 12:05:48 --> Language Class Initialized
INFO - 2017-10-31 12:05:48 --> Loader Class Initialized
INFO - 2017-10-31 12:05:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:05:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:05:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:05:48 --> Email Class Initialized
INFO - 2017-10-31 12:05:48 --> Model Class Initialized
INFO - 2017-10-31 12:05:48 --> Controller Class Initialized
INFO - 2017-10-31 12:05:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:05:48 --> Total execution time: 0.0022
INFO - 2017-10-31 12:06:53 --> Config Class Initialized
INFO - 2017-10-31 12:06:53 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:53 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:53 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:53 --> URI Class Initialized
INFO - 2017-10-31 12:06:53 --> Router Class Initialized
INFO - 2017-10-31 12:06:53 --> Output Class Initialized
INFO - 2017-10-31 12:06:53 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:53 --> Input Class Initialized
INFO - 2017-10-31 12:06:53 --> Language Class Initialized
INFO - 2017-10-31 12:06:53 --> Loader Class Initialized
INFO - 2017-10-31 12:06:53 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:53 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:53 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:53 --> Email Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Controller Class Initialized
INFO - 2017-10-31 12:06:53 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> Model Class Initialized
INFO - 2017-10-31 12:06:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:53 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:53 --> Total execution time: 0.0350
INFO - 2017-10-31 12:06:55 --> Config Class Initialized
INFO - 2017-10-31 12:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:55 --> URI Class Initialized
INFO - 2017-10-31 12:06:55 --> Router Class Initialized
INFO - 2017-10-31 12:06:55 --> Output Class Initialized
INFO - 2017-10-31 12:06:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:55 --> Input Class Initialized
INFO - 2017-10-31 12:06:55 --> Language Class Initialized
INFO - 2017-10-31 12:06:55 --> Loader Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:55 --> Email Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Controller Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:55 --> Total execution time: 0.0296
INFO - 2017-10-31 12:06:55 --> Config Class Initialized
INFO - 2017-10-31 12:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:55 --> URI Class Initialized
INFO - 2017-10-31 12:06:55 --> Router Class Initialized
INFO - 2017-10-31 12:06:55 --> Output Class Initialized
INFO - 2017-10-31 12:06:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:55 --> Input Class Initialized
INFO - 2017-10-31 12:06:55 --> Language Class Initialized
INFO - 2017-10-31 12:06:55 --> Loader Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:55 --> Email Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Controller Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:55 --> Total execution time: 0.0404
INFO - 2017-10-31 12:06:55 --> Config Class Initialized
INFO - 2017-10-31 12:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:55 --> URI Class Initialized
INFO - 2017-10-31 12:06:55 --> Router Class Initialized
INFO - 2017-10-31 12:06:55 --> Output Class Initialized
INFO - 2017-10-31 12:06:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:55 --> Input Class Initialized
INFO - 2017-10-31 12:06:55 --> Language Class Initialized
INFO - 2017-10-31 12:06:55 --> Loader Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:55 --> Email Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Controller Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:55 --> Total execution time: 0.0557
INFO - 2017-10-31 12:06:55 --> Config Class Initialized
INFO - 2017-10-31 12:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:55 --> URI Class Initialized
INFO - 2017-10-31 12:06:55 --> Router Class Initialized
INFO - 2017-10-31 12:06:55 --> Output Class Initialized
INFO - 2017-10-31 12:06:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:55 --> Input Class Initialized
INFO - 2017-10-31 12:06:55 --> Language Class Initialized
INFO - 2017-10-31 12:06:55 --> Loader Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:55 --> Email Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Controller Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:55 --> Total execution time: 0.0521
INFO - 2017-10-31 12:06:55 --> Config Class Initialized
INFO - 2017-10-31 12:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:55 --> URI Class Initialized
INFO - 2017-10-31 12:06:55 --> Router Class Initialized
INFO - 2017-10-31 12:06:55 --> Output Class Initialized
INFO - 2017-10-31 12:06:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:55 --> Input Class Initialized
INFO - 2017-10-31 12:06:55 --> Language Class Initialized
INFO - 2017-10-31 12:06:55 --> Loader Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:55 --> Email Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Controller Class Initialized
INFO - 2017-10-31 12:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> Model Class Initialized
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:55 --> Total execution time: 0.0387
INFO - 2017-10-31 12:06:56 --> Config Class Initialized
INFO - 2017-10-31 12:06:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:56 --> URI Class Initialized
INFO - 2017-10-31 12:06:56 --> Router Class Initialized
INFO - 2017-10-31 12:06:56 --> Output Class Initialized
INFO - 2017-10-31 12:06:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:56 --> Input Class Initialized
INFO - 2017-10-31 12:06:56 --> Language Class Initialized
INFO - 2017-10-31 12:06:56 --> Loader Class Initialized
INFO - 2017-10-31 12:06:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:56 --> Email Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Controller Class Initialized
INFO - 2017-10-31 12:06:56 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:56 --> Total execution time: 0.0500
INFO - 2017-10-31 12:06:56 --> Config Class Initialized
INFO - 2017-10-31 12:06:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:06:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:06:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:06:56 --> URI Class Initialized
INFO - 2017-10-31 12:06:56 --> Router Class Initialized
INFO - 2017-10-31 12:06:56 --> Output Class Initialized
INFO - 2017-10-31 12:06:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:06:56 --> Input Class Initialized
INFO - 2017-10-31 12:06:56 --> Language Class Initialized
INFO - 2017-10-31 12:06:56 --> Loader Class Initialized
INFO - 2017-10-31 12:06:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:06:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:06:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:06:56 --> Email Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Controller Class Initialized
INFO - 2017-10-31 12:06:56 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> Model Class Initialized
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:06:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:06:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:06:56 --> Total execution time: 0.0525
INFO - 2017-10-31 12:07:03 --> Config Class Initialized
INFO - 2017-10-31 12:07:03 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:03 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:03 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:03 --> URI Class Initialized
INFO - 2017-10-31 12:07:03 --> Router Class Initialized
INFO - 2017-10-31 12:07:03 --> Output Class Initialized
INFO - 2017-10-31 12:07:03 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:03 --> Input Class Initialized
INFO - 2017-10-31 12:07:03 --> Language Class Initialized
INFO - 2017-10-31 12:07:03 --> Loader Class Initialized
INFO - 2017-10-31 12:07:03 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:03 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:03 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:03 --> Email Class Initialized
INFO - 2017-10-31 12:07:03 --> Model Class Initialized
INFO - 2017-10-31 12:07:03 --> Controller Class Initialized
INFO - 2017-10-31 12:07:03 --> Model Class Initialized
INFO - 2017-10-31 12:07:03 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:03 --> Total execution time: 0.0035
INFO - 2017-10-31 12:07:08 --> Config Class Initialized
INFO - 2017-10-31 12:07:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:08 --> URI Class Initialized
INFO - 2017-10-31 12:07:08 --> Router Class Initialized
INFO - 2017-10-31 12:07:08 --> Output Class Initialized
INFO - 2017-10-31 12:07:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:08 --> Input Class Initialized
INFO - 2017-10-31 12:07:08 --> Language Class Initialized
INFO - 2017-10-31 12:07:08 --> Loader Class Initialized
INFO - 2017-10-31 12:07:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:08 --> Email Class Initialized
INFO - 2017-10-31 12:07:08 --> Model Class Initialized
INFO - 2017-10-31 12:07:08 --> Controller Class Initialized
INFO - 2017-10-31 12:07:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:08 --> Total execution time: 0.0038
INFO - 2017-10-31 12:07:12 --> Config Class Initialized
INFO - 2017-10-31 12:07:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:12 --> URI Class Initialized
INFO - 2017-10-31 12:07:12 --> Router Class Initialized
INFO - 2017-10-31 12:07:12 --> Output Class Initialized
INFO - 2017-10-31 12:07:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:12 --> Input Class Initialized
INFO - 2017-10-31 12:07:12 --> Language Class Initialized
INFO - 2017-10-31 12:07:12 --> Loader Class Initialized
INFO - 2017-10-31 12:07:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:12 --> Email Class Initialized
INFO - 2017-10-31 12:07:12 --> Model Class Initialized
INFO - 2017-10-31 12:07:12 --> Controller Class Initialized
INFO - 2017-10-31 12:07:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:12 --> Total execution time: 0.0035
INFO - 2017-10-31 12:07:12 --> Config Class Initialized
INFO - 2017-10-31 12:07:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:12 --> URI Class Initialized
INFO - 2017-10-31 12:07:12 --> Router Class Initialized
INFO - 2017-10-31 12:07:12 --> Output Class Initialized
INFO - 2017-10-31 12:07:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:12 --> Input Class Initialized
INFO - 2017-10-31 12:07:12 --> Language Class Initialized
INFO - 2017-10-31 12:07:12 --> Loader Class Initialized
INFO - 2017-10-31 12:07:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:12 --> Email Class Initialized
INFO - 2017-10-31 12:07:12 --> Model Class Initialized
INFO - 2017-10-31 12:07:12 --> Controller Class Initialized
INFO - 2017-10-31 12:07:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:12 --> Total execution time: 0.0059
INFO - 2017-10-31 12:07:12 --> Config Class Initialized
INFO - 2017-10-31 12:07:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:12 --> URI Class Initialized
INFO - 2017-10-31 12:07:12 --> Router Class Initialized
INFO - 2017-10-31 12:07:12 --> Output Class Initialized
INFO - 2017-10-31 12:07:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:12 --> Input Class Initialized
INFO - 2017-10-31 12:07:12 --> Language Class Initialized
INFO - 2017-10-31 12:07:12 --> Loader Class Initialized
INFO - 2017-10-31 12:07:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:12 --> Email Class Initialized
INFO - 2017-10-31 12:07:12 --> Model Class Initialized
INFO - 2017-10-31 12:07:12 --> Controller Class Initialized
INFO - 2017-10-31 12:07:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:12 --> Total execution time: 0.0029
INFO - 2017-10-31 12:07:13 --> Config Class Initialized
INFO - 2017-10-31 12:07:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:13 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:13 --> URI Class Initialized
INFO - 2017-10-31 12:07:13 --> Router Class Initialized
INFO - 2017-10-31 12:07:13 --> Output Class Initialized
INFO - 2017-10-31 12:07:13 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:13 --> Input Class Initialized
INFO - 2017-10-31 12:07:13 --> Language Class Initialized
INFO - 2017-10-31 12:07:13 --> Loader Class Initialized
INFO - 2017-10-31 12:07:13 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:13 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:13 --> Email Class Initialized
INFO - 2017-10-31 12:07:13 --> Model Class Initialized
INFO - 2017-10-31 12:07:13 --> Controller Class Initialized
INFO - 2017-10-31 12:07:13 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:13 --> Total execution time: 0.0030
INFO - 2017-10-31 12:07:13 --> Config Class Initialized
INFO - 2017-10-31 12:07:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:13 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:13 --> URI Class Initialized
INFO - 2017-10-31 12:07:13 --> Router Class Initialized
INFO - 2017-10-31 12:07:13 --> Output Class Initialized
INFO - 2017-10-31 12:07:13 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:13 --> Input Class Initialized
INFO - 2017-10-31 12:07:13 --> Language Class Initialized
INFO - 2017-10-31 12:07:13 --> Loader Class Initialized
INFO - 2017-10-31 12:07:13 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:13 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:13 --> Email Class Initialized
INFO - 2017-10-31 12:07:13 --> Model Class Initialized
INFO - 2017-10-31 12:07:13 --> Controller Class Initialized
INFO - 2017-10-31 12:07:13 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:13 --> Total execution time: 0.0052
INFO - 2017-10-31 12:07:14 --> Config Class Initialized
INFO - 2017-10-31 12:07:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:14 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:14 --> URI Class Initialized
INFO - 2017-10-31 12:07:14 --> Router Class Initialized
INFO - 2017-10-31 12:07:14 --> Output Class Initialized
INFO - 2017-10-31 12:07:14 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:14 --> Input Class Initialized
INFO - 2017-10-31 12:07:14 --> Language Class Initialized
INFO - 2017-10-31 12:07:14 --> Loader Class Initialized
INFO - 2017-10-31 12:07:14 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:14 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:14 --> Email Class Initialized
INFO - 2017-10-31 12:07:14 --> Model Class Initialized
INFO - 2017-10-31 12:07:14 --> Controller Class Initialized
INFO - 2017-10-31 12:07:14 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:14 --> Total execution time: 0.0030
INFO - 2017-10-31 12:07:41 --> Config Class Initialized
INFO - 2017-10-31 12:07:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:41 --> URI Class Initialized
INFO - 2017-10-31 12:07:41 --> Router Class Initialized
INFO - 2017-10-31 12:07:41 --> Output Class Initialized
INFO - 2017-10-31 12:07:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:41 --> Input Class Initialized
INFO - 2017-10-31 12:07:41 --> Language Class Initialized
INFO - 2017-10-31 12:07:41 --> Loader Class Initialized
INFO - 2017-10-31 12:07:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:41 --> Email Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Controller Class Initialized
INFO - 2017-10-31 12:07:41 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:07:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:07:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:07:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:07:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:07:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:41 --> Total execution time: 0.0290
INFO - 2017-10-31 12:07:41 --> Config Class Initialized
INFO - 2017-10-31 12:07:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:41 --> URI Class Initialized
INFO - 2017-10-31 12:07:41 --> Router Class Initialized
INFO - 2017-10-31 12:07:41 --> Output Class Initialized
INFO - 2017-10-31 12:07:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:41 --> Input Class Initialized
INFO - 2017-10-31 12:07:41 --> Language Class Initialized
INFO - 2017-10-31 12:07:41 --> Loader Class Initialized
INFO - 2017-10-31 12:07:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:41 --> Email Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Controller Class Initialized
INFO - 2017-10-31 12:07:41 --> Model Class Initialized
INFO - 2017-10-31 12:07:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:41 --> Total execution time: 0.0026
INFO - 2017-10-31 12:07:43 --> Config Class Initialized
INFO - 2017-10-31 12:07:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:43 --> URI Class Initialized
INFO - 2017-10-31 12:07:43 --> Router Class Initialized
INFO - 2017-10-31 12:07:43 --> Output Class Initialized
INFO - 2017-10-31 12:07:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:43 --> Input Class Initialized
INFO - 2017-10-31 12:07:43 --> Language Class Initialized
INFO - 2017-10-31 12:07:43 --> Loader Class Initialized
INFO - 2017-10-31 12:07:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:43 --> Email Class Initialized
INFO - 2017-10-31 12:07:43 --> Model Class Initialized
INFO - 2017-10-31 12:07:43 --> Controller Class Initialized
INFO - 2017-10-31 12:07:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:43 --> Total execution time: 0.0024
INFO - 2017-10-31 12:07:47 --> Config Class Initialized
INFO - 2017-10-31 12:07:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:47 --> URI Class Initialized
INFO - 2017-10-31 12:07:47 --> Router Class Initialized
INFO - 2017-10-31 12:07:47 --> Output Class Initialized
INFO - 2017-10-31 12:07:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:47 --> Input Class Initialized
INFO - 2017-10-31 12:07:47 --> Language Class Initialized
INFO - 2017-10-31 12:07:47 --> Loader Class Initialized
INFO - 2017-10-31 12:07:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:47 --> Email Class Initialized
INFO - 2017-10-31 12:07:47 --> Model Class Initialized
INFO - 2017-10-31 12:07:47 --> Controller Class Initialized
INFO - 2017-10-31 12:07:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:47 --> Total execution time: 0.0022
INFO - 2017-10-31 12:07:48 --> Config Class Initialized
INFO - 2017-10-31 12:07:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:48 --> URI Class Initialized
INFO - 2017-10-31 12:07:48 --> Router Class Initialized
INFO - 2017-10-31 12:07:48 --> Output Class Initialized
INFO - 2017-10-31 12:07:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:48 --> Input Class Initialized
INFO - 2017-10-31 12:07:48 --> Language Class Initialized
INFO - 2017-10-31 12:07:48 --> Loader Class Initialized
INFO - 2017-10-31 12:07:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:48 --> Email Class Initialized
INFO - 2017-10-31 12:07:48 --> Model Class Initialized
INFO - 2017-10-31 12:07:48 --> Controller Class Initialized
INFO - 2017-10-31 12:07:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:48 --> Total execution time: 0.0019
INFO - 2017-10-31 12:07:49 --> Config Class Initialized
INFO - 2017-10-31 12:07:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:49 --> URI Class Initialized
INFO - 2017-10-31 12:07:49 --> Router Class Initialized
INFO - 2017-10-31 12:07:49 --> Output Class Initialized
INFO - 2017-10-31 12:07:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:49 --> Input Class Initialized
INFO - 2017-10-31 12:07:49 --> Language Class Initialized
INFO - 2017-10-31 12:07:49 --> Loader Class Initialized
INFO - 2017-10-31 12:07:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:49 --> Email Class Initialized
INFO - 2017-10-31 12:07:49 --> Model Class Initialized
INFO - 2017-10-31 12:07:49 --> Controller Class Initialized
INFO - 2017-10-31 12:07:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:49 --> Total execution time: 0.0018
INFO - 2017-10-31 12:07:49 --> Config Class Initialized
INFO - 2017-10-31 12:07:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:49 --> URI Class Initialized
INFO - 2017-10-31 12:07:49 --> Router Class Initialized
INFO - 2017-10-31 12:07:49 --> Output Class Initialized
INFO - 2017-10-31 12:07:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:49 --> Input Class Initialized
INFO - 2017-10-31 12:07:49 --> Language Class Initialized
INFO - 2017-10-31 12:07:49 --> Loader Class Initialized
INFO - 2017-10-31 12:07:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:49 --> Email Class Initialized
INFO - 2017-10-31 12:07:49 --> Model Class Initialized
INFO - 2017-10-31 12:07:49 --> Controller Class Initialized
INFO - 2017-10-31 12:07:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:49 --> Total execution time: 0.0016
INFO - 2017-10-31 12:07:50 --> Config Class Initialized
INFO - 2017-10-31 12:07:50 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:50 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:50 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:50 --> URI Class Initialized
INFO - 2017-10-31 12:07:50 --> Router Class Initialized
INFO - 2017-10-31 12:07:50 --> Output Class Initialized
INFO - 2017-10-31 12:07:50 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:50 --> Input Class Initialized
INFO - 2017-10-31 12:07:50 --> Language Class Initialized
INFO - 2017-10-31 12:07:50 --> Loader Class Initialized
INFO - 2017-10-31 12:07:50 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:50 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:50 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:50 --> Email Class Initialized
INFO - 2017-10-31 12:07:50 --> Model Class Initialized
INFO - 2017-10-31 12:07:50 --> Controller Class Initialized
INFO - 2017-10-31 12:07:50 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:50 --> Total execution time: 0.0016
INFO - 2017-10-31 12:07:55 --> Config Class Initialized
INFO - 2017-10-31 12:07:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:55 --> URI Class Initialized
INFO - 2017-10-31 12:07:55 --> Router Class Initialized
INFO - 2017-10-31 12:07:55 --> Output Class Initialized
INFO - 2017-10-31 12:07:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:55 --> Input Class Initialized
INFO - 2017-10-31 12:07:55 --> Language Class Initialized
INFO - 2017-10-31 12:07:55 --> Loader Class Initialized
INFO - 2017-10-31 12:07:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:55 --> Email Class Initialized
INFO - 2017-10-31 12:07:55 --> Model Class Initialized
INFO - 2017-10-31 12:07:55 --> Controller Class Initialized
INFO - 2017-10-31 12:07:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:55 --> Total execution time: 0.0025
INFO - 2017-10-31 12:07:55 --> Config Class Initialized
INFO - 2017-10-31 12:07:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:55 --> URI Class Initialized
INFO - 2017-10-31 12:07:55 --> Router Class Initialized
INFO - 2017-10-31 12:07:55 --> Output Class Initialized
INFO - 2017-10-31 12:07:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:55 --> Input Class Initialized
INFO - 2017-10-31 12:07:55 --> Language Class Initialized
INFO - 2017-10-31 12:07:55 --> Loader Class Initialized
INFO - 2017-10-31 12:07:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:55 --> Email Class Initialized
INFO - 2017-10-31 12:07:55 --> Model Class Initialized
INFO - 2017-10-31 12:07:55 --> Controller Class Initialized
INFO - 2017-10-31 12:07:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:55 --> Total execution time: 0.0016
INFO - 2017-10-31 12:07:56 --> Config Class Initialized
INFO - 2017-10-31 12:07:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:07:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:07:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:07:56 --> URI Class Initialized
INFO - 2017-10-31 12:07:56 --> Router Class Initialized
INFO - 2017-10-31 12:07:56 --> Output Class Initialized
INFO - 2017-10-31 12:07:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:07:56 --> Input Class Initialized
INFO - 2017-10-31 12:07:56 --> Language Class Initialized
INFO - 2017-10-31 12:07:56 --> Loader Class Initialized
INFO - 2017-10-31 12:07:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:07:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:07:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:07:56 --> Email Class Initialized
INFO - 2017-10-31 12:07:56 --> Model Class Initialized
INFO - 2017-10-31 12:07:56 --> Controller Class Initialized
INFO - 2017-10-31 12:07:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:07:56 --> Total execution time: 0.0017
INFO - 2017-10-31 12:10:42 --> Config Class Initialized
INFO - 2017-10-31 12:10:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:42 --> URI Class Initialized
INFO - 2017-10-31 12:10:42 --> Router Class Initialized
INFO - 2017-10-31 12:10:42 --> Output Class Initialized
INFO - 2017-10-31 12:10:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:42 --> Input Class Initialized
INFO - 2017-10-31 12:10:42 --> Language Class Initialized
INFO - 2017-10-31 12:10:42 --> Loader Class Initialized
INFO - 2017-10-31 12:10:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:42 --> Email Class Initialized
INFO - 2017-10-31 12:10:42 --> Model Class Initialized
INFO - 2017-10-31 12:10:42 --> Controller Class Initialized
INFO - 2017-10-31 12:10:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:42 --> Total execution time: 0.0016
INFO - 2017-10-31 12:10:42 --> Config Class Initialized
INFO - 2017-10-31 12:10:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:42 --> URI Class Initialized
INFO - 2017-10-31 12:10:42 --> Router Class Initialized
INFO - 2017-10-31 12:10:42 --> Output Class Initialized
INFO - 2017-10-31 12:10:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:42 --> Input Class Initialized
INFO - 2017-10-31 12:10:42 --> Language Class Initialized
INFO - 2017-10-31 12:10:42 --> Loader Class Initialized
INFO - 2017-10-31 12:10:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:42 --> Email Class Initialized
INFO - 2017-10-31 12:10:42 --> Model Class Initialized
INFO - 2017-10-31 12:10:42 --> Controller Class Initialized
INFO - 2017-10-31 12:10:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:42 --> Total execution time: 0.0015
INFO - 2017-10-31 12:10:43 --> Config Class Initialized
INFO - 2017-10-31 12:10:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:43 --> URI Class Initialized
INFO - 2017-10-31 12:10:43 --> Router Class Initialized
INFO - 2017-10-31 12:10:43 --> Output Class Initialized
INFO - 2017-10-31 12:10:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:43 --> Input Class Initialized
INFO - 2017-10-31 12:10:43 --> Language Class Initialized
INFO - 2017-10-31 12:10:43 --> Loader Class Initialized
INFO - 2017-10-31 12:10:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:43 --> Email Class Initialized
INFO - 2017-10-31 12:10:43 --> Model Class Initialized
INFO - 2017-10-31 12:10:43 --> Controller Class Initialized
INFO - 2017-10-31 12:10:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:43 --> Total execution time: 0.0016
INFO - 2017-10-31 12:10:43 --> Config Class Initialized
INFO - 2017-10-31 12:10:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:43 --> URI Class Initialized
INFO - 2017-10-31 12:10:43 --> Router Class Initialized
INFO - 2017-10-31 12:10:43 --> Output Class Initialized
INFO - 2017-10-31 12:10:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:43 --> Input Class Initialized
INFO - 2017-10-31 12:10:43 --> Language Class Initialized
INFO - 2017-10-31 12:10:43 --> Loader Class Initialized
INFO - 2017-10-31 12:10:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:43 --> Email Class Initialized
INFO - 2017-10-31 12:10:43 --> Model Class Initialized
INFO - 2017-10-31 12:10:43 --> Controller Class Initialized
INFO - 2017-10-31 12:10:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:43 --> Total execution time: 0.0016
INFO - 2017-10-31 12:10:43 --> Config Class Initialized
INFO - 2017-10-31 12:10:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:43 --> URI Class Initialized
INFO - 2017-10-31 12:10:43 --> Router Class Initialized
INFO - 2017-10-31 12:10:43 --> Output Class Initialized
INFO - 2017-10-31 12:10:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:43 --> Input Class Initialized
INFO - 2017-10-31 12:10:43 --> Language Class Initialized
INFO - 2017-10-31 12:10:43 --> Loader Class Initialized
INFO - 2017-10-31 12:10:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:43 --> Email Class Initialized
INFO - 2017-10-31 12:10:43 --> Model Class Initialized
INFO - 2017-10-31 12:10:43 --> Controller Class Initialized
INFO - 2017-10-31 12:10:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:43 --> Total execution time: 0.0016
INFO - 2017-10-31 12:10:43 --> Config Class Initialized
INFO - 2017-10-31 12:10:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:43 --> URI Class Initialized
INFO - 2017-10-31 12:10:43 --> Router Class Initialized
INFO - 2017-10-31 12:10:43 --> Output Class Initialized
INFO - 2017-10-31 12:10:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:43 --> Input Class Initialized
INFO - 2017-10-31 12:10:43 --> Language Class Initialized
INFO - 2017-10-31 12:10:43 --> Loader Class Initialized
INFO - 2017-10-31 12:10:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:43 --> Email Class Initialized
INFO - 2017-10-31 12:10:43 --> Model Class Initialized
INFO - 2017-10-31 12:10:43 --> Controller Class Initialized
INFO - 2017-10-31 12:10:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:43 --> Total execution time: 0.0017
INFO - 2017-10-31 12:10:43 --> Config Class Initialized
INFO - 2017-10-31 12:10:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:10:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:10:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:10:43 --> URI Class Initialized
INFO - 2017-10-31 12:10:43 --> Router Class Initialized
INFO - 2017-10-31 12:10:43 --> Output Class Initialized
INFO - 2017-10-31 12:10:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:10:43 --> Input Class Initialized
INFO - 2017-10-31 12:10:43 --> Language Class Initialized
INFO - 2017-10-31 12:10:43 --> Loader Class Initialized
INFO - 2017-10-31 12:10:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:10:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:10:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:10:43 --> Email Class Initialized
INFO - 2017-10-31 12:10:43 --> Model Class Initialized
INFO - 2017-10-31 12:10:43 --> Controller Class Initialized
INFO - 2017-10-31 12:10:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:10:43 --> Total execution time: 0.0016
INFO - 2017-10-31 12:17:00 --> Config Class Initialized
INFO - 2017-10-31 12:17:00 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:00 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:00 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:00 --> URI Class Initialized
INFO - 2017-10-31 12:17:00 --> Router Class Initialized
INFO - 2017-10-31 12:17:00 --> Output Class Initialized
INFO - 2017-10-31 12:17:00 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:00 --> Input Class Initialized
INFO - 2017-10-31 12:17:00 --> Language Class Initialized
INFO - 2017-10-31 12:17:00 --> Loader Class Initialized
INFO - 2017-10-31 12:17:00 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:00 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:00 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:00 --> Email Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Controller Class Initialized
INFO - 2017-10-31 12:17:00 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:17:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:17:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:17:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:17:00 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:17:00 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:00 --> Total execution time: 0.0291
INFO - 2017-10-31 12:17:00 --> Config Class Initialized
INFO - 2017-10-31 12:17:00 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:00 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:00 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:00 --> URI Class Initialized
INFO - 2017-10-31 12:17:00 --> Router Class Initialized
INFO - 2017-10-31 12:17:00 --> Output Class Initialized
INFO - 2017-10-31 12:17:00 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:00 --> Input Class Initialized
INFO - 2017-10-31 12:17:00 --> Language Class Initialized
INFO - 2017-10-31 12:17:00 --> Loader Class Initialized
INFO - 2017-10-31 12:17:00 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:00 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:00 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:00 --> Email Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Controller Class Initialized
INFO - 2017-10-31 12:17:00 --> Model Class Initialized
INFO - 2017-10-31 12:17:00 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:00 --> Total execution time: 0.0020
INFO - 2017-10-31 12:17:01 --> Config Class Initialized
INFO - 2017-10-31 12:17:01 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:01 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:01 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:01 --> URI Class Initialized
INFO - 2017-10-31 12:17:01 --> Router Class Initialized
INFO - 2017-10-31 12:17:01 --> Output Class Initialized
INFO - 2017-10-31 12:17:01 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:01 --> Input Class Initialized
INFO - 2017-10-31 12:17:01 --> Language Class Initialized
INFO - 2017-10-31 12:17:01 --> Loader Class Initialized
INFO - 2017-10-31 12:17:01 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:01 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:01 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:01 --> Email Class Initialized
INFO - 2017-10-31 12:17:01 --> Model Class Initialized
INFO - 2017-10-31 12:17:01 --> Controller Class Initialized
INFO - 2017-10-31 12:17:01 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:01 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:07 --> Config Class Initialized
INFO - 2017-10-31 12:17:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:07 --> URI Class Initialized
INFO - 2017-10-31 12:17:07 --> Router Class Initialized
INFO - 2017-10-31 12:17:07 --> Output Class Initialized
INFO - 2017-10-31 12:17:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:07 --> Input Class Initialized
INFO - 2017-10-31 12:17:07 --> Language Class Initialized
INFO - 2017-10-31 12:17:07 --> Loader Class Initialized
INFO - 2017-10-31 12:17:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:07 --> Email Class Initialized
INFO - 2017-10-31 12:17:07 --> Model Class Initialized
INFO - 2017-10-31 12:17:07 --> Controller Class Initialized
INFO - 2017-10-31 12:17:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:07 --> Total execution time: 0.0024
INFO - 2017-10-31 12:17:07 --> Config Class Initialized
INFO - 2017-10-31 12:17:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:07 --> URI Class Initialized
INFO - 2017-10-31 12:17:07 --> Router Class Initialized
INFO - 2017-10-31 12:17:07 --> Output Class Initialized
INFO - 2017-10-31 12:17:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:07 --> Input Class Initialized
INFO - 2017-10-31 12:17:07 --> Language Class Initialized
INFO - 2017-10-31 12:17:07 --> Loader Class Initialized
INFO - 2017-10-31 12:17:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:07 --> Email Class Initialized
INFO - 2017-10-31 12:17:07 --> Model Class Initialized
INFO - 2017-10-31 12:17:07 --> Controller Class Initialized
INFO - 2017-10-31 12:17:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:07 --> Total execution time: 0.0019
INFO - 2017-10-31 12:17:07 --> Config Class Initialized
INFO - 2017-10-31 12:17:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:07 --> URI Class Initialized
INFO - 2017-10-31 12:17:07 --> Router Class Initialized
INFO - 2017-10-31 12:17:07 --> Output Class Initialized
INFO - 2017-10-31 12:17:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:07 --> Input Class Initialized
INFO - 2017-10-31 12:17:07 --> Language Class Initialized
INFO - 2017-10-31 12:17:07 --> Loader Class Initialized
INFO - 2017-10-31 12:17:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:07 --> Email Class Initialized
INFO - 2017-10-31 12:17:07 --> Model Class Initialized
INFO - 2017-10-31 12:17:07 --> Controller Class Initialized
INFO - 2017-10-31 12:17:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:07 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:08 --> Config Class Initialized
INFO - 2017-10-31 12:17:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:08 --> URI Class Initialized
INFO - 2017-10-31 12:17:08 --> Router Class Initialized
INFO - 2017-10-31 12:17:08 --> Output Class Initialized
INFO - 2017-10-31 12:17:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:08 --> Input Class Initialized
INFO - 2017-10-31 12:17:08 --> Language Class Initialized
INFO - 2017-10-31 12:17:08 --> Loader Class Initialized
INFO - 2017-10-31 12:17:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:08 --> Email Class Initialized
INFO - 2017-10-31 12:17:08 --> Model Class Initialized
INFO - 2017-10-31 12:17:08 --> Controller Class Initialized
INFO - 2017-10-31 12:17:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:08 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:21 --> Config Class Initialized
INFO - 2017-10-31 12:17:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:21 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:21 --> URI Class Initialized
INFO - 2017-10-31 12:17:21 --> Router Class Initialized
INFO - 2017-10-31 12:17:21 --> Output Class Initialized
INFO - 2017-10-31 12:17:21 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:21 --> Input Class Initialized
INFO - 2017-10-31 12:17:21 --> Language Class Initialized
INFO - 2017-10-31 12:17:21 --> Loader Class Initialized
INFO - 2017-10-31 12:17:21 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:21 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:21 --> Email Class Initialized
INFO - 2017-10-31 12:17:21 --> Model Class Initialized
INFO - 2017-10-31 12:17:21 --> Controller Class Initialized
INFO - 2017-10-31 12:17:21 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:21 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:42 --> Config Class Initialized
INFO - 2017-10-31 12:17:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:42 --> URI Class Initialized
INFO - 2017-10-31 12:17:42 --> Router Class Initialized
INFO - 2017-10-31 12:17:42 --> Output Class Initialized
INFO - 2017-10-31 12:17:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:42 --> Input Class Initialized
INFO - 2017-10-31 12:17:42 --> Language Class Initialized
INFO - 2017-10-31 12:17:42 --> Loader Class Initialized
INFO - 2017-10-31 12:17:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:42 --> Email Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Controller Class Initialized
INFO - 2017-10-31 12:17:42 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:17:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:42 --> Total execution time: 0.0267
INFO - 2017-10-31 12:17:42 --> Config Class Initialized
INFO - 2017-10-31 12:17:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:42 --> URI Class Initialized
INFO - 2017-10-31 12:17:42 --> Router Class Initialized
INFO - 2017-10-31 12:17:42 --> Output Class Initialized
INFO - 2017-10-31 12:17:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:42 --> Input Class Initialized
INFO - 2017-10-31 12:17:42 --> Language Class Initialized
INFO - 2017-10-31 12:17:42 --> Loader Class Initialized
INFO - 2017-10-31 12:17:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:42 --> Email Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Controller Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:42 --> Total execution time: 0.0031
INFO - 2017-10-31 12:17:42 --> Config Class Initialized
INFO - 2017-10-31 12:17:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:42 --> URI Class Initialized
INFO - 2017-10-31 12:17:42 --> Router Class Initialized
INFO - 2017-10-31 12:17:42 --> Output Class Initialized
INFO - 2017-10-31 12:17:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:42 --> Input Class Initialized
INFO - 2017-10-31 12:17:42 --> Language Class Initialized
INFO - 2017-10-31 12:17:42 --> Loader Class Initialized
INFO - 2017-10-31 12:17:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:42 --> Email Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Controller Class Initialized
INFO - 2017-10-31 12:17:42 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> Model Class Initialized
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:17:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:17:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:42 --> Total execution time: 0.0368
INFO - 2017-10-31 12:17:43 --> Config Class Initialized
INFO - 2017-10-31 12:17:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:43 --> URI Class Initialized
INFO - 2017-10-31 12:17:43 --> Router Class Initialized
INFO - 2017-10-31 12:17:43 --> Output Class Initialized
INFO - 2017-10-31 12:17:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:43 --> Input Class Initialized
INFO - 2017-10-31 12:17:43 --> Language Class Initialized
INFO - 2017-10-31 12:17:43 --> Loader Class Initialized
INFO - 2017-10-31 12:17:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:43 --> Email Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Controller Class Initialized
INFO - 2017-10-31 12:17:43 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:17:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:17:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:17:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:17:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:17:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:43 --> Total execution time: 0.0353
INFO - 2017-10-31 12:17:43 --> Config Class Initialized
INFO - 2017-10-31 12:17:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:43 --> URI Class Initialized
INFO - 2017-10-31 12:17:43 --> Router Class Initialized
INFO - 2017-10-31 12:17:43 --> Output Class Initialized
INFO - 2017-10-31 12:17:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:43 --> Input Class Initialized
INFO - 2017-10-31 12:17:43 --> Language Class Initialized
INFO - 2017-10-31 12:17:43 --> Loader Class Initialized
INFO - 2017-10-31 12:17:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:43 --> Email Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Controller Class Initialized
INFO - 2017-10-31 12:17:43 --> Model Class Initialized
INFO - 2017-10-31 12:17:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:43 --> Total execution time: 0.0020
INFO - 2017-10-31 12:17:44 --> Config Class Initialized
INFO - 2017-10-31 12:17:44 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:44 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:44 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:44 --> URI Class Initialized
INFO - 2017-10-31 12:17:44 --> Router Class Initialized
INFO - 2017-10-31 12:17:44 --> Output Class Initialized
INFO - 2017-10-31 12:17:44 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:44 --> Input Class Initialized
INFO - 2017-10-31 12:17:44 --> Language Class Initialized
INFO - 2017-10-31 12:17:44 --> Loader Class Initialized
INFO - 2017-10-31 12:17:44 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:44 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:44 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:44 --> Email Class Initialized
INFO - 2017-10-31 12:17:44 --> Model Class Initialized
INFO - 2017-10-31 12:17:44 --> Controller Class Initialized
INFO - 2017-10-31 12:17:44 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:44 --> Total execution time: 0.0037
INFO - 2017-10-31 12:17:47 --> Config Class Initialized
INFO - 2017-10-31 12:17:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:47 --> URI Class Initialized
INFO - 2017-10-31 12:17:47 --> Router Class Initialized
INFO - 2017-10-31 12:17:47 --> Output Class Initialized
INFO - 2017-10-31 12:17:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:47 --> Input Class Initialized
INFO - 2017-10-31 12:17:47 --> Language Class Initialized
INFO - 2017-10-31 12:17:47 --> Loader Class Initialized
INFO - 2017-10-31 12:17:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:47 --> Email Class Initialized
INFO - 2017-10-31 12:17:47 --> Model Class Initialized
INFO - 2017-10-31 12:17:47 --> Controller Class Initialized
INFO - 2017-10-31 12:17:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:47 --> Total execution time: 0.0023
INFO - 2017-10-31 12:17:47 --> Config Class Initialized
INFO - 2017-10-31 12:17:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:47 --> URI Class Initialized
INFO - 2017-10-31 12:17:47 --> Router Class Initialized
INFO - 2017-10-31 12:17:47 --> Output Class Initialized
INFO - 2017-10-31 12:17:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:47 --> Input Class Initialized
INFO - 2017-10-31 12:17:47 --> Language Class Initialized
INFO - 2017-10-31 12:17:47 --> Loader Class Initialized
INFO - 2017-10-31 12:17:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:47 --> Email Class Initialized
INFO - 2017-10-31 12:17:47 --> Model Class Initialized
INFO - 2017-10-31 12:17:47 --> Controller Class Initialized
INFO - 2017-10-31 12:17:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:47 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:47 --> Config Class Initialized
INFO - 2017-10-31 12:17:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:47 --> URI Class Initialized
INFO - 2017-10-31 12:17:47 --> Router Class Initialized
INFO - 2017-10-31 12:17:47 --> Output Class Initialized
INFO - 2017-10-31 12:17:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:47 --> Input Class Initialized
INFO - 2017-10-31 12:17:47 --> Language Class Initialized
INFO - 2017-10-31 12:17:47 --> Loader Class Initialized
INFO - 2017-10-31 12:17:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:47 --> Email Class Initialized
INFO - 2017-10-31 12:17:47 --> Model Class Initialized
INFO - 2017-10-31 12:17:47 --> Controller Class Initialized
INFO - 2017-10-31 12:17:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:47 --> Total execution time: 0.0016
INFO - 2017-10-31 12:17:48 --> Config Class Initialized
INFO - 2017-10-31 12:17:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:48 --> URI Class Initialized
INFO - 2017-10-31 12:17:48 --> Router Class Initialized
INFO - 2017-10-31 12:17:48 --> Output Class Initialized
INFO - 2017-10-31 12:17:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:48 --> Input Class Initialized
INFO - 2017-10-31 12:17:48 --> Language Class Initialized
INFO - 2017-10-31 12:17:48 --> Loader Class Initialized
INFO - 2017-10-31 12:17:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:48 --> Email Class Initialized
INFO - 2017-10-31 12:17:48 --> Model Class Initialized
INFO - 2017-10-31 12:17:48 --> Controller Class Initialized
INFO - 2017-10-31 12:17:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:48 --> Total execution time: 0.0017
INFO - 2017-10-31 12:17:49 --> Config Class Initialized
INFO - 2017-10-31 12:17:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:49 --> URI Class Initialized
INFO - 2017-10-31 12:17:49 --> Router Class Initialized
INFO - 2017-10-31 12:17:49 --> Output Class Initialized
INFO - 2017-10-31 12:17:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:49 --> Input Class Initialized
INFO - 2017-10-31 12:17:49 --> Language Class Initialized
INFO - 2017-10-31 12:17:49 --> Loader Class Initialized
INFO - 2017-10-31 12:17:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:49 --> Email Class Initialized
INFO - 2017-10-31 12:17:49 --> Model Class Initialized
INFO - 2017-10-31 12:17:49 --> Controller Class Initialized
INFO - 2017-10-31 12:17:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:49 --> Total execution time: 0.0016
INFO - 2017-10-31 12:17:49 --> Config Class Initialized
INFO - 2017-10-31 12:17:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:17:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:17:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:17:49 --> URI Class Initialized
INFO - 2017-10-31 12:17:49 --> Router Class Initialized
INFO - 2017-10-31 12:17:49 --> Output Class Initialized
INFO - 2017-10-31 12:17:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:17:49 --> Input Class Initialized
INFO - 2017-10-31 12:17:49 --> Language Class Initialized
INFO - 2017-10-31 12:17:49 --> Loader Class Initialized
INFO - 2017-10-31 12:17:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:17:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:17:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:17:49 --> Email Class Initialized
INFO - 2017-10-31 12:17:49 --> Model Class Initialized
INFO - 2017-10-31 12:17:49 --> Controller Class Initialized
INFO - 2017-10-31 12:17:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:17:49 --> Total execution time: 0.0016
INFO - 2017-10-31 12:18:02 --> Config Class Initialized
INFO - 2017-10-31 12:18:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:02 --> URI Class Initialized
INFO - 2017-10-31 12:18:02 --> Router Class Initialized
INFO - 2017-10-31 12:18:02 --> Output Class Initialized
INFO - 2017-10-31 12:18:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:02 --> Input Class Initialized
INFO - 2017-10-31 12:18:02 --> Language Class Initialized
INFO - 2017-10-31 12:18:02 --> Loader Class Initialized
INFO - 2017-10-31 12:18:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:02 --> Email Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Controller Class Initialized
INFO - 2017-10-31 12:18:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:18:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:18:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:18:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:18:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:18:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:02 --> Total execution time: 0.0241
INFO - 2017-10-31 12:18:02 --> Config Class Initialized
INFO - 2017-10-31 12:18:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:02 --> URI Class Initialized
INFO - 2017-10-31 12:18:02 --> Router Class Initialized
INFO - 2017-10-31 12:18:02 --> Output Class Initialized
INFO - 2017-10-31 12:18:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:02 --> Input Class Initialized
INFO - 2017-10-31 12:18:02 --> Language Class Initialized
INFO - 2017-10-31 12:18:02 --> Loader Class Initialized
INFO - 2017-10-31 12:18:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:02 --> Email Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Controller Class Initialized
INFO - 2017-10-31 12:18:02 --> Model Class Initialized
INFO - 2017-10-31 12:18:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:02 --> Total execution time: 0.0023
INFO - 2017-10-31 12:18:04 --> Config Class Initialized
INFO - 2017-10-31 12:18:04 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:04 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:04 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:04 --> URI Class Initialized
INFO - 2017-10-31 12:18:04 --> Router Class Initialized
INFO - 2017-10-31 12:18:04 --> Output Class Initialized
INFO - 2017-10-31 12:18:04 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:04 --> Input Class Initialized
INFO - 2017-10-31 12:18:04 --> Language Class Initialized
INFO - 2017-10-31 12:18:04 --> Loader Class Initialized
INFO - 2017-10-31 12:18:04 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:04 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:04 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:04 --> Email Class Initialized
INFO - 2017-10-31 12:18:04 --> Model Class Initialized
INFO - 2017-10-31 12:18:04 --> Controller Class Initialized
INFO - 2017-10-31 12:18:04 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:04 --> Total execution time: 0.0020
INFO - 2017-10-31 12:18:06 --> Config Class Initialized
INFO - 2017-10-31 12:18:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:06 --> URI Class Initialized
INFO - 2017-10-31 12:18:06 --> Router Class Initialized
INFO - 2017-10-31 12:18:06 --> Output Class Initialized
INFO - 2017-10-31 12:18:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:06 --> Input Class Initialized
INFO - 2017-10-31 12:18:06 --> Language Class Initialized
INFO - 2017-10-31 12:18:06 --> Loader Class Initialized
INFO - 2017-10-31 12:18:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:06 --> Email Class Initialized
INFO - 2017-10-31 12:18:06 --> Model Class Initialized
INFO - 2017-10-31 12:18:06 --> Controller Class Initialized
INFO - 2017-10-31 12:18:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:06 --> Total execution time: 0.0017
INFO - 2017-10-31 12:18:07 --> Config Class Initialized
INFO - 2017-10-31 12:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:07 --> URI Class Initialized
INFO - 2017-10-31 12:18:07 --> Router Class Initialized
INFO - 2017-10-31 12:18:07 --> Output Class Initialized
INFO - 2017-10-31 12:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:07 --> Input Class Initialized
INFO - 2017-10-31 12:18:07 --> Language Class Initialized
INFO - 2017-10-31 12:18:07 --> Loader Class Initialized
INFO - 2017-10-31 12:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:07 --> Email Class Initialized
INFO - 2017-10-31 12:18:07 --> Model Class Initialized
INFO - 2017-10-31 12:18:07 --> Controller Class Initialized
INFO - 2017-10-31 12:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:07 --> Total execution time: 0.0016
INFO - 2017-10-31 12:18:07 --> Config Class Initialized
INFO - 2017-10-31 12:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:07 --> URI Class Initialized
INFO - 2017-10-31 12:18:07 --> Router Class Initialized
INFO - 2017-10-31 12:18:07 --> Output Class Initialized
INFO - 2017-10-31 12:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:07 --> Input Class Initialized
INFO - 2017-10-31 12:18:07 --> Language Class Initialized
INFO - 2017-10-31 12:18:07 --> Loader Class Initialized
INFO - 2017-10-31 12:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:07 --> Email Class Initialized
INFO - 2017-10-31 12:18:07 --> Model Class Initialized
INFO - 2017-10-31 12:18:07 --> Controller Class Initialized
INFO - 2017-10-31 12:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:07 --> Total execution time: 0.0018
INFO - 2017-10-31 12:18:07 --> Config Class Initialized
INFO - 2017-10-31 12:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:18:07 --> URI Class Initialized
INFO - 2017-10-31 12:18:07 --> Router Class Initialized
INFO - 2017-10-31 12:18:07 --> Output Class Initialized
INFO - 2017-10-31 12:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:18:07 --> Input Class Initialized
INFO - 2017-10-31 12:18:07 --> Language Class Initialized
INFO - 2017-10-31 12:18:07 --> Loader Class Initialized
INFO - 2017-10-31 12:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:18:07 --> Email Class Initialized
INFO - 2017-10-31 12:18:07 --> Model Class Initialized
INFO - 2017-10-31 12:18:07 --> Controller Class Initialized
INFO - 2017-10-31 12:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:18:07 --> Total execution time: 0.0016
INFO - 2017-10-31 12:24:38 --> Config Class Initialized
INFO - 2017-10-31 12:24:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:38 --> URI Class Initialized
INFO - 2017-10-31 12:24:38 --> Router Class Initialized
INFO - 2017-10-31 12:24:38 --> Output Class Initialized
INFO - 2017-10-31 12:24:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:38 --> Input Class Initialized
INFO - 2017-10-31 12:24:38 --> Language Class Initialized
INFO - 2017-10-31 12:24:38 --> Loader Class Initialized
INFO - 2017-10-31 12:24:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:38 --> Email Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Controller Class Initialized
INFO - 2017-10-31 12:24:38 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> Model Class Initialized
INFO - 2017-10-31 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:24:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:24:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:38 --> Total execution time: 0.0316
INFO - 2017-10-31 12:24:39 --> Config Class Initialized
INFO - 2017-10-31 12:24:39 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:39 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:39 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:39 --> URI Class Initialized
INFO - 2017-10-31 12:24:39 --> Router Class Initialized
INFO - 2017-10-31 12:24:39 --> Output Class Initialized
INFO - 2017-10-31 12:24:39 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:39 --> Input Class Initialized
INFO - 2017-10-31 12:24:39 --> Language Class Initialized
INFO - 2017-10-31 12:24:39 --> Loader Class Initialized
INFO - 2017-10-31 12:24:39 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:39 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:39 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:39 --> Email Class Initialized
INFO - 2017-10-31 12:24:39 --> Model Class Initialized
INFO - 2017-10-31 12:24:39 --> Controller Class Initialized
INFO - 2017-10-31 12:24:39 --> Model Class Initialized
INFO - 2017-10-31 12:24:39 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:39 --> Total execution time: 0.0020
INFO - 2017-10-31 12:24:40 --> Config Class Initialized
INFO - 2017-10-31 12:24:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:40 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:40 --> URI Class Initialized
INFO - 2017-10-31 12:24:40 --> Router Class Initialized
INFO - 2017-10-31 12:24:40 --> Output Class Initialized
INFO - 2017-10-31 12:24:40 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:40 --> Input Class Initialized
INFO - 2017-10-31 12:24:40 --> Language Class Initialized
INFO - 2017-10-31 12:24:40 --> Loader Class Initialized
INFO - 2017-10-31 12:24:40 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:40 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:40 --> Email Class Initialized
INFO - 2017-10-31 12:24:40 --> Model Class Initialized
INFO - 2017-10-31 12:24:40 --> Controller Class Initialized
INFO - 2017-10-31 12:24:40 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:40 --> Total execution time: 0.0019
INFO - 2017-10-31 12:24:42 --> Config Class Initialized
INFO - 2017-10-31 12:24:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:42 --> URI Class Initialized
INFO - 2017-10-31 12:24:42 --> Router Class Initialized
INFO - 2017-10-31 12:24:42 --> Output Class Initialized
INFO - 2017-10-31 12:24:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:42 --> Input Class Initialized
INFO - 2017-10-31 12:24:42 --> Language Class Initialized
INFO - 2017-10-31 12:24:42 --> Loader Class Initialized
INFO - 2017-10-31 12:24:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:42 --> Email Class Initialized
INFO - 2017-10-31 12:24:42 --> Model Class Initialized
INFO - 2017-10-31 12:24:42 --> Controller Class Initialized
INFO - 2017-10-31 12:24:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:42 --> Total execution time: 0.0018
INFO - 2017-10-31 12:24:43 --> Config Class Initialized
INFO - 2017-10-31 12:24:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:43 --> URI Class Initialized
INFO - 2017-10-31 12:24:43 --> Router Class Initialized
INFO - 2017-10-31 12:24:43 --> Output Class Initialized
INFO - 2017-10-31 12:24:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:43 --> Input Class Initialized
INFO - 2017-10-31 12:24:43 --> Language Class Initialized
INFO - 2017-10-31 12:24:43 --> Loader Class Initialized
INFO - 2017-10-31 12:24:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:43 --> Email Class Initialized
INFO - 2017-10-31 12:24:43 --> Model Class Initialized
INFO - 2017-10-31 12:24:43 --> Controller Class Initialized
INFO - 2017-10-31 12:24:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:43 --> Total execution time: 0.0016
INFO - 2017-10-31 12:24:43 --> Config Class Initialized
INFO - 2017-10-31 12:24:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:43 --> URI Class Initialized
INFO - 2017-10-31 12:24:43 --> Router Class Initialized
INFO - 2017-10-31 12:24:43 --> Output Class Initialized
INFO - 2017-10-31 12:24:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:43 --> Input Class Initialized
INFO - 2017-10-31 12:24:43 --> Language Class Initialized
INFO - 2017-10-31 12:24:43 --> Loader Class Initialized
INFO - 2017-10-31 12:24:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:43 --> Email Class Initialized
INFO - 2017-10-31 12:24:43 --> Model Class Initialized
INFO - 2017-10-31 12:24:43 --> Controller Class Initialized
INFO - 2017-10-31 12:24:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:43 --> Total execution time: 0.0020
INFO - 2017-10-31 12:24:43 --> Config Class Initialized
INFO - 2017-10-31 12:24:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:43 --> URI Class Initialized
INFO - 2017-10-31 12:24:43 --> Router Class Initialized
INFO - 2017-10-31 12:24:43 --> Output Class Initialized
INFO - 2017-10-31 12:24:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:43 --> Input Class Initialized
INFO - 2017-10-31 12:24:43 --> Language Class Initialized
INFO - 2017-10-31 12:24:43 --> Loader Class Initialized
INFO - 2017-10-31 12:24:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:43 --> Email Class Initialized
INFO - 2017-10-31 12:24:43 --> Model Class Initialized
INFO - 2017-10-31 12:24:43 --> Controller Class Initialized
INFO - 2017-10-31 12:24:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:43 --> Total execution time: 0.0017
INFO - 2017-10-31 12:24:44 --> Config Class Initialized
INFO - 2017-10-31 12:24:44 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:44 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:44 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:44 --> URI Class Initialized
INFO - 2017-10-31 12:24:44 --> Router Class Initialized
INFO - 2017-10-31 12:24:44 --> Output Class Initialized
INFO - 2017-10-31 12:24:44 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:44 --> Input Class Initialized
INFO - 2017-10-31 12:24:44 --> Language Class Initialized
INFO - 2017-10-31 12:24:44 --> Loader Class Initialized
INFO - 2017-10-31 12:24:44 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:44 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:44 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:44 --> Email Class Initialized
INFO - 2017-10-31 12:24:44 --> Model Class Initialized
INFO - 2017-10-31 12:24:44 --> Controller Class Initialized
INFO - 2017-10-31 12:24:44 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:44 --> Total execution time: 0.0030
INFO - 2017-10-31 12:24:45 --> Config Class Initialized
INFO - 2017-10-31 12:24:45 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:24:45 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:24:45 --> Utf8 Class Initialized
INFO - 2017-10-31 12:24:45 --> URI Class Initialized
INFO - 2017-10-31 12:24:45 --> Router Class Initialized
INFO - 2017-10-31 12:24:45 --> Output Class Initialized
INFO - 2017-10-31 12:24:45 --> Security Class Initialized
DEBUG - 2017-10-31 12:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:24:45 --> Input Class Initialized
INFO - 2017-10-31 12:24:45 --> Language Class Initialized
INFO - 2017-10-31 12:24:45 --> Loader Class Initialized
INFO - 2017-10-31 12:24:45 --> Helper loaded: url_helper
INFO - 2017-10-31 12:24:45 --> Helper loaded: common_helper
INFO - 2017-10-31 12:24:45 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:24:45 --> Email Class Initialized
INFO - 2017-10-31 12:24:45 --> Model Class Initialized
INFO - 2017-10-31 12:24:45 --> Controller Class Initialized
INFO - 2017-10-31 12:24:45 --> Final output sent to browser
DEBUG - 2017-10-31 12:24:45 --> Total execution time: 0.0021
INFO - 2017-10-31 12:25:10 --> Config Class Initialized
INFO - 2017-10-31 12:25:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:10 --> URI Class Initialized
INFO - 2017-10-31 12:25:10 --> Router Class Initialized
INFO - 2017-10-31 12:25:10 --> Output Class Initialized
INFO - 2017-10-31 12:25:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:10 --> Input Class Initialized
INFO - 2017-10-31 12:25:10 --> Language Class Initialized
INFO - 2017-10-31 12:25:10 --> Loader Class Initialized
INFO - 2017-10-31 12:25:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:10 --> Email Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Controller Class Initialized
INFO - 2017-10-31 12:25:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> Model Class Initialized
INFO - 2017-10-31 12:25:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:10 --> Total execution time: 0.0278
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0022
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0279
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0284
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0442
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0431
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0328
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0495
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0252
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0360
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0343
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0233
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0209
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0256
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0215
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0199
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0240
INFO - 2017-10-31 12:25:11 --> Config Class Initialized
INFO - 2017-10-31 12:25:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:11 --> URI Class Initialized
INFO - 2017-10-31 12:25:11 --> Router Class Initialized
INFO - 2017-10-31 12:25:11 --> Output Class Initialized
INFO - 2017-10-31 12:25:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:11 --> Input Class Initialized
INFO - 2017-10-31 12:25:11 --> Language Class Initialized
INFO - 2017-10-31 12:25:11 --> Loader Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:11 --> Email Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Controller Class Initialized
INFO - 2017-10-31 12:25:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> Model Class Initialized
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:11 --> Total execution time: 0.0213
INFO - 2017-10-31 12:25:12 --> Config Class Initialized
INFO - 2017-10-31 12:25:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:12 --> URI Class Initialized
INFO - 2017-10-31 12:25:12 --> Router Class Initialized
INFO - 2017-10-31 12:25:12 --> Output Class Initialized
INFO - 2017-10-31 12:25:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:12 --> Input Class Initialized
INFO - 2017-10-31 12:25:12 --> Language Class Initialized
INFO - 2017-10-31 12:25:12 --> Loader Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:12 --> Email Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Controller Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:12 --> Total execution time: 0.0020
INFO - 2017-10-31 12:25:12 --> Config Class Initialized
INFO - 2017-10-31 12:25:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:12 --> URI Class Initialized
INFO - 2017-10-31 12:25:12 --> Router Class Initialized
INFO - 2017-10-31 12:25:12 --> Output Class Initialized
INFO - 2017-10-31 12:25:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:12 --> Input Class Initialized
INFO - 2017-10-31 12:25:12 --> Language Class Initialized
INFO - 2017-10-31 12:25:12 --> Loader Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:12 --> Email Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Controller Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:12 --> Total execution time: 0.0324
INFO - 2017-10-31 12:25:12 --> Config Class Initialized
INFO - 2017-10-31 12:25:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:12 --> URI Class Initialized
INFO - 2017-10-31 12:25:12 --> Router Class Initialized
INFO - 2017-10-31 12:25:12 --> Output Class Initialized
INFO - 2017-10-31 12:25:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:12 --> Input Class Initialized
INFO - 2017-10-31 12:25:12 --> Language Class Initialized
INFO - 2017-10-31 12:25:12 --> Loader Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:12 --> Email Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Controller Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:12 --> Total execution time: 0.0026
INFO - 2017-10-31 12:25:12 --> Config Class Initialized
INFO - 2017-10-31 12:25:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:12 --> URI Class Initialized
INFO - 2017-10-31 12:25:12 --> Router Class Initialized
INFO - 2017-10-31 12:25:12 --> Output Class Initialized
INFO - 2017-10-31 12:25:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:12 --> Input Class Initialized
INFO - 2017-10-31 12:25:12 --> Language Class Initialized
INFO - 2017-10-31 12:25:12 --> Loader Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:12 --> Email Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Controller Class Initialized
INFO - 2017-10-31 12:25:12 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> Model Class Initialized
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:12 --> Total execution time: 0.0261
INFO - 2017-10-31 12:25:13 --> Config Class Initialized
INFO - 2017-10-31 12:25:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:13 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:13 --> URI Class Initialized
INFO - 2017-10-31 12:25:13 --> Router Class Initialized
INFO - 2017-10-31 12:25:13 --> Output Class Initialized
INFO - 2017-10-31 12:25:13 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:13 --> Input Class Initialized
INFO - 2017-10-31 12:25:13 --> Language Class Initialized
INFO - 2017-10-31 12:25:13 --> Loader Class Initialized
INFO - 2017-10-31 12:25:13 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:13 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:13 --> Email Class Initialized
INFO - 2017-10-31 12:25:13 --> Model Class Initialized
INFO - 2017-10-31 12:25:13 --> Controller Class Initialized
INFO - 2017-10-31 12:25:13 --> Model Class Initialized
INFO - 2017-10-31 12:25:13 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:13 --> Total execution time: 0.0019
INFO - 2017-10-31 12:25:14 --> Config Class Initialized
INFO - 2017-10-31 12:25:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:14 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:14 --> URI Class Initialized
INFO - 2017-10-31 12:25:14 --> Router Class Initialized
INFO - 2017-10-31 12:25:14 --> Output Class Initialized
INFO - 2017-10-31 12:25:14 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:14 --> Input Class Initialized
INFO - 2017-10-31 12:25:14 --> Language Class Initialized
INFO - 2017-10-31 12:25:14 --> Loader Class Initialized
INFO - 2017-10-31 12:25:14 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:14 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:14 --> Email Class Initialized
INFO - 2017-10-31 12:25:14 --> Model Class Initialized
INFO - 2017-10-31 12:25:14 --> Controller Class Initialized
INFO - 2017-10-31 12:25:14 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:14 --> Total execution time: 0.0023
INFO - 2017-10-31 12:25:21 --> Config Class Initialized
INFO - 2017-10-31 12:25:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:21 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:21 --> URI Class Initialized
INFO - 2017-10-31 12:25:21 --> Router Class Initialized
INFO - 2017-10-31 12:25:21 --> Output Class Initialized
INFO - 2017-10-31 12:25:21 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:21 --> Input Class Initialized
INFO - 2017-10-31 12:25:21 --> Language Class Initialized
INFO - 2017-10-31 12:25:21 --> Loader Class Initialized
INFO - 2017-10-31 12:25:21 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:21 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:21 --> Email Class Initialized
INFO - 2017-10-31 12:25:21 --> Model Class Initialized
INFO - 2017-10-31 12:25:21 --> Controller Class Initialized
INFO - 2017-10-31 12:25:21 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:21 --> Total execution time: 0.0023
INFO - 2017-10-31 12:25:22 --> Config Class Initialized
INFO - 2017-10-31 12:25:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:22 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:22 --> URI Class Initialized
INFO - 2017-10-31 12:25:22 --> Router Class Initialized
INFO - 2017-10-31 12:25:22 --> Output Class Initialized
INFO - 2017-10-31 12:25:22 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:22 --> Input Class Initialized
INFO - 2017-10-31 12:25:22 --> Language Class Initialized
INFO - 2017-10-31 12:25:22 --> Loader Class Initialized
INFO - 2017-10-31 12:25:22 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:22 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:22 --> Email Class Initialized
INFO - 2017-10-31 12:25:22 --> Model Class Initialized
INFO - 2017-10-31 12:25:22 --> Controller Class Initialized
INFO - 2017-10-31 12:25:22 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:22 --> Total execution time: 0.0017
INFO - 2017-10-31 12:25:37 --> Config Class Initialized
INFO - 2017-10-31 12:25:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:37 --> URI Class Initialized
INFO - 2017-10-31 12:25:37 --> Router Class Initialized
INFO - 2017-10-31 12:25:37 --> Output Class Initialized
INFO - 2017-10-31 12:25:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:37 --> Input Class Initialized
INFO - 2017-10-31 12:25:37 --> Language Class Initialized
INFO - 2017-10-31 12:25:37 --> Loader Class Initialized
INFO - 2017-10-31 12:25:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:37 --> Email Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Controller Class Initialized
INFO - 2017-10-31 12:25:37 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:37 --> Total execution time: 0.0024
INFO - 2017-10-31 12:25:37 --> Config Class Initialized
INFO - 2017-10-31 12:25:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:37 --> URI Class Initialized
INFO - 2017-10-31 12:25:37 --> Router Class Initialized
INFO - 2017-10-31 12:25:37 --> Output Class Initialized
INFO - 2017-10-31 12:25:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:37 --> Input Class Initialized
INFO - 2017-10-31 12:25:37 --> Language Class Initialized
INFO - 2017-10-31 12:25:37 --> Loader Class Initialized
INFO - 2017-10-31 12:25:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:37 --> Email Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Controller Class Initialized
INFO - 2017-10-31 12:25:37 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:37 --> Model Class Initialized
INFO - 2017-10-31 12:25:38 --> Model Class Initialized
INFO - 2017-10-31 12:25:38 --> Model Class Initialized
INFO - 2017-10-31 12:25:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:38 --> Total execution time: 0.0266
INFO - 2017-10-31 12:25:38 --> Config Class Initialized
INFO - 2017-10-31 12:25:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:38 --> URI Class Initialized
INFO - 2017-10-31 12:25:38 --> Router Class Initialized
INFO - 2017-10-31 12:25:38 --> Output Class Initialized
INFO - 2017-10-31 12:25:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:38 --> Input Class Initialized
INFO - 2017-10-31 12:25:38 --> Language Class Initialized
INFO - 2017-10-31 12:25:38 --> Loader Class Initialized
INFO - 2017-10-31 12:25:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:38 --> Email Class Initialized
INFO - 2017-10-31 12:25:38 --> Model Class Initialized
INFO - 2017-10-31 12:25:38 --> Controller Class Initialized
INFO - 2017-10-31 12:25:38 --> Model Class Initialized
INFO - 2017-10-31 12:25:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:38 --> Total execution time: 0.0028
INFO - 2017-10-31 12:25:39 --> Config Class Initialized
INFO - 2017-10-31 12:25:39 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:39 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:39 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:39 --> URI Class Initialized
INFO - 2017-10-31 12:25:39 --> Router Class Initialized
INFO - 2017-10-31 12:25:39 --> Output Class Initialized
INFO - 2017-10-31 12:25:39 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:39 --> Input Class Initialized
INFO - 2017-10-31 12:25:39 --> Language Class Initialized
INFO - 2017-10-31 12:25:39 --> Loader Class Initialized
INFO - 2017-10-31 12:25:39 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:39 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:39 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:39 --> Email Class Initialized
INFO - 2017-10-31 12:25:39 --> Model Class Initialized
INFO - 2017-10-31 12:25:39 --> Controller Class Initialized
INFO - 2017-10-31 12:25:39 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:39 --> Total execution time: 0.0024
INFO - 2017-10-31 12:25:56 --> Config Class Initialized
INFO - 2017-10-31 12:25:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:56 --> URI Class Initialized
INFO - 2017-10-31 12:25:56 --> Router Class Initialized
INFO - 2017-10-31 12:25:56 --> Output Class Initialized
INFO - 2017-10-31 12:25:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:56 --> Input Class Initialized
INFO - 2017-10-31 12:25:56 --> Language Class Initialized
INFO - 2017-10-31 12:25:56 --> Loader Class Initialized
INFO - 2017-10-31 12:25:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:56 --> Email Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Controller Class Initialized
INFO - 2017-10-31 12:25:56 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:56 --> Total execution time: 0.0258
INFO - 2017-10-31 12:25:56 --> Config Class Initialized
INFO - 2017-10-31 12:25:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:56 --> URI Class Initialized
INFO - 2017-10-31 12:25:56 --> Router Class Initialized
INFO - 2017-10-31 12:25:56 --> Output Class Initialized
INFO - 2017-10-31 12:25:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:56 --> Input Class Initialized
INFO - 2017-10-31 12:25:56 --> Language Class Initialized
INFO - 2017-10-31 12:25:56 --> Loader Class Initialized
INFO - 2017-10-31 12:25:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:56 --> Email Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Controller Class Initialized
INFO - 2017-10-31 12:25:56 --> Model Class Initialized
INFO - 2017-10-31 12:25:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:56 --> Total execution time: 0.0028
INFO - 2017-10-31 12:25:57 --> Config Class Initialized
INFO - 2017-10-31 12:25:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:57 --> URI Class Initialized
INFO - 2017-10-31 12:25:57 --> Router Class Initialized
INFO - 2017-10-31 12:25:57 --> Output Class Initialized
INFO - 2017-10-31 12:25:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:57 --> Input Class Initialized
INFO - 2017-10-31 12:25:57 --> Language Class Initialized
INFO - 2017-10-31 12:25:57 --> Loader Class Initialized
INFO - 2017-10-31 12:25:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:57 --> Email Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Controller Class Initialized
INFO - 2017-10-31 12:25:57 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Config Class Initialized
INFO - 2017-10-31 12:25:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:57 --> URI Class Initialized
INFO - 2017-10-31 12:25:57 --> Router Class Initialized
INFO - 2017-10-31 12:25:57 --> Output Class Initialized
INFO - 2017-10-31 12:25:57 --> Security Class Initialized
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
DEBUG - 2017-10-31 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:57 --> Input Class Initialized
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:57 --> Language Class Initialized
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:57 --> Loader Class Initialized
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:57 --> Total execution time: 0.0305
INFO - 2017-10-31 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:57 --> Email Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Controller Class Initialized
INFO - 2017-10-31 12:25:57 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:25:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:25:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:57 --> Total execution time: 0.0298
INFO - 2017-10-31 12:25:57 --> Config Class Initialized
INFO - 2017-10-31 12:25:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:57 --> URI Class Initialized
INFO - 2017-10-31 12:25:57 --> Router Class Initialized
INFO - 2017-10-31 12:25:57 --> Output Class Initialized
INFO - 2017-10-31 12:25:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:57 --> Input Class Initialized
INFO - 2017-10-31 12:25:57 --> Language Class Initialized
INFO - 2017-10-31 12:25:57 --> Loader Class Initialized
INFO - 2017-10-31 12:25:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:57 --> Email Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Controller Class Initialized
INFO - 2017-10-31 12:25:57 --> Model Class Initialized
INFO - 2017-10-31 12:25:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:57 --> Total execution time: 0.0019
INFO - 2017-10-31 12:25:58 --> Config Class Initialized
INFO - 2017-10-31 12:25:58 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:25:58 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:25:58 --> Utf8 Class Initialized
INFO - 2017-10-31 12:25:58 --> URI Class Initialized
INFO - 2017-10-31 12:25:58 --> Router Class Initialized
INFO - 2017-10-31 12:25:58 --> Output Class Initialized
INFO - 2017-10-31 12:25:58 --> Security Class Initialized
DEBUG - 2017-10-31 12:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:25:58 --> Input Class Initialized
INFO - 2017-10-31 12:25:58 --> Language Class Initialized
INFO - 2017-10-31 12:25:58 --> Loader Class Initialized
INFO - 2017-10-31 12:25:58 --> Helper loaded: url_helper
INFO - 2017-10-31 12:25:58 --> Helper loaded: common_helper
INFO - 2017-10-31 12:25:58 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:25:58 --> Email Class Initialized
INFO - 2017-10-31 12:25:58 --> Model Class Initialized
INFO - 2017-10-31 12:25:58 --> Controller Class Initialized
INFO - 2017-10-31 12:25:58 --> Final output sent to browser
DEBUG - 2017-10-31 12:25:58 --> Total execution time: 0.0019
INFO - 2017-10-31 12:26:03 --> Config Class Initialized
INFO - 2017-10-31 12:26:03 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:03 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:03 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:03 --> URI Class Initialized
INFO - 2017-10-31 12:26:03 --> Router Class Initialized
INFO - 2017-10-31 12:26:03 --> Output Class Initialized
INFO - 2017-10-31 12:26:03 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:03 --> Input Class Initialized
INFO - 2017-10-31 12:26:03 --> Language Class Initialized
INFO - 2017-10-31 12:26:03 --> Loader Class Initialized
INFO - 2017-10-31 12:26:03 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:03 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:03 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:03 --> Email Class Initialized
INFO - 2017-10-31 12:26:03 --> Model Class Initialized
INFO - 2017-10-31 12:26:03 --> Controller Class Initialized
INFO - 2017-10-31 12:26:03 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:03 --> Total execution time: 0.0029
INFO - 2017-10-31 12:26:07 --> Config Class Initialized
INFO - 2017-10-31 12:26:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:07 --> URI Class Initialized
INFO - 2017-10-31 12:26:07 --> Router Class Initialized
INFO - 2017-10-31 12:26:07 --> Output Class Initialized
INFO - 2017-10-31 12:26:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:07 --> Input Class Initialized
INFO - 2017-10-31 12:26:07 --> Language Class Initialized
INFO - 2017-10-31 12:26:07 --> Loader Class Initialized
INFO - 2017-10-31 12:26:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:07 --> Email Class Initialized
INFO - 2017-10-31 12:26:07 --> Model Class Initialized
INFO - 2017-10-31 12:26:07 --> Controller Class Initialized
INFO - 2017-10-31 12:26:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:07 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:07 --> Config Class Initialized
INFO - 2017-10-31 12:26:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:07 --> URI Class Initialized
INFO - 2017-10-31 12:26:07 --> Router Class Initialized
INFO - 2017-10-31 12:26:07 --> Output Class Initialized
INFO - 2017-10-31 12:26:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:07 --> Input Class Initialized
INFO - 2017-10-31 12:26:07 --> Language Class Initialized
INFO - 2017-10-31 12:26:07 --> Loader Class Initialized
INFO - 2017-10-31 12:26:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:07 --> Email Class Initialized
INFO - 2017-10-31 12:26:07 --> Model Class Initialized
INFO - 2017-10-31 12:26:07 --> Controller Class Initialized
INFO - 2017-10-31 12:26:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:07 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:08 --> Config Class Initialized
INFO - 2017-10-31 12:26:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:08 --> URI Class Initialized
INFO - 2017-10-31 12:26:08 --> Router Class Initialized
INFO - 2017-10-31 12:26:08 --> Output Class Initialized
INFO - 2017-10-31 12:26:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:08 --> Input Class Initialized
INFO - 2017-10-31 12:26:08 --> Language Class Initialized
INFO - 2017-10-31 12:26:08 --> Loader Class Initialized
INFO - 2017-10-31 12:26:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:08 --> Email Class Initialized
INFO - 2017-10-31 12:26:08 --> Model Class Initialized
INFO - 2017-10-31 12:26:08 --> Controller Class Initialized
INFO - 2017-10-31 12:26:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:08 --> Total execution time: 0.0016
INFO - 2017-10-31 12:26:08 --> Config Class Initialized
INFO - 2017-10-31 12:26:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:08 --> URI Class Initialized
INFO - 2017-10-31 12:26:08 --> Router Class Initialized
INFO - 2017-10-31 12:26:08 --> Output Class Initialized
INFO - 2017-10-31 12:26:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:08 --> Input Class Initialized
INFO - 2017-10-31 12:26:08 --> Language Class Initialized
INFO - 2017-10-31 12:26:08 --> Loader Class Initialized
INFO - 2017-10-31 12:26:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:08 --> Email Class Initialized
INFO - 2017-10-31 12:26:08 --> Model Class Initialized
INFO - 2017-10-31 12:26:08 --> Controller Class Initialized
INFO - 2017-10-31 12:26:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:08 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:08 --> Config Class Initialized
INFO - 2017-10-31 12:26:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:08 --> URI Class Initialized
INFO - 2017-10-31 12:26:08 --> Router Class Initialized
INFO - 2017-10-31 12:26:08 --> Output Class Initialized
INFO - 2017-10-31 12:26:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:08 --> Input Class Initialized
INFO - 2017-10-31 12:26:08 --> Language Class Initialized
INFO - 2017-10-31 12:26:08 --> Loader Class Initialized
INFO - 2017-10-31 12:26:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:08 --> Email Class Initialized
INFO - 2017-10-31 12:26:08 --> Model Class Initialized
INFO - 2017-10-31 12:26:08 --> Controller Class Initialized
INFO - 2017-10-31 12:26:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:08 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:08 --> Config Class Initialized
INFO - 2017-10-31 12:26:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:08 --> URI Class Initialized
INFO - 2017-10-31 12:26:08 --> Router Class Initialized
INFO - 2017-10-31 12:26:08 --> Output Class Initialized
INFO - 2017-10-31 12:26:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:08 --> Input Class Initialized
INFO - 2017-10-31 12:26:08 --> Language Class Initialized
INFO - 2017-10-31 12:26:08 --> Loader Class Initialized
INFO - 2017-10-31 12:26:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:08 --> Email Class Initialized
INFO - 2017-10-31 12:26:08 --> Model Class Initialized
INFO - 2017-10-31 12:26:08 --> Controller Class Initialized
INFO - 2017-10-31 12:26:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:08 --> Total execution time: 0.0015
INFO - 2017-10-31 12:26:08 --> Config Class Initialized
INFO - 2017-10-31 12:26:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:08 --> URI Class Initialized
INFO - 2017-10-31 12:26:08 --> Router Class Initialized
INFO - 2017-10-31 12:26:08 --> Output Class Initialized
INFO - 2017-10-31 12:26:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:08 --> Input Class Initialized
INFO - 2017-10-31 12:26:08 --> Language Class Initialized
INFO - 2017-10-31 12:26:08 --> Loader Class Initialized
INFO - 2017-10-31 12:26:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:08 --> Email Class Initialized
INFO - 2017-10-31 12:26:08 --> Model Class Initialized
INFO - 2017-10-31 12:26:08 --> Controller Class Initialized
INFO - 2017-10-31 12:26:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:08 --> Total execution time: 0.0015
INFO - 2017-10-31 12:26:09 --> Config Class Initialized
INFO - 2017-10-31 12:26:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:09 --> URI Class Initialized
INFO - 2017-10-31 12:26:09 --> Router Class Initialized
INFO - 2017-10-31 12:26:09 --> Output Class Initialized
INFO - 2017-10-31 12:26:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:09 --> Input Class Initialized
INFO - 2017-10-31 12:26:09 --> Language Class Initialized
INFO - 2017-10-31 12:26:09 --> Loader Class Initialized
INFO - 2017-10-31 12:26:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:09 --> Email Class Initialized
INFO - 2017-10-31 12:26:09 --> Model Class Initialized
INFO - 2017-10-31 12:26:09 --> Controller Class Initialized
INFO - 2017-10-31 12:26:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:09 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:09 --> Config Class Initialized
INFO - 2017-10-31 12:26:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:09 --> URI Class Initialized
INFO - 2017-10-31 12:26:09 --> Router Class Initialized
INFO - 2017-10-31 12:26:09 --> Output Class Initialized
INFO - 2017-10-31 12:26:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:09 --> Input Class Initialized
INFO - 2017-10-31 12:26:09 --> Language Class Initialized
INFO - 2017-10-31 12:26:09 --> Loader Class Initialized
INFO - 2017-10-31 12:26:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:09 --> Email Class Initialized
INFO - 2017-10-31 12:26:09 --> Model Class Initialized
INFO - 2017-10-31 12:26:09 --> Controller Class Initialized
INFO - 2017-10-31 12:26:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:09 --> Total execution time: 0.0024
INFO - 2017-10-31 12:26:09 --> Config Class Initialized
INFO - 2017-10-31 12:26:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:09 --> URI Class Initialized
INFO - 2017-10-31 12:26:09 --> Router Class Initialized
INFO - 2017-10-31 12:26:09 --> Output Class Initialized
INFO - 2017-10-31 12:26:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:09 --> Input Class Initialized
INFO - 2017-10-31 12:26:09 --> Language Class Initialized
INFO - 2017-10-31 12:26:09 --> Loader Class Initialized
INFO - 2017-10-31 12:26:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:09 --> Email Class Initialized
INFO - 2017-10-31 12:26:09 --> Model Class Initialized
INFO - 2017-10-31 12:26:09 --> Controller Class Initialized
INFO - 2017-10-31 12:26:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:09 --> Total execution time: 0.0023
INFO - 2017-10-31 12:26:26 --> Config Class Initialized
INFO - 2017-10-31 12:26:26 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:26 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:26 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:26 --> URI Class Initialized
INFO - 2017-10-31 12:26:26 --> Router Class Initialized
INFO - 2017-10-31 12:26:26 --> Output Class Initialized
INFO - 2017-10-31 12:26:26 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:26 --> Input Class Initialized
INFO - 2017-10-31 12:26:26 --> Language Class Initialized
INFO - 2017-10-31 12:26:26 --> Loader Class Initialized
INFO - 2017-10-31 12:26:26 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:26 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:26 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:26 --> Email Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Controller Class Initialized
INFO - 2017-10-31 12:26:26 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:26 --> Total execution time: 0.0020
INFO - 2017-10-31 12:26:26 --> Config Class Initialized
INFO - 2017-10-31 12:26:26 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:26 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:26 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:26 --> URI Class Initialized
INFO - 2017-10-31 12:26:26 --> Router Class Initialized
INFO - 2017-10-31 12:26:26 --> Output Class Initialized
INFO - 2017-10-31 12:26:26 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:26 --> Input Class Initialized
INFO - 2017-10-31 12:26:26 --> Language Class Initialized
INFO - 2017-10-31 12:26:26 --> Loader Class Initialized
INFO - 2017-10-31 12:26:26 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:26 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:26 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:26 --> Email Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Controller Class Initialized
INFO - 2017-10-31 12:26:26 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> Model Class Initialized
INFO - 2017-10-31 12:26:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:26:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:26:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:26:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:26:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:26:26 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:26 --> Total execution time: 0.0226
INFO - 2017-10-31 12:26:27 --> Config Class Initialized
INFO - 2017-10-31 12:26:27 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:27 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:27 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:27 --> URI Class Initialized
INFO - 2017-10-31 12:26:27 --> Router Class Initialized
INFO - 2017-10-31 12:26:27 --> Output Class Initialized
INFO - 2017-10-31 12:26:27 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:27 --> Input Class Initialized
INFO - 2017-10-31 12:26:27 --> Language Class Initialized
INFO - 2017-10-31 12:26:27 --> Loader Class Initialized
INFO - 2017-10-31 12:26:27 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:27 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:27 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:27 --> Email Class Initialized
INFO - 2017-10-31 12:26:27 --> Model Class Initialized
INFO - 2017-10-31 12:26:27 --> Controller Class Initialized
INFO - 2017-10-31 12:26:27 --> Model Class Initialized
INFO - 2017-10-31 12:26:27 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:27 --> Total execution time: 0.0019
INFO - 2017-10-31 12:26:29 --> Config Class Initialized
INFO - 2017-10-31 12:26:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:29 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:29 --> URI Class Initialized
INFO - 2017-10-31 12:26:29 --> Router Class Initialized
INFO - 2017-10-31 12:26:29 --> Output Class Initialized
INFO - 2017-10-31 12:26:29 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:29 --> Input Class Initialized
INFO - 2017-10-31 12:26:29 --> Language Class Initialized
INFO - 2017-10-31 12:26:29 --> Loader Class Initialized
INFO - 2017-10-31 12:26:29 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:29 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:29 --> Email Class Initialized
INFO - 2017-10-31 12:26:29 --> Model Class Initialized
INFO - 2017-10-31 12:26:29 --> Controller Class Initialized
INFO - 2017-10-31 12:26:29 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:29 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:35 --> Config Class Initialized
INFO - 2017-10-31 12:26:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:35 --> URI Class Initialized
INFO - 2017-10-31 12:26:35 --> Router Class Initialized
INFO - 2017-10-31 12:26:35 --> Output Class Initialized
INFO - 2017-10-31 12:26:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:35 --> Input Class Initialized
INFO - 2017-10-31 12:26:35 --> Language Class Initialized
INFO - 2017-10-31 12:26:35 --> Loader Class Initialized
INFO - 2017-10-31 12:26:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:35 --> Email Class Initialized
INFO - 2017-10-31 12:26:35 --> Model Class Initialized
INFO - 2017-10-31 12:26:35 --> Controller Class Initialized
INFO - 2017-10-31 12:26:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:35 --> Total execution time: 0.0016
INFO - 2017-10-31 12:26:35 --> Config Class Initialized
INFO - 2017-10-31 12:26:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:35 --> URI Class Initialized
INFO - 2017-10-31 12:26:35 --> Router Class Initialized
INFO - 2017-10-31 12:26:35 --> Output Class Initialized
INFO - 2017-10-31 12:26:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:35 --> Input Class Initialized
INFO - 2017-10-31 12:26:35 --> Language Class Initialized
INFO - 2017-10-31 12:26:35 --> Loader Class Initialized
INFO - 2017-10-31 12:26:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:35 --> Email Class Initialized
INFO - 2017-10-31 12:26:35 --> Model Class Initialized
INFO - 2017-10-31 12:26:35 --> Controller Class Initialized
INFO - 2017-10-31 12:26:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:35 --> Total execution time: 0.0016
INFO - 2017-10-31 12:26:35 --> Config Class Initialized
INFO - 2017-10-31 12:26:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:35 --> URI Class Initialized
INFO - 2017-10-31 12:26:35 --> Router Class Initialized
INFO - 2017-10-31 12:26:35 --> Output Class Initialized
INFO - 2017-10-31 12:26:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:35 --> Input Class Initialized
INFO - 2017-10-31 12:26:35 --> Language Class Initialized
INFO - 2017-10-31 12:26:35 --> Loader Class Initialized
INFO - 2017-10-31 12:26:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:35 --> Email Class Initialized
INFO - 2017-10-31 12:26:35 --> Model Class Initialized
INFO - 2017-10-31 12:26:35 --> Controller Class Initialized
INFO - 2017-10-31 12:26:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:35 --> Total execution time: 0.0015
INFO - 2017-10-31 12:26:35 --> Config Class Initialized
INFO - 2017-10-31 12:26:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:35 --> URI Class Initialized
INFO - 2017-10-31 12:26:35 --> Router Class Initialized
INFO - 2017-10-31 12:26:35 --> Output Class Initialized
INFO - 2017-10-31 12:26:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:35 --> Input Class Initialized
INFO - 2017-10-31 12:26:35 --> Language Class Initialized
INFO - 2017-10-31 12:26:35 --> Loader Class Initialized
INFO - 2017-10-31 12:26:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:35 --> Email Class Initialized
INFO - 2017-10-31 12:26:35 --> Model Class Initialized
INFO - 2017-10-31 12:26:35 --> Controller Class Initialized
INFO - 2017-10-31 12:26:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:35 --> Total execution time: 0.0017
INFO - 2017-10-31 12:26:40 --> Config Class Initialized
INFO - 2017-10-31 12:26:40 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:40 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:40 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:40 --> URI Class Initialized
INFO - 2017-10-31 12:26:40 --> Router Class Initialized
INFO - 2017-10-31 12:26:40 --> Output Class Initialized
INFO - 2017-10-31 12:26:40 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:40 --> Input Class Initialized
INFO - 2017-10-31 12:26:40 --> Language Class Initialized
INFO - 2017-10-31 12:26:40 --> Loader Class Initialized
INFO - 2017-10-31 12:26:40 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:40 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:40 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:40 --> Email Class Initialized
INFO - 2017-10-31 12:26:40 --> Model Class Initialized
INFO - 2017-10-31 12:26:40 --> Controller Class Initialized
INFO - 2017-10-31 12:26:40 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:40 --> Total execution time: 0.0020
INFO - 2017-10-31 12:26:59 --> Config Class Initialized
INFO - 2017-10-31 12:26:59 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:26:59 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:26:59 --> Utf8 Class Initialized
INFO - 2017-10-31 12:26:59 --> URI Class Initialized
INFO - 2017-10-31 12:26:59 --> Router Class Initialized
INFO - 2017-10-31 12:26:59 --> Output Class Initialized
INFO - 2017-10-31 12:26:59 --> Security Class Initialized
DEBUG - 2017-10-31 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:26:59 --> Input Class Initialized
INFO - 2017-10-31 12:26:59 --> Language Class Initialized
INFO - 2017-10-31 12:26:59 --> Loader Class Initialized
INFO - 2017-10-31 12:26:59 --> Helper loaded: url_helper
INFO - 2017-10-31 12:26:59 --> Helper loaded: common_helper
INFO - 2017-10-31 12:26:59 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:26:59 --> Email Class Initialized
INFO - 2017-10-31 12:26:59 --> Model Class Initialized
INFO - 2017-10-31 12:26:59 --> Controller Class Initialized
INFO - 2017-10-31 12:26:59 --> Final output sent to browser
DEBUG - 2017-10-31 12:26:59 --> Total execution time: 0.0019
INFO - 2017-10-31 12:27:02 --> Config Class Initialized
INFO - 2017-10-31 12:27:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:02 --> URI Class Initialized
INFO - 2017-10-31 12:27:02 --> Router Class Initialized
INFO - 2017-10-31 12:27:02 --> Output Class Initialized
INFO - 2017-10-31 12:27:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:02 --> Input Class Initialized
INFO - 2017-10-31 12:27:02 --> Language Class Initialized
INFO - 2017-10-31 12:27:02 --> Loader Class Initialized
INFO - 2017-10-31 12:27:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:02 --> Email Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Controller Class Initialized
INFO - 2017-10-31 12:27:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:02 --> Model Class Initialized
INFO - 2017-10-31 12:27:03 --> Model Class Initialized
INFO - 2017-10-31 12:27:03 --> Model Class Initialized
INFO - 2017-10-31 12:27:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:03 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:03 --> Total execution time: 0.0234
INFO - 2017-10-31 12:27:03 --> Config Class Initialized
INFO - 2017-10-31 12:27:03 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:03 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:03 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:03 --> URI Class Initialized
INFO - 2017-10-31 12:27:03 --> Router Class Initialized
INFO - 2017-10-31 12:27:03 --> Output Class Initialized
INFO - 2017-10-31 12:27:03 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:03 --> Input Class Initialized
INFO - 2017-10-31 12:27:03 --> Language Class Initialized
INFO - 2017-10-31 12:27:03 --> Loader Class Initialized
INFO - 2017-10-31 12:27:03 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:03 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:03 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:03 --> Email Class Initialized
INFO - 2017-10-31 12:27:03 --> Model Class Initialized
INFO - 2017-10-31 12:27:03 --> Controller Class Initialized
INFO - 2017-10-31 12:27:03 --> Model Class Initialized
INFO - 2017-10-31 12:27:03 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:03 --> Total execution time: 0.0019
INFO - 2017-10-31 12:27:04 --> Config Class Initialized
INFO - 2017-10-31 12:27:04 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:04 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:04 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:04 --> URI Class Initialized
INFO - 2017-10-31 12:27:04 --> Router Class Initialized
INFO - 2017-10-31 12:27:04 --> Output Class Initialized
INFO - 2017-10-31 12:27:04 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:04 --> Input Class Initialized
INFO - 2017-10-31 12:27:04 --> Language Class Initialized
INFO - 2017-10-31 12:27:04 --> Loader Class Initialized
INFO - 2017-10-31 12:27:04 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:04 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:04 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:04 --> Email Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Controller Class Initialized
INFO - 2017-10-31 12:27:04 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> Model Class Initialized
INFO - 2017-10-31 12:27:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:04 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:04 --> Total execution time: 0.0217
INFO - 2017-10-31 12:27:05 --> Config Class Initialized
INFO - 2017-10-31 12:27:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:05 --> URI Class Initialized
INFO - 2017-10-31 12:27:05 --> Router Class Initialized
INFO - 2017-10-31 12:27:05 --> Output Class Initialized
INFO - 2017-10-31 12:27:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:05 --> Input Class Initialized
INFO - 2017-10-31 12:27:05 --> Language Class Initialized
INFO - 2017-10-31 12:27:05 --> Loader Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:05 --> Email Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Controller Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:05 --> Total execution time: 0.0270
INFO - 2017-10-31 12:27:05 --> Config Class Initialized
INFO - 2017-10-31 12:27:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:05 --> URI Class Initialized
INFO - 2017-10-31 12:27:05 --> Router Class Initialized
INFO - 2017-10-31 12:27:05 --> Output Class Initialized
INFO - 2017-10-31 12:27:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:05 --> Input Class Initialized
INFO - 2017-10-31 12:27:05 --> Language Class Initialized
INFO - 2017-10-31 12:27:05 --> Loader Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:05 --> Email Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Controller Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:05 --> Total execution time: 0.0256
INFO - 2017-10-31 12:27:05 --> Config Class Initialized
INFO - 2017-10-31 12:27:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:05 --> URI Class Initialized
INFO - 2017-10-31 12:27:05 --> Router Class Initialized
INFO - 2017-10-31 12:27:05 --> Output Class Initialized
INFO - 2017-10-31 12:27:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:05 --> Input Class Initialized
INFO - 2017-10-31 12:27:05 --> Language Class Initialized
INFO - 2017-10-31 12:27:05 --> Loader Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:05 --> Email Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Controller Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:05 --> Total execution time: 0.0312
INFO - 2017-10-31 12:27:05 --> Config Class Initialized
INFO - 2017-10-31 12:27:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:05 --> URI Class Initialized
INFO - 2017-10-31 12:27:05 --> Router Class Initialized
INFO - 2017-10-31 12:27:05 --> Output Class Initialized
INFO - 2017-10-31 12:27:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:05 --> Input Class Initialized
INFO - 2017-10-31 12:27:05 --> Language Class Initialized
INFO - 2017-10-31 12:27:05 --> Loader Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:05 --> Email Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Controller Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:05 --> Total execution time: 0.0328
INFO - 2017-10-31 12:27:05 --> Config Class Initialized
INFO - 2017-10-31 12:27:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:05 --> URI Class Initialized
INFO - 2017-10-31 12:27:05 --> Router Class Initialized
INFO - 2017-10-31 12:27:05 --> Output Class Initialized
INFO - 2017-10-31 12:27:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:05 --> Input Class Initialized
INFO - 2017-10-31 12:27:05 --> Language Class Initialized
INFO - 2017-10-31 12:27:05 --> Loader Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:05 --> Email Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Controller Class Initialized
INFO - 2017-10-31 12:27:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> Model Class Initialized
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:27:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:27:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:05 --> Total execution time: 0.0279
INFO - 2017-10-31 12:27:06 --> Config Class Initialized
INFO - 2017-10-31 12:27:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:06 --> URI Class Initialized
INFO - 2017-10-31 12:27:06 --> Router Class Initialized
INFO - 2017-10-31 12:27:06 --> Output Class Initialized
INFO - 2017-10-31 12:27:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:06 --> Input Class Initialized
INFO - 2017-10-31 12:27:06 --> Language Class Initialized
INFO - 2017-10-31 12:27:06 --> Loader Class Initialized
INFO - 2017-10-31 12:27:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:06 --> Email Class Initialized
INFO - 2017-10-31 12:27:06 --> Model Class Initialized
INFO - 2017-10-31 12:27:06 --> Controller Class Initialized
INFO - 2017-10-31 12:27:06 --> Model Class Initialized
INFO - 2017-10-31 12:27:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:06 --> Total execution time: 0.0019
INFO - 2017-10-31 12:27:51 --> Config Class Initialized
INFO - 2017-10-31 12:27:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:27:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:27:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:27:51 --> URI Class Initialized
INFO - 2017-10-31 12:27:51 --> Router Class Initialized
INFO - 2017-10-31 12:27:51 --> Output Class Initialized
INFO - 2017-10-31 12:27:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:27:51 --> Input Class Initialized
INFO - 2017-10-31 12:27:51 --> Language Class Initialized
INFO - 2017-10-31 12:27:51 --> Loader Class Initialized
INFO - 2017-10-31 12:27:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:27:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:27:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:27:51 --> Email Class Initialized
INFO - 2017-10-31 12:27:51 --> Model Class Initialized
INFO - 2017-10-31 12:27:51 --> Controller Class Initialized
INFO - 2017-10-31 12:27:51 --> Final output sent to browser
DEBUG - 2017-10-31 12:27:51 --> Total execution time: 0.0021
INFO - 2017-10-31 12:28:05 --> Config Class Initialized
INFO - 2017-10-31 12:28:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:05 --> URI Class Initialized
INFO - 2017-10-31 12:28:05 --> Router Class Initialized
INFO - 2017-10-31 12:28:05 --> Output Class Initialized
INFO - 2017-10-31 12:28:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:05 --> Input Class Initialized
INFO - 2017-10-31 12:28:05 --> Language Class Initialized
INFO - 2017-10-31 12:28:05 --> Loader Class Initialized
INFO - 2017-10-31 12:28:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:05 --> Email Class Initialized
INFO - 2017-10-31 12:28:05 --> Model Class Initialized
INFO - 2017-10-31 12:28:05 --> Controller Class Initialized
INFO - 2017-10-31 12:28:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:05 --> Total execution time: 0.0031
INFO - 2017-10-31 12:28:06 --> Config Class Initialized
INFO - 2017-10-31 12:28:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:06 --> URI Class Initialized
INFO - 2017-10-31 12:28:06 --> Router Class Initialized
INFO - 2017-10-31 12:28:06 --> Output Class Initialized
INFO - 2017-10-31 12:28:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:06 --> Input Class Initialized
INFO - 2017-10-31 12:28:06 --> Language Class Initialized
INFO - 2017-10-31 12:28:06 --> Loader Class Initialized
INFO - 2017-10-31 12:28:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:06 --> Email Class Initialized
INFO - 2017-10-31 12:28:06 --> Model Class Initialized
INFO - 2017-10-31 12:28:06 --> Controller Class Initialized
INFO - 2017-10-31 12:28:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:06 --> Total execution time: 0.0017
INFO - 2017-10-31 12:28:06 --> Config Class Initialized
INFO - 2017-10-31 12:28:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:06 --> URI Class Initialized
INFO - 2017-10-31 12:28:06 --> Router Class Initialized
INFO - 2017-10-31 12:28:06 --> Output Class Initialized
INFO - 2017-10-31 12:28:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:06 --> Input Class Initialized
INFO - 2017-10-31 12:28:06 --> Language Class Initialized
INFO - 2017-10-31 12:28:06 --> Loader Class Initialized
INFO - 2017-10-31 12:28:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:06 --> Email Class Initialized
INFO - 2017-10-31 12:28:06 --> Model Class Initialized
INFO - 2017-10-31 12:28:06 --> Controller Class Initialized
INFO - 2017-10-31 12:28:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:06 --> Total execution time: 0.0023
INFO - 2017-10-31 12:28:48 --> Config Class Initialized
INFO - 2017-10-31 12:28:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:48 --> URI Class Initialized
INFO - 2017-10-31 12:28:48 --> Router Class Initialized
INFO - 2017-10-31 12:28:48 --> Output Class Initialized
INFO - 2017-10-31 12:28:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:48 --> Input Class Initialized
INFO - 2017-10-31 12:28:48 --> Language Class Initialized
INFO - 2017-10-31 12:28:48 --> Loader Class Initialized
INFO - 2017-10-31 12:28:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:48 --> Email Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Controller Class Initialized
INFO - 2017-10-31 12:28:48 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> Model Class Initialized
INFO - 2017-10-31 12:28:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:28:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:28:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:28:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:28:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:28:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:48 --> Total execution time: 0.0275
INFO - 2017-10-31 12:28:49 --> Config Class Initialized
INFO - 2017-10-31 12:28:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:49 --> URI Class Initialized
INFO - 2017-10-31 12:28:49 --> Router Class Initialized
INFO - 2017-10-31 12:28:49 --> Output Class Initialized
INFO - 2017-10-31 12:28:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:49 --> Input Class Initialized
INFO - 2017-10-31 12:28:49 --> Language Class Initialized
INFO - 2017-10-31 12:28:49 --> Loader Class Initialized
INFO - 2017-10-31 12:28:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:49 --> Email Class Initialized
INFO - 2017-10-31 12:28:49 --> Model Class Initialized
INFO - 2017-10-31 12:28:49 --> Controller Class Initialized
INFO - 2017-10-31 12:28:49 --> Model Class Initialized
INFO - 2017-10-31 12:28:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:49 --> Total execution time: 0.0020
INFO - 2017-10-31 12:28:52 --> Config Class Initialized
INFO - 2017-10-31 12:28:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:28:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:28:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:28:52 --> URI Class Initialized
INFO - 2017-10-31 12:28:52 --> Router Class Initialized
INFO - 2017-10-31 12:28:52 --> Output Class Initialized
INFO - 2017-10-31 12:28:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:28:52 --> Input Class Initialized
INFO - 2017-10-31 12:28:52 --> Language Class Initialized
INFO - 2017-10-31 12:28:52 --> Loader Class Initialized
INFO - 2017-10-31 12:28:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:28:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:28:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:28:52 --> Email Class Initialized
INFO - 2017-10-31 12:28:52 --> Model Class Initialized
INFO - 2017-10-31 12:28:52 --> Controller Class Initialized
INFO - 2017-10-31 12:28:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:28:52 --> Total execution time: 0.0036
INFO - 2017-10-31 12:30:12 --> Config Class Initialized
INFO - 2017-10-31 12:30:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:30:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:30:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:30:12 --> URI Class Initialized
INFO - 2017-10-31 12:30:12 --> Router Class Initialized
INFO - 2017-10-31 12:30:12 --> Output Class Initialized
INFO - 2017-10-31 12:30:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:30:12 --> Input Class Initialized
INFO - 2017-10-31 12:30:12 --> Language Class Initialized
INFO - 2017-10-31 12:30:12 --> Loader Class Initialized
INFO - 2017-10-31 12:30:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:30:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:30:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:30:12 --> Email Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Controller Class Initialized
INFO - 2017-10-31 12:30:12 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:30:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:30:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:30:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:30:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:30:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:30:12 --> Total execution time: 0.0411
INFO - 2017-10-31 12:30:12 --> Config Class Initialized
INFO - 2017-10-31 12:30:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:30:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:30:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:30:12 --> URI Class Initialized
INFO - 2017-10-31 12:30:12 --> Router Class Initialized
INFO - 2017-10-31 12:30:12 --> Output Class Initialized
INFO - 2017-10-31 12:30:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:30:12 --> Input Class Initialized
INFO - 2017-10-31 12:30:12 --> Language Class Initialized
INFO - 2017-10-31 12:30:12 --> Loader Class Initialized
INFO - 2017-10-31 12:30:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:30:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:30:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:30:12 --> Email Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Controller Class Initialized
INFO - 2017-10-31 12:30:12 --> Model Class Initialized
INFO - 2017-10-31 12:30:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:30:12 --> Total execution time: 0.0053
INFO - 2017-10-31 12:30:14 --> Config Class Initialized
INFO - 2017-10-31 12:30:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:30:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:30:14 --> Utf8 Class Initialized
INFO - 2017-10-31 12:30:14 --> URI Class Initialized
INFO - 2017-10-31 12:30:14 --> Router Class Initialized
INFO - 2017-10-31 12:30:14 --> Output Class Initialized
INFO - 2017-10-31 12:30:14 --> Security Class Initialized
DEBUG - 2017-10-31 12:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:30:14 --> Input Class Initialized
INFO - 2017-10-31 12:30:14 --> Language Class Initialized
INFO - 2017-10-31 12:30:14 --> Loader Class Initialized
INFO - 2017-10-31 12:30:14 --> Helper loaded: url_helper
INFO - 2017-10-31 12:30:14 --> Helper loaded: common_helper
INFO - 2017-10-31 12:30:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:30:14 --> Email Class Initialized
INFO - 2017-10-31 12:30:14 --> Model Class Initialized
INFO - 2017-10-31 12:30:14 --> Controller Class Initialized
INFO - 2017-10-31 12:30:14 --> Final output sent to browser
DEBUG - 2017-10-31 12:30:14 --> Total execution time: 0.0025
INFO - 2017-10-31 12:32:57 --> Config Class Initialized
INFO - 2017-10-31 12:32:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:32:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:32:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:32:57 --> URI Class Initialized
INFO - 2017-10-31 12:32:57 --> Router Class Initialized
INFO - 2017-10-31 12:32:57 --> Output Class Initialized
INFO - 2017-10-31 12:32:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:32:57 --> Input Class Initialized
INFO - 2017-10-31 12:32:57 --> Language Class Initialized
INFO - 2017-10-31 12:32:57 --> Loader Class Initialized
INFO - 2017-10-31 12:32:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:32:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:32:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:32:57 --> Email Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Controller Class Initialized
INFO - 2017-10-31 12:32:57 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:32:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:32:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:32:57 --> Total execution time: 0.0254
INFO - 2017-10-31 12:32:57 --> Config Class Initialized
INFO - 2017-10-31 12:32:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:32:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:32:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:32:57 --> URI Class Initialized
INFO - 2017-10-31 12:32:57 --> Router Class Initialized
INFO - 2017-10-31 12:32:57 --> Output Class Initialized
INFO - 2017-10-31 12:32:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:32:57 --> Input Class Initialized
INFO - 2017-10-31 12:32:57 --> Language Class Initialized
INFO - 2017-10-31 12:32:57 --> Loader Class Initialized
INFO - 2017-10-31 12:32:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:32:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:32:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:32:57 --> Email Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Controller Class Initialized
INFO - 2017-10-31 12:32:57 --> Model Class Initialized
INFO - 2017-10-31 12:32:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:32:57 --> Total execution time: 0.0025
INFO - 2017-10-31 12:32:59 --> Config Class Initialized
INFO - 2017-10-31 12:32:59 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:32:59 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:32:59 --> Utf8 Class Initialized
INFO - 2017-10-31 12:32:59 --> URI Class Initialized
INFO - 2017-10-31 12:32:59 --> Router Class Initialized
INFO - 2017-10-31 12:32:59 --> Output Class Initialized
INFO - 2017-10-31 12:32:59 --> Security Class Initialized
DEBUG - 2017-10-31 12:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:32:59 --> Input Class Initialized
INFO - 2017-10-31 12:32:59 --> Language Class Initialized
INFO - 2017-10-31 12:32:59 --> Loader Class Initialized
INFO - 2017-10-31 12:32:59 --> Helper loaded: url_helper
INFO - 2017-10-31 12:32:59 --> Helper loaded: common_helper
INFO - 2017-10-31 12:32:59 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:32:59 --> Email Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Controller Class Initialized
INFO - 2017-10-31 12:32:59 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:32:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:32:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:32:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:32:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:32:59 --> Final output sent to browser
DEBUG - 2017-10-31 12:32:59 --> Total execution time: 0.0234
INFO - 2017-10-31 12:32:59 --> Config Class Initialized
INFO - 2017-10-31 12:32:59 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:32:59 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:32:59 --> Utf8 Class Initialized
INFO - 2017-10-31 12:32:59 --> URI Class Initialized
INFO - 2017-10-31 12:32:59 --> Router Class Initialized
INFO - 2017-10-31 12:32:59 --> Output Class Initialized
INFO - 2017-10-31 12:32:59 --> Security Class Initialized
DEBUG - 2017-10-31 12:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:32:59 --> Input Class Initialized
INFO - 2017-10-31 12:32:59 --> Language Class Initialized
INFO - 2017-10-31 12:32:59 --> Loader Class Initialized
INFO - 2017-10-31 12:32:59 --> Helper loaded: url_helper
INFO - 2017-10-31 12:32:59 --> Helper loaded: common_helper
INFO - 2017-10-31 12:32:59 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:32:59 --> Email Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Controller Class Initialized
INFO - 2017-10-31 12:32:59 --> Model Class Initialized
INFO - 2017-10-31 12:32:59 --> Final output sent to browser
DEBUG - 2017-10-31 12:32:59 --> Total execution time: 0.0018
INFO - 2017-10-31 12:33:01 --> Config Class Initialized
INFO - 2017-10-31 12:33:01 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:33:01 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:33:01 --> Utf8 Class Initialized
INFO - 2017-10-31 12:33:01 --> URI Class Initialized
INFO - 2017-10-31 12:33:01 --> Router Class Initialized
INFO - 2017-10-31 12:33:01 --> Output Class Initialized
INFO - 2017-10-31 12:33:01 --> Security Class Initialized
DEBUG - 2017-10-31 12:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:33:01 --> Input Class Initialized
INFO - 2017-10-31 12:33:01 --> Language Class Initialized
INFO - 2017-10-31 12:33:01 --> Loader Class Initialized
INFO - 2017-10-31 12:33:01 --> Helper loaded: url_helper
INFO - 2017-10-31 12:33:01 --> Helper loaded: common_helper
INFO - 2017-10-31 12:33:01 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:33:01 --> Email Class Initialized
INFO - 2017-10-31 12:33:01 --> Model Class Initialized
INFO - 2017-10-31 12:33:01 --> Controller Class Initialized
INFO - 2017-10-31 12:33:01 --> Final output sent to browser
DEBUG - 2017-10-31 12:33:01 --> Total execution time: 0.0023
INFO - 2017-10-31 12:34:09 --> Config Class Initialized
INFO - 2017-10-31 12:34:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:09 --> URI Class Initialized
INFO - 2017-10-31 12:34:09 --> Router Class Initialized
INFO - 2017-10-31 12:34:09 --> Output Class Initialized
INFO - 2017-10-31 12:34:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:09 --> Input Class Initialized
INFO - 2017-10-31 12:34:09 --> Language Class Initialized
INFO - 2017-10-31 12:34:09 --> Loader Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:09 --> Email Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Controller Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:09 --> Total execution time: 0.0237
INFO - 2017-10-31 12:34:09 --> Config Class Initialized
INFO - 2017-10-31 12:34:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:09 --> URI Class Initialized
INFO - 2017-10-31 12:34:09 --> Router Class Initialized
INFO - 2017-10-31 12:34:09 --> Output Class Initialized
INFO - 2017-10-31 12:34:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:09 --> Input Class Initialized
INFO - 2017-10-31 12:34:09 --> Language Class Initialized
INFO - 2017-10-31 12:34:09 --> Loader Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:09 --> Email Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Controller Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:09 --> Total execution time: 0.0205
INFO - 2017-10-31 12:34:09 --> Config Class Initialized
INFO - 2017-10-31 12:34:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:09 --> URI Class Initialized
INFO - 2017-10-31 12:34:09 --> Router Class Initialized
INFO - 2017-10-31 12:34:09 --> Output Class Initialized
INFO - 2017-10-31 12:34:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:09 --> Input Class Initialized
INFO - 2017-10-31 12:34:09 --> Language Class Initialized
INFO - 2017-10-31 12:34:09 --> Loader Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:09 --> Email Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Controller Class Initialized
INFO - 2017-10-31 12:34:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> Model Class Initialized
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:09 --> Total execution time: 0.0213
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0203
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0213
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0211
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0214
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0229
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0229
INFO - 2017-10-31 12:34:10 --> Config Class Initialized
INFO - 2017-10-31 12:34:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:10 --> URI Class Initialized
INFO - 2017-10-31 12:34:10 --> Router Class Initialized
INFO - 2017-10-31 12:34:10 --> Output Class Initialized
INFO - 2017-10-31 12:34:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:10 --> Input Class Initialized
INFO - 2017-10-31 12:34:10 --> Language Class Initialized
INFO - 2017-10-31 12:34:10 --> Loader Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:10 --> Email Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Controller Class Initialized
INFO - 2017-10-31 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> Model Class Initialized
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:10 --> Total execution time: 0.0331
INFO - 2017-10-31 12:34:11 --> Config Class Initialized
INFO - 2017-10-31 12:34:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:11 --> URI Class Initialized
INFO - 2017-10-31 12:34:11 --> Router Class Initialized
INFO - 2017-10-31 12:34:11 --> Output Class Initialized
INFO - 2017-10-31 12:34:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:11 --> Input Class Initialized
INFO - 2017-10-31 12:34:11 --> Language Class Initialized
INFO - 2017-10-31 12:34:11 --> Loader Class Initialized
INFO - 2017-10-31 12:34:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:11 --> Email Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Controller Class Initialized
INFO - 2017-10-31 12:34:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:11 --> Total execution time: 0.0236
INFO - 2017-10-31 12:34:11 --> Config Class Initialized
INFO - 2017-10-31 12:34:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:11 --> URI Class Initialized
INFO - 2017-10-31 12:34:11 --> Router Class Initialized
INFO - 2017-10-31 12:34:11 --> Output Class Initialized
INFO - 2017-10-31 12:34:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:11 --> Input Class Initialized
INFO - 2017-10-31 12:34:11 --> Language Class Initialized
INFO - 2017-10-31 12:34:11 --> Loader Class Initialized
INFO - 2017-10-31 12:34:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:11 --> Email Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Controller Class Initialized
INFO - 2017-10-31 12:34:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:34:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:34:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:11 --> Total execution time: 0.0255
INFO - 2017-10-31 12:34:11 --> Config Class Initialized
INFO - 2017-10-31 12:34:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:11 --> URI Class Initialized
INFO - 2017-10-31 12:34:11 --> Router Class Initialized
INFO - 2017-10-31 12:34:11 --> Output Class Initialized
INFO - 2017-10-31 12:34:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:11 --> Input Class Initialized
INFO - 2017-10-31 12:34:11 --> Language Class Initialized
INFO - 2017-10-31 12:34:11 --> Loader Class Initialized
INFO - 2017-10-31 12:34:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:11 --> Email Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Controller Class Initialized
INFO - 2017-10-31 12:34:11 --> Model Class Initialized
INFO - 2017-10-31 12:34:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:11 --> Total execution time: 0.0019
INFO - 2017-10-31 12:34:16 --> Config Class Initialized
INFO - 2017-10-31 12:34:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:34:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:34:16 --> Utf8 Class Initialized
INFO - 2017-10-31 12:34:16 --> URI Class Initialized
INFO - 2017-10-31 12:34:16 --> Router Class Initialized
INFO - 2017-10-31 12:34:16 --> Output Class Initialized
INFO - 2017-10-31 12:34:16 --> Security Class Initialized
DEBUG - 2017-10-31 12:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:34:16 --> Input Class Initialized
INFO - 2017-10-31 12:34:16 --> Language Class Initialized
INFO - 2017-10-31 12:34:16 --> Loader Class Initialized
INFO - 2017-10-31 12:34:16 --> Helper loaded: url_helper
INFO - 2017-10-31 12:34:16 --> Helper loaded: common_helper
INFO - 2017-10-31 12:34:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:34:16 --> Email Class Initialized
INFO - 2017-10-31 12:34:16 --> Model Class Initialized
INFO - 2017-10-31 12:34:16 --> Controller Class Initialized
INFO - 2017-10-31 12:34:16 --> Final output sent to browser
DEBUG - 2017-10-31 12:34:16 --> Total execution time: 0.0018
INFO - 2017-10-31 12:35:32 --> Config Class Initialized
INFO - 2017-10-31 12:35:32 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:35:32 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:35:32 --> Utf8 Class Initialized
INFO - 2017-10-31 12:35:32 --> URI Class Initialized
INFO - 2017-10-31 12:35:32 --> Router Class Initialized
INFO - 2017-10-31 12:35:32 --> Output Class Initialized
INFO - 2017-10-31 12:35:32 --> Security Class Initialized
DEBUG - 2017-10-31 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:35:32 --> Input Class Initialized
INFO - 2017-10-31 12:35:32 --> Language Class Initialized
INFO - 2017-10-31 12:35:32 --> Loader Class Initialized
INFO - 2017-10-31 12:35:32 --> Helper loaded: url_helper
INFO - 2017-10-31 12:35:32 --> Helper loaded: common_helper
INFO - 2017-10-31 12:35:32 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:35:32 --> Email Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Controller Class Initialized
INFO - 2017-10-31 12:35:32 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:35:32 --> Final output sent to browser
DEBUG - 2017-10-31 12:35:32 --> Total execution time: 0.0300
INFO - 2017-10-31 12:35:32 --> Config Class Initialized
INFO - 2017-10-31 12:35:32 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:35:32 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:35:32 --> Utf8 Class Initialized
INFO - 2017-10-31 12:35:32 --> URI Class Initialized
INFO - 2017-10-31 12:35:32 --> Router Class Initialized
INFO - 2017-10-31 12:35:32 --> Output Class Initialized
INFO - 2017-10-31 12:35:32 --> Security Class Initialized
DEBUG - 2017-10-31 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:35:32 --> Input Class Initialized
INFO - 2017-10-31 12:35:32 --> Language Class Initialized
INFO - 2017-10-31 12:35:32 --> Loader Class Initialized
INFO - 2017-10-31 12:35:32 --> Helper loaded: url_helper
INFO - 2017-10-31 12:35:32 --> Helper loaded: common_helper
INFO - 2017-10-31 12:35:32 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:35:32 --> Email Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Controller Class Initialized
INFO - 2017-10-31 12:35:32 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> Model Class Initialized
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:35:32 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:35:32 --> Final output sent to browser
DEBUG - 2017-10-31 12:35:32 --> Total execution time: 0.0355
INFO - 2017-10-31 12:35:33 --> Config Class Initialized
INFO - 2017-10-31 12:35:33 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:35:33 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:35:33 --> Utf8 Class Initialized
INFO - 2017-10-31 12:35:33 --> URI Class Initialized
INFO - 2017-10-31 12:35:33 --> Router Class Initialized
INFO - 2017-10-31 12:35:33 --> Output Class Initialized
INFO - 2017-10-31 12:35:33 --> Security Class Initialized
DEBUG - 2017-10-31 12:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:35:33 --> Input Class Initialized
INFO - 2017-10-31 12:35:33 --> Language Class Initialized
INFO - 2017-10-31 12:35:33 --> Loader Class Initialized
INFO - 2017-10-31 12:35:33 --> Helper loaded: url_helper
INFO - 2017-10-31 12:35:33 --> Helper loaded: common_helper
INFO - 2017-10-31 12:35:33 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:35:33 --> Email Class Initialized
INFO - 2017-10-31 12:35:33 --> Model Class Initialized
INFO - 2017-10-31 12:35:33 --> Controller Class Initialized
INFO - 2017-10-31 12:35:33 --> Model Class Initialized
INFO - 2017-10-31 12:35:33 --> Final output sent to browser
DEBUG - 2017-10-31 12:35:33 --> Total execution time: 0.0023
INFO - 2017-10-31 12:35:34 --> Config Class Initialized
INFO - 2017-10-31 12:35:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:35:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:35:34 --> Utf8 Class Initialized
INFO - 2017-10-31 12:35:34 --> URI Class Initialized
INFO - 2017-10-31 12:35:34 --> Router Class Initialized
INFO - 2017-10-31 12:35:34 --> Output Class Initialized
INFO - 2017-10-31 12:35:34 --> Security Class Initialized
DEBUG - 2017-10-31 12:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:35:34 --> Input Class Initialized
INFO - 2017-10-31 12:35:34 --> Language Class Initialized
INFO - 2017-10-31 12:35:34 --> Loader Class Initialized
INFO - 2017-10-31 12:35:34 --> Helper loaded: url_helper
INFO - 2017-10-31 12:35:34 --> Helper loaded: common_helper
INFO - 2017-10-31 12:35:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:35:34 --> Email Class Initialized
INFO - 2017-10-31 12:35:34 --> Model Class Initialized
INFO - 2017-10-31 12:35:34 --> Controller Class Initialized
INFO - 2017-10-31 12:35:34 --> Final output sent to browser
DEBUG - 2017-10-31 12:35:34 --> Total execution time: 0.0020
INFO - 2017-10-31 12:37:20 --> Config Class Initialized
INFO - 2017-10-31 12:37:20 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:20 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:20 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:20 --> URI Class Initialized
INFO - 2017-10-31 12:37:20 --> Router Class Initialized
INFO - 2017-10-31 12:37:20 --> Output Class Initialized
INFO - 2017-10-31 12:37:20 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:20 --> Input Class Initialized
INFO - 2017-10-31 12:37:20 --> Language Class Initialized
INFO - 2017-10-31 12:37:20 --> Loader Class Initialized
INFO - 2017-10-31 12:37:20 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:20 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:20 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:20 --> Email Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Controller Class Initialized
INFO - 2017-10-31 12:37:20 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:37:20 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:20 --> Total execution time: 0.0239
INFO - 2017-10-31 12:37:20 --> Config Class Initialized
INFO - 2017-10-31 12:37:20 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:20 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:20 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:20 --> URI Class Initialized
INFO - 2017-10-31 12:37:20 --> Router Class Initialized
INFO - 2017-10-31 12:37:20 --> Output Class Initialized
INFO - 2017-10-31 12:37:20 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:20 --> Input Class Initialized
INFO - 2017-10-31 12:37:20 --> Language Class Initialized
INFO - 2017-10-31 12:37:20 --> Loader Class Initialized
INFO - 2017-10-31 12:37:20 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:20 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:20 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:20 --> Email Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Controller Class Initialized
INFO - 2017-10-31 12:37:20 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> Model Class Initialized
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:37:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:37:20 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:20 --> Total execution time: 0.0337
INFO - 2017-10-31 12:37:21 --> Config Class Initialized
INFO - 2017-10-31 12:37:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:21 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:21 --> URI Class Initialized
INFO - 2017-10-31 12:37:21 --> Router Class Initialized
INFO - 2017-10-31 12:37:21 --> Output Class Initialized
INFO - 2017-10-31 12:37:21 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:21 --> Input Class Initialized
INFO - 2017-10-31 12:37:21 --> Language Class Initialized
INFO - 2017-10-31 12:37:21 --> Loader Class Initialized
INFO - 2017-10-31 12:37:21 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:21 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:21 --> Email Class Initialized
INFO - 2017-10-31 12:37:21 --> Model Class Initialized
INFO - 2017-10-31 12:37:21 --> Controller Class Initialized
INFO - 2017-10-31 12:37:21 --> Model Class Initialized
INFO - 2017-10-31 12:37:21 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:21 --> Total execution time: 0.0032
INFO - 2017-10-31 12:37:22 --> Config Class Initialized
INFO - 2017-10-31 12:37:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:22 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:22 --> URI Class Initialized
INFO - 2017-10-31 12:37:22 --> Router Class Initialized
INFO - 2017-10-31 12:37:22 --> Output Class Initialized
INFO - 2017-10-31 12:37:22 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:22 --> Input Class Initialized
INFO - 2017-10-31 12:37:22 --> Language Class Initialized
INFO - 2017-10-31 12:37:22 --> Loader Class Initialized
INFO - 2017-10-31 12:37:22 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:22 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:22 --> Email Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Controller Class Initialized
INFO - 2017-10-31 12:37:22 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> Model Class Initialized
INFO - 2017-10-31 12:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:37:22 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:22 --> Total execution time: 0.0230
INFO - 2017-10-31 12:37:23 --> Config Class Initialized
INFO - 2017-10-31 12:37:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:23 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:23 --> URI Class Initialized
INFO - 2017-10-31 12:37:23 --> Router Class Initialized
INFO - 2017-10-31 12:37:23 --> Output Class Initialized
INFO - 2017-10-31 12:37:23 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:23 --> Input Class Initialized
INFO - 2017-10-31 12:37:23 --> Language Class Initialized
INFO - 2017-10-31 12:37:23 --> Loader Class Initialized
INFO - 2017-10-31 12:37:23 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:23 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:23 --> Email Class Initialized
INFO - 2017-10-31 12:37:23 --> Model Class Initialized
INFO - 2017-10-31 12:37:23 --> Controller Class Initialized
INFO - 2017-10-31 12:37:23 --> Model Class Initialized
INFO - 2017-10-31 12:37:23 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:23 --> Total execution time: 0.0020
INFO - 2017-10-31 12:37:25 --> Config Class Initialized
INFO - 2017-10-31 12:37:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:37:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:37:25 --> Utf8 Class Initialized
INFO - 2017-10-31 12:37:25 --> URI Class Initialized
INFO - 2017-10-31 12:37:25 --> Router Class Initialized
INFO - 2017-10-31 12:37:25 --> Output Class Initialized
INFO - 2017-10-31 12:37:25 --> Security Class Initialized
DEBUG - 2017-10-31 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:37:25 --> Input Class Initialized
INFO - 2017-10-31 12:37:25 --> Language Class Initialized
INFO - 2017-10-31 12:37:25 --> Loader Class Initialized
INFO - 2017-10-31 12:37:25 --> Helper loaded: url_helper
INFO - 2017-10-31 12:37:25 --> Helper loaded: common_helper
INFO - 2017-10-31 12:37:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:37:25 --> Email Class Initialized
INFO - 2017-10-31 12:37:25 --> Model Class Initialized
INFO - 2017-10-31 12:37:25 --> Controller Class Initialized
INFO - 2017-10-31 12:37:25 --> Final output sent to browser
DEBUG - 2017-10-31 12:37:25 --> Total execution time: 0.0017
INFO - 2017-10-31 12:39:01 --> Config Class Initialized
INFO - 2017-10-31 12:39:01 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:01 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:01 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:01 --> URI Class Initialized
INFO - 2017-10-31 12:39:01 --> Router Class Initialized
INFO - 2017-10-31 12:39:01 --> Output Class Initialized
INFO - 2017-10-31 12:39:01 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:01 --> Input Class Initialized
INFO - 2017-10-31 12:39:01 --> Language Class Initialized
INFO - 2017-10-31 12:39:01 --> Loader Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:01 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:01 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:01 --> Email Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Controller Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:01 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:01 --> Total execution time: 0.0260
INFO - 2017-10-31 12:39:01 --> Config Class Initialized
INFO - 2017-10-31 12:39:01 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:01 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:01 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:01 --> URI Class Initialized
INFO - 2017-10-31 12:39:01 --> Router Class Initialized
INFO - 2017-10-31 12:39:01 --> Output Class Initialized
INFO - 2017-10-31 12:39:01 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:01 --> Input Class Initialized
INFO - 2017-10-31 12:39:01 --> Language Class Initialized
INFO - 2017-10-31 12:39:01 --> Loader Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:01 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:01 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:01 --> Email Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Controller Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:01 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:01 --> Total execution time: 0.0226
INFO - 2017-10-31 12:39:01 --> Config Class Initialized
INFO - 2017-10-31 12:39:01 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:01 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:01 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:01 --> URI Class Initialized
INFO - 2017-10-31 12:39:01 --> Router Class Initialized
INFO - 2017-10-31 12:39:01 --> Output Class Initialized
INFO - 2017-10-31 12:39:01 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:01 --> Input Class Initialized
INFO - 2017-10-31 12:39:01 --> Language Class Initialized
INFO - 2017-10-31 12:39:01 --> Loader Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:01 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:01 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:01 --> Email Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Controller Class Initialized
INFO - 2017-10-31 12:39:01 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> Model Class Initialized
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:01 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:01 --> Total execution time: 0.0212
INFO - 2017-10-31 12:39:02 --> Config Class Initialized
INFO - 2017-10-31 12:39:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:02 --> URI Class Initialized
INFO - 2017-10-31 12:39:02 --> Router Class Initialized
INFO - 2017-10-31 12:39:02 --> Output Class Initialized
INFO - 2017-10-31 12:39:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:02 --> Input Class Initialized
INFO - 2017-10-31 12:39:02 --> Language Class Initialized
INFO - 2017-10-31 12:39:02 --> Loader Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:02 --> Email Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Controller Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:02 --> Total execution time: 0.0224
INFO - 2017-10-31 12:39:02 --> Config Class Initialized
INFO - 2017-10-31 12:39:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:02 --> URI Class Initialized
INFO - 2017-10-31 12:39:02 --> Router Class Initialized
INFO - 2017-10-31 12:39:02 --> Output Class Initialized
INFO - 2017-10-31 12:39:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:02 --> Input Class Initialized
INFO - 2017-10-31 12:39:02 --> Language Class Initialized
INFO - 2017-10-31 12:39:02 --> Loader Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:02 --> Email Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Controller Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:02 --> Total execution time: 0.0213
INFO - 2017-10-31 12:39:02 --> Config Class Initialized
INFO - 2017-10-31 12:39:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:02 --> URI Class Initialized
INFO - 2017-10-31 12:39:02 --> Router Class Initialized
INFO - 2017-10-31 12:39:02 --> Output Class Initialized
INFO - 2017-10-31 12:39:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:02 --> Input Class Initialized
INFO - 2017-10-31 12:39:02 --> Language Class Initialized
INFO - 2017-10-31 12:39:02 --> Loader Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:02 --> Email Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Controller Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:39:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:39:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:02 --> Total execution time: 0.0203
INFO - 2017-10-31 12:39:02 --> Config Class Initialized
INFO - 2017-10-31 12:39:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:02 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:02 --> URI Class Initialized
INFO - 2017-10-31 12:39:02 --> Router Class Initialized
INFO - 2017-10-31 12:39:02 --> Output Class Initialized
INFO - 2017-10-31 12:39:02 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:02 --> Input Class Initialized
INFO - 2017-10-31 12:39:02 --> Language Class Initialized
INFO - 2017-10-31 12:39:02 --> Loader Class Initialized
INFO - 2017-10-31 12:39:02 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:02 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:02 --> Email Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Controller Class Initialized
INFO - 2017-10-31 12:39:02 --> Model Class Initialized
INFO - 2017-10-31 12:39:02 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:02 --> Total execution time: 0.0049
INFO - 2017-10-31 12:39:06 --> Config Class Initialized
INFO - 2017-10-31 12:39:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:39:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:39:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:39:06 --> URI Class Initialized
INFO - 2017-10-31 12:39:06 --> Router Class Initialized
INFO - 2017-10-31 12:39:06 --> Output Class Initialized
INFO - 2017-10-31 12:39:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:39:06 --> Input Class Initialized
INFO - 2017-10-31 12:39:06 --> Language Class Initialized
INFO - 2017-10-31 12:39:06 --> Loader Class Initialized
INFO - 2017-10-31 12:39:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:39:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:39:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:39:06 --> Email Class Initialized
INFO - 2017-10-31 12:39:06 --> Model Class Initialized
INFO - 2017-10-31 12:39:06 --> Controller Class Initialized
INFO - 2017-10-31 12:39:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:39:06 --> Total execution time: 0.0024
INFO - 2017-10-31 12:40:45 --> Config Class Initialized
INFO - 2017-10-31 12:40:45 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:40:45 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:40:45 --> Utf8 Class Initialized
INFO - 2017-10-31 12:40:45 --> URI Class Initialized
INFO - 2017-10-31 12:40:45 --> Router Class Initialized
INFO - 2017-10-31 12:40:45 --> Output Class Initialized
INFO - 2017-10-31 12:40:45 --> Security Class Initialized
DEBUG - 2017-10-31 12:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:40:45 --> Input Class Initialized
INFO - 2017-10-31 12:40:45 --> Language Class Initialized
INFO - 2017-10-31 12:40:45 --> Loader Class Initialized
INFO - 2017-10-31 12:40:45 --> Helper loaded: url_helper
INFO - 2017-10-31 12:40:45 --> Helper loaded: common_helper
INFO - 2017-10-31 12:40:45 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:40:45 --> Email Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Controller Class Initialized
INFO - 2017-10-31 12:40:45 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> Model Class Initialized
INFO - 2017-10-31 12:40:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:40:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:40:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:40:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:40:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:40:45 --> Final output sent to browser
DEBUG - 2017-10-31 12:40:45 --> Total execution time: 0.0292
INFO - 2017-10-31 12:40:46 --> Config Class Initialized
INFO - 2017-10-31 12:40:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:40:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:40:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:40:46 --> URI Class Initialized
INFO - 2017-10-31 12:40:46 --> Router Class Initialized
INFO - 2017-10-31 12:40:46 --> Output Class Initialized
INFO - 2017-10-31 12:40:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:40:46 --> Input Class Initialized
INFO - 2017-10-31 12:40:46 --> Language Class Initialized
INFO - 2017-10-31 12:40:46 --> Loader Class Initialized
INFO - 2017-10-31 12:40:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:40:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:40:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:40:46 --> Email Class Initialized
INFO - 2017-10-31 12:40:46 --> Model Class Initialized
INFO - 2017-10-31 12:40:46 --> Controller Class Initialized
INFO - 2017-10-31 12:40:46 --> Model Class Initialized
INFO - 2017-10-31 12:40:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:40:46 --> Total execution time: 0.0022
INFO - 2017-10-31 12:40:48 --> Config Class Initialized
INFO - 2017-10-31 12:40:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:40:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:40:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:40:48 --> URI Class Initialized
INFO - 2017-10-31 12:40:48 --> Router Class Initialized
INFO - 2017-10-31 12:40:48 --> Output Class Initialized
INFO - 2017-10-31 12:40:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:40:48 --> Input Class Initialized
INFO - 2017-10-31 12:40:48 --> Language Class Initialized
INFO - 2017-10-31 12:40:48 --> Loader Class Initialized
INFO - 2017-10-31 12:40:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:40:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:40:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:40:48 --> Email Class Initialized
INFO - 2017-10-31 12:40:48 --> Model Class Initialized
INFO - 2017-10-31 12:40:48 --> Controller Class Initialized
INFO - 2017-10-31 12:40:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:40:48 --> Total execution time: 0.0018
INFO - 2017-10-31 12:42:56 --> Config Class Initialized
INFO - 2017-10-31 12:42:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:42:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:42:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:42:56 --> URI Class Initialized
INFO - 2017-10-31 12:42:56 --> Router Class Initialized
INFO - 2017-10-31 12:42:56 --> Output Class Initialized
INFO - 2017-10-31 12:42:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:42:56 --> Input Class Initialized
INFO - 2017-10-31 12:42:56 --> Language Class Initialized
INFO - 2017-10-31 12:42:56 --> Loader Class Initialized
INFO - 2017-10-31 12:42:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:42:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:42:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:42:56 --> Email Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Controller Class Initialized
INFO - 2017-10-31 12:42:56 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> Model Class Initialized
INFO - 2017-10-31 12:42:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:42:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:42:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:42:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:42:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:42:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:42:56 --> Total execution time: 0.0261
INFO - 2017-10-31 12:42:58 --> Config Class Initialized
INFO - 2017-10-31 12:42:58 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:42:58 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:42:58 --> Utf8 Class Initialized
INFO - 2017-10-31 12:42:58 --> URI Class Initialized
INFO - 2017-10-31 12:42:58 --> Router Class Initialized
INFO - 2017-10-31 12:42:58 --> Output Class Initialized
INFO - 2017-10-31 12:42:58 --> Security Class Initialized
DEBUG - 2017-10-31 12:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:42:58 --> Input Class Initialized
INFO - 2017-10-31 12:42:58 --> Language Class Initialized
INFO - 2017-10-31 12:42:58 --> Loader Class Initialized
INFO - 2017-10-31 12:42:58 --> Helper loaded: url_helper
INFO - 2017-10-31 12:42:58 --> Helper loaded: common_helper
INFO - 2017-10-31 12:42:58 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:42:58 --> Email Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Controller Class Initialized
INFO - 2017-10-31 12:42:58 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> Model Class Initialized
INFO - 2017-10-31 12:42:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:42:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:42:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:42:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:42:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:42:58 --> Final output sent to browser
DEBUG - 2017-10-31 12:42:58 --> Total execution time: 0.0232
INFO - 2017-10-31 12:43:08 --> Config Class Initialized
INFO - 2017-10-31 12:43:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:08 --> URI Class Initialized
INFO - 2017-10-31 12:43:08 --> Router Class Initialized
INFO - 2017-10-31 12:43:08 --> Output Class Initialized
INFO - 2017-10-31 12:43:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:08 --> Input Class Initialized
INFO - 2017-10-31 12:43:08 --> Language Class Initialized
INFO - 2017-10-31 12:43:08 --> Loader Class Initialized
INFO - 2017-10-31 12:43:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:08 --> Email Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Controller Class Initialized
INFO - 2017-10-31 12:43:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> Model Class Initialized
INFO - 2017-10-31 12:43:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:43:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:43:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:43:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:43:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:43:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:08 --> Total execution time: 0.0244
INFO - 2017-10-31 12:43:09 --> Config Class Initialized
INFO - 2017-10-31 12:43:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:09 --> URI Class Initialized
INFO - 2017-10-31 12:43:09 --> Router Class Initialized
INFO - 2017-10-31 12:43:09 --> Output Class Initialized
INFO - 2017-10-31 12:43:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:09 --> Input Class Initialized
INFO - 2017-10-31 12:43:09 --> Language Class Initialized
INFO - 2017-10-31 12:43:09 --> Loader Class Initialized
INFO - 2017-10-31 12:43:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:09 --> Email Class Initialized
INFO - 2017-10-31 12:43:09 --> Model Class Initialized
INFO - 2017-10-31 12:43:09 --> Controller Class Initialized
INFO - 2017-10-31 12:43:09 --> Model Class Initialized
INFO - 2017-10-31 12:43:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:09 --> Total execution time: 0.0024
INFO - 2017-10-31 12:43:12 --> Config Class Initialized
INFO - 2017-10-31 12:43:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:12 --> URI Class Initialized
INFO - 2017-10-31 12:43:12 --> Router Class Initialized
INFO - 2017-10-31 12:43:12 --> Output Class Initialized
INFO - 2017-10-31 12:43:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:12 --> Input Class Initialized
INFO - 2017-10-31 12:43:12 --> Language Class Initialized
INFO - 2017-10-31 12:43:12 --> Loader Class Initialized
INFO - 2017-10-31 12:43:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:12 --> Email Class Initialized
INFO - 2017-10-31 12:43:12 --> Model Class Initialized
INFO - 2017-10-31 12:43:12 --> Controller Class Initialized
INFO - 2017-10-31 12:43:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:12 --> Total execution time: 0.0035
INFO - 2017-10-31 12:43:54 --> Config Class Initialized
INFO - 2017-10-31 12:43:54 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:54 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:54 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:54 --> URI Class Initialized
INFO - 2017-10-31 12:43:54 --> Router Class Initialized
INFO - 2017-10-31 12:43:54 --> Output Class Initialized
INFO - 2017-10-31 12:43:54 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:54 --> Input Class Initialized
INFO - 2017-10-31 12:43:54 --> Language Class Initialized
INFO - 2017-10-31 12:43:54 --> Loader Class Initialized
INFO - 2017-10-31 12:43:54 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:54 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:54 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:54 --> Email Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Controller Class Initialized
INFO - 2017-10-31 12:43:54 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> Model Class Initialized
INFO - 2017-10-31 12:43:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:43:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:43:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:43:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:43:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:43:54 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:54 --> Total execution time: 0.0252
INFO - 2017-10-31 12:43:55 --> Config Class Initialized
INFO - 2017-10-31 12:43:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:55 --> URI Class Initialized
INFO - 2017-10-31 12:43:55 --> Router Class Initialized
INFO - 2017-10-31 12:43:55 --> Output Class Initialized
INFO - 2017-10-31 12:43:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:55 --> Input Class Initialized
INFO - 2017-10-31 12:43:55 --> Language Class Initialized
INFO - 2017-10-31 12:43:55 --> Loader Class Initialized
INFO - 2017-10-31 12:43:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:55 --> Email Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Controller Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:55 --> Total execution time: 0.0024
INFO - 2017-10-31 12:43:55 --> Config Class Initialized
INFO - 2017-10-31 12:43:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:55 --> URI Class Initialized
INFO - 2017-10-31 12:43:55 --> Router Class Initialized
INFO - 2017-10-31 12:43:55 --> Output Class Initialized
INFO - 2017-10-31 12:43:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:55 --> Input Class Initialized
INFO - 2017-10-31 12:43:55 --> Language Class Initialized
INFO - 2017-10-31 12:43:55 --> Loader Class Initialized
INFO - 2017-10-31 12:43:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:55 --> Email Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Controller Class Initialized
INFO - 2017-10-31 12:43:55 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> Model Class Initialized
INFO - 2017-10-31 12:43:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:43:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:43:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:43:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:43:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:43:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:55 --> Total execution time: 0.0244
INFO - 2017-10-31 12:43:56 --> Config Class Initialized
INFO - 2017-10-31 12:43:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:56 --> URI Class Initialized
INFO - 2017-10-31 12:43:56 --> Router Class Initialized
INFO - 2017-10-31 12:43:56 --> Output Class Initialized
INFO - 2017-10-31 12:43:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:56 --> Input Class Initialized
INFO - 2017-10-31 12:43:56 --> Language Class Initialized
INFO - 2017-10-31 12:43:56 --> Loader Class Initialized
INFO - 2017-10-31 12:43:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:56 --> Email Class Initialized
INFO - 2017-10-31 12:43:56 --> Model Class Initialized
INFO - 2017-10-31 12:43:56 --> Controller Class Initialized
INFO - 2017-10-31 12:43:56 --> Model Class Initialized
INFO - 2017-10-31 12:43:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:56 --> Total execution time: 0.0026
INFO - 2017-10-31 12:43:57 --> Config Class Initialized
INFO - 2017-10-31 12:43:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:43:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:43:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:43:57 --> URI Class Initialized
INFO - 2017-10-31 12:43:57 --> Router Class Initialized
INFO - 2017-10-31 12:43:57 --> Output Class Initialized
INFO - 2017-10-31 12:43:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:43:57 --> Input Class Initialized
INFO - 2017-10-31 12:43:57 --> Language Class Initialized
INFO - 2017-10-31 12:43:57 --> Loader Class Initialized
INFO - 2017-10-31 12:43:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:43:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:43:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:43:57 --> Email Class Initialized
INFO - 2017-10-31 12:43:57 --> Model Class Initialized
INFO - 2017-10-31 12:43:57 --> Controller Class Initialized
INFO - 2017-10-31 12:43:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:43:57 --> Total execution time: 0.0018
INFO - 2017-10-31 12:44:05 --> Config Class Initialized
INFO - 2017-10-31 12:44:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:05 --> URI Class Initialized
INFO - 2017-10-31 12:44:05 --> Router Class Initialized
INFO - 2017-10-31 12:44:05 --> Output Class Initialized
INFO - 2017-10-31 12:44:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:05 --> Input Class Initialized
INFO - 2017-10-31 12:44:05 --> Language Class Initialized
INFO - 2017-10-31 12:44:05 --> Loader Class Initialized
INFO - 2017-10-31 12:44:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:05 --> Email Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Controller Class Initialized
INFO - 2017-10-31 12:44:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:05 --> Total execution time: 0.0420
INFO - 2017-10-31 12:44:05 --> Config Class Initialized
INFO - 2017-10-31 12:44:05 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:05 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:05 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:05 --> URI Class Initialized
INFO - 2017-10-31 12:44:05 --> Router Class Initialized
INFO - 2017-10-31 12:44:05 --> Output Class Initialized
INFO - 2017-10-31 12:44:05 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:05 --> Input Class Initialized
INFO - 2017-10-31 12:44:05 --> Language Class Initialized
INFO - 2017-10-31 12:44:05 --> Loader Class Initialized
INFO - 2017-10-31 12:44:05 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:05 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:05 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:05 --> Email Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Controller Class Initialized
INFO - 2017-10-31 12:44:05 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> Model Class Initialized
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:05 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:05 --> Total execution time: 0.0699
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0646
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0571
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0572
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0562
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0689
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0601
INFO - 2017-10-31 12:44:06 --> Config Class Initialized
INFO - 2017-10-31 12:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:06 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:06 --> URI Class Initialized
INFO - 2017-10-31 12:44:06 --> Router Class Initialized
INFO - 2017-10-31 12:44:06 --> Output Class Initialized
INFO - 2017-10-31 12:44:06 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:06 --> Input Class Initialized
INFO - 2017-10-31 12:44:06 --> Language Class Initialized
INFO - 2017-10-31 12:44:06 --> Loader Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:06 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:06 --> Email Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Controller Class Initialized
INFO - 2017-10-31 12:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> Model Class Initialized
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:06 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:06 --> Total execution time: 0.0436
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:07 --> Total execution time: 0.0630
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:07 --> Total execution time: 0.0553
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:07 --> Total execution time: 0.0518
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:07 --> Total execution time: 0.0640
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:07 --> Total execution time: 0.0501
INFO - 2017-10-31 12:44:07 --> Config Class Initialized
INFO - 2017-10-31 12:44:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:07 --> URI Class Initialized
INFO - 2017-10-31 12:44:07 --> Router Class Initialized
INFO - 2017-10-31 12:44:07 --> Output Class Initialized
INFO - 2017-10-31 12:44:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:07 --> Input Class Initialized
INFO - 2017-10-31 12:44:07 --> Language Class Initialized
INFO - 2017-10-31 12:44:07 --> Loader Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:07 --> Email Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Controller Class Initialized
INFO - 2017-10-31 12:44:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:07 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0592
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0561
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0640
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0524
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0505
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:08 --> Total execution time: 0.0546
INFO - 2017-10-31 12:44:08 --> Config Class Initialized
INFO - 2017-10-31 12:44:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:08 --> URI Class Initialized
INFO - 2017-10-31 12:44:08 --> Router Class Initialized
INFO - 2017-10-31 12:44:08 --> Output Class Initialized
INFO - 2017-10-31 12:44:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:08 --> Input Class Initialized
INFO - 2017-10-31 12:44:08 --> Language Class Initialized
INFO - 2017-10-31 12:44:08 --> Loader Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:08 --> Email Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Controller Class Initialized
INFO - 2017-10-31 12:44:08 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:08 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:09 --> Total execution time: 0.0595
INFO - 2017-10-31 12:44:09 --> Config Class Initialized
INFO - 2017-10-31 12:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:09 --> URI Class Initialized
INFO - 2017-10-31 12:44:09 --> Router Class Initialized
INFO - 2017-10-31 12:44:09 --> Output Class Initialized
INFO - 2017-10-31 12:44:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:09 --> Input Class Initialized
INFO - 2017-10-31 12:44:09 --> Language Class Initialized
INFO - 2017-10-31 12:44:09 --> Loader Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:09 --> Email Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Controller Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:09 --> Total execution time: 0.0509
INFO - 2017-10-31 12:44:09 --> Config Class Initialized
INFO - 2017-10-31 12:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:09 --> URI Class Initialized
INFO - 2017-10-31 12:44:09 --> Router Class Initialized
INFO - 2017-10-31 12:44:09 --> Output Class Initialized
INFO - 2017-10-31 12:44:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:09 --> Input Class Initialized
INFO - 2017-10-31 12:44:09 --> Language Class Initialized
INFO - 2017-10-31 12:44:09 --> Loader Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:09 --> Email Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Controller Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:09 --> Total execution time: 0.0540
INFO - 2017-10-31 12:44:09 --> Config Class Initialized
INFO - 2017-10-31 12:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:09 --> URI Class Initialized
INFO - 2017-10-31 12:44:09 --> Router Class Initialized
INFO - 2017-10-31 12:44:09 --> Output Class Initialized
INFO - 2017-10-31 12:44:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:09 --> Input Class Initialized
INFO - 2017-10-31 12:44:09 --> Language Class Initialized
INFO - 2017-10-31 12:44:09 --> Loader Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:09 --> Email Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Controller Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Config Class Initialized
INFO - 2017-10-31 12:44:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:09 --> URI Class Initialized
INFO - 2017-10-31 12:44:09 --> Router Class Initialized
INFO - 2017-10-31 12:44:09 --> Output Class Initialized
INFO - 2017-10-31 12:44:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:09 --> Input Class Initialized
INFO - 2017-10-31 12:44:09 --> Language Class Initialized
INFO - 2017-10-31 12:44:09 --> Loader Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:09 --> Total execution time: 0.1334
INFO - 2017-10-31 12:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:09 --> Email Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Controller Class Initialized
INFO - 2017-10-31 12:44:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> Model Class Initialized
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:44:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:44:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:09 --> Total execution time: 0.1668
INFO - 2017-10-31 12:44:15 --> Config Class Initialized
INFO - 2017-10-31 12:44:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:15 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:15 --> URI Class Initialized
INFO - 2017-10-31 12:44:15 --> Router Class Initialized
INFO - 2017-10-31 12:44:15 --> Output Class Initialized
INFO - 2017-10-31 12:44:15 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:15 --> Input Class Initialized
INFO - 2017-10-31 12:44:15 --> Language Class Initialized
INFO - 2017-10-31 12:44:15 --> Loader Class Initialized
INFO - 2017-10-31 12:44:15 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:15 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:15 --> Email Class Initialized
INFO - 2017-10-31 12:44:15 --> Model Class Initialized
INFO - 2017-10-31 12:44:15 --> Controller Class Initialized
INFO - 2017-10-31 12:44:15 --> Model Class Initialized
INFO - 2017-10-31 12:44:15 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:15 --> Total execution time: 0.0108
INFO - 2017-10-31 12:44:17 --> Config Class Initialized
INFO - 2017-10-31 12:44:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:44:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:44:17 --> Utf8 Class Initialized
INFO - 2017-10-31 12:44:17 --> URI Class Initialized
INFO - 2017-10-31 12:44:17 --> Router Class Initialized
INFO - 2017-10-31 12:44:17 --> Output Class Initialized
INFO - 2017-10-31 12:44:17 --> Security Class Initialized
DEBUG - 2017-10-31 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:44:17 --> Input Class Initialized
INFO - 2017-10-31 12:44:17 --> Language Class Initialized
INFO - 2017-10-31 12:44:17 --> Loader Class Initialized
INFO - 2017-10-31 12:44:17 --> Helper loaded: url_helper
INFO - 2017-10-31 12:44:17 --> Helper loaded: common_helper
INFO - 2017-10-31 12:44:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:44:17 --> Email Class Initialized
INFO - 2017-10-31 12:44:17 --> Model Class Initialized
INFO - 2017-10-31 12:44:17 --> Controller Class Initialized
INFO - 2017-10-31 12:44:17 --> Final output sent to browser
DEBUG - 2017-10-31 12:44:17 --> Total execution time: 0.0104
INFO - 2017-10-31 12:45:31 --> Config Class Initialized
INFO - 2017-10-31 12:45:31 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:31 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:31 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:31 --> URI Class Initialized
INFO - 2017-10-31 12:45:31 --> Router Class Initialized
INFO - 2017-10-31 12:45:31 --> Output Class Initialized
INFO - 2017-10-31 12:45:31 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:31 --> Input Class Initialized
INFO - 2017-10-31 12:45:31 --> Language Class Initialized
INFO - 2017-10-31 12:45:31 --> Loader Class Initialized
INFO - 2017-10-31 12:45:31 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:31 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:31 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:31 --> Email Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Controller Class Initialized
INFO - 2017-10-31 12:45:31 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:45:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:45:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:45:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:45:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:45:31 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:31 --> Total execution time: 0.0233
INFO - 2017-10-31 12:45:31 --> Config Class Initialized
INFO - 2017-10-31 12:45:31 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:31 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:31 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:31 --> URI Class Initialized
INFO - 2017-10-31 12:45:31 --> Router Class Initialized
INFO - 2017-10-31 12:45:31 --> Output Class Initialized
INFO - 2017-10-31 12:45:31 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:31 --> Input Class Initialized
INFO - 2017-10-31 12:45:31 --> Language Class Initialized
INFO - 2017-10-31 12:45:31 --> Loader Class Initialized
INFO - 2017-10-31 12:45:31 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:31 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:31 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:31 --> Email Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Controller Class Initialized
INFO - 2017-10-31 12:45:31 --> Model Class Initialized
INFO - 2017-10-31 12:45:31 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:31 --> Total execution time: 0.0023
INFO - 2017-10-31 12:45:33 --> Config Class Initialized
INFO - 2017-10-31 12:45:33 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:33 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:33 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:33 --> URI Class Initialized
INFO - 2017-10-31 12:45:33 --> Router Class Initialized
INFO - 2017-10-31 12:45:33 --> Output Class Initialized
INFO - 2017-10-31 12:45:33 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:33 --> Input Class Initialized
INFO - 2017-10-31 12:45:33 --> Language Class Initialized
INFO - 2017-10-31 12:45:33 --> Loader Class Initialized
INFO - 2017-10-31 12:45:33 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:33 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:33 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:33 --> Email Class Initialized
INFO - 2017-10-31 12:45:33 --> Model Class Initialized
INFO - 2017-10-31 12:45:33 --> Controller Class Initialized
INFO - 2017-10-31 12:45:33 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:33 --> Total execution time: 0.0017
INFO - 2017-10-31 12:45:37 --> Config Class Initialized
INFO - 2017-10-31 12:45:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:37 --> URI Class Initialized
INFO - 2017-10-31 12:45:37 --> Router Class Initialized
INFO - 2017-10-31 12:45:37 --> Output Class Initialized
INFO - 2017-10-31 12:45:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:37 --> Input Class Initialized
INFO - 2017-10-31 12:45:37 --> Language Class Initialized
INFO - 2017-10-31 12:45:37 --> Loader Class Initialized
INFO - 2017-10-31 12:45:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:37 --> Email Class Initialized
INFO - 2017-10-31 12:45:37 --> Model Class Initialized
INFO - 2017-10-31 12:45:37 --> Controller Class Initialized
INFO - 2017-10-31 12:45:37 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:37 --> Total execution time: 0.0016
INFO - 2017-10-31 12:45:38 --> Config Class Initialized
INFO - 2017-10-31 12:45:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:38 --> URI Class Initialized
INFO - 2017-10-31 12:45:38 --> Router Class Initialized
INFO - 2017-10-31 12:45:38 --> Output Class Initialized
INFO - 2017-10-31 12:45:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:38 --> Input Class Initialized
INFO - 2017-10-31 12:45:38 --> Language Class Initialized
INFO - 2017-10-31 12:45:38 --> Loader Class Initialized
INFO - 2017-10-31 12:45:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:38 --> Email Class Initialized
INFO - 2017-10-31 12:45:38 --> Model Class Initialized
INFO - 2017-10-31 12:45:38 --> Controller Class Initialized
INFO - 2017-10-31 12:45:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:38 --> Total execution time: 0.0015
INFO - 2017-10-31 12:45:38 --> Config Class Initialized
INFO - 2017-10-31 12:45:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:38 --> URI Class Initialized
INFO - 2017-10-31 12:45:38 --> Router Class Initialized
INFO - 2017-10-31 12:45:38 --> Output Class Initialized
INFO - 2017-10-31 12:45:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:38 --> Input Class Initialized
INFO - 2017-10-31 12:45:38 --> Language Class Initialized
INFO - 2017-10-31 12:45:38 --> Loader Class Initialized
INFO - 2017-10-31 12:45:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:38 --> Email Class Initialized
INFO - 2017-10-31 12:45:38 --> Model Class Initialized
INFO - 2017-10-31 12:45:38 --> Controller Class Initialized
INFO - 2017-10-31 12:45:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:38 --> Total execution time: 0.0016
INFO - 2017-10-31 12:45:38 --> Config Class Initialized
INFO - 2017-10-31 12:45:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:45:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:45:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:45:38 --> URI Class Initialized
INFO - 2017-10-31 12:45:38 --> Router Class Initialized
INFO - 2017-10-31 12:45:38 --> Output Class Initialized
INFO - 2017-10-31 12:45:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:45:38 --> Input Class Initialized
INFO - 2017-10-31 12:45:38 --> Language Class Initialized
INFO - 2017-10-31 12:45:38 --> Loader Class Initialized
INFO - 2017-10-31 12:45:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:45:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:45:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:45:38 --> Email Class Initialized
INFO - 2017-10-31 12:45:38 --> Model Class Initialized
INFO - 2017-10-31 12:45:38 --> Controller Class Initialized
INFO - 2017-10-31 12:45:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:45:38 --> Total execution time: 0.0017
INFO - 2017-10-31 12:46:00 --> Config Class Initialized
INFO - 2017-10-31 12:46:00 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:00 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:00 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:00 --> URI Class Initialized
INFO - 2017-10-31 12:46:00 --> Router Class Initialized
INFO - 2017-10-31 12:46:00 --> Output Class Initialized
INFO - 2017-10-31 12:46:00 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:00 --> Input Class Initialized
INFO - 2017-10-31 12:46:00 --> Language Class Initialized
INFO - 2017-10-31 12:46:00 --> Loader Class Initialized
INFO - 2017-10-31 12:46:00 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:00 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:00 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:00 --> Email Class Initialized
INFO - 2017-10-31 12:46:00 --> Model Class Initialized
INFO - 2017-10-31 12:46:00 --> Controller Class Initialized
INFO - 2017-10-31 12:46:00 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:00 --> Total execution time: 0.0017
INFO - 2017-10-31 12:46:00 --> Config Class Initialized
INFO - 2017-10-31 12:46:00 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:00 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:00 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:00 --> URI Class Initialized
INFO - 2017-10-31 12:46:00 --> Router Class Initialized
INFO - 2017-10-31 12:46:00 --> Output Class Initialized
INFO - 2017-10-31 12:46:00 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:00 --> Input Class Initialized
INFO - 2017-10-31 12:46:00 --> Language Class Initialized
INFO - 2017-10-31 12:46:00 --> Loader Class Initialized
INFO - 2017-10-31 12:46:00 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:00 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:00 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:00 --> Email Class Initialized
INFO - 2017-10-31 12:46:00 --> Model Class Initialized
INFO - 2017-10-31 12:46:00 --> Controller Class Initialized
INFO - 2017-10-31 12:46:00 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:00 --> Total execution time: 0.0017
INFO - 2017-10-31 12:46:03 --> Config Class Initialized
INFO - 2017-10-31 12:46:03 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:03 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:03 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:03 --> URI Class Initialized
INFO - 2017-10-31 12:46:03 --> Router Class Initialized
INFO - 2017-10-31 12:46:03 --> Output Class Initialized
INFO - 2017-10-31 12:46:03 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:03 --> Input Class Initialized
INFO - 2017-10-31 12:46:03 --> Language Class Initialized
INFO - 2017-10-31 12:46:03 --> Loader Class Initialized
INFO - 2017-10-31 12:46:03 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:03 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:03 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:03 --> Email Class Initialized
INFO - 2017-10-31 12:46:03 --> Model Class Initialized
INFO - 2017-10-31 12:46:03 --> Controller Class Initialized
INFO - 2017-10-31 12:46:03 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:03 --> Total execution time: 0.0018
INFO - 2017-10-31 12:46:10 --> Config Class Initialized
INFO - 2017-10-31 12:46:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:10 --> URI Class Initialized
INFO - 2017-10-31 12:46:10 --> Router Class Initialized
INFO - 2017-10-31 12:46:10 --> Output Class Initialized
INFO - 2017-10-31 12:46:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:10 --> Input Class Initialized
INFO - 2017-10-31 12:46:10 --> Language Class Initialized
INFO - 2017-10-31 12:46:10 --> Loader Class Initialized
INFO - 2017-10-31 12:46:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:10 --> Email Class Initialized
INFO - 2017-10-31 12:46:10 --> Model Class Initialized
INFO - 2017-10-31 12:46:10 --> Controller Class Initialized
INFO - 2017-10-31 12:46:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:10 --> Total execution time: 0.0019
INFO - 2017-10-31 12:46:11 --> Config Class Initialized
INFO - 2017-10-31 12:46:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:11 --> URI Class Initialized
INFO - 2017-10-31 12:46:11 --> Router Class Initialized
INFO - 2017-10-31 12:46:11 --> Output Class Initialized
INFO - 2017-10-31 12:46:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:11 --> Input Class Initialized
INFO - 2017-10-31 12:46:11 --> Language Class Initialized
INFO - 2017-10-31 12:46:11 --> Loader Class Initialized
INFO - 2017-10-31 12:46:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:11 --> Email Class Initialized
INFO - 2017-10-31 12:46:11 --> Model Class Initialized
INFO - 2017-10-31 12:46:11 --> Controller Class Initialized
INFO - 2017-10-31 12:46:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:11 --> Total execution time: 0.0016
INFO - 2017-10-31 12:46:11 --> Config Class Initialized
INFO - 2017-10-31 12:46:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:11 --> URI Class Initialized
INFO - 2017-10-31 12:46:11 --> Router Class Initialized
INFO - 2017-10-31 12:46:11 --> Output Class Initialized
INFO - 2017-10-31 12:46:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:11 --> Input Class Initialized
INFO - 2017-10-31 12:46:11 --> Language Class Initialized
INFO - 2017-10-31 12:46:11 --> Loader Class Initialized
INFO - 2017-10-31 12:46:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:11 --> Email Class Initialized
INFO - 2017-10-31 12:46:11 --> Model Class Initialized
INFO - 2017-10-31 12:46:11 --> Controller Class Initialized
INFO - 2017-10-31 12:46:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:11 --> Total execution time: 0.0016
INFO - 2017-10-31 12:46:12 --> Config Class Initialized
INFO - 2017-10-31 12:46:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:46:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:46:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:46:12 --> URI Class Initialized
INFO - 2017-10-31 12:46:12 --> Router Class Initialized
INFO - 2017-10-31 12:46:12 --> Output Class Initialized
INFO - 2017-10-31 12:46:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:46:12 --> Input Class Initialized
INFO - 2017-10-31 12:46:12 --> Language Class Initialized
INFO - 2017-10-31 12:46:12 --> Loader Class Initialized
INFO - 2017-10-31 12:46:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:46:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:46:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:46:12 --> Email Class Initialized
INFO - 2017-10-31 12:46:12 --> Model Class Initialized
INFO - 2017-10-31 12:46:12 --> Controller Class Initialized
INFO - 2017-10-31 12:46:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:46:12 --> Total execution time: 0.0017
INFO - 2017-10-31 12:47:38 --> Config Class Initialized
INFO - 2017-10-31 12:47:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:38 --> URI Class Initialized
INFO - 2017-10-31 12:47:38 --> Router Class Initialized
INFO - 2017-10-31 12:47:38 --> Output Class Initialized
INFO - 2017-10-31 12:47:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:38 --> Input Class Initialized
INFO - 2017-10-31 12:47:38 --> Language Class Initialized
INFO - 2017-10-31 12:47:38 --> Loader Class Initialized
INFO - 2017-10-31 12:47:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:38 --> Email Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Controller Class Initialized
INFO - 2017-10-31 12:47:38 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:47:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:47:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:47:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:47:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:47:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:38 --> Total execution time: 0.0248
INFO - 2017-10-31 12:47:38 --> Config Class Initialized
INFO - 2017-10-31 12:47:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:38 --> URI Class Initialized
INFO - 2017-10-31 12:47:38 --> Router Class Initialized
INFO - 2017-10-31 12:47:38 --> Output Class Initialized
INFO - 2017-10-31 12:47:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:38 --> Input Class Initialized
INFO - 2017-10-31 12:47:38 --> Language Class Initialized
INFO - 2017-10-31 12:47:38 --> Loader Class Initialized
INFO - 2017-10-31 12:47:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:38 --> Email Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Controller Class Initialized
INFO - 2017-10-31 12:47:38 --> Model Class Initialized
INFO - 2017-10-31 12:47:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:38 --> Total execution time: 0.0025
INFO - 2017-10-31 12:47:42 --> Config Class Initialized
INFO - 2017-10-31 12:47:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:42 --> URI Class Initialized
INFO - 2017-10-31 12:47:42 --> Router Class Initialized
INFO - 2017-10-31 12:47:42 --> Output Class Initialized
INFO - 2017-10-31 12:47:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:42 --> Input Class Initialized
INFO - 2017-10-31 12:47:42 --> Language Class Initialized
INFO - 2017-10-31 12:47:42 --> Loader Class Initialized
INFO - 2017-10-31 12:47:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:42 --> Email Class Initialized
INFO - 2017-10-31 12:47:42 --> Model Class Initialized
INFO - 2017-10-31 12:47:42 --> Controller Class Initialized
INFO - 2017-10-31 12:47:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:42 --> Total execution time: 0.0017
INFO - 2017-10-31 12:47:46 --> Config Class Initialized
INFO - 2017-10-31 12:47:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:46 --> URI Class Initialized
INFO - 2017-10-31 12:47:46 --> Router Class Initialized
INFO - 2017-10-31 12:47:46 --> Output Class Initialized
INFO - 2017-10-31 12:47:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:46 --> Input Class Initialized
INFO - 2017-10-31 12:47:46 --> Language Class Initialized
INFO - 2017-10-31 12:47:46 --> Loader Class Initialized
INFO - 2017-10-31 12:47:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:46 --> Email Class Initialized
INFO - 2017-10-31 12:47:46 --> Model Class Initialized
INFO - 2017-10-31 12:47:46 --> Controller Class Initialized
INFO - 2017-10-31 12:47:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:46 --> Total execution time: 0.0040
INFO - 2017-10-31 12:47:47 --> Config Class Initialized
INFO - 2017-10-31 12:47:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:47 --> URI Class Initialized
INFO - 2017-10-31 12:47:47 --> Router Class Initialized
INFO - 2017-10-31 12:47:47 --> Output Class Initialized
INFO - 2017-10-31 12:47:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:47 --> Input Class Initialized
INFO - 2017-10-31 12:47:47 --> Language Class Initialized
INFO - 2017-10-31 12:47:47 --> Loader Class Initialized
INFO - 2017-10-31 12:47:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:47 --> Email Class Initialized
INFO - 2017-10-31 12:47:47 --> Model Class Initialized
INFO - 2017-10-31 12:47:47 --> Controller Class Initialized
INFO - 2017-10-31 12:47:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:47 --> Total execution time: 0.0016
INFO - 2017-10-31 12:47:47 --> Config Class Initialized
INFO - 2017-10-31 12:47:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:47 --> URI Class Initialized
INFO - 2017-10-31 12:47:47 --> Router Class Initialized
INFO - 2017-10-31 12:47:47 --> Output Class Initialized
INFO - 2017-10-31 12:47:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:47 --> Input Class Initialized
INFO - 2017-10-31 12:47:47 --> Language Class Initialized
INFO - 2017-10-31 12:47:47 --> Loader Class Initialized
INFO - 2017-10-31 12:47:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:47 --> Email Class Initialized
INFO - 2017-10-31 12:47:47 --> Model Class Initialized
INFO - 2017-10-31 12:47:47 --> Controller Class Initialized
INFO - 2017-10-31 12:47:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:47 --> Total execution time: 0.0019
INFO - 2017-10-31 12:47:48 --> Config Class Initialized
INFO - 2017-10-31 12:47:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:48 --> URI Class Initialized
INFO - 2017-10-31 12:47:48 --> Router Class Initialized
INFO - 2017-10-31 12:47:48 --> Output Class Initialized
INFO - 2017-10-31 12:47:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:48 --> Input Class Initialized
INFO - 2017-10-31 12:47:48 --> Language Class Initialized
INFO - 2017-10-31 12:47:48 --> Loader Class Initialized
INFO - 2017-10-31 12:47:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:48 --> Email Class Initialized
INFO - 2017-10-31 12:47:48 --> Model Class Initialized
INFO - 2017-10-31 12:47:48 --> Controller Class Initialized
INFO - 2017-10-31 12:47:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:48 --> Total execution time: 0.0016
INFO - 2017-10-31 12:47:50 --> Config Class Initialized
INFO - 2017-10-31 12:47:50 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:47:50 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:47:50 --> Utf8 Class Initialized
INFO - 2017-10-31 12:47:50 --> URI Class Initialized
INFO - 2017-10-31 12:47:50 --> Router Class Initialized
INFO - 2017-10-31 12:47:50 --> Output Class Initialized
INFO - 2017-10-31 12:47:50 --> Security Class Initialized
DEBUG - 2017-10-31 12:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:47:50 --> Input Class Initialized
INFO - 2017-10-31 12:47:50 --> Language Class Initialized
INFO - 2017-10-31 12:47:50 --> Loader Class Initialized
INFO - 2017-10-31 12:47:50 --> Helper loaded: url_helper
INFO - 2017-10-31 12:47:50 --> Helper loaded: common_helper
INFO - 2017-10-31 12:47:50 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:47:50 --> Email Class Initialized
INFO - 2017-10-31 12:47:50 --> Model Class Initialized
INFO - 2017-10-31 12:47:50 --> Controller Class Initialized
INFO - 2017-10-31 12:47:50 --> Final output sent to browser
DEBUG - 2017-10-31 12:47:50 --> Total execution time: 0.0018
INFO - 2017-10-31 12:48:09 --> Config Class Initialized
INFO - 2017-10-31 12:48:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:09 --> URI Class Initialized
INFO - 2017-10-31 12:48:09 --> Router Class Initialized
INFO - 2017-10-31 12:48:09 --> Output Class Initialized
INFO - 2017-10-31 12:48:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:09 --> Input Class Initialized
INFO - 2017-10-31 12:48:09 --> Language Class Initialized
INFO - 2017-10-31 12:48:09 --> Loader Class Initialized
INFO - 2017-10-31 12:48:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:09 --> Email Class Initialized
INFO - 2017-10-31 12:48:09 --> Model Class Initialized
INFO - 2017-10-31 12:48:09 --> Controller Class Initialized
INFO - 2017-10-31 12:48:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:09 --> Total execution time: 0.0026
INFO - 2017-10-31 12:48:13 --> Config Class Initialized
INFO - 2017-10-31 12:48:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:13 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:13 --> URI Class Initialized
INFO - 2017-10-31 12:48:13 --> Router Class Initialized
INFO - 2017-10-31 12:48:13 --> Output Class Initialized
INFO - 2017-10-31 12:48:13 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:13 --> Input Class Initialized
INFO - 2017-10-31 12:48:13 --> Language Class Initialized
INFO - 2017-10-31 12:48:13 --> Loader Class Initialized
INFO - 2017-10-31 12:48:13 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:13 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:13 --> Email Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Controller Class Initialized
INFO - 2017-10-31 12:48:13 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:48:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:48:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:48:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:48:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:48:13 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:13 --> Total execution time: 0.0245
INFO - 2017-10-31 12:48:13 --> Config Class Initialized
INFO - 2017-10-31 12:48:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:13 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:13 --> URI Class Initialized
INFO - 2017-10-31 12:48:13 --> Router Class Initialized
INFO - 2017-10-31 12:48:13 --> Output Class Initialized
INFO - 2017-10-31 12:48:13 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:13 --> Input Class Initialized
INFO - 2017-10-31 12:48:13 --> Language Class Initialized
INFO - 2017-10-31 12:48:13 --> Loader Class Initialized
INFO - 2017-10-31 12:48:13 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:13 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:13 --> Email Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Controller Class Initialized
INFO - 2017-10-31 12:48:13 --> Model Class Initialized
INFO - 2017-10-31 12:48:13 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:13 --> Total execution time: 0.0027
INFO - 2017-10-31 12:48:14 --> Config Class Initialized
INFO - 2017-10-31 12:48:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:14 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:14 --> URI Class Initialized
INFO - 2017-10-31 12:48:14 --> Router Class Initialized
INFO - 2017-10-31 12:48:14 --> Output Class Initialized
INFO - 2017-10-31 12:48:14 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:14 --> Input Class Initialized
INFO - 2017-10-31 12:48:14 --> Language Class Initialized
INFO - 2017-10-31 12:48:14 --> Loader Class Initialized
INFO - 2017-10-31 12:48:14 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:14 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:14 --> Email Class Initialized
INFO - 2017-10-31 12:48:14 --> Model Class Initialized
INFO - 2017-10-31 12:48:14 --> Controller Class Initialized
INFO - 2017-10-31 12:48:14 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:14 --> Total execution time: 0.0025
INFO - 2017-10-31 12:48:17 --> Config Class Initialized
INFO - 2017-10-31 12:48:17 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:17 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:17 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:17 --> URI Class Initialized
INFO - 2017-10-31 12:48:17 --> Router Class Initialized
INFO - 2017-10-31 12:48:17 --> Output Class Initialized
INFO - 2017-10-31 12:48:17 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:17 --> Input Class Initialized
INFO - 2017-10-31 12:48:17 --> Language Class Initialized
INFO - 2017-10-31 12:48:17 --> Loader Class Initialized
INFO - 2017-10-31 12:48:17 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:17 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:17 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:17 --> Email Class Initialized
INFO - 2017-10-31 12:48:17 --> Model Class Initialized
INFO - 2017-10-31 12:48:17 --> Controller Class Initialized
INFO - 2017-10-31 12:48:17 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:17 --> Total execution time: 0.0018
INFO - 2017-10-31 12:48:18 --> Config Class Initialized
INFO - 2017-10-31 12:48:18 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:18 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:18 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:18 --> URI Class Initialized
INFO - 2017-10-31 12:48:18 --> Router Class Initialized
INFO - 2017-10-31 12:48:18 --> Output Class Initialized
INFO - 2017-10-31 12:48:18 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:18 --> Input Class Initialized
INFO - 2017-10-31 12:48:18 --> Language Class Initialized
INFO - 2017-10-31 12:48:18 --> Loader Class Initialized
INFO - 2017-10-31 12:48:18 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:18 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:18 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:18 --> Email Class Initialized
INFO - 2017-10-31 12:48:18 --> Model Class Initialized
INFO - 2017-10-31 12:48:18 --> Controller Class Initialized
INFO - 2017-10-31 12:48:18 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:18 --> Total execution time: 0.0019
INFO - 2017-10-31 12:48:19 --> Config Class Initialized
INFO - 2017-10-31 12:48:19 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:19 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:19 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:19 --> URI Class Initialized
INFO - 2017-10-31 12:48:19 --> Router Class Initialized
INFO - 2017-10-31 12:48:19 --> Output Class Initialized
INFO - 2017-10-31 12:48:19 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:19 --> Input Class Initialized
INFO - 2017-10-31 12:48:19 --> Language Class Initialized
INFO - 2017-10-31 12:48:19 --> Loader Class Initialized
INFO - 2017-10-31 12:48:19 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:19 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:19 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:19 --> Email Class Initialized
INFO - 2017-10-31 12:48:19 --> Model Class Initialized
INFO - 2017-10-31 12:48:19 --> Controller Class Initialized
INFO - 2017-10-31 12:48:19 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:19 --> Total execution time: 0.0018
INFO - 2017-10-31 12:48:19 --> Config Class Initialized
INFO - 2017-10-31 12:48:19 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:19 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:19 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:19 --> URI Class Initialized
INFO - 2017-10-31 12:48:19 --> Router Class Initialized
INFO - 2017-10-31 12:48:19 --> Output Class Initialized
INFO - 2017-10-31 12:48:19 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:19 --> Input Class Initialized
INFO - 2017-10-31 12:48:19 --> Language Class Initialized
INFO - 2017-10-31 12:48:19 --> Loader Class Initialized
INFO - 2017-10-31 12:48:19 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:19 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:19 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:19 --> Email Class Initialized
INFO - 2017-10-31 12:48:19 --> Model Class Initialized
INFO - 2017-10-31 12:48:19 --> Controller Class Initialized
INFO - 2017-10-31 12:48:19 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:19 --> Total execution time: 0.0016
INFO - 2017-10-31 12:48:21 --> Config Class Initialized
INFO - 2017-10-31 12:48:21 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:21 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:21 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:21 --> URI Class Initialized
INFO - 2017-10-31 12:48:21 --> Router Class Initialized
INFO - 2017-10-31 12:48:21 --> Output Class Initialized
INFO - 2017-10-31 12:48:21 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:21 --> Input Class Initialized
INFO - 2017-10-31 12:48:21 --> Language Class Initialized
INFO - 2017-10-31 12:48:21 --> Loader Class Initialized
INFO - 2017-10-31 12:48:21 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:21 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:21 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:21 --> Email Class Initialized
INFO - 2017-10-31 12:48:21 --> Model Class Initialized
INFO - 2017-10-31 12:48:21 --> Controller Class Initialized
INFO - 2017-10-31 12:48:21 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:21 --> Total execution time: 0.0019
INFO - 2017-10-31 12:48:22 --> Config Class Initialized
INFO - 2017-10-31 12:48:22 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:22 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:22 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:22 --> URI Class Initialized
INFO - 2017-10-31 12:48:22 --> Router Class Initialized
INFO - 2017-10-31 12:48:22 --> Output Class Initialized
INFO - 2017-10-31 12:48:22 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:22 --> Input Class Initialized
INFO - 2017-10-31 12:48:22 --> Language Class Initialized
INFO - 2017-10-31 12:48:22 --> Loader Class Initialized
INFO - 2017-10-31 12:48:22 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:22 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:22 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:22 --> Email Class Initialized
INFO - 2017-10-31 12:48:22 --> Model Class Initialized
INFO - 2017-10-31 12:48:22 --> Controller Class Initialized
INFO - 2017-10-31 12:48:22 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:22 --> Total execution time: 0.0077
INFO - 2017-10-31 12:48:23 --> Config Class Initialized
INFO - 2017-10-31 12:48:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:23 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:23 --> URI Class Initialized
INFO - 2017-10-31 12:48:23 --> Router Class Initialized
INFO - 2017-10-31 12:48:23 --> Output Class Initialized
INFO - 2017-10-31 12:48:23 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:23 --> Input Class Initialized
INFO - 2017-10-31 12:48:23 --> Language Class Initialized
INFO - 2017-10-31 12:48:23 --> Loader Class Initialized
INFO - 2017-10-31 12:48:23 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:23 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:23 --> Email Class Initialized
INFO - 2017-10-31 12:48:23 --> Model Class Initialized
INFO - 2017-10-31 12:48:23 --> Controller Class Initialized
INFO - 2017-10-31 12:48:23 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:23 --> Total execution time: 0.0024
INFO - 2017-10-31 12:48:47 --> Config Class Initialized
INFO - 2017-10-31 12:48:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:47 --> URI Class Initialized
INFO - 2017-10-31 12:48:47 --> Router Class Initialized
INFO - 2017-10-31 12:48:47 --> Output Class Initialized
INFO - 2017-10-31 12:48:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:47 --> Input Class Initialized
INFO - 2017-10-31 12:48:47 --> Language Class Initialized
INFO - 2017-10-31 12:48:47 --> Loader Class Initialized
INFO - 2017-10-31 12:48:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:47 --> Email Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Controller Class Initialized
INFO - 2017-10-31 12:48:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:47 --> Total execution time: 0.0021
INFO - 2017-10-31 12:48:47 --> Config Class Initialized
INFO - 2017-10-31 12:48:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:47 --> URI Class Initialized
INFO - 2017-10-31 12:48:47 --> Router Class Initialized
INFO - 2017-10-31 12:48:47 --> Output Class Initialized
INFO - 2017-10-31 12:48:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:47 --> Input Class Initialized
INFO - 2017-10-31 12:48:47 --> Language Class Initialized
INFO - 2017-10-31 12:48:47 --> Loader Class Initialized
INFO - 2017-10-31 12:48:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:47 --> Email Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Controller Class Initialized
INFO - 2017-10-31 12:48:47 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> Model Class Initialized
INFO - 2017-10-31 12:48:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:48:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:48:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:48:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:48:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:48:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:47 --> Total execution time: 0.0253
INFO - 2017-10-31 12:48:48 --> Config Class Initialized
INFO - 2017-10-31 12:48:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:48 --> URI Class Initialized
INFO - 2017-10-31 12:48:48 --> Router Class Initialized
INFO - 2017-10-31 12:48:48 --> Output Class Initialized
INFO - 2017-10-31 12:48:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:48 --> Input Class Initialized
INFO - 2017-10-31 12:48:48 --> Language Class Initialized
INFO - 2017-10-31 12:48:48 --> Loader Class Initialized
INFO - 2017-10-31 12:48:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:48 --> Email Class Initialized
INFO - 2017-10-31 12:48:48 --> Model Class Initialized
INFO - 2017-10-31 12:48:48 --> Controller Class Initialized
INFO - 2017-10-31 12:48:48 --> Model Class Initialized
INFO - 2017-10-31 12:48:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:48 --> Total execution time: 0.0021
INFO - 2017-10-31 12:48:50 --> Config Class Initialized
INFO - 2017-10-31 12:48:50 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:50 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:50 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:50 --> URI Class Initialized
INFO - 2017-10-31 12:48:50 --> Router Class Initialized
INFO - 2017-10-31 12:48:50 --> Output Class Initialized
INFO - 2017-10-31 12:48:50 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:50 --> Input Class Initialized
INFO - 2017-10-31 12:48:50 --> Language Class Initialized
INFO - 2017-10-31 12:48:50 --> Loader Class Initialized
INFO - 2017-10-31 12:48:50 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:50 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:50 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:50 --> Email Class Initialized
INFO - 2017-10-31 12:48:50 --> Model Class Initialized
INFO - 2017-10-31 12:48:50 --> Controller Class Initialized
INFO - 2017-10-31 12:48:50 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:50 --> Total execution time: 0.0022
INFO - 2017-10-31 12:48:53 --> Config Class Initialized
INFO - 2017-10-31 12:48:53 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:53 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:53 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:53 --> URI Class Initialized
INFO - 2017-10-31 12:48:53 --> Router Class Initialized
INFO - 2017-10-31 12:48:53 --> Output Class Initialized
INFO - 2017-10-31 12:48:53 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:53 --> Input Class Initialized
INFO - 2017-10-31 12:48:53 --> Language Class Initialized
INFO - 2017-10-31 12:48:53 --> Loader Class Initialized
INFO - 2017-10-31 12:48:53 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:53 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:53 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:53 --> Email Class Initialized
INFO - 2017-10-31 12:48:53 --> Model Class Initialized
INFO - 2017-10-31 12:48:53 --> Controller Class Initialized
INFO - 2017-10-31 12:48:53 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:53 --> Total execution time: 0.0024
INFO - 2017-10-31 12:48:53 --> Config Class Initialized
INFO - 2017-10-31 12:48:53 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:53 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:53 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:53 --> URI Class Initialized
INFO - 2017-10-31 12:48:53 --> Router Class Initialized
INFO - 2017-10-31 12:48:53 --> Output Class Initialized
INFO - 2017-10-31 12:48:53 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:53 --> Input Class Initialized
INFO - 2017-10-31 12:48:53 --> Language Class Initialized
INFO - 2017-10-31 12:48:53 --> Loader Class Initialized
INFO - 2017-10-31 12:48:53 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:53 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:53 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:53 --> Email Class Initialized
INFO - 2017-10-31 12:48:53 --> Model Class Initialized
INFO - 2017-10-31 12:48:53 --> Controller Class Initialized
INFO - 2017-10-31 12:48:53 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:53 --> Total execution time: 0.0021
INFO - 2017-10-31 12:48:53 --> Config Class Initialized
INFO - 2017-10-31 12:48:53 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:53 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:53 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:53 --> URI Class Initialized
INFO - 2017-10-31 12:48:53 --> Router Class Initialized
INFO - 2017-10-31 12:48:53 --> Output Class Initialized
INFO - 2017-10-31 12:48:53 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:53 --> Input Class Initialized
INFO - 2017-10-31 12:48:53 --> Language Class Initialized
INFO - 2017-10-31 12:48:53 --> Loader Class Initialized
INFO - 2017-10-31 12:48:53 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:53 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:53 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:53 --> Email Class Initialized
INFO - 2017-10-31 12:48:53 --> Model Class Initialized
INFO - 2017-10-31 12:48:53 --> Controller Class Initialized
INFO - 2017-10-31 12:48:53 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:53 --> Total execution time: 0.0020
INFO - 2017-10-31 12:48:54 --> Config Class Initialized
INFO - 2017-10-31 12:48:54 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:48:54 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:48:54 --> Utf8 Class Initialized
INFO - 2017-10-31 12:48:54 --> URI Class Initialized
INFO - 2017-10-31 12:48:54 --> Router Class Initialized
INFO - 2017-10-31 12:48:54 --> Output Class Initialized
INFO - 2017-10-31 12:48:54 --> Security Class Initialized
DEBUG - 2017-10-31 12:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:48:54 --> Input Class Initialized
INFO - 2017-10-31 12:48:54 --> Language Class Initialized
INFO - 2017-10-31 12:48:54 --> Loader Class Initialized
INFO - 2017-10-31 12:48:54 --> Helper loaded: url_helper
INFO - 2017-10-31 12:48:54 --> Helper loaded: common_helper
INFO - 2017-10-31 12:48:54 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:48:54 --> Email Class Initialized
INFO - 2017-10-31 12:48:54 --> Model Class Initialized
INFO - 2017-10-31 12:48:54 --> Controller Class Initialized
INFO - 2017-10-31 12:48:54 --> Final output sent to browser
DEBUG - 2017-10-31 12:48:54 --> Total execution time: 0.0015
INFO - 2017-10-31 12:49:07 --> Config Class Initialized
INFO - 2017-10-31 12:49:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:07 --> URI Class Initialized
INFO - 2017-10-31 12:49:07 --> Router Class Initialized
INFO - 2017-10-31 12:49:07 --> Output Class Initialized
INFO - 2017-10-31 12:49:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:07 --> Input Class Initialized
INFO - 2017-10-31 12:49:07 --> Language Class Initialized
INFO - 2017-10-31 12:49:07 --> Loader Class Initialized
INFO - 2017-10-31 12:49:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:07 --> Email Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Controller Class Initialized
INFO - 2017-10-31 12:49:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:07 --> Total execution time: 0.0031
INFO - 2017-10-31 12:49:07 --> Config Class Initialized
INFO - 2017-10-31 12:49:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:07 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:07 --> URI Class Initialized
INFO - 2017-10-31 12:49:07 --> Router Class Initialized
INFO - 2017-10-31 12:49:07 --> Output Class Initialized
INFO - 2017-10-31 12:49:07 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:07 --> Input Class Initialized
INFO - 2017-10-31 12:49:07 --> Language Class Initialized
INFO - 2017-10-31 12:49:07 --> Loader Class Initialized
INFO - 2017-10-31 12:49:07 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:07 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:07 --> Email Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Controller Class Initialized
INFO - 2017-10-31 12:49:07 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> Model Class Initialized
INFO - 2017-10-31 12:49:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:49:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:49:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:49:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:49:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:49:07 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:07 --> Total execution time: 0.0254
INFO - 2017-10-31 12:49:08 --> Config Class Initialized
INFO - 2017-10-31 12:49:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:08 --> URI Class Initialized
INFO - 2017-10-31 12:49:08 --> Router Class Initialized
INFO - 2017-10-31 12:49:08 --> Output Class Initialized
INFO - 2017-10-31 12:49:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:08 --> Input Class Initialized
INFO - 2017-10-31 12:49:08 --> Language Class Initialized
INFO - 2017-10-31 12:49:08 --> Loader Class Initialized
INFO - 2017-10-31 12:49:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:08 --> Email Class Initialized
INFO - 2017-10-31 12:49:08 --> Model Class Initialized
INFO - 2017-10-31 12:49:08 --> Controller Class Initialized
INFO - 2017-10-31 12:49:08 --> Model Class Initialized
INFO - 2017-10-31 12:49:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:08 --> Total execution time: 0.0027
INFO - 2017-10-31 12:49:09 --> Config Class Initialized
INFO - 2017-10-31 12:49:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:09 --> URI Class Initialized
INFO - 2017-10-31 12:49:09 --> Router Class Initialized
INFO - 2017-10-31 12:49:09 --> Output Class Initialized
INFO - 2017-10-31 12:49:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:09 --> Input Class Initialized
INFO - 2017-10-31 12:49:09 --> Language Class Initialized
INFO - 2017-10-31 12:49:09 --> Loader Class Initialized
INFO - 2017-10-31 12:49:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:09 --> Email Class Initialized
INFO - 2017-10-31 12:49:09 --> Model Class Initialized
INFO - 2017-10-31 12:49:09 --> Controller Class Initialized
INFO - 2017-10-31 12:49:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:09 --> Total execution time: 0.0024
INFO - 2017-10-31 12:49:11 --> Config Class Initialized
INFO - 2017-10-31 12:49:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:11 --> URI Class Initialized
INFO - 2017-10-31 12:49:11 --> Router Class Initialized
INFO - 2017-10-31 12:49:11 --> Output Class Initialized
INFO - 2017-10-31 12:49:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:11 --> Input Class Initialized
INFO - 2017-10-31 12:49:11 --> Language Class Initialized
INFO - 2017-10-31 12:49:11 --> Loader Class Initialized
INFO - 2017-10-31 12:49:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:11 --> Email Class Initialized
INFO - 2017-10-31 12:49:11 --> Model Class Initialized
INFO - 2017-10-31 12:49:11 --> Controller Class Initialized
INFO - 2017-10-31 12:49:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:11 --> Total execution time: 0.0017
INFO - 2017-10-31 12:49:12 --> Config Class Initialized
INFO - 2017-10-31 12:49:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:12 --> URI Class Initialized
INFO - 2017-10-31 12:49:12 --> Router Class Initialized
INFO - 2017-10-31 12:49:12 --> Output Class Initialized
INFO - 2017-10-31 12:49:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:12 --> Input Class Initialized
INFO - 2017-10-31 12:49:12 --> Language Class Initialized
INFO - 2017-10-31 12:49:12 --> Loader Class Initialized
INFO - 2017-10-31 12:49:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:12 --> Email Class Initialized
INFO - 2017-10-31 12:49:12 --> Model Class Initialized
INFO - 2017-10-31 12:49:12 --> Controller Class Initialized
INFO - 2017-10-31 12:49:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:12 --> Total execution time: 0.0016
INFO - 2017-10-31 12:49:12 --> Config Class Initialized
INFO - 2017-10-31 12:49:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:12 --> URI Class Initialized
INFO - 2017-10-31 12:49:12 --> Router Class Initialized
INFO - 2017-10-31 12:49:12 --> Output Class Initialized
INFO - 2017-10-31 12:49:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:12 --> Input Class Initialized
INFO - 2017-10-31 12:49:12 --> Language Class Initialized
INFO - 2017-10-31 12:49:12 --> Loader Class Initialized
INFO - 2017-10-31 12:49:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:12 --> Email Class Initialized
INFO - 2017-10-31 12:49:12 --> Model Class Initialized
INFO - 2017-10-31 12:49:12 --> Controller Class Initialized
INFO - 2017-10-31 12:49:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:12 --> Total execution time: 0.0015
INFO - 2017-10-31 12:49:12 --> Config Class Initialized
INFO - 2017-10-31 12:49:12 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:12 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:12 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:12 --> URI Class Initialized
INFO - 2017-10-31 12:49:12 --> Router Class Initialized
INFO - 2017-10-31 12:49:12 --> Output Class Initialized
INFO - 2017-10-31 12:49:12 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:12 --> Input Class Initialized
INFO - 2017-10-31 12:49:12 --> Language Class Initialized
INFO - 2017-10-31 12:49:12 --> Loader Class Initialized
INFO - 2017-10-31 12:49:12 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:12 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:12 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:12 --> Email Class Initialized
INFO - 2017-10-31 12:49:12 --> Model Class Initialized
INFO - 2017-10-31 12:49:12 --> Controller Class Initialized
INFO - 2017-10-31 12:49:12 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:12 --> Total execution time: 0.0015
INFO - 2017-10-31 12:49:42 --> Config Class Initialized
INFO - 2017-10-31 12:49:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:42 --> URI Class Initialized
INFO - 2017-10-31 12:49:42 --> Router Class Initialized
INFO - 2017-10-31 12:49:42 --> Output Class Initialized
INFO - 2017-10-31 12:49:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:42 --> Input Class Initialized
INFO - 2017-10-31 12:49:42 --> Language Class Initialized
INFO - 2017-10-31 12:49:42 --> Loader Class Initialized
INFO - 2017-10-31 12:49:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:42 --> Email Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Controller Class Initialized
INFO - 2017-10-31 12:49:42 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> Model Class Initialized
INFO - 2017-10-31 12:49:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:49:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:49:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:49:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:49:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:49:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:42 --> Total execution time: 0.0314
INFO - 2017-10-31 12:49:43 --> Config Class Initialized
INFO - 2017-10-31 12:49:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:43 --> URI Class Initialized
INFO - 2017-10-31 12:49:43 --> Router Class Initialized
INFO - 2017-10-31 12:49:43 --> Output Class Initialized
INFO - 2017-10-31 12:49:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:43 --> Input Class Initialized
INFO - 2017-10-31 12:49:43 --> Language Class Initialized
INFO - 2017-10-31 12:49:43 --> Loader Class Initialized
INFO - 2017-10-31 12:49:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:43 --> Email Class Initialized
INFO - 2017-10-31 12:49:43 --> Model Class Initialized
INFO - 2017-10-31 12:49:43 --> Controller Class Initialized
INFO - 2017-10-31 12:49:43 --> Model Class Initialized
INFO - 2017-10-31 12:49:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:43 --> Total execution time: 0.0033
INFO - 2017-10-31 12:49:44 --> Config Class Initialized
INFO - 2017-10-31 12:49:44 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:44 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:44 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:44 --> URI Class Initialized
INFO - 2017-10-31 12:49:44 --> Router Class Initialized
INFO - 2017-10-31 12:49:44 --> Output Class Initialized
INFO - 2017-10-31 12:49:44 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:44 --> Input Class Initialized
INFO - 2017-10-31 12:49:44 --> Language Class Initialized
INFO - 2017-10-31 12:49:44 --> Loader Class Initialized
INFO - 2017-10-31 12:49:44 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:44 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:44 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:44 --> Email Class Initialized
INFO - 2017-10-31 12:49:44 --> Model Class Initialized
INFO - 2017-10-31 12:49:44 --> Controller Class Initialized
INFO - 2017-10-31 12:49:44 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:44 --> Total execution time: 0.0032
INFO - 2017-10-31 12:49:47 --> Config Class Initialized
INFO - 2017-10-31 12:49:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:47 --> URI Class Initialized
INFO - 2017-10-31 12:49:47 --> Router Class Initialized
INFO - 2017-10-31 12:49:47 --> Output Class Initialized
INFO - 2017-10-31 12:49:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:47 --> Input Class Initialized
INFO - 2017-10-31 12:49:47 --> Language Class Initialized
INFO - 2017-10-31 12:49:47 --> Loader Class Initialized
INFO - 2017-10-31 12:49:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:47 --> Email Class Initialized
INFO - 2017-10-31 12:49:47 --> Model Class Initialized
INFO - 2017-10-31 12:49:47 --> Controller Class Initialized
INFO - 2017-10-31 12:49:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:47 --> Total execution time: 0.0017
INFO - 2017-10-31 12:49:48 --> Config Class Initialized
INFO - 2017-10-31 12:49:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:48 --> URI Class Initialized
INFO - 2017-10-31 12:49:48 --> Router Class Initialized
INFO - 2017-10-31 12:49:48 --> Output Class Initialized
INFO - 2017-10-31 12:49:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:48 --> Input Class Initialized
INFO - 2017-10-31 12:49:48 --> Language Class Initialized
INFO - 2017-10-31 12:49:48 --> Loader Class Initialized
INFO - 2017-10-31 12:49:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:48 --> Email Class Initialized
INFO - 2017-10-31 12:49:48 --> Model Class Initialized
INFO - 2017-10-31 12:49:48 --> Controller Class Initialized
INFO - 2017-10-31 12:49:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:48 --> Total execution time: 0.0016
INFO - 2017-10-31 12:49:48 --> Config Class Initialized
INFO - 2017-10-31 12:49:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:48 --> URI Class Initialized
INFO - 2017-10-31 12:49:48 --> Router Class Initialized
INFO - 2017-10-31 12:49:48 --> Output Class Initialized
INFO - 2017-10-31 12:49:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:48 --> Input Class Initialized
INFO - 2017-10-31 12:49:48 --> Language Class Initialized
INFO - 2017-10-31 12:49:48 --> Loader Class Initialized
INFO - 2017-10-31 12:49:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:48 --> Email Class Initialized
INFO - 2017-10-31 12:49:48 --> Model Class Initialized
INFO - 2017-10-31 12:49:48 --> Controller Class Initialized
INFO - 2017-10-31 12:49:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:48 --> Total execution time: 0.0017
INFO - 2017-10-31 12:49:48 --> Config Class Initialized
INFO - 2017-10-31 12:49:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:49:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:49:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:49:48 --> URI Class Initialized
INFO - 2017-10-31 12:49:48 --> Router Class Initialized
INFO - 2017-10-31 12:49:48 --> Output Class Initialized
INFO - 2017-10-31 12:49:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:49:48 --> Input Class Initialized
INFO - 2017-10-31 12:49:48 --> Language Class Initialized
INFO - 2017-10-31 12:49:48 --> Loader Class Initialized
INFO - 2017-10-31 12:49:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:49:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:49:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:49:48 --> Email Class Initialized
INFO - 2017-10-31 12:49:48 --> Model Class Initialized
INFO - 2017-10-31 12:49:48 --> Controller Class Initialized
INFO - 2017-10-31 12:49:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:49:48 --> Total execution time: 0.0016
INFO - 2017-10-31 12:50:41 --> Config Class Initialized
INFO - 2017-10-31 12:50:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:41 --> URI Class Initialized
INFO - 2017-10-31 12:50:41 --> Router Class Initialized
INFO - 2017-10-31 12:50:41 --> Output Class Initialized
INFO - 2017-10-31 12:50:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:41 --> Input Class Initialized
INFO - 2017-10-31 12:50:41 --> Language Class Initialized
INFO - 2017-10-31 12:50:41 --> Loader Class Initialized
INFO - 2017-10-31 12:50:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:41 --> Email Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Controller Class Initialized
INFO - 2017-10-31 12:50:41 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:50:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:50:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:41 --> Total execution time: 0.0251
INFO - 2017-10-31 12:50:41 --> Config Class Initialized
INFO - 2017-10-31 12:50:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:41 --> URI Class Initialized
INFO - 2017-10-31 12:50:41 --> Router Class Initialized
INFO - 2017-10-31 12:50:41 --> Output Class Initialized
INFO - 2017-10-31 12:50:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:41 --> Input Class Initialized
INFO - 2017-10-31 12:50:41 --> Language Class Initialized
INFO - 2017-10-31 12:50:41 --> Loader Class Initialized
INFO - 2017-10-31 12:50:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:41 --> Email Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Controller Class Initialized
INFO - 2017-10-31 12:50:41 --> Model Class Initialized
INFO - 2017-10-31 12:50:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:41 --> Total execution time: 0.0027
INFO - 2017-10-31 12:50:42 --> Config Class Initialized
INFO - 2017-10-31 12:50:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:42 --> URI Class Initialized
INFO - 2017-10-31 12:50:42 --> Router Class Initialized
INFO - 2017-10-31 12:50:42 --> Output Class Initialized
INFO - 2017-10-31 12:50:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:42 --> Input Class Initialized
INFO - 2017-10-31 12:50:42 --> Language Class Initialized
INFO - 2017-10-31 12:50:42 --> Loader Class Initialized
INFO - 2017-10-31 12:50:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:42 --> Email Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Controller Class Initialized
INFO - 2017-10-31 12:50:42 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:50:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:50:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:50:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:50:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:50:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:42 --> Total execution time: 0.0250
INFO - 2017-10-31 12:50:42 --> Config Class Initialized
INFO - 2017-10-31 12:50:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:42 --> URI Class Initialized
INFO - 2017-10-31 12:50:42 --> Router Class Initialized
INFO - 2017-10-31 12:50:42 --> Output Class Initialized
INFO - 2017-10-31 12:50:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:42 --> Input Class Initialized
INFO - 2017-10-31 12:50:42 --> Language Class Initialized
INFO - 2017-10-31 12:50:42 --> Loader Class Initialized
INFO - 2017-10-31 12:50:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:42 --> Email Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Controller Class Initialized
INFO - 2017-10-31 12:50:42 --> Model Class Initialized
INFO - 2017-10-31 12:50:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:42 --> Total execution time: 0.0022
INFO - 2017-10-31 12:50:43 --> Config Class Initialized
INFO - 2017-10-31 12:50:43 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:43 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:43 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:43 --> URI Class Initialized
INFO - 2017-10-31 12:50:43 --> Router Class Initialized
INFO - 2017-10-31 12:50:43 --> Output Class Initialized
INFO - 2017-10-31 12:50:43 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:43 --> Input Class Initialized
INFO - 2017-10-31 12:50:43 --> Language Class Initialized
INFO - 2017-10-31 12:50:43 --> Loader Class Initialized
INFO - 2017-10-31 12:50:43 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:43 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:43 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:43 --> Email Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Controller Class Initialized
INFO - 2017-10-31 12:50:43 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> Model Class Initialized
INFO - 2017-10-31 12:50:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:50:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:50:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:50:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:50:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:50:43 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:43 --> Total execution time: 0.0343
INFO - 2017-10-31 12:50:44 --> Config Class Initialized
INFO - 2017-10-31 12:50:44 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:44 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:44 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:44 --> URI Class Initialized
INFO - 2017-10-31 12:50:44 --> Router Class Initialized
INFO - 2017-10-31 12:50:44 --> Output Class Initialized
INFO - 2017-10-31 12:50:44 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:44 --> Input Class Initialized
INFO - 2017-10-31 12:50:44 --> Language Class Initialized
INFO - 2017-10-31 12:50:44 --> Loader Class Initialized
INFO - 2017-10-31 12:50:44 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:44 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:44 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:44 --> Email Class Initialized
INFO - 2017-10-31 12:50:44 --> Model Class Initialized
INFO - 2017-10-31 12:50:44 --> Controller Class Initialized
INFO - 2017-10-31 12:50:44 --> Model Class Initialized
INFO - 2017-10-31 12:50:44 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:44 --> Total execution time: 0.0030
INFO - 2017-10-31 12:50:44 --> Config Class Initialized
INFO - 2017-10-31 12:50:44 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:44 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:44 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:44 --> URI Class Initialized
INFO - 2017-10-31 12:50:44 --> Router Class Initialized
INFO - 2017-10-31 12:50:44 --> Output Class Initialized
INFO - 2017-10-31 12:50:44 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:44 --> Input Class Initialized
INFO - 2017-10-31 12:50:44 --> Language Class Initialized
INFO - 2017-10-31 12:50:44 --> Loader Class Initialized
INFO - 2017-10-31 12:50:44 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:44 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:44 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:44 --> Email Class Initialized
INFO - 2017-10-31 12:50:44 --> Model Class Initialized
INFO - 2017-10-31 12:50:44 --> Controller Class Initialized
INFO - 2017-10-31 12:50:44 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:44 --> Total execution time: 0.0020
INFO - 2017-10-31 12:50:49 --> Config Class Initialized
INFO - 2017-10-31 12:50:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:49 --> URI Class Initialized
INFO - 2017-10-31 12:50:49 --> Router Class Initialized
INFO - 2017-10-31 12:50:49 --> Output Class Initialized
INFO - 2017-10-31 12:50:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:49 --> Input Class Initialized
INFO - 2017-10-31 12:50:49 --> Language Class Initialized
INFO - 2017-10-31 12:50:49 --> Loader Class Initialized
INFO - 2017-10-31 12:50:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:49 --> Email Class Initialized
INFO - 2017-10-31 12:50:49 --> Model Class Initialized
INFO - 2017-10-31 12:50:49 --> Controller Class Initialized
INFO - 2017-10-31 12:50:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:49 --> Total execution time: 0.0017
INFO - 2017-10-31 12:50:49 --> Config Class Initialized
INFO - 2017-10-31 12:50:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:49 --> URI Class Initialized
INFO - 2017-10-31 12:50:49 --> Router Class Initialized
INFO - 2017-10-31 12:50:49 --> Output Class Initialized
INFO - 2017-10-31 12:50:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:49 --> Input Class Initialized
INFO - 2017-10-31 12:50:49 --> Language Class Initialized
INFO - 2017-10-31 12:50:49 --> Loader Class Initialized
INFO - 2017-10-31 12:50:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:49 --> Email Class Initialized
INFO - 2017-10-31 12:50:49 --> Model Class Initialized
INFO - 2017-10-31 12:50:49 --> Controller Class Initialized
INFO - 2017-10-31 12:50:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:49 --> Total execution time: 0.0016
INFO - 2017-10-31 12:50:49 --> Config Class Initialized
INFO - 2017-10-31 12:50:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:49 --> URI Class Initialized
INFO - 2017-10-31 12:50:49 --> Router Class Initialized
INFO - 2017-10-31 12:50:49 --> Output Class Initialized
INFO - 2017-10-31 12:50:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:49 --> Input Class Initialized
INFO - 2017-10-31 12:50:49 --> Language Class Initialized
INFO - 2017-10-31 12:50:49 --> Loader Class Initialized
INFO - 2017-10-31 12:50:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:49 --> Email Class Initialized
INFO - 2017-10-31 12:50:49 --> Model Class Initialized
INFO - 2017-10-31 12:50:49 --> Controller Class Initialized
INFO - 2017-10-31 12:50:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:49 --> Total execution time: 0.0015
INFO - 2017-10-31 12:50:50 --> Config Class Initialized
INFO - 2017-10-31 12:50:50 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:50:50 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:50:50 --> Utf8 Class Initialized
INFO - 2017-10-31 12:50:50 --> URI Class Initialized
INFO - 2017-10-31 12:50:50 --> Router Class Initialized
INFO - 2017-10-31 12:50:50 --> Output Class Initialized
INFO - 2017-10-31 12:50:50 --> Security Class Initialized
DEBUG - 2017-10-31 12:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:50:50 --> Input Class Initialized
INFO - 2017-10-31 12:50:50 --> Language Class Initialized
INFO - 2017-10-31 12:50:50 --> Loader Class Initialized
INFO - 2017-10-31 12:50:50 --> Helper loaded: url_helper
INFO - 2017-10-31 12:50:50 --> Helper loaded: common_helper
INFO - 2017-10-31 12:50:50 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:50:50 --> Email Class Initialized
INFO - 2017-10-31 12:50:50 --> Model Class Initialized
INFO - 2017-10-31 12:50:50 --> Controller Class Initialized
INFO - 2017-10-31 12:50:50 --> Final output sent to browser
DEBUG - 2017-10-31 12:50:50 --> Total execution time: 0.0016
INFO - 2017-10-31 12:51:46 --> Config Class Initialized
INFO - 2017-10-31 12:51:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:46 --> URI Class Initialized
INFO - 2017-10-31 12:51:46 --> Router Class Initialized
INFO - 2017-10-31 12:51:46 --> Output Class Initialized
INFO - 2017-10-31 12:51:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:46 --> Input Class Initialized
INFO - 2017-10-31 12:51:46 --> Language Class Initialized
INFO - 2017-10-31 12:51:46 --> Loader Class Initialized
INFO - 2017-10-31 12:51:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:46 --> Email Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Controller Class Initialized
INFO - 2017-10-31 12:51:46 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:51:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:51:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:51:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:51:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:51:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:46 --> Total execution time: 0.0217
INFO - 2017-10-31 12:51:46 --> Config Class Initialized
INFO - 2017-10-31 12:51:46 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:46 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:46 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:46 --> URI Class Initialized
INFO - 2017-10-31 12:51:46 --> Router Class Initialized
INFO - 2017-10-31 12:51:46 --> Output Class Initialized
INFO - 2017-10-31 12:51:46 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:46 --> Input Class Initialized
INFO - 2017-10-31 12:51:46 --> Language Class Initialized
INFO - 2017-10-31 12:51:46 --> Loader Class Initialized
INFO - 2017-10-31 12:51:46 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:46 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:46 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:46 --> Email Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Controller Class Initialized
INFO - 2017-10-31 12:51:46 --> Model Class Initialized
INFO - 2017-10-31 12:51:46 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:46 --> Total execution time: 0.0028
INFO - 2017-10-31 12:51:47 --> Config Class Initialized
INFO - 2017-10-31 12:51:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:47 --> URI Class Initialized
INFO - 2017-10-31 12:51:47 --> Router Class Initialized
INFO - 2017-10-31 12:51:47 --> Output Class Initialized
INFO - 2017-10-31 12:51:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:47 --> Input Class Initialized
INFO - 2017-10-31 12:51:47 --> Language Class Initialized
INFO - 2017-10-31 12:51:47 --> Loader Class Initialized
INFO - 2017-10-31 12:51:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:47 --> Email Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Controller Class Initialized
INFO - 2017-10-31 12:51:47 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:51:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:51:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:51:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:51:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:51:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:47 --> Total execution time: 0.0288
INFO - 2017-10-31 12:51:47 --> Config Class Initialized
INFO - 2017-10-31 12:51:47 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:47 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:47 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:47 --> URI Class Initialized
INFO - 2017-10-31 12:51:47 --> Router Class Initialized
INFO - 2017-10-31 12:51:47 --> Output Class Initialized
INFO - 2017-10-31 12:51:47 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:47 --> Input Class Initialized
INFO - 2017-10-31 12:51:47 --> Language Class Initialized
INFO - 2017-10-31 12:51:47 --> Loader Class Initialized
INFO - 2017-10-31 12:51:47 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:47 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:47 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:47 --> Email Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Controller Class Initialized
INFO - 2017-10-31 12:51:47 --> Model Class Initialized
INFO - 2017-10-31 12:51:47 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:47 --> Total execution time: 0.0033
INFO - 2017-10-31 12:51:48 --> Config Class Initialized
INFO - 2017-10-31 12:51:48 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:48 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:48 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:48 --> URI Class Initialized
INFO - 2017-10-31 12:51:48 --> Router Class Initialized
INFO - 2017-10-31 12:51:48 --> Output Class Initialized
INFO - 2017-10-31 12:51:48 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:48 --> Input Class Initialized
INFO - 2017-10-31 12:51:48 --> Language Class Initialized
INFO - 2017-10-31 12:51:48 --> Loader Class Initialized
INFO - 2017-10-31 12:51:48 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:48 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:48 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:48 --> Email Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Controller Class Initialized
INFO - 2017-10-31 12:51:48 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> Model Class Initialized
INFO - 2017-10-31 12:51:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:51:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:51:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:51:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:51:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:51:48 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:48 --> Total execution time: 0.0247
INFO - 2017-10-31 12:51:49 --> Config Class Initialized
INFO - 2017-10-31 12:51:49 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:49 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:49 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:49 --> URI Class Initialized
INFO - 2017-10-31 12:51:49 --> Router Class Initialized
INFO - 2017-10-31 12:51:49 --> Output Class Initialized
INFO - 2017-10-31 12:51:49 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:49 --> Input Class Initialized
INFO - 2017-10-31 12:51:49 --> Language Class Initialized
INFO - 2017-10-31 12:51:49 --> Loader Class Initialized
INFO - 2017-10-31 12:51:49 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:49 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:49 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:49 --> Email Class Initialized
INFO - 2017-10-31 12:51:49 --> Model Class Initialized
INFO - 2017-10-31 12:51:49 --> Controller Class Initialized
INFO - 2017-10-31 12:51:49 --> Model Class Initialized
INFO - 2017-10-31 12:51:49 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:49 --> Total execution time: 0.0020
INFO - 2017-10-31 12:51:50 --> Config Class Initialized
INFO - 2017-10-31 12:51:50 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:50 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:50 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:50 --> URI Class Initialized
INFO - 2017-10-31 12:51:50 --> Router Class Initialized
INFO - 2017-10-31 12:51:50 --> Output Class Initialized
INFO - 2017-10-31 12:51:50 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:50 --> Input Class Initialized
INFO - 2017-10-31 12:51:50 --> Language Class Initialized
INFO - 2017-10-31 12:51:50 --> Loader Class Initialized
INFO - 2017-10-31 12:51:50 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:50 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:50 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:50 --> Email Class Initialized
INFO - 2017-10-31 12:51:50 --> Model Class Initialized
INFO - 2017-10-31 12:51:50 --> Controller Class Initialized
INFO - 2017-10-31 12:51:50 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:50 --> Total execution time: 0.0023
INFO - 2017-10-31 12:51:53 --> Config Class Initialized
INFO - 2017-10-31 12:51:53 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:53 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:53 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:53 --> URI Class Initialized
INFO - 2017-10-31 12:51:53 --> Router Class Initialized
INFO - 2017-10-31 12:51:53 --> Output Class Initialized
INFO - 2017-10-31 12:51:53 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:53 --> Input Class Initialized
INFO - 2017-10-31 12:51:53 --> Language Class Initialized
INFO - 2017-10-31 12:51:53 --> Loader Class Initialized
INFO - 2017-10-31 12:51:53 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:53 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:53 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:53 --> Email Class Initialized
INFO - 2017-10-31 12:51:53 --> Model Class Initialized
INFO - 2017-10-31 12:51:53 --> Controller Class Initialized
INFO - 2017-10-31 12:51:53 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:53 --> Total execution time: 0.0017
INFO - 2017-10-31 12:51:54 --> Config Class Initialized
INFO - 2017-10-31 12:51:54 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:54 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:54 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:54 --> URI Class Initialized
INFO - 2017-10-31 12:51:54 --> Router Class Initialized
INFO - 2017-10-31 12:51:54 --> Output Class Initialized
INFO - 2017-10-31 12:51:54 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:54 --> Input Class Initialized
INFO - 2017-10-31 12:51:54 --> Language Class Initialized
INFO - 2017-10-31 12:51:54 --> Loader Class Initialized
INFO - 2017-10-31 12:51:54 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:54 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:54 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:54 --> Email Class Initialized
INFO - 2017-10-31 12:51:54 --> Model Class Initialized
INFO - 2017-10-31 12:51:54 --> Controller Class Initialized
INFO - 2017-10-31 12:51:54 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:54 --> Total execution time: 0.0022
INFO - 2017-10-31 12:51:55 --> Config Class Initialized
INFO - 2017-10-31 12:51:55 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:51:55 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:51:55 --> Utf8 Class Initialized
INFO - 2017-10-31 12:51:55 --> URI Class Initialized
INFO - 2017-10-31 12:51:55 --> Router Class Initialized
INFO - 2017-10-31 12:51:55 --> Output Class Initialized
INFO - 2017-10-31 12:51:55 --> Security Class Initialized
DEBUG - 2017-10-31 12:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:51:55 --> Input Class Initialized
INFO - 2017-10-31 12:51:55 --> Language Class Initialized
INFO - 2017-10-31 12:51:55 --> Loader Class Initialized
INFO - 2017-10-31 12:51:55 --> Helper loaded: url_helper
INFO - 2017-10-31 12:51:55 --> Helper loaded: common_helper
INFO - 2017-10-31 12:51:55 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:51:55 --> Email Class Initialized
INFO - 2017-10-31 12:51:55 --> Model Class Initialized
INFO - 2017-10-31 12:51:55 --> Controller Class Initialized
INFO - 2017-10-31 12:51:55 --> Final output sent to browser
DEBUG - 2017-10-31 12:51:55 --> Total execution time: 0.0019
INFO - 2017-10-31 12:52:08 --> Config Class Initialized
INFO - 2017-10-31 12:52:08 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:52:08 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:52:08 --> Utf8 Class Initialized
INFO - 2017-10-31 12:52:08 --> URI Class Initialized
INFO - 2017-10-31 12:52:08 --> Router Class Initialized
INFO - 2017-10-31 12:52:08 --> Output Class Initialized
INFO - 2017-10-31 12:52:08 --> Security Class Initialized
DEBUG - 2017-10-31 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:52:08 --> Input Class Initialized
INFO - 2017-10-31 12:52:08 --> Language Class Initialized
INFO - 2017-10-31 12:52:08 --> Loader Class Initialized
INFO - 2017-10-31 12:52:08 --> Helper loaded: url_helper
INFO - 2017-10-31 12:52:08 --> Helper loaded: common_helper
INFO - 2017-10-31 12:52:08 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:52:08 --> Email Class Initialized
INFO - 2017-10-31 12:52:08 --> Model Class Initialized
INFO - 2017-10-31 12:52:08 --> Controller Class Initialized
INFO - 2017-10-31 12:52:08 --> Final output sent to browser
DEBUG - 2017-10-31 12:52:08 --> Total execution time: 0.0037
INFO - 2017-10-31 12:52:11 --> Config Class Initialized
INFO - 2017-10-31 12:52:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:52:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:52:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:52:11 --> URI Class Initialized
INFO - 2017-10-31 12:52:11 --> Router Class Initialized
INFO - 2017-10-31 12:52:11 --> Output Class Initialized
INFO - 2017-10-31 12:52:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:52:11 --> Input Class Initialized
INFO - 2017-10-31 12:52:11 --> Language Class Initialized
INFO - 2017-10-31 12:52:11 --> Loader Class Initialized
INFO - 2017-10-31 12:52:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:52:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:52:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:52:11 --> Email Class Initialized
INFO - 2017-10-31 12:52:11 --> Model Class Initialized
INFO - 2017-10-31 12:52:11 --> Controller Class Initialized
INFO - 2017-10-31 12:52:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:52:11 --> Total execution time: 0.0025
INFO - 2017-10-31 12:52:26 --> Config Class Initialized
INFO - 2017-10-31 12:52:26 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:52:26 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:52:26 --> Utf8 Class Initialized
INFO - 2017-10-31 12:52:26 --> URI Class Initialized
INFO - 2017-10-31 12:52:26 --> Router Class Initialized
INFO - 2017-10-31 12:52:26 --> Output Class Initialized
INFO - 2017-10-31 12:52:26 --> Security Class Initialized
DEBUG - 2017-10-31 12:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:52:26 --> Input Class Initialized
INFO - 2017-10-31 12:52:26 --> Language Class Initialized
INFO - 2017-10-31 12:52:26 --> Loader Class Initialized
INFO - 2017-10-31 12:52:26 --> Helper loaded: url_helper
INFO - 2017-10-31 12:52:26 --> Helper loaded: common_helper
INFO - 2017-10-31 12:52:26 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:52:26 --> Email Class Initialized
INFO - 2017-10-31 12:52:26 --> Model Class Initialized
INFO - 2017-10-31 12:52:26 --> Controller Class Initialized
INFO - 2017-10-31 12:52:26 --> Final output sent to browser
DEBUG - 2017-10-31 12:52:26 --> Total execution time: 0.0024
INFO - 2017-10-31 12:57:09 --> Config Class Initialized
INFO - 2017-10-31 12:57:09 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:09 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:09 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:09 --> URI Class Initialized
INFO - 2017-10-31 12:57:09 --> Router Class Initialized
INFO - 2017-10-31 12:57:09 --> Output Class Initialized
INFO - 2017-10-31 12:57:09 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:09 --> Input Class Initialized
INFO - 2017-10-31 12:57:09 --> Language Class Initialized
INFO - 2017-10-31 12:57:09 --> Loader Class Initialized
INFO - 2017-10-31 12:57:09 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:09 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:09 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:09 --> Email Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Controller Class Initialized
INFO - 2017-10-31 12:57:09 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> Model Class Initialized
INFO - 2017-10-31 12:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:09 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:09 --> Total execution time: 0.0242
INFO - 2017-10-31 12:57:10 --> Config Class Initialized
INFO - 2017-10-31 12:57:10 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:10 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:10 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:10 --> URI Class Initialized
INFO - 2017-10-31 12:57:10 --> Router Class Initialized
INFO - 2017-10-31 12:57:10 --> Output Class Initialized
INFO - 2017-10-31 12:57:10 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:10 --> Input Class Initialized
INFO - 2017-10-31 12:57:10 --> Language Class Initialized
INFO - 2017-10-31 12:57:10 --> Loader Class Initialized
INFO - 2017-10-31 12:57:10 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:10 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:10 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:10 --> Email Class Initialized
INFO - 2017-10-31 12:57:10 --> Model Class Initialized
INFO - 2017-10-31 12:57:10 --> Controller Class Initialized
INFO - 2017-10-31 12:57:10 --> Model Class Initialized
INFO - 2017-10-31 12:57:10 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:10 --> Total execution time: 0.0035
INFO - 2017-10-31 12:57:11 --> Config Class Initialized
INFO - 2017-10-31 12:57:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:11 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:11 --> URI Class Initialized
INFO - 2017-10-31 12:57:11 --> Router Class Initialized
INFO - 2017-10-31 12:57:11 --> Output Class Initialized
INFO - 2017-10-31 12:57:11 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:11 --> Input Class Initialized
INFO - 2017-10-31 12:57:11 --> Language Class Initialized
INFO - 2017-10-31 12:57:11 --> Loader Class Initialized
INFO - 2017-10-31 12:57:11 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:11 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:11 --> Email Class Initialized
INFO - 2017-10-31 12:57:11 --> Model Class Initialized
INFO - 2017-10-31 12:57:11 --> Controller Class Initialized
INFO - 2017-10-31 12:57:11 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:11 --> Total execution time: 0.0021
INFO - 2017-10-31 12:57:14 --> Config Class Initialized
INFO - 2017-10-31 12:57:14 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:14 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:14 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:14 --> URI Class Initialized
INFO - 2017-10-31 12:57:14 --> Router Class Initialized
INFO - 2017-10-31 12:57:14 --> Output Class Initialized
INFO - 2017-10-31 12:57:14 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:14 --> Input Class Initialized
INFO - 2017-10-31 12:57:14 --> Language Class Initialized
INFO - 2017-10-31 12:57:14 --> Loader Class Initialized
INFO - 2017-10-31 12:57:14 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:14 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:14 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:14 --> Email Class Initialized
INFO - 2017-10-31 12:57:14 --> Model Class Initialized
INFO - 2017-10-31 12:57:14 --> Controller Class Initialized
INFO - 2017-10-31 12:57:14 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:14 --> Total execution time: 0.0016
INFO - 2017-10-31 12:57:15 --> Config Class Initialized
INFO - 2017-10-31 12:57:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:15 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:15 --> URI Class Initialized
INFO - 2017-10-31 12:57:15 --> Router Class Initialized
INFO - 2017-10-31 12:57:15 --> Output Class Initialized
INFO - 2017-10-31 12:57:15 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:15 --> Input Class Initialized
INFO - 2017-10-31 12:57:15 --> Language Class Initialized
INFO - 2017-10-31 12:57:15 --> Loader Class Initialized
INFO - 2017-10-31 12:57:15 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:15 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:15 --> Email Class Initialized
INFO - 2017-10-31 12:57:15 --> Model Class Initialized
INFO - 2017-10-31 12:57:15 --> Controller Class Initialized
INFO - 2017-10-31 12:57:15 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:15 --> Total execution time: 0.0017
INFO - 2017-10-31 12:57:15 --> Config Class Initialized
INFO - 2017-10-31 12:57:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:15 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:15 --> URI Class Initialized
INFO - 2017-10-31 12:57:15 --> Router Class Initialized
INFO - 2017-10-31 12:57:15 --> Output Class Initialized
INFO - 2017-10-31 12:57:15 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:15 --> Input Class Initialized
INFO - 2017-10-31 12:57:15 --> Language Class Initialized
INFO - 2017-10-31 12:57:15 --> Loader Class Initialized
INFO - 2017-10-31 12:57:15 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:15 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:15 --> Email Class Initialized
INFO - 2017-10-31 12:57:15 --> Model Class Initialized
INFO - 2017-10-31 12:57:15 --> Controller Class Initialized
INFO - 2017-10-31 12:57:15 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:15 --> Total execution time: 0.0026
INFO - 2017-10-31 12:57:16 --> Config Class Initialized
INFO - 2017-10-31 12:57:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:16 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:16 --> URI Class Initialized
INFO - 2017-10-31 12:57:16 --> Router Class Initialized
INFO - 2017-10-31 12:57:16 --> Output Class Initialized
INFO - 2017-10-31 12:57:16 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:16 --> Input Class Initialized
INFO - 2017-10-31 12:57:16 --> Language Class Initialized
INFO - 2017-10-31 12:57:16 --> Loader Class Initialized
INFO - 2017-10-31 12:57:16 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:16 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:16 --> Email Class Initialized
INFO - 2017-10-31 12:57:16 --> Model Class Initialized
INFO - 2017-10-31 12:57:16 --> Controller Class Initialized
INFO - 2017-10-31 12:57:16 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:16 --> Total execution time: 0.0018
INFO - 2017-10-31 12:57:23 --> Config Class Initialized
INFO - 2017-10-31 12:57:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:23 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:23 --> URI Class Initialized
INFO - 2017-10-31 12:57:23 --> Router Class Initialized
INFO - 2017-10-31 12:57:23 --> Output Class Initialized
INFO - 2017-10-31 12:57:23 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:23 --> Input Class Initialized
INFO - 2017-10-31 12:57:23 --> Language Class Initialized
INFO - 2017-10-31 12:57:23 --> Loader Class Initialized
INFO - 2017-10-31 12:57:23 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:23 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:23 --> Email Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Controller Class Initialized
INFO - 2017-10-31 12:57:23 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:23 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:23 --> Total execution time: 0.0304
INFO - 2017-10-31 12:57:23 --> Config Class Initialized
INFO - 2017-10-31 12:57:23 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:23 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:23 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:23 --> URI Class Initialized
INFO - 2017-10-31 12:57:23 --> Router Class Initialized
INFO - 2017-10-31 12:57:23 --> Output Class Initialized
INFO - 2017-10-31 12:57:23 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:23 --> Input Class Initialized
INFO - 2017-10-31 12:57:23 --> Language Class Initialized
INFO - 2017-10-31 12:57:23 --> Loader Class Initialized
INFO - 2017-10-31 12:57:23 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:23 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:23 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:23 --> Email Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Controller Class Initialized
INFO - 2017-10-31 12:57:23 --> Model Class Initialized
INFO - 2017-10-31 12:57:23 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:23 --> Total execution time: 0.0025
INFO - 2017-10-31 12:57:24 --> Config Class Initialized
INFO - 2017-10-31 12:57:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:24 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:24 --> URI Class Initialized
INFO - 2017-10-31 12:57:24 --> Router Class Initialized
INFO - 2017-10-31 12:57:24 --> Output Class Initialized
INFO - 2017-10-31 12:57:24 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:24 --> Input Class Initialized
INFO - 2017-10-31 12:57:24 --> Language Class Initialized
INFO - 2017-10-31 12:57:24 --> Loader Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:24 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:24 --> Email Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Controller Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:24 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:24 --> Total execution time: 0.0290
INFO - 2017-10-31 12:57:24 --> Config Class Initialized
INFO - 2017-10-31 12:57:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:24 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:24 --> URI Class Initialized
INFO - 2017-10-31 12:57:24 --> Router Class Initialized
INFO - 2017-10-31 12:57:24 --> Output Class Initialized
INFO - 2017-10-31 12:57:24 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:24 --> Input Class Initialized
INFO - 2017-10-31 12:57:24 --> Language Class Initialized
INFO - 2017-10-31 12:57:24 --> Loader Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:24 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:24 --> Email Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Controller Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:24 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:24 --> Total execution time: 0.0325
INFO - 2017-10-31 12:57:24 --> Config Class Initialized
INFO - 2017-10-31 12:57:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:24 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:24 --> URI Class Initialized
INFO - 2017-10-31 12:57:24 --> Router Class Initialized
INFO - 2017-10-31 12:57:24 --> Output Class Initialized
INFO - 2017-10-31 12:57:24 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:24 --> Input Class Initialized
INFO - 2017-10-31 12:57:24 --> Language Class Initialized
INFO - 2017-10-31 12:57:24 --> Loader Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:24 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:24 --> Email Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Controller Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:24 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:24 --> Total execution time: 0.0299
INFO - 2017-10-31 12:57:24 --> Config Class Initialized
INFO - 2017-10-31 12:57:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:24 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:24 --> URI Class Initialized
INFO - 2017-10-31 12:57:24 --> Router Class Initialized
INFO - 2017-10-31 12:57:24 --> Output Class Initialized
INFO - 2017-10-31 12:57:24 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:24 --> Input Class Initialized
INFO - 2017-10-31 12:57:24 --> Language Class Initialized
INFO - 2017-10-31 12:57:24 --> Loader Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:24 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:24 --> Email Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Controller Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:24 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:24 --> Total execution time: 0.0214
INFO - 2017-10-31 12:57:24 --> Config Class Initialized
INFO - 2017-10-31 12:57:24 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:24 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:24 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:24 --> URI Class Initialized
INFO - 2017-10-31 12:57:24 --> Router Class Initialized
INFO - 2017-10-31 12:57:24 --> Output Class Initialized
INFO - 2017-10-31 12:57:24 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:24 --> Input Class Initialized
INFO - 2017-10-31 12:57:24 --> Language Class Initialized
INFO - 2017-10-31 12:57:24 --> Loader Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:24 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:24 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:24 --> Email Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Controller Class Initialized
INFO - 2017-10-31 12:57:24 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:24 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:25 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:25 --> Total execution time: 0.0248
INFO - 2017-10-31 12:57:25 --> Config Class Initialized
INFO - 2017-10-31 12:57:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:25 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:25 --> URI Class Initialized
INFO - 2017-10-31 12:57:25 --> Router Class Initialized
INFO - 2017-10-31 12:57:25 --> Output Class Initialized
INFO - 2017-10-31 12:57:25 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:25 --> Input Class Initialized
INFO - 2017-10-31 12:57:25 --> Language Class Initialized
INFO - 2017-10-31 12:57:25 --> Loader Class Initialized
INFO - 2017-10-31 12:57:25 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:25 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:25 --> Email Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Controller Class Initialized
INFO - 2017-10-31 12:57:25 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:25 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:25 --> Total execution time: 0.0251
INFO - 2017-10-31 12:57:25 --> Config Class Initialized
INFO - 2017-10-31 12:57:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:25 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:25 --> URI Class Initialized
INFO - 2017-10-31 12:57:25 --> Router Class Initialized
INFO - 2017-10-31 12:57:25 --> Output Class Initialized
INFO - 2017-10-31 12:57:25 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:25 --> Input Class Initialized
INFO - 2017-10-31 12:57:25 --> Language Class Initialized
INFO - 2017-10-31 12:57:25 --> Loader Class Initialized
INFO - 2017-10-31 12:57:25 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:25 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:25 --> Email Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Controller Class Initialized
INFO - 2017-10-31 12:57:25 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:57:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:57:25 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:25 --> Total execution time: 0.0315
INFO - 2017-10-31 12:57:25 --> Config Class Initialized
INFO - 2017-10-31 12:57:25 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:25 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:25 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:25 --> URI Class Initialized
INFO - 2017-10-31 12:57:25 --> Router Class Initialized
INFO - 2017-10-31 12:57:25 --> Output Class Initialized
INFO - 2017-10-31 12:57:25 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:25 --> Input Class Initialized
INFO - 2017-10-31 12:57:25 --> Language Class Initialized
INFO - 2017-10-31 12:57:25 --> Loader Class Initialized
INFO - 2017-10-31 12:57:25 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:25 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:25 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:25 --> Email Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Controller Class Initialized
INFO - 2017-10-31 12:57:25 --> Model Class Initialized
INFO - 2017-10-31 12:57:25 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:25 --> Total execution time: 0.0033
INFO - 2017-10-31 12:57:33 --> Config Class Initialized
INFO - 2017-10-31 12:57:33 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:33 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:33 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:33 --> URI Class Initialized
INFO - 2017-10-31 12:57:33 --> Router Class Initialized
INFO - 2017-10-31 12:57:33 --> Output Class Initialized
INFO - 2017-10-31 12:57:33 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:33 --> Input Class Initialized
INFO - 2017-10-31 12:57:33 --> Language Class Initialized
INFO - 2017-10-31 12:57:33 --> Loader Class Initialized
INFO - 2017-10-31 12:57:33 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:33 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:33 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:33 --> Email Class Initialized
INFO - 2017-10-31 12:57:33 --> Model Class Initialized
INFO - 2017-10-31 12:57:33 --> Controller Class Initialized
INFO - 2017-10-31 12:57:33 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:33 --> Total execution time: 0.0026
INFO - 2017-10-31 12:57:36 --> Config Class Initialized
INFO - 2017-10-31 12:57:36 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:36 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:36 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:36 --> URI Class Initialized
INFO - 2017-10-31 12:57:36 --> Router Class Initialized
INFO - 2017-10-31 12:57:36 --> Output Class Initialized
INFO - 2017-10-31 12:57:36 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:36 --> Input Class Initialized
INFO - 2017-10-31 12:57:36 --> Language Class Initialized
INFO - 2017-10-31 12:57:36 --> Loader Class Initialized
INFO - 2017-10-31 12:57:36 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:36 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:36 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:36 --> Email Class Initialized
INFO - 2017-10-31 12:57:36 --> Model Class Initialized
INFO - 2017-10-31 12:57:36 --> Controller Class Initialized
INFO - 2017-10-31 12:57:36 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:36 --> Total execution time: 0.0020
INFO - 2017-10-31 12:57:36 --> Config Class Initialized
INFO - 2017-10-31 12:57:36 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:36 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:36 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:36 --> URI Class Initialized
INFO - 2017-10-31 12:57:36 --> Router Class Initialized
INFO - 2017-10-31 12:57:36 --> Output Class Initialized
INFO - 2017-10-31 12:57:36 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:36 --> Input Class Initialized
INFO - 2017-10-31 12:57:36 --> Language Class Initialized
INFO - 2017-10-31 12:57:36 --> Loader Class Initialized
INFO - 2017-10-31 12:57:36 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:36 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:36 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:36 --> Email Class Initialized
INFO - 2017-10-31 12:57:36 --> Model Class Initialized
INFO - 2017-10-31 12:57:36 --> Controller Class Initialized
INFO - 2017-10-31 12:57:36 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:36 --> Total execution time: 0.0017
INFO - 2017-10-31 12:57:37 --> Config Class Initialized
INFO - 2017-10-31 12:57:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:37 --> URI Class Initialized
INFO - 2017-10-31 12:57:37 --> Router Class Initialized
INFO - 2017-10-31 12:57:37 --> Output Class Initialized
INFO - 2017-10-31 12:57:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:37 --> Input Class Initialized
INFO - 2017-10-31 12:57:37 --> Language Class Initialized
INFO - 2017-10-31 12:57:37 --> Loader Class Initialized
INFO - 2017-10-31 12:57:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:37 --> Email Class Initialized
INFO - 2017-10-31 12:57:37 --> Model Class Initialized
INFO - 2017-10-31 12:57:37 --> Controller Class Initialized
INFO - 2017-10-31 12:57:37 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:37 --> Total execution time: 0.0016
INFO - 2017-10-31 12:57:37 --> Config Class Initialized
INFO - 2017-10-31 12:57:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:57:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:57:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:57:37 --> URI Class Initialized
INFO - 2017-10-31 12:57:37 --> Router Class Initialized
INFO - 2017-10-31 12:57:37 --> Output Class Initialized
INFO - 2017-10-31 12:57:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:57:37 --> Input Class Initialized
INFO - 2017-10-31 12:57:37 --> Language Class Initialized
INFO - 2017-10-31 12:57:37 --> Loader Class Initialized
INFO - 2017-10-31 12:57:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:57:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:57:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:57:37 --> Email Class Initialized
INFO - 2017-10-31 12:57:37 --> Model Class Initialized
INFO - 2017-10-31 12:57:37 --> Controller Class Initialized
INFO - 2017-10-31 12:57:37 --> Final output sent to browser
DEBUG - 2017-10-31 12:57:37 --> Total execution time: 0.0015
INFO - 2017-10-31 12:58:29 --> Config Class Initialized
INFO - 2017-10-31 12:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:29 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:29 --> URI Class Initialized
INFO - 2017-10-31 12:58:29 --> Router Class Initialized
INFO - 2017-10-31 12:58:29 --> Output Class Initialized
INFO - 2017-10-31 12:58:29 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:29 --> Input Class Initialized
INFO - 2017-10-31 12:58:29 --> Language Class Initialized
INFO - 2017-10-31 12:58:29 --> Loader Class Initialized
INFO - 2017-10-31 12:58:29 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:29 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:29 --> Email Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Controller Class Initialized
INFO - 2017-10-31 12:58:29 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:58:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:58:29 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:29 --> Total execution time: 0.0235
INFO - 2017-10-31 12:58:29 --> Config Class Initialized
INFO - 2017-10-31 12:58:29 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:29 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:29 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:29 --> URI Class Initialized
INFO - 2017-10-31 12:58:29 --> Router Class Initialized
INFO - 2017-10-31 12:58:29 --> Output Class Initialized
INFO - 2017-10-31 12:58:29 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:29 --> Input Class Initialized
INFO - 2017-10-31 12:58:29 --> Language Class Initialized
INFO - 2017-10-31 12:58:29 --> Loader Class Initialized
INFO - 2017-10-31 12:58:29 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:29 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:29 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:29 --> Email Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Controller Class Initialized
INFO - 2017-10-31 12:58:29 --> Model Class Initialized
INFO - 2017-10-31 12:58:29 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:29 --> Total execution time: 0.0027
INFO - 2017-10-31 12:58:30 --> Config Class Initialized
INFO - 2017-10-31 12:58:30 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:30 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:30 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:30 --> URI Class Initialized
INFO - 2017-10-31 12:58:30 --> Router Class Initialized
INFO - 2017-10-31 12:58:30 --> Output Class Initialized
INFO - 2017-10-31 12:58:30 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:30 --> Input Class Initialized
INFO - 2017-10-31 12:58:30 --> Language Class Initialized
INFO - 2017-10-31 12:58:30 --> Loader Class Initialized
INFO - 2017-10-31 12:58:30 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:30 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:30 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:30 --> Email Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Controller Class Initialized
INFO - 2017-10-31 12:58:30 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> Model Class Initialized
INFO - 2017-10-31 12:58:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:58:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:58:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:58:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:58:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:58:30 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:30 --> Total execution time: 0.0289
INFO - 2017-10-31 12:58:31 --> Config Class Initialized
INFO - 2017-10-31 12:58:31 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:31 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:31 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:31 --> URI Class Initialized
INFO - 2017-10-31 12:58:31 --> Router Class Initialized
INFO - 2017-10-31 12:58:31 --> Output Class Initialized
INFO - 2017-10-31 12:58:31 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:31 --> Input Class Initialized
INFO - 2017-10-31 12:58:31 --> Language Class Initialized
INFO - 2017-10-31 12:58:31 --> Loader Class Initialized
INFO - 2017-10-31 12:58:31 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:31 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:31 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:31 --> Email Class Initialized
INFO - 2017-10-31 12:58:31 --> Model Class Initialized
INFO - 2017-10-31 12:58:31 --> Controller Class Initialized
INFO - 2017-10-31 12:58:31 --> Model Class Initialized
INFO - 2017-10-31 12:58:31 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:31 --> Total execution time: 0.0028
INFO - 2017-10-31 12:58:32 --> Config Class Initialized
INFO - 2017-10-31 12:58:32 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:32 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:32 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:32 --> URI Class Initialized
INFO - 2017-10-31 12:58:32 --> Router Class Initialized
INFO - 2017-10-31 12:58:32 --> Output Class Initialized
INFO - 2017-10-31 12:58:32 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:32 --> Input Class Initialized
INFO - 2017-10-31 12:58:32 --> Language Class Initialized
INFO - 2017-10-31 12:58:32 --> Loader Class Initialized
INFO - 2017-10-31 12:58:32 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:32 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:32 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:32 --> Email Class Initialized
INFO - 2017-10-31 12:58:32 --> Model Class Initialized
INFO - 2017-10-31 12:58:32 --> Controller Class Initialized
INFO - 2017-10-31 12:58:32 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:32 --> Total execution time: 0.0020
INFO - 2017-10-31 12:58:34 --> Config Class Initialized
INFO - 2017-10-31 12:58:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:34 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:34 --> URI Class Initialized
INFO - 2017-10-31 12:58:34 --> Router Class Initialized
INFO - 2017-10-31 12:58:34 --> Output Class Initialized
INFO - 2017-10-31 12:58:34 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:34 --> Input Class Initialized
INFO - 2017-10-31 12:58:34 --> Language Class Initialized
INFO - 2017-10-31 12:58:34 --> Loader Class Initialized
INFO - 2017-10-31 12:58:34 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:34 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:34 --> Email Class Initialized
INFO - 2017-10-31 12:58:34 --> Model Class Initialized
INFO - 2017-10-31 12:58:34 --> Controller Class Initialized
INFO - 2017-10-31 12:58:34 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:34 --> Total execution time: 0.0016
INFO - 2017-10-31 12:58:34 --> Config Class Initialized
INFO - 2017-10-31 12:58:34 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:34 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:34 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:34 --> URI Class Initialized
INFO - 2017-10-31 12:58:34 --> Router Class Initialized
INFO - 2017-10-31 12:58:34 --> Output Class Initialized
INFO - 2017-10-31 12:58:34 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:34 --> Input Class Initialized
INFO - 2017-10-31 12:58:34 --> Language Class Initialized
INFO - 2017-10-31 12:58:34 --> Loader Class Initialized
INFO - 2017-10-31 12:58:34 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:34 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:34 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:34 --> Email Class Initialized
INFO - 2017-10-31 12:58:34 --> Model Class Initialized
INFO - 2017-10-31 12:58:34 --> Controller Class Initialized
INFO - 2017-10-31 12:58:34 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:34 --> Total execution time: 0.0017
INFO - 2017-10-31 12:58:35 --> Config Class Initialized
INFO - 2017-10-31 12:58:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:35 --> URI Class Initialized
INFO - 2017-10-31 12:58:35 --> Router Class Initialized
INFO - 2017-10-31 12:58:35 --> Output Class Initialized
INFO - 2017-10-31 12:58:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:35 --> Input Class Initialized
INFO - 2017-10-31 12:58:35 --> Language Class Initialized
INFO - 2017-10-31 12:58:35 --> Loader Class Initialized
INFO - 2017-10-31 12:58:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:35 --> Email Class Initialized
INFO - 2017-10-31 12:58:35 --> Model Class Initialized
INFO - 2017-10-31 12:58:35 --> Controller Class Initialized
INFO - 2017-10-31 12:58:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:35 --> Total execution time: 0.0017
INFO - 2017-10-31 12:58:35 --> Config Class Initialized
INFO - 2017-10-31 12:58:35 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:58:35 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:58:35 --> Utf8 Class Initialized
INFO - 2017-10-31 12:58:35 --> URI Class Initialized
INFO - 2017-10-31 12:58:35 --> Router Class Initialized
INFO - 2017-10-31 12:58:35 --> Output Class Initialized
INFO - 2017-10-31 12:58:35 --> Security Class Initialized
DEBUG - 2017-10-31 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:58:35 --> Input Class Initialized
INFO - 2017-10-31 12:58:35 --> Language Class Initialized
INFO - 2017-10-31 12:58:35 --> Loader Class Initialized
INFO - 2017-10-31 12:58:35 --> Helper loaded: url_helper
INFO - 2017-10-31 12:58:35 --> Helper loaded: common_helper
INFO - 2017-10-31 12:58:35 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:58:35 --> Email Class Initialized
INFO - 2017-10-31 12:58:35 --> Model Class Initialized
INFO - 2017-10-31 12:58:35 --> Controller Class Initialized
INFO - 2017-10-31 12:58:35 --> Final output sent to browser
DEBUG - 2017-10-31 12:58:35 --> Total execution time: 0.0016
INFO - 2017-10-31 12:59:36 --> Config Class Initialized
INFO - 2017-10-31 12:59:36 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:36 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:36 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:36 --> URI Class Initialized
INFO - 2017-10-31 12:59:36 --> Router Class Initialized
INFO - 2017-10-31 12:59:36 --> Output Class Initialized
INFO - 2017-10-31 12:59:36 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:36 --> Input Class Initialized
INFO - 2017-10-31 12:59:36 --> Language Class Initialized
INFO - 2017-10-31 12:59:36 --> Loader Class Initialized
INFO - 2017-10-31 12:59:36 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:36 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:36 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:36 --> Email Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Controller Class Initialized
INFO - 2017-10-31 12:59:36 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> Model Class Initialized
INFO - 2017-10-31 12:59:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:36 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:36 --> Total execution time: 0.0250
INFO - 2017-10-31 12:59:37 --> Config Class Initialized
INFO - 2017-10-31 12:59:37 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:37 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:37 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:37 --> URI Class Initialized
INFO - 2017-10-31 12:59:37 --> Router Class Initialized
INFO - 2017-10-31 12:59:37 --> Output Class Initialized
INFO - 2017-10-31 12:59:37 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:37 --> Input Class Initialized
INFO - 2017-10-31 12:59:37 --> Language Class Initialized
INFO - 2017-10-31 12:59:37 --> Loader Class Initialized
INFO - 2017-10-31 12:59:37 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:37 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:37 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:37 --> Email Class Initialized
INFO - 2017-10-31 12:59:37 --> Model Class Initialized
INFO - 2017-10-31 12:59:37 --> Controller Class Initialized
INFO - 2017-10-31 12:59:37 --> Model Class Initialized
INFO - 2017-10-31 12:59:37 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:37 --> Total execution time: 0.0029
INFO - 2017-10-31 12:59:38 --> Config Class Initialized
INFO - 2017-10-31 12:59:38 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:38 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:38 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:38 --> URI Class Initialized
INFO - 2017-10-31 12:59:38 --> Router Class Initialized
INFO - 2017-10-31 12:59:38 --> Output Class Initialized
INFO - 2017-10-31 12:59:38 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:38 --> Input Class Initialized
INFO - 2017-10-31 12:59:38 --> Language Class Initialized
INFO - 2017-10-31 12:59:38 --> Loader Class Initialized
INFO - 2017-10-31 12:59:38 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:38 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:38 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:38 --> Email Class Initialized
INFO - 2017-10-31 12:59:38 --> Model Class Initialized
INFO - 2017-10-31 12:59:38 --> Controller Class Initialized
INFO - 2017-10-31 12:59:38 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:38 --> Total execution time: 0.0023
INFO - 2017-10-31 12:59:41 --> Config Class Initialized
INFO - 2017-10-31 12:59:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:41 --> URI Class Initialized
INFO - 2017-10-31 12:59:41 --> Router Class Initialized
INFO - 2017-10-31 12:59:41 --> Output Class Initialized
INFO - 2017-10-31 12:59:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:41 --> Input Class Initialized
INFO - 2017-10-31 12:59:41 --> Language Class Initialized
INFO - 2017-10-31 12:59:41 --> Loader Class Initialized
INFO - 2017-10-31 12:59:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:41 --> Email Class Initialized
INFO - 2017-10-31 12:59:41 --> Model Class Initialized
INFO - 2017-10-31 12:59:41 --> Controller Class Initialized
INFO - 2017-10-31 12:59:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:41 --> Total execution time: 0.0017
INFO - 2017-10-31 12:59:41 --> Config Class Initialized
INFO - 2017-10-31 12:59:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:41 --> URI Class Initialized
INFO - 2017-10-31 12:59:41 --> Router Class Initialized
INFO - 2017-10-31 12:59:41 --> Output Class Initialized
INFO - 2017-10-31 12:59:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:41 --> Input Class Initialized
INFO - 2017-10-31 12:59:41 --> Language Class Initialized
INFO - 2017-10-31 12:59:41 --> Loader Class Initialized
INFO - 2017-10-31 12:59:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:41 --> Email Class Initialized
INFO - 2017-10-31 12:59:41 --> Model Class Initialized
INFO - 2017-10-31 12:59:41 --> Controller Class Initialized
INFO - 2017-10-31 12:59:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:41 --> Total execution time: 0.0016
INFO - 2017-10-31 12:59:41 --> Config Class Initialized
INFO - 2017-10-31 12:59:41 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:41 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:41 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:41 --> URI Class Initialized
INFO - 2017-10-31 12:59:41 --> Router Class Initialized
INFO - 2017-10-31 12:59:41 --> Output Class Initialized
INFO - 2017-10-31 12:59:41 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:41 --> Input Class Initialized
INFO - 2017-10-31 12:59:41 --> Language Class Initialized
INFO - 2017-10-31 12:59:41 --> Loader Class Initialized
INFO - 2017-10-31 12:59:41 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:41 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:41 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:41 --> Email Class Initialized
INFO - 2017-10-31 12:59:41 --> Model Class Initialized
INFO - 2017-10-31 12:59:41 --> Controller Class Initialized
INFO - 2017-10-31 12:59:41 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:41 --> Total execution time: 0.0015
INFO - 2017-10-31 12:59:42 --> Config Class Initialized
INFO - 2017-10-31 12:59:42 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:42 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:42 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:42 --> URI Class Initialized
INFO - 2017-10-31 12:59:42 --> Router Class Initialized
INFO - 2017-10-31 12:59:42 --> Output Class Initialized
INFO - 2017-10-31 12:59:42 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:42 --> Input Class Initialized
INFO - 2017-10-31 12:59:42 --> Language Class Initialized
INFO - 2017-10-31 12:59:42 --> Loader Class Initialized
INFO - 2017-10-31 12:59:42 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:42 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:42 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:42 --> Email Class Initialized
INFO - 2017-10-31 12:59:42 --> Model Class Initialized
INFO - 2017-10-31 12:59:42 --> Controller Class Initialized
INFO - 2017-10-31 12:59:42 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:42 --> Total execution time: 0.0017
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:51 --> Email Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Controller Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:51 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:51 --> Total execution time: 0.0234
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:51 --> Email Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Controller Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:51 --> Total execution time: 0.0028
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:51 --> Email Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Controller Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:51 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:51 --> Total execution time: 0.0331
INFO - 2017-10-31 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:51 --> Email Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Controller Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:51 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:51 --> Total execution time: 0.0447
INFO - 2017-10-31 12:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:51 --> Email Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Controller Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Config Class Initialized
INFO - 2017-10-31 12:59:51 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:51 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:51 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:51 --> URI Class Initialized
INFO - 2017-10-31 12:59:51 --> Router Class Initialized
INFO - 2017-10-31 12:59:51 --> Output Class Initialized
INFO - 2017-10-31 12:59:51 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:51 --> Input Class Initialized
INFO - 2017-10-31 12:59:51 --> Language Class Initialized
INFO - 2017-10-31 12:59:51 --> Loader Class Initialized
INFO - 2017-10-31 12:59:51 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:51 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:51 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:51 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0414
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0493
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0350
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0317
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0422
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0473
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0386
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0521
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0574
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0549
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: cookie_helper
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 12:59:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0429
INFO - 2017-10-31 12:59:52 --> Config Class Initialized
INFO - 2017-10-31 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:52 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:52 --> URI Class Initialized
INFO - 2017-10-31 12:59:52 --> Router Class Initialized
INFO - 2017-10-31 12:59:52 --> Output Class Initialized
INFO - 2017-10-31 12:59:52 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:52 --> Input Class Initialized
INFO - 2017-10-31 12:59:52 --> Language Class Initialized
INFO - 2017-10-31 12:59:52 --> Loader Class Initialized
INFO - 2017-10-31 12:59:52 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:52 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:52 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:52 --> Email Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Controller Class Initialized
INFO - 2017-10-31 12:59:52 --> Model Class Initialized
INFO - 2017-10-31 12:59:52 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:52 --> Total execution time: 0.0031
INFO - 2017-10-31 12:59:54 --> Config Class Initialized
INFO - 2017-10-31 12:59:54 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:54 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:54 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:54 --> URI Class Initialized
INFO - 2017-10-31 12:59:54 --> Router Class Initialized
INFO - 2017-10-31 12:59:54 --> Output Class Initialized
INFO - 2017-10-31 12:59:54 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:54 --> Input Class Initialized
INFO - 2017-10-31 12:59:54 --> Language Class Initialized
INFO - 2017-10-31 12:59:54 --> Loader Class Initialized
INFO - 2017-10-31 12:59:54 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:54 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:54 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:54 --> Email Class Initialized
INFO - 2017-10-31 12:59:54 --> Model Class Initialized
INFO - 2017-10-31 12:59:54 --> Controller Class Initialized
INFO - 2017-10-31 12:59:54 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:54 --> Total execution time: 0.0038
INFO - 2017-10-31 12:59:56 --> Config Class Initialized
INFO - 2017-10-31 12:59:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:56 --> URI Class Initialized
INFO - 2017-10-31 12:59:56 --> Router Class Initialized
INFO - 2017-10-31 12:59:56 --> Output Class Initialized
INFO - 2017-10-31 12:59:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:56 --> Input Class Initialized
INFO - 2017-10-31 12:59:56 --> Language Class Initialized
INFO - 2017-10-31 12:59:56 --> Loader Class Initialized
INFO - 2017-10-31 12:59:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:56 --> Email Class Initialized
INFO - 2017-10-31 12:59:56 --> Model Class Initialized
INFO - 2017-10-31 12:59:56 --> Controller Class Initialized
INFO - 2017-10-31 12:59:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:56 --> Total execution time: 0.0015
INFO - 2017-10-31 12:59:56 --> Config Class Initialized
INFO - 2017-10-31 12:59:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:56 --> URI Class Initialized
INFO - 2017-10-31 12:59:56 --> Router Class Initialized
INFO - 2017-10-31 12:59:56 --> Output Class Initialized
INFO - 2017-10-31 12:59:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:56 --> Input Class Initialized
INFO - 2017-10-31 12:59:56 --> Language Class Initialized
INFO - 2017-10-31 12:59:56 --> Loader Class Initialized
INFO - 2017-10-31 12:59:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:56 --> Email Class Initialized
INFO - 2017-10-31 12:59:56 --> Model Class Initialized
INFO - 2017-10-31 12:59:56 --> Controller Class Initialized
INFO - 2017-10-31 12:59:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:56 --> Total execution time: 0.0015
INFO - 2017-10-31 12:59:56 --> Config Class Initialized
INFO - 2017-10-31 12:59:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:56 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:56 --> URI Class Initialized
INFO - 2017-10-31 12:59:56 --> Router Class Initialized
INFO - 2017-10-31 12:59:56 --> Output Class Initialized
INFO - 2017-10-31 12:59:56 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:56 --> Input Class Initialized
INFO - 2017-10-31 12:59:56 --> Language Class Initialized
INFO - 2017-10-31 12:59:56 --> Loader Class Initialized
INFO - 2017-10-31 12:59:56 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:56 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:56 --> Email Class Initialized
INFO - 2017-10-31 12:59:56 --> Model Class Initialized
INFO - 2017-10-31 12:59:56 --> Controller Class Initialized
INFO - 2017-10-31 12:59:56 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:56 --> Total execution time: 0.0015
INFO - 2017-10-31 12:59:57 --> Config Class Initialized
INFO - 2017-10-31 12:59:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 12:59:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 12:59:57 --> Utf8 Class Initialized
INFO - 2017-10-31 12:59:57 --> URI Class Initialized
INFO - 2017-10-31 12:59:57 --> Router Class Initialized
INFO - 2017-10-31 12:59:57 --> Output Class Initialized
INFO - 2017-10-31 12:59:57 --> Security Class Initialized
DEBUG - 2017-10-31 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 12:59:57 --> Input Class Initialized
INFO - 2017-10-31 12:59:57 --> Language Class Initialized
INFO - 2017-10-31 12:59:57 --> Loader Class Initialized
INFO - 2017-10-31 12:59:57 --> Helper loaded: url_helper
INFO - 2017-10-31 12:59:57 --> Helper loaded: common_helper
INFO - 2017-10-31 12:59:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 12:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 12:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 12:59:57 --> Email Class Initialized
INFO - 2017-10-31 12:59:57 --> Model Class Initialized
INFO - 2017-10-31 12:59:57 --> Controller Class Initialized
INFO - 2017-10-31 12:59:57 --> Final output sent to browser
DEBUG - 2017-10-31 12:59:57 --> Total execution time: 0.0017
INFO - 2017-10-31 13:17:11 --> Config Class Initialized
INFO - 2017-10-31 13:17:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:11 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:11 --> URI Class Initialized
INFO - 2017-10-31 13:17:11 --> Router Class Initialized
INFO - 2017-10-31 13:17:11 --> Output Class Initialized
INFO - 2017-10-31 13:17:11 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:11 --> Input Class Initialized
INFO - 2017-10-31 13:17:11 --> Language Class Initialized
INFO - 2017-10-31 13:17:11 --> Loader Class Initialized
INFO - 2017-10-31 13:17:11 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:11 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:11 --> Email Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Controller Class Initialized
INFO - 2017-10-31 13:17:11 --> Helper loaded: cookie_helper
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 13:17:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 13:17:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 13:17:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 13:17:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 13:17:11 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:11 --> Total execution time: 0.0261
INFO - 2017-10-31 13:17:11 --> Config Class Initialized
INFO - 2017-10-31 13:17:11 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:11 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:11 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:11 --> URI Class Initialized
INFO - 2017-10-31 13:17:11 --> Router Class Initialized
INFO - 2017-10-31 13:17:11 --> Output Class Initialized
INFO - 2017-10-31 13:17:11 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:11 --> Input Class Initialized
INFO - 2017-10-31 13:17:11 --> Language Class Initialized
INFO - 2017-10-31 13:17:11 --> Loader Class Initialized
INFO - 2017-10-31 13:17:11 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:11 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:11 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:11 --> Email Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Controller Class Initialized
INFO - 2017-10-31 13:17:11 --> Model Class Initialized
INFO - 2017-10-31 13:17:11 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:11 --> Total execution time: 0.0030
INFO - 2017-10-31 13:17:13 --> Config Class Initialized
INFO - 2017-10-31 13:17:13 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:13 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:13 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:13 --> URI Class Initialized
INFO - 2017-10-31 13:17:13 --> Router Class Initialized
INFO - 2017-10-31 13:17:13 --> Output Class Initialized
INFO - 2017-10-31 13:17:13 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:13 --> Input Class Initialized
INFO - 2017-10-31 13:17:13 --> Language Class Initialized
INFO - 2017-10-31 13:17:13 --> Loader Class Initialized
INFO - 2017-10-31 13:17:13 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:13 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:13 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:13 --> Email Class Initialized
INFO - 2017-10-31 13:17:13 --> Model Class Initialized
INFO - 2017-10-31 13:17:13 --> Controller Class Initialized
INFO - 2017-10-31 13:17:13 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:13 --> Total execution time: 0.0018
INFO - 2017-10-31 13:17:15 --> Config Class Initialized
INFO - 2017-10-31 13:17:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:15 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:15 --> URI Class Initialized
INFO - 2017-10-31 13:17:15 --> Router Class Initialized
INFO - 2017-10-31 13:17:15 --> Output Class Initialized
INFO - 2017-10-31 13:17:15 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:15 --> Input Class Initialized
INFO - 2017-10-31 13:17:15 --> Language Class Initialized
INFO - 2017-10-31 13:17:15 --> Loader Class Initialized
INFO - 2017-10-31 13:17:15 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:15 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:15 --> Email Class Initialized
INFO - 2017-10-31 13:17:15 --> Model Class Initialized
INFO - 2017-10-31 13:17:15 --> Controller Class Initialized
INFO - 2017-10-31 13:17:15 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:15 --> Total execution time: 0.0022
INFO - 2017-10-31 13:17:16 --> Config Class Initialized
INFO - 2017-10-31 13:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:16 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:16 --> URI Class Initialized
INFO - 2017-10-31 13:17:16 --> Router Class Initialized
INFO - 2017-10-31 13:17:16 --> Output Class Initialized
INFO - 2017-10-31 13:17:16 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:16 --> Input Class Initialized
INFO - 2017-10-31 13:17:16 --> Language Class Initialized
INFO - 2017-10-31 13:17:16 --> Loader Class Initialized
INFO - 2017-10-31 13:17:16 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:16 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:16 --> Email Class Initialized
INFO - 2017-10-31 13:17:16 --> Model Class Initialized
INFO - 2017-10-31 13:17:16 --> Controller Class Initialized
INFO - 2017-10-31 13:17:16 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:16 --> Total execution time: 0.0017
INFO - 2017-10-31 13:17:16 --> Config Class Initialized
INFO - 2017-10-31 13:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:16 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:16 --> URI Class Initialized
INFO - 2017-10-31 13:17:16 --> Router Class Initialized
INFO - 2017-10-31 13:17:16 --> Output Class Initialized
INFO - 2017-10-31 13:17:16 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:16 --> Input Class Initialized
INFO - 2017-10-31 13:17:16 --> Language Class Initialized
INFO - 2017-10-31 13:17:16 --> Loader Class Initialized
INFO - 2017-10-31 13:17:16 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:16 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:16 --> Email Class Initialized
INFO - 2017-10-31 13:17:16 --> Model Class Initialized
INFO - 2017-10-31 13:17:16 --> Controller Class Initialized
INFO - 2017-10-31 13:17:16 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:16 --> Total execution time: 0.0019
INFO - 2017-10-31 13:17:16 --> Config Class Initialized
INFO - 2017-10-31 13:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:16 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:16 --> URI Class Initialized
INFO - 2017-10-31 13:17:16 --> Router Class Initialized
INFO - 2017-10-31 13:17:16 --> Output Class Initialized
INFO - 2017-10-31 13:17:16 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:16 --> Input Class Initialized
INFO - 2017-10-31 13:17:16 --> Language Class Initialized
INFO - 2017-10-31 13:17:16 --> Loader Class Initialized
INFO - 2017-10-31 13:17:16 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:16 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:16 --> Email Class Initialized
INFO - 2017-10-31 13:17:16 --> Model Class Initialized
INFO - 2017-10-31 13:17:16 --> Controller Class Initialized
INFO - 2017-10-31 13:17:16 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:16 --> Total execution time: 0.0022
INFO - 2017-10-31 13:17:56 --> Config Class Initialized
INFO - 2017-10-31 13:17:56 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:56 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:56 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:56 --> URI Class Initialized
INFO - 2017-10-31 13:17:56 --> Router Class Initialized
INFO - 2017-10-31 13:17:56 --> Output Class Initialized
INFO - 2017-10-31 13:17:56 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:56 --> Input Class Initialized
INFO - 2017-10-31 13:17:56 --> Language Class Initialized
INFO - 2017-10-31 13:17:56 --> Loader Class Initialized
INFO - 2017-10-31 13:17:56 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:56 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:56 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:56 --> Email Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Controller Class Initialized
INFO - 2017-10-31 13:17:56 --> Helper loaded: cookie_helper
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> Model Class Initialized
INFO - 2017-10-31 13:17:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-31 13:17:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-31 13:17:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-31 13:17:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-31 13:17:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-31 13:17:56 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:56 --> Total execution time: 0.0220
INFO - 2017-10-31 13:17:57 --> Config Class Initialized
INFO - 2017-10-31 13:17:57 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:57 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:57 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:57 --> URI Class Initialized
INFO - 2017-10-31 13:17:57 --> Router Class Initialized
INFO - 2017-10-31 13:17:57 --> Output Class Initialized
INFO - 2017-10-31 13:17:57 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:57 --> Input Class Initialized
INFO - 2017-10-31 13:17:57 --> Language Class Initialized
INFO - 2017-10-31 13:17:57 --> Loader Class Initialized
INFO - 2017-10-31 13:17:57 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:57 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:57 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:57 --> Email Class Initialized
INFO - 2017-10-31 13:17:57 --> Model Class Initialized
INFO - 2017-10-31 13:17:57 --> Controller Class Initialized
INFO - 2017-10-31 13:17:57 --> Model Class Initialized
INFO - 2017-10-31 13:17:57 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:57 --> Total execution time: 0.0031
INFO - 2017-10-31 13:17:58 --> Config Class Initialized
INFO - 2017-10-31 13:17:58 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:17:58 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:17:58 --> Utf8 Class Initialized
INFO - 2017-10-31 13:17:58 --> URI Class Initialized
INFO - 2017-10-31 13:17:58 --> Router Class Initialized
INFO - 2017-10-31 13:17:58 --> Output Class Initialized
INFO - 2017-10-31 13:17:58 --> Security Class Initialized
DEBUG - 2017-10-31 13:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:17:58 --> Input Class Initialized
INFO - 2017-10-31 13:17:58 --> Language Class Initialized
INFO - 2017-10-31 13:17:58 --> Loader Class Initialized
INFO - 2017-10-31 13:17:58 --> Helper loaded: url_helper
INFO - 2017-10-31 13:17:58 --> Helper loaded: common_helper
INFO - 2017-10-31 13:17:58 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:17:58 --> Email Class Initialized
INFO - 2017-10-31 13:17:58 --> Model Class Initialized
INFO - 2017-10-31 13:17:58 --> Controller Class Initialized
INFO - 2017-10-31 13:17:58 --> Final output sent to browser
DEBUG - 2017-10-31 13:17:58 --> Total execution time: 0.0016
INFO - 2017-10-31 13:18:06 --> Config Class Initialized
INFO - 2017-10-31 13:18:06 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:18:06 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:18:06 --> Utf8 Class Initialized
INFO - 2017-10-31 13:18:06 --> URI Class Initialized
INFO - 2017-10-31 13:18:06 --> Router Class Initialized
INFO - 2017-10-31 13:18:06 --> Output Class Initialized
INFO - 2017-10-31 13:18:06 --> Security Class Initialized
DEBUG - 2017-10-31 13:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:18:06 --> Input Class Initialized
INFO - 2017-10-31 13:18:06 --> Language Class Initialized
INFO - 2017-10-31 13:18:06 --> Loader Class Initialized
INFO - 2017-10-31 13:18:06 --> Helper loaded: url_helper
INFO - 2017-10-31 13:18:06 --> Helper loaded: common_helper
INFO - 2017-10-31 13:18:06 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:18:06 --> Email Class Initialized
INFO - 2017-10-31 13:18:06 --> Model Class Initialized
INFO - 2017-10-31 13:18:06 --> Controller Class Initialized
INFO - 2017-10-31 13:18:06 --> Final output sent to browser
DEBUG - 2017-10-31 13:18:06 --> Total execution time: 0.0018
INFO - 2017-10-31 13:18:07 --> Config Class Initialized
INFO - 2017-10-31 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 13:18:07 --> URI Class Initialized
INFO - 2017-10-31 13:18:07 --> Router Class Initialized
INFO - 2017-10-31 13:18:07 --> Output Class Initialized
INFO - 2017-10-31 13:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:18:07 --> Input Class Initialized
INFO - 2017-10-31 13:18:07 --> Language Class Initialized
INFO - 2017-10-31 13:18:07 --> Loader Class Initialized
INFO - 2017-10-31 13:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 13:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 13:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:18:07 --> Email Class Initialized
INFO - 2017-10-31 13:18:07 --> Model Class Initialized
INFO - 2017-10-31 13:18:07 --> Controller Class Initialized
INFO - 2017-10-31 13:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 13:18:07 --> Total execution time: 0.0016
INFO - 2017-10-31 13:18:07 --> Config Class Initialized
INFO - 2017-10-31 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 13:18:07 --> URI Class Initialized
INFO - 2017-10-31 13:18:07 --> Router Class Initialized
INFO - 2017-10-31 13:18:07 --> Output Class Initialized
INFO - 2017-10-31 13:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:18:07 --> Input Class Initialized
INFO - 2017-10-31 13:18:07 --> Language Class Initialized
INFO - 2017-10-31 13:18:07 --> Loader Class Initialized
INFO - 2017-10-31 13:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 13:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 13:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:18:07 --> Email Class Initialized
INFO - 2017-10-31 13:18:07 --> Model Class Initialized
INFO - 2017-10-31 13:18:07 --> Controller Class Initialized
INFO - 2017-10-31 13:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 13:18:07 --> Total execution time: 0.0015
INFO - 2017-10-31 13:18:07 --> Config Class Initialized
INFO - 2017-10-31 13:18:07 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:18:07 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:18:07 --> Utf8 Class Initialized
INFO - 2017-10-31 13:18:07 --> URI Class Initialized
INFO - 2017-10-31 13:18:07 --> Router Class Initialized
INFO - 2017-10-31 13:18:07 --> Output Class Initialized
INFO - 2017-10-31 13:18:07 --> Security Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:18:07 --> Input Class Initialized
INFO - 2017-10-31 13:18:07 --> Language Class Initialized
INFO - 2017-10-31 13:18:07 --> Loader Class Initialized
INFO - 2017-10-31 13:18:07 --> Helper loaded: url_helper
INFO - 2017-10-31 13:18:07 --> Helper loaded: common_helper
INFO - 2017-10-31 13:18:07 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:18:07 --> Email Class Initialized
INFO - 2017-10-31 13:18:07 --> Model Class Initialized
INFO - 2017-10-31 13:18:07 --> Controller Class Initialized
INFO - 2017-10-31 13:18:07 --> Final output sent to browser
DEBUG - 2017-10-31 13:18:07 --> Total execution time: 0.0016
INFO - 2017-10-31 13:18:15 --> Config Class Initialized
INFO - 2017-10-31 13:18:15 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:18:15 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:18:15 --> Utf8 Class Initialized
INFO - 2017-10-31 13:18:15 --> URI Class Initialized
INFO - 2017-10-31 13:18:15 --> Router Class Initialized
INFO - 2017-10-31 13:18:15 --> Output Class Initialized
INFO - 2017-10-31 13:18:15 --> Security Class Initialized
DEBUG - 2017-10-31 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:18:15 --> Input Class Initialized
INFO - 2017-10-31 13:18:15 --> Language Class Initialized
INFO - 2017-10-31 13:18:15 --> Loader Class Initialized
INFO - 2017-10-31 13:18:15 --> Helper loaded: url_helper
INFO - 2017-10-31 13:18:15 --> Helper loaded: common_helper
INFO - 2017-10-31 13:18:15 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:18:15 --> Email Class Initialized
INFO - 2017-10-31 13:18:15 --> Model Class Initialized
INFO - 2017-10-31 13:18:15 --> Controller Class Initialized
INFO - 2017-10-31 13:18:15 --> Final output sent to browser
DEBUG - 2017-10-31 13:18:15 --> Total execution time: 0.0033
INFO - 2017-10-31 13:21:02 --> Config Class Initialized
INFO - 2017-10-31 13:21:02 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:21:02 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:21:02 --> Utf8 Class Initialized
INFO - 2017-10-31 13:21:02 --> URI Class Initialized
INFO - 2017-10-31 13:21:02 --> Router Class Initialized
INFO - 2017-10-31 13:21:02 --> Output Class Initialized
INFO - 2017-10-31 13:21:02 --> Security Class Initialized
DEBUG - 2017-10-31 13:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:21:02 --> Input Class Initialized
INFO - 2017-10-31 13:21:02 --> Language Class Initialized
INFO - 2017-10-31 13:21:02 --> Loader Class Initialized
INFO - 2017-10-31 13:21:02 --> Helper loaded: url_helper
INFO - 2017-10-31 13:21:02 --> Helper loaded: common_helper
INFO - 2017-10-31 13:21:02 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:21:02 --> Email Class Initialized
INFO - 2017-10-31 13:21:02 --> Model Class Initialized
INFO - 2017-10-31 13:21:02 --> Controller Class Initialized
INFO - 2017-10-31 13:21:02 --> Final output sent to browser
DEBUG - 2017-10-31 13:21:02 --> Total execution time: 0.0023
INFO - 2017-10-31 13:21:04 --> Config Class Initialized
INFO - 2017-10-31 13:21:04 --> Hooks Class Initialized
DEBUG - 2017-10-31 13:21:04 --> UTF-8 Support Enabled
INFO - 2017-10-31 13:21:04 --> Utf8 Class Initialized
INFO - 2017-10-31 13:21:04 --> URI Class Initialized
INFO - 2017-10-31 13:21:04 --> Router Class Initialized
INFO - 2017-10-31 13:21:04 --> Output Class Initialized
INFO - 2017-10-31 13:21:04 --> Security Class Initialized
DEBUG - 2017-10-31 13:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-31 13:21:04 --> Input Class Initialized
INFO - 2017-10-31 13:21:04 --> Language Class Initialized
INFO - 2017-10-31 13:21:04 --> Loader Class Initialized
INFO - 2017-10-31 13:21:04 --> Helper loaded: url_helper
INFO - 2017-10-31 13:21:04 --> Helper loaded: common_helper
INFO - 2017-10-31 13:21:04 --> Database Driver Class Initialized
DEBUG - 2017-10-31 13:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-31 13:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-31 13:21:04 --> Email Class Initialized
INFO - 2017-10-31 13:21:04 --> Model Class Initialized
INFO - 2017-10-31 13:21:04 --> Controller Class Initialized
INFO - 2017-10-31 13:21:04 --> Final output sent to browser
DEBUG - 2017-10-31 13:21:04 --> Total execution time: 0.0023
