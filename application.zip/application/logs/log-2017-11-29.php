<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-29 09:41:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-11-29 09:42:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-11-29 09:43:44 --> 404 Page Not Found: Assets/uploads
ERROR - 2017-11-29 09:45:02 --> 404 Page Not Found: Assets/uploads
