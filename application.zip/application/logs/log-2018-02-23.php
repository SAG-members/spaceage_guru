<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-23 11:04:12 --> 404 Page Not Found: Public/api_down_man
ERROR - 2018-02-23 11:04:22 --> 404 Page Not Found: Public/api
ERROR - 2018-02-23 11:04:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 2747
ERROR - 2018-02-23 11:04:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/Webservice_controller.php 2771
ERROR - 2018-02-23 18:45:27 --> 404 Page Not Found: Assets/uploads
