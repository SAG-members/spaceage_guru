<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-24 10:27:09 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 10:33:52 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 10:34:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 10:34:29 --> 404 Page Not Found: Ebusiness/index
ERROR - 2018-02-24 10:34:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 10:34:42 --> 404 Page Not Found: Ebusiness_controller/index
ERROR - 2018-02-24 10:45:26 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:45:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:45:42 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:45:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:45:49 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:45:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:46:10 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:46:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:47:58 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:47:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:48:35 --> Severity: Notice --> Undefined variable: profile /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 10:48:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/services/e-business.php 26
ERROR - 2018-02-24 11:06:06 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::results() /var/www/html/spaceage_guru/application/controllers/module/product/Ebusiness_controller.php 78
ERROR - 2018-02-24 11:23:23 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:23:45 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:23:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:44:08 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:44:16 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:44:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:45:11 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:45:39 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:46:10 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:46:50 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:47:23 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:47:37 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:47:47 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:48:07 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:49:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-24 11:52:36 --> Severity: error --> Exception: Undefined class constant 'id' /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 260
ERROR - 2018-02-24 11:53:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '50000 = ''
WHERE `id` = '29'' at line 1 - Invalid query: UPDATE `pct_wallet_amount` SET 50000 = ''
WHERE `id` = '29'
ERROR - 2018-02-24 11:59:05 --> Severity: Notice --> Undefined property: Payment::$pct_transaction /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 219
ERROR - 2018-02-24 11:59:05 --> Severity: error --> Exception: Call to a member function create_transaction() on null /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 219
ERROR - 2018-02-24 12:03:54 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT `id`, `event_id`, `comment_id`, `escrow_buyer_id`, `escrow_seller_id`, `status`
FROM `pct_transactions`, `user_library_event_escrow`
WHERE `from_user` = '29'
OR `to_user` = '29'
AND `comment_id` = '26'
ERROR - 2018-02-24 12:04:23 --> Severity: 4096 --> Object of class Ebusiness_controller could not be converted to string /var/www/html/spaceage_guru/application/controllers/module/product/Ebusiness_controller.php 86
ERROR - 2018-02-24 12:04:23 --> Severity: Notice --> Undefined variable:  /var/www/html/spaceage_guru/application/controllers/module/product/Ebusiness_controller.php 86
ERROR - 2018-02-24 12:04:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/controllers/module/product/Ebusiness_controller.php 86
ERROR - 2018-02-24 12:04:23 --> Severity: error --> Exception: Call to a member function title() on null /var/www/html/spaceage_guru/application/controllers/module/product/Ebusiness_controller.php 86
