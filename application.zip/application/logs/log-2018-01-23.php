<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-23 18:29:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
