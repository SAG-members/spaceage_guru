<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-19 10:06:01 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:07:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:08:15 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:15:41 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:15:57 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:16:23 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:16:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:17:02 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 10:27:02 --> 404 Page Not Found: Pay-via-pct-wallet/index
ERROR - 2018-02-19 10:27:17 --> 404 Page Not Found: Pay-via-pct-wallet/index
ERROR - 2018-02-19 10:34:49 --> 404 Page Not Found: Payment/payment
ERROR - 2018-02-19 10:59:23 --> Severity: Notice --> Undefined variable: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 14
ERROR - 2018-02-19 10:59:23 --> Severity: Notice --> Undefined variable: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:00:04 --> Severity: Notice --> Undefined variable: data /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 1
ERROR - 2018-02-19 11:00:04 --> Severity: Notice --> Undefined variable: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:00:04 --> Severity: Notice --> Undefined variable: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 16
ERROR - 2018-02-19 11:00:09 --> Severity: Notice --> Undefined variable: data /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 1
ERROR - 2018-02-19 11:00:09 --> Severity: Notice --> Undefined variable: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:00:09 --> Severity: Notice --> Undefined variable: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 16
ERROR - 2018-02-19 11:00:54 --> Severity: Notice --> Undefined variable: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:00:54 --> Severity: Notice --> Undefined variable: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 16
ERROR - 2018-02-19 11:01:22 --> Severity: Notice --> Undefined index: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:01:22 --> Severity: Notice --> Undefined index: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 16
ERROR - 2018-02-19 11:13:55 --> Severity: Notice --> Undefined index: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 14
ERROR - 2018-02-19 11:13:55 --> Severity: Notice --> Undefined index: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:13:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 25
ERROR - 2018-02-19 11:14:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 25
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 14
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 15
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: item_id /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 34
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: item_name /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 35
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: category_id /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 36
ERROR - 2018-02-19 11:19:30 --> Severity: Notice --> Undefined index: invoice_amount /var/www/html/spaceage_guru/application/views/templates/public/module/internal-pct-wallet.php 38
ERROR - 2018-02-19 11:46:31 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 11:49:03 --> Severity: error --> Exception: Call to undefined function mircrotime() /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 202
ERROR - 2018-02-19 12:19:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 12:19:47 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 12:23:37 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 12:23:53 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-02-19 19:25:18 --> 404 Page Not Found: Assets/uploads
