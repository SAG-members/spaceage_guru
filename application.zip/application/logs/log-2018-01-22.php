<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-22 10:37:06 --> Severity: Warning --> Missing argument 1 for CI_DB_driver::query(), called in /var/www/html/spaceage_guru/application/core/Base.php on line 40 and defined /var/www/html/spaceage_guru/system/database/DB_driver.php 608
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 610
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 617
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 647
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 654
ERROR - 2018-01-22 10:37:06 --> Severity: Warning --> mysqli::query(): Empty query /var/www/html/spaceage_guru/system/database/drivers/mysqli/mysqli_driver.php 306
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 671
ERROR - 2018-01-22 10:37:06 --> Query error:  - Invalid query: 
ERROR - 2018-01-22 10:37:06 --> Severity: Notice --> Undefined variable: sql /var/www/html/spaceage_guru/system/database/DB_driver.php 691
ERROR - 2018-01-22 10:37:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/spaceage_guru/system/core/Exceptions.php:272) /var/www/html/spaceage_guru/system/core/Common.php 573
ERROR - 2018-01-22 12:47:25 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:47:25 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:47:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:47:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:47:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:47:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:48:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 12:48:20 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:02:06 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:47:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:47:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:48:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:48:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:48:57 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:48:57 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:49:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:49:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:50:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 13:50:36 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 16:37:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 16:42:30 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 140
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 141
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 142
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 143
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 144
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 145
ERROR - 2018-01-22 19:38:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/models/admin/User.php 146
ERROR - 2018-01-22 19:38:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined variable: subscriptionType /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 209
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined variable: subscribedItem /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 210
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 211
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 190
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 190
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 211
ERROR - 2018-01-22 19:38:46 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 211
ERROR - 2018-01-22 19:38:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:38:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:38:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:41:33 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 191
ERROR - 2018-01-22 19:41:33 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 191
ERROR - 2018-01-22 19:41:33 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 191
ERROR - 2018-01-22 19:41:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:41:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:41:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:43:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:43:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:43:19 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:43:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:43:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:44:14 --> 404 Page Not Found: Assets/uploads
ERROR - 2018-01-22 19:44:14 --> 404 Page Not Found: Assets/uploads
