<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-21 19:37:15 --> Config Class Initialized
INFO - 2017-11-21 19:37:15 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:37:15 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:37:15 --> Utf8 Class Initialized
INFO - 2017-11-21 19:37:15 --> URI Class Initialized
DEBUG - 2017-11-21 19:37:15 --> No URI present. Default controller set.
INFO - 2017-11-21 19:37:15 --> Router Class Initialized
INFO - 2017-11-21 19:37:15 --> Output Class Initialized
INFO - 2017-11-21 19:37:15 --> Security Class Initialized
DEBUG - 2017-11-21 19:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:37:15 --> Input Class Initialized
INFO - 2017-11-21 19:37:15 --> Language Class Initialized
INFO - 2017-11-21 19:37:15 --> Loader Class Initialized
INFO - 2017-11-21 19:37:15 --> Helper loaded: url_helper
INFO - 2017-11-21 19:37:15 --> Helper loaded: common_helper
INFO - 2017-11-21 19:37:16 --> Database Driver Class Initialized
DEBUG - 2017-11-21 19:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-21 19:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-21 19:37:16 --> Email Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Controller Class Initialized
INFO - 2017-11-21 19:37:16 --> Helper loaded: cookie_helper
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> Model Class Initialized
INFO - 2017-11-21 19:37:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-21 19:37:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-21 19:37:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-11-21 19:37:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-21 19:37:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-21 19:37:16 --> Final output sent to browser
DEBUG - 2017-11-21 19:37:16 --> Total execution time: 0.7290
INFO - 2017-11-21 19:37:22 --> Config Class Initialized
INFO - 2017-11-21 19:37:22 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:37:22 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:37:22 --> Utf8 Class Initialized
INFO - 2017-11-21 19:37:22 --> URI Class Initialized
INFO - 2017-11-21 19:37:22 --> Router Class Initialized
INFO - 2017-11-21 19:37:22 --> Output Class Initialized
INFO - 2017-11-21 19:37:22 --> Security Class Initialized
DEBUG - 2017-11-21 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:37:22 --> Input Class Initialized
INFO - 2017-11-21 19:37:22 --> Language Class Initialized
INFO - 2017-11-21 19:37:22 --> Loader Class Initialized
INFO - 2017-11-21 19:37:22 --> Helper loaded: url_helper
INFO - 2017-11-21 19:37:22 --> Helper loaded: common_helper
INFO - 2017-11-21 19:37:22 --> Database Driver Class Initialized
DEBUG - 2017-11-21 19:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-21 19:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-21 19:37:22 --> Email Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Controller Class Initialized
INFO - 2017-11-21 19:37:22 --> Helper loaded: cookie_helper
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Config Class Initialized
INFO - 2017-11-21 19:37:22 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:37:22 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:37:22 --> Utf8 Class Initialized
INFO - 2017-11-21 19:37:22 --> URI Class Initialized
INFO - 2017-11-21 19:37:22 --> Router Class Initialized
INFO - 2017-11-21 19:37:22 --> Output Class Initialized
INFO - 2017-11-21 19:37:22 --> Security Class Initialized
DEBUG - 2017-11-21 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:37:22 --> Input Class Initialized
INFO - 2017-11-21 19:37:22 --> Language Class Initialized
INFO - 2017-11-21 19:37:22 --> Loader Class Initialized
INFO - 2017-11-21 19:37:22 --> Helper loaded: url_helper
INFO - 2017-11-21 19:37:22 --> Helper loaded: common_helper
INFO - 2017-11-21 19:37:22 --> Database Driver Class Initialized
DEBUG - 2017-11-21 19:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-21 19:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-21 19:37:22 --> Email Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Controller Class Initialized
INFO - 2017-11-21 19:37:22 --> Helper loaded: cookie_helper
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> Model Class Initialized
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-21 19:37:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-21 19:37:22 --> Final output sent to browser
DEBUG - 2017-11-21 19:37:22 --> Total execution time: 0.1106
INFO - 2017-11-21 19:37:22 --> Config Class Initialized
INFO - 2017-11-21 19:37:22 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:37:22 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:37:22 --> Utf8 Class Initialized
INFO - 2017-11-21 19:37:22 --> URI Class Initialized
INFO - 2017-11-21 19:37:22 --> Router Class Initialized
INFO - 2017-11-21 19:37:22 --> Output Class Initialized
INFO - 2017-11-21 19:37:22 --> Security Class Initialized
DEBUG - 2017-11-21 19:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:37:22 --> Input Class Initialized
INFO - 2017-11-21 19:37:22 --> Language Class Initialized
ERROR - 2017-11-21 19:37:22 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-21 19:40:21 --> Config Class Initialized
INFO - 2017-11-21 19:40:21 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:40:21 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:40:21 --> Utf8 Class Initialized
INFO - 2017-11-21 19:40:21 --> URI Class Initialized
INFO - 2017-11-21 19:40:21 --> Router Class Initialized
INFO - 2017-11-21 19:40:21 --> Output Class Initialized
INFO - 2017-11-21 19:40:21 --> Security Class Initialized
DEBUG - 2017-11-21 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:40:21 --> Input Class Initialized
INFO - 2017-11-21 19:40:21 --> Language Class Initialized
INFO - 2017-11-21 19:40:21 --> Loader Class Initialized
INFO - 2017-11-21 19:40:21 --> Helper loaded: url_helper
INFO - 2017-11-21 19:40:21 --> Helper loaded: common_helper
INFO - 2017-11-21 19:40:21 --> Database Driver Class Initialized
DEBUG - 2017-11-21 19:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-21 19:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-21 19:40:21 --> Email Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Controller Class Initialized
INFO - 2017-11-21 19:40:21 --> Helper loaded: cookie_helper
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> Model Class Initialized
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-21 19:40:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-21 19:40:21 --> Final output sent to browser
DEBUG - 2017-11-21 19:40:21 --> Total execution time: 0.0400
INFO - 2017-11-21 19:40:21 --> Config Class Initialized
INFO - 2017-11-21 19:40:21 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:40:21 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:40:21 --> Utf8 Class Initialized
INFO - 2017-11-21 19:40:21 --> URI Class Initialized
INFO - 2017-11-21 19:40:21 --> Router Class Initialized
INFO - 2017-11-21 19:40:21 --> Output Class Initialized
INFO - 2017-11-21 19:40:21 --> Security Class Initialized
DEBUG - 2017-11-21 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:40:21 --> Input Class Initialized
INFO - 2017-11-21 19:40:21 --> Language Class Initialized
ERROR - 2017-11-21 19:40:21 --> 404 Page Not Found: Assets/uploads
INFO - 2017-11-21 19:41:07 --> Config Class Initialized
INFO - 2017-11-21 19:41:07 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:41:07 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:41:07 --> Utf8 Class Initialized
INFO - 2017-11-21 19:41:07 --> URI Class Initialized
INFO - 2017-11-21 19:41:07 --> Router Class Initialized
INFO - 2017-11-21 19:41:07 --> Output Class Initialized
INFO - 2017-11-21 19:41:07 --> Security Class Initialized
DEBUG - 2017-11-21 19:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:41:07 --> Input Class Initialized
INFO - 2017-11-21 19:41:07 --> Language Class Initialized
INFO - 2017-11-21 19:41:07 --> Loader Class Initialized
INFO - 2017-11-21 19:41:07 --> Helper loaded: url_helper
INFO - 2017-11-21 19:41:07 --> Helper loaded: common_helper
INFO - 2017-11-21 19:41:07 --> Database Driver Class Initialized
DEBUG - 2017-11-21 19:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-21 19:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-21 19:41:07 --> Email Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Controller Class Initialized
INFO - 2017-11-21 19:41:07 --> Helper loaded: cookie_helper
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> Model Class Initialized
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-11-21 19:41:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-11-21 19:41:07 --> Final output sent to browser
DEBUG - 2017-11-21 19:41:07 --> Total execution time: 0.0356
INFO - 2017-11-21 19:41:07 --> Config Class Initialized
INFO - 2017-11-21 19:41:07 --> Hooks Class Initialized
DEBUG - 2017-11-21 19:41:07 --> UTF-8 Support Enabled
INFO - 2017-11-21 19:41:07 --> Utf8 Class Initialized
INFO - 2017-11-21 19:41:07 --> URI Class Initialized
INFO - 2017-11-21 19:41:07 --> Router Class Initialized
INFO - 2017-11-21 19:41:07 --> Output Class Initialized
INFO - 2017-11-21 19:41:07 --> Security Class Initialized
DEBUG - 2017-11-21 19:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-21 19:41:07 --> Input Class Initialized
INFO - 2017-11-21 19:41:07 --> Language Class Initialized
ERROR - 2017-11-21 19:41:07 --> 404 Page Not Found: Assets/uploads
