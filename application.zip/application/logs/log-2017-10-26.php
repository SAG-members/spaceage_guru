<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-10-26 10:11:08 --> Config Class Initialized
INFO - 2017-10-26 10:11:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:11:08 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:11:08 --> Utf8 Class Initialized
INFO - 2017-10-26 10:11:08 --> URI Class Initialized
DEBUG - 2017-10-26 10:11:08 --> No URI present. Default controller set.
INFO - 2017-10-26 10:11:08 --> Router Class Initialized
INFO - 2017-10-26 10:11:08 --> Output Class Initialized
INFO - 2017-10-26 10:11:08 --> Security Class Initialized
DEBUG - 2017-10-26 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:11:08 --> Input Class Initialized
INFO - 2017-10-26 10:11:08 --> Language Class Initialized
INFO - 2017-10-26 10:11:08 --> Loader Class Initialized
INFO - 2017-10-26 10:11:08 --> Helper loaded: url_helper
INFO - 2017-10-26 10:11:08 --> Helper loaded: common_helper
INFO - 2017-10-26 10:11:08 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:11:09 --> Email Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Controller Class Initialized
INFO - 2017-10-26 10:11:09 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> Model Class Initialized
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:11:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:11:09 --> Final output sent to browser
DEBUG - 2017-10-26 10:11:09 --> Total execution time: 0.9513
INFO - 2017-10-26 10:11:15 --> Config Class Initialized
INFO - 2017-10-26 10:11:15 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:11:15 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:11:15 --> Utf8 Class Initialized
INFO - 2017-10-26 10:11:15 --> URI Class Initialized
INFO - 2017-10-26 10:11:15 --> Router Class Initialized
INFO - 2017-10-26 10:11:15 --> Output Class Initialized
INFO - 2017-10-26 10:11:15 --> Security Class Initialized
DEBUG - 2017-10-26 10:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:11:15 --> Input Class Initialized
INFO - 2017-10-26 10:11:15 --> Language Class Initialized
INFO - 2017-10-26 10:11:15 --> Loader Class Initialized
INFO - 2017-10-26 10:11:15 --> Helper loaded: url_helper
INFO - 2017-10-26 10:11:15 --> Helper loaded: common_helper
INFO - 2017-10-26 10:11:15 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:11:15 --> Email Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Controller Class Initialized
INFO - 2017-10-26 10:11:15 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> Model Class Initialized
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:11:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:11:15 --> Final output sent to browser
DEBUG - 2017-10-26 10:11:15 --> Total execution time: 0.1661
INFO - 2017-10-26 10:11:18 --> Config Class Initialized
INFO - 2017-10-26 10:11:18 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:11:18 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:11:18 --> Utf8 Class Initialized
INFO - 2017-10-26 10:11:18 --> URI Class Initialized
INFO - 2017-10-26 10:11:18 --> Router Class Initialized
INFO - 2017-10-26 10:11:18 --> Output Class Initialized
INFO - 2017-10-26 10:11:18 --> Security Class Initialized
DEBUG - 2017-10-26 10:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:11:18 --> Input Class Initialized
INFO - 2017-10-26 10:11:18 --> Language Class Initialized
INFO - 2017-10-26 10:11:18 --> Loader Class Initialized
INFO - 2017-10-26 10:11:18 --> Helper loaded: url_helper
INFO - 2017-10-26 10:11:18 --> Helper loaded: common_helper
INFO - 2017-10-26 10:11:18 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:11:18 --> Email Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Controller Class Initialized
INFO - 2017-10-26 10:11:18 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> Model Class Initialized
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:11:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:11:18 --> Final output sent to browser
DEBUG - 2017-10-26 10:11:18 --> Total execution time: 0.1065
INFO - 2017-10-26 10:11:46 --> Config Class Initialized
INFO - 2017-10-26 10:11:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:11:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:11:46 --> Utf8 Class Initialized
INFO - 2017-10-26 10:11:46 --> URI Class Initialized
INFO - 2017-10-26 10:11:46 --> Router Class Initialized
INFO - 2017-10-26 10:11:46 --> Output Class Initialized
INFO - 2017-10-26 10:11:46 --> Security Class Initialized
DEBUG - 2017-10-26 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:11:46 --> Input Class Initialized
INFO - 2017-10-26 10:11:46 --> Language Class Initialized
INFO - 2017-10-26 10:11:46 --> Loader Class Initialized
INFO - 2017-10-26 10:11:46 --> Helper loaded: url_helper
INFO - 2017-10-26 10:11:46 --> Helper loaded: common_helper
INFO - 2017-10-26 10:11:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:11:46 --> Email Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Controller Class Initialized
INFO - 2017-10-26 10:11:46 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Model Class Initialized
INFO - 2017-10-26 10:11:46 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:11:46 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:11:46 --> Final output sent to browser
DEBUG - 2017-10-26 10:11:46 --> Total execution time: 0.0412
INFO - 2017-10-26 10:18:46 --> Config Class Initialized
INFO - 2017-10-26 10:18:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:18:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:18:46 --> Utf8 Class Initialized
INFO - 2017-10-26 10:18:46 --> URI Class Initialized
INFO - 2017-10-26 10:18:46 --> Router Class Initialized
INFO - 2017-10-26 10:18:46 --> Output Class Initialized
INFO - 2017-10-26 10:18:46 --> Security Class Initialized
DEBUG - 2017-10-26 10:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:18:46 --> Input Class Initialized
INFO - 2017-10-26 10:18:46 --> Language Class Initialized
INFO - 2017-10-26 10:18:46 --> Loader Class Initialized
INFO - 2017-10-26 10:18:46 --> Helper loaded: url_helper
INFO - 2017-10-26 10:18:46 --> Helper loaded: common_helper
INFO - 2017-10-26 10:18:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:18:46 --> Email Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Controller Class Initialized
INFO - 2017-10-26 10:18:46 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Model Class Initialized
INFO - 2017-10-26 10:18:46 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:18:46 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:18:46 --> Final output sent to browser
DEBUG - 2017-10-26 10:18:46 --> Total execution time: 0.0422
INFO - 2017-10-26 10:20:11 --> Config Class Initialized
INFO - 2017-10-26 10:20:11 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:11 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:11 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:11 --> URI Class Initialized
DEBUG - 2017-10-26 10:20:11 --> No URI present. Default controller set.
INFO - 2017-10-26 10:20:11 --> Router Class Initialized
INFO - 2017-10-26 10:20:11 --> Output Class Initialized
INFO - 2017-10-26 10:20:11 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:11 --> Input Class Initialized
INFO - 2017-10-26 10:20:11 --> Language Class Initialized
INFO - 2017-10-26 10:20:11 --> Loader Class Initialized
INFO - 2017-10-26 10:20:11 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:11 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:11 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:11 --> Email Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Controller Class Initialized
INFO - 2017-10-26 10:20:11 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> Model Class Initialized
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:20:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:20:11 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:11 --> Total execution time: 0.0233
INFO - 2017-10-26 10:20:13 --> Config Class Initialized
INFO - 2017-10-26 10:20:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:13 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:13 --> URI Class Initialized
INFO - 2017-10-26 10:20:13 --> Router Class Initialized
INFO - 2017-10-26 10:20:13 --> Output Class Initialized
INFO - 2017-10-26 10:20:13 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:13 --> Input Class Initialized
INFO - 2017-10-26 10:20:13 --> Language Class Initialized
INFO - 2017-10-26 10:20:13 --> Loader Class Initialized
INFO - 2017-10-26 10:20:13 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:13 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:13 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:13 --> Email Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Controller Class Initialized
INFO - 2017-10-26 10:20:13 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> Model Class Initialized
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:20:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:20:13 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:13 --> Total execution time: 0.0219
INFO - 2017-10-26 10:20:52 --> Config Class Initialized
INFO - 2017-10-26 10:20:52 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:52 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:52 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:52 --> URI Class Initialized
INFO - 2017-10-26 10:20:52 --> Router Class Initialized
INFO - 2017-10-26 10:20:52 --> Output Class Initialized
INFO - 2017-10-26 10:20:52 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:52 --> Input Class Initialized
INFO - 2017-10-26 10:20:52 --> Language Class Initialized
INFO - 2017-10-26 10:20:52 --> Loader Class Initialized
INFO - 2017-10-26 10:20:52 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:52 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:52 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:52 --> Email Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Controller Class Initialized
INFO - 2017-10-26 10:20:52 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> Model Class Initialized
INFO - 2017-10-26 10:20:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:20:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:20:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 10:20:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 10:20:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 10:20:52 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:52 --> Total execution time: 0.1668
INFO - 2017-10-26 10:20:53 --> Config Class Initialized
INFO - 2017-10-26 10:20:53 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:53 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:53 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:53 --> URI Class Initialized
INFO - 2017-10-26 10:20:53 --> Router Class Initialized
INFO - 2017-10-26 10:20:53 --> Output Class Initialized
INFO - 2017-10-26 10:20:53 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:53 --> Input Class Initialized
INFO - 2017-10-26 10:20:53 --> Language Class Initialized
INFO - 2017-10-26 10:20:53 --> Loader Class Initialized
INFO - 2017-10-26 10:20:53 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:53 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:53 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:53 --> Email Class Initialized
INFO - 2017-10-26 10:20:53 --> Model Class Initialized
INFO - 2017-10-26 10:20:53 --> Controller Class Initialized
INFO - 2017-10-26 10:20:53 --> Model Class Initialized
INFO - 2017-10-26 10:20:53 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:53 --> Total execution time: 0.0251
INFO - 2017-10-26 10:20:54 --> Config Class Initialized
INFO - 2017-10-26 10:20:54 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:54 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:54 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:54 --> URI Class Initialized
INFO - 2017-10-26 10:20:54 --> Router Class Initialized
INFO - 2017-10-26 10:20:54 --> Output Class Initialized
INFO - 2017-10-26 10:20:54 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:54 --> Input Class Initialized
INFO - 2017-10-26 10:20:54 --> Language Class Initialized
INFO - 2017-10-26 10:20:54 --> Loader Class Initialized
INFO - 2017-10-26 10:20:54 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:54 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:54 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:54 --> Email Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Controller Class Initialized
INFO - 2017-10-26 10:20:54 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> Model Class Initialized
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:20:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:20:54 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:54 --> Total execution time: 0.1251
INFO - 2017-10-26 10:20:55 --> Config Class Initialized
INFO - 2017-10-26 10:20:55 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:55 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:55 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:55 --> URI Class Initialized
INFO - 2017-10-26 10:20:55 --> Router Class Initialized
INFO - 2017-10-26 10:20:55 --> Output Class Initialized
INFO - 2017-10-26 10:20:55 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:55 --> Input Class Initialized
INFO - 2017-10-26 10:20:55 --> Language Class Initialized
INFO - 2017-10-26 10:20:55 --> Loader Class Initialized
INFO - 2017-10-26 10:20:55 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:55 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:55 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:55 --> Email Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Controller Class Initialized
INFO - 2017-10-26 10:20:55 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:20:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:20:55 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:55 --> Total execution time: 0.0644
INFO - 2017-10-26 10:20:55 --> Config Class Initialized
INFO - 2017-10-26 10:20:55 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:20:55 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:20:55 --> Utf8 Class Initialized
INFO - 2017-10-26 10:20:55 --> URI Class Initialized
INFO - 2017-10-26 10:20:55 --> Router Class Initialized
INFO - 2017-10-26 10:20:55 --> Output Class Initialized
INFO - 2017-10-26 10:20:55 --> Security Class Initialized
DEBUG - 2017-10-26 10:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:20:55 --> Input Class Initialized
INFO - 2017-10-26 10:20:55 --> Language Class Initialized
INFO - 2017-10-26 10:20:55 --> Loader Class Initialized
INFO - 2017-10-26 10:20:55 --> Helper loaded: url_helper
INFO - 2017-10-26 10:20:55 --> Helper loaded: common_helper
INFO - 2017-10-26 10:20:55 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:20:55 --> Email Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Controller Class Initialized
INFO - 2017-10-26 10:20:55 --> Model Class Initialized
INFO - 2017-10-26 10:20:55 --> Final output sent to browser
DEBUG - 2017-10-26 10:20:55 --> Total execution time: 0.0052
INFO - 2017-10-26 10:21:09 --> Config Class Initialized
INFO - 2017-10-26 10:21:09 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:09 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:09 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:09 --> URI Class Initialized
INFO - 2017-10-26 10:21:09 --> Router Class Initialized
INFO - 2017-10-26 10:21:09 --> Output Class Initialized
INFO - 2017-10-26 10:21:09 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:09 --> Input Class Initialized
INFO - 2017-10-26 10:21:09 --> Language Class Initialized
INFO - 2017-10-26 10:21:09 --> Loader Class Initialized
INFO - 2017-10-26 10:21:09 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:09 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:09 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:09 --> Email Class Initialized
INFO - 2017-10-26 10:21:09 --> Model Class Initialized
INFO - 2017-10-26 10:21:09 --> Controller Class Initialized
INFO - 2017-10-26 10:21:09 --> Model Class Initialized
INFO - 2017-10-26 10:21:09 --> Model Class Initialized
INFO - 2017-10-26 10:21:09 --> Model Class Initialized
INFO - 2017-10-26 10:21:09 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:09 --> Total execution time: 0.1347
INFO - 2017-10-26 10:21:11 --> Config Class Initialized
INFO - 2017-10-26 10:21:11 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:11 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:11 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:11 --> URI Class Initialized
INFO - 2017-10-26 10:21:11 --> Router Class Initialized
INFO - 2017-10-26 10:21:11 --> Output Class Initialized
INFO - 2017-10-26 10:21:11 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:11 --> Input Class Initialized
INFO - 2017-10-26 10:21:11 --> Language Class Initialized
INFO - 2017-10-26 10:21:11 --> Loader Class Initialized
INFO - 2017-10-26 10:21:11 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:11 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:11 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:11 --> Email Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Controller Class Initialized
INFO - 2017-10-26 10:21:11 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:11 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:11 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:11 --> Total execution time: 0.0679
INFO - 2017-10-26 10:21:11 --> Config Class Initialized
INFO - 2017-10-26 10:21:11 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:11 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:11 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:11 --> URI Class Initialized
INFO - 2017-10-26 10:21:11 --> Router Class Initialized
INFO - 2017-10-26 10:21:11 --> Output Class Initialized
INFO - 2017-10-26 10:21:11 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:11 --> Input Class Initialized
INFO - 2017-10-26 10:21:11 --> Language Class Initialized
INFO - 2017-10-26 10:21:11 --> Loader Class Initialized
INFO - 2017-10-26 10:21:11 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:11 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:11 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:11 --> Email Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Controller Class Initialized
INFO - 2017-10-26 10:21:11 --> Model Class Initialized
INFO - 2017-10-26 10:21:11 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:11 --> Total execution time: 0.0037
INFO - 2017-10-26 10:21:30 --> Config Class Initialized
INFO - 2017-10-26 10:21:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:30 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:30 --> URI Class Initialized
INFO - 2017-10-26 10:21:30 --> Router Class Initialized
INFO - 2017-10-26 10:21:30 --> Output Class Initialized
INFO - 2017-10-26 10:21:30 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:30 --> Input Class Initialized
INFO - 2017-10-26 10:21:30 --> Language Class Initialized
INFO - 2017-10-26 10:21:30 --> Loader Class Initialized
INFO - 2017-10-26 10:21:30 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:30 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:30 --> Email Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Controller Class Initialized
INFO - 2017-10-26 10:21:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> Model Class Initialized
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:30 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:30 --> Total execution time: 0.0620
INFO - 2017-10-26 10:21:34 --> Config Class Initialized
INFO - 2017-10-26 10:21:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:34 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:34 --> URI Class Initialized
INFO - 2017-10-26 10:21:34 --> Router Class Initialized
INFO - 2017-10-26 10:21:34 --> Output Class Initialized
INFO - 2017-10-26 10:21:34 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:34 --> Input Class Initialized
INFO - 2017-10-26 10:21:34 --> Language Class Initialized
INFO - 2017-10-26 10:21:34 --> Loader Class Initialized
INFO - 2017-10-26 10:21:34 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:34 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:34 --> Email Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Controller Class Initialized
INFO - 2017-10-26 10:21:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Config Class Initialized
INFO - 2017-10-26 10:21:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:34 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:34 --> URI Class Initialized
INFO - 2017-10-26 10:21:34 --> Router Class Initialized
INFO - 2017-10-26 10:21:34 --> Output Class Initialized
INFO - 2017-10-26 10:21:34 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:34 --> Input Class Initialized
INFO - 2017-10-26 10:21:34 --> Language Class Initialized
INFO - 2017-10-26 10:21:34 --> Loader Class Initialized
INFO - 2017-10-26 10:21:34 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:34 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:34 --> Email Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Controller Class Initialized
INFO - 2017-10-26 10:21:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> Model Class Initialized
INFO - 2017-10-26 10:21:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-26 10:21:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:34 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:34 --> Total execution time: 0.0952
INFO - 2017-10-26 10:21:39 --> Config Class Initialized
INFO - 2017-10-26 10:21:39 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:39 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:39 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:39 --> URI Class Initialized
INFO - 2017-10-26 10:21:39 --> Router Class Initialized
INFO - 2017-10-26 10:21:39 --> Output Class Initialized
INFO - 2017-10-26 10:21:39 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:39 --> Input Class Initialized
INFO - 2017-10-26 10:21:39 --> Language Class Initialized
INFO - 2017-10-26 10:21:39 --> Loader Class Initialized
INFO - 2017-10-26 10:21:39 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:39 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:39 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:39 --> Email Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Controller Class Initialized
INFO - 2017-10-26 10:21:39 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Model Class Initialized
INFO - 2017-10-26 10:21:39 --> Config Class Initialized
INFO - 2017-10-26 10:21:39 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:39 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:39 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:39 --> URI Class Initialized
INFO - 2017-10-26 10:21:39 --> Router Class Initialized
INFO - 2017-10-26 10:21:39 --> Output Class Initialized
INFO - 2017-10-26 10:21:39 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:39 --> Input Class Initialized
INFO - 2017-10-26 10:21:39 --> Language Class Initialized
INFO - 2017-10-26 10:21:40 --> Loader Class Initialized
INFO - 2017-10-26 10:21:40 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:40 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:40 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:40 --> Email Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Controller Class Initialized
INFO - 2017-10-26 10:21:40 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> Model Class Initialized
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:40 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:40 --> Total execution time: 0.3855
INFO - 2017-10-26 10:21:42 --> Config Class Initialized
INFO - 2017-10-26 10:21:42 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:42 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:42 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:42 --> URI Class Initialized
INFO - 2017-10-26 10:21:42 --> Router Class Initialized
INFO - 2017-10-26 10:21:42 --> Output Class Initialized
INFO - 2017-10-26 10:21:42 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:42 --> Input Class Initialized
INFO - 2017-10-26 10:21:42 --> Language Class Initialized
INFO - 2017-10-26 10:21:42 --> Loader Class Initialized
INFO - 2017-10-26 10:21:42 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:42 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:42 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:42 --> Email Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Controller Class Initialized
INFO - 2017-10-26 10:21:42 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:42 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> Model Class Initialized
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:43 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:43 --> Total execution time: 0.2303
INFO - 2017-10-26 10:21:47 --> Config Class Initialized
INFO - 2017-10-26 10:21:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:21:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:21:47 --> Utf8 Class Initialized
INFO - 2017-10-26 10:21:47 --> URI Class Initialized
INFO - 2017-10-26 10:21:47 --> Router Class Initialized
INFO - 2017-10-26 10:21:47 --> Output Class Initialized
INFO - 2017-10-26 10:21:47 --> Security Class Initialized
DEBUG - 2017-10-26 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:21:47 --> Input Class Initialized
INFO - 2017-10-26 10:21:47 --> Language Class Initialized
INFO - 2017-10-26 10:21:47 --> Loader Class Initialized
INFO - 2017-10-26 10:21:47 --> Helper loaded: url_helper
INFO - 2017-10-26 10:21:47 --> Helper loaded: common_helper
INFO - 2017-10-26 10:21:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:21:47 --> Email Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Controller Class Initialized
INFO - 2017-10-26 10:21:47 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:47 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> Model Class Initialized
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_create_view.php
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:21:48 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:21:48 --> Final output sent to browser
DEBUG - 2017-10-26 10:21:48 --> Total execution time: 0.2405
INFO - 2017-10-26 10:34:38 --> Config Class Initialized
INFO - 2017-10-26 10:34:38 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:34:38 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:34:38 --> Utf8 Class Initialized
INFO - 2017-10-26 10:34:38 --> URI Class Initialized
INFO - 2017-10-26 10:34:38 --> Router Class Initialized
INFO - 2017-10-26 10:34:38 --> Output Class Initialized
INFO - 2017-10-26 10:34:38 --> Security Class Initialized
DEBUG - 2017-10-26 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:34:38 --> Input Class Initialized
INFO - 2017-10-26 10:34:38 --> Language Class Initialized
INFO - 2017-10-26 10:34:38 --> Loader Class Initialized
INFO - 2017-10-26 10:34:38 --> Helper loaded: url_helper
INFO - 2017-10-26 10:34:38 --> Helper loaded: common_helper
INFO - 2017-10-26 10:34:38 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:34:38 --> Email Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Controller Class Initialized
INFO - 2017-10-26 10:34:38 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> Model Class Initialized
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:34:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:34:38 --> Final output sent to browser
DEBUG - 2017-10-26 10:34:38 --> Total execution time: 0.0217
INFO - 2017-10-26 10:34:39 --> Config Class Initialized
INFO - 2017-10-26 10:34:39 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:34:39 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:34:39 --> Utf8 Class Initialized
INFO - 2017-10-26 10:34:39 --> URI Class Initialized
INFO - 2017-10-26 10:34:39 --> Router Class Initialized
INFO - 2017-10-26 10:34:39 --> Output Class Initialized
INFO - 2017-10-26 10:34:39 --> Security Class Initialized
DEBUG - 2017-10-26 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:34:39 --> Input Class Initialized
INFO - 2017-10-26 10:34:39 --> Language Class Initialized
INFO - 2017-10-26 10:34:39 --> Loader Class Initialized
INFO - 2017-10-26 10:34:39 --> Helper loaded: url_helper
INFO - 2017-10-26 10:34:39 --> Helper loaded: common_helper
INFO - 2017-10-26 10:34:39 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:34:39 --> Email Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Controller Class Initialized
INFO - 2017-10-26 10:34:39 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> Model Class Initialized
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:34:39 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:34:39 --> Final output sent to browser
DEBUG - 2017-10-26 10:34:39 --> Total execution time: 0.0206
INFO - 2017-10-26 10:34:44 --> Config Class Initialized
INFO - 2017-10-26 10:34:44 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:34:44 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:34:44 --> Utf8 Class Initialized
INFO - 2017-10-26 10:34:44 --> URI Class Initialized
INFO - 2017-10-26 10:34:44 --> Router Class Initialized
INFO - 2017-10-26 10:34:44 --> Output Class Initialized
INFO - 2017-10-26 10:34:44 --> Security Class Initialized
DEBUG - 2017-10-26 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:34:44 --> Input Class Initialized
INFO - 2017-10-26 10:34:44 --> Language Class Initialized
INFO - 2017-10-26 10:34:44 --> Loader Class Initialized
INFO - 2017-10-26 10:34:44 --> Helper loaded: url_helper
INFO - 2017-10-26 10:34:44 --> Helper loaded: common_helper
INFO - 2017-10-26 10:34:44 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:34:44 --> Email Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Controller Class Initialized
INFO - 2017-10-26 10:34:44 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Model Class Initialized
INFO - 2017-10-26 10:34:44 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:34:44 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:34:44 --> Final output sent to browser
DEBUG - 2017-10-26 10:34:44 --> Total execution time: 0.0254
INFO - 2017-10-26 10:36:04 --> Config Class Initialized
INFO - 2017-10-26 10:36:04 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:36:04 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:36:04 --> Utf8 Class Initialized
INFO - 2017-10-26 10:36:04 --> URI Class Initialized
INFO - 2017-10-26 10:36:04 --> Router Class Initialized
INFO - 2017-10-26 10:36:04 --> Output Class Initialized
INFO - 2017-10-26 10:36:04 --> Security Class Initialized
DEBUG - 2017-10-26 10:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:36:04 --> Input Class Initialized
INFO - 2017-10-26 10:36:04 --> Language Class Initialized
INFO - 2017-10-26 10:36:04 --> Loader Class Initialized
INFO - 2017-10-26 10:36:04 --> Helper loaded: url_helper
INFO - 2017-10-26 10:36:04 --> Helper loaded: common_helper
INFO - 2017-10-26 10:36:04 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:36:04 --> Email Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Controller Class Initialized
INFO - 2017-10-26 10:36:04 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Model Class Initialized
INFO - 2017-10-26 10:36:04 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:36:04 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:36:04 --> Final output sent to browser
DEBUG - 2017-10-26 10:36:04 --> Total execution time: 0.0192
INFO - 2017-10-26 10:44:42 --> Config Class Initialized
INFO - 2017-10-26 10:44:42 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:44:42 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:44:42 --> Utf8 Class Initialized
INFO - 2017-10-26 10:44:42 --> URI Class Initialized
DEBUG - 2017-10-26 10:44:42 --> No URI present. Default controller set.
INFO - 2017-10-26 10:44:42 --> Router Class Initialized
INFO - 2017-10-26 10:44:42 --> Output Class Initialized
INFO - 2017-10-26 10:44:42 --> Security Class Initialized
DEBUG - 2017-10-26 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:44:42 --> Input Class Initialized
INFO - 2017-10-26 10:44:42 --> Language Class Initialized
INFO - 2017-10-26 10:44:42 --> Loader Class Initialized
INFO - 2017-10-26 10:44:42 --> Helper loaded: url_helper
INFO - 2017-10-26 10:44:42 --> Helper loaded: common_helper
INFO - 2017-10-26 10:44:42 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:44:42 --> Email Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Controller Class Initialized
INFO - 2017-10-26 10:44:42 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> Model Class Initialized
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:44:42 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:44:42 --> Final output sent to browser
DEBUG - 2017-10-26 10:44:42 --> Total execution time: 0.0286
INFO - 2017-10-26 10:44:44 --> Config Class Initialized
INFO - 2017-10-26 10:44:44 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:44:44 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:44:44 --> Utf8 Class Initialized
INFO - 2017-10-26 10:44:44 --> URI Class Initialized
INFO - 2017-10-26 10:44:44 --> Router Class Initialized
INFO - 2017-10-26 10:44:44 --> Output Class Initialized
INFO - 2017-10-26 10:44:44 --> Security Class Initialized
DEBUG - 2017-10-26 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:44:44 --> Input Class Initialized
INFO - 2017-10-26 10:44:44 --> Language Class Initialized
INFO - 2017-10-26 10:44:44 --> Loader Class Initialized
INFO - 2017-10-26 10:44:44 --> Helper loaded: url_helper
INFO - 2017-10-26 10:44:44 --> Helper loaded: common_helper
INFO - 2017-10-26 10:44:44 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:44:44 --> Email Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Controller Class Initialized
INFO - 2017-10-26 10:44:44 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> Model Class Initialized
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:44:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:44:44 --> Final output sent to browser
DEBUG - 2017-10-26 10:44:44 --> Total execution time: 0.0238
INFO - 2017-10-26 10:44:46 --> Config Class Initialized
INFO - 2017-10-26 10:44:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:44:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:44:46 --> Utf8 Class Initialized
INFO - 2017-10-26 10:44:46 --> URI Class Initialized
INFO - 2017-10-26 10:44:46 --> Router Class Initialized
INFO - 2017-10-26 10:44:46 --> Output Class Initialized
INFO - 2017-10-26 10:44:46 --> Security Class Initialized
DEBUG - 2017-10-26 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:44:46 --> Input Class Initialized
INFO - 2017-10-26 10:44:46 --> Language Class Initialized
INFO - 2017-10-26 10:44:46 --> Loader Class Initialized
INFO - 2017-10-26 10:44:46 --> Helper loaded: url_helper
INFO - 2017-10-26 10:44:46 --> Helper loaded: common_helper
INFO - 2017-10-26 10:44:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:44:46 --> Email Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Controller Class Initialized
INFO - 2017-10-26 10:44:46 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> Model Class Initialized
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:44:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:44:46 --> Final output sent to browser
DEBUG - 2017-10-26 10:44:46 --> Total execution time: 0.0208
INFO - 2017-10-26 10:44:49 --> Config Class Initialized
INFO - 2017-10-26 10:44:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:44:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:44:49 --> Utf8 Class Initialized
INFO - 2017-10-26 10:44:49 --> URI Class Initialized
INFO - 2017-10-26 10:44:49 --> Router Class Initialized
INFO - 2017-10-26 10:44:49 --> Output Class Initialized
INFO - 2017-10-26 10:44:49 --> Security Class Initialized
DEBUG - 2017-10-26 10:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:44:49 --> Input Class Initialized
INFO - 2017-10-26 10:44:49 --> Language Class Initialized
INFO - 2017-10-26 10:44:49 --> Loader Class Initialized
INFO - 2017-10-26 10:44:49 --> Helper loaded: url_helper
INFO - 2017-10-26 10:44:49 --> Helper loaded: common_helper
INFO - 2017-10-26 10:44:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:44:49 --> Email Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Controller Class Initialized
INFO - 2017-10-26 10:44:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Model Class Initialized
INFO - 2017-10-26 10:44:49 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:44:49 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:45:30 --> Config Class Initialized
INFO - 2017-10-26 10:45:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:30 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:30 --> URI Class Initialized
INFO - 2017-10-26 10:45:30 --> Router Class Initialized
INFO - 2017-10-26 10:45:30 --> Output Class Initialized
INFO - 2017-10-26 10:45:30 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:30 --> Input Class Initialized
INFO - 2017-10-26 10:45:30 --> Language Class Initialized
INFO - 2017-10-26 10:45:30 --> Loader Class Initialized
INFO - 2017-10-26 10:45:30 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:30 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:30 --> Email Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Controller Class Initialized
INFO - 2017-10-26 10:45:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Model Class Initialized
INFO - 2017-10-26 10:45:30 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:45:30 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
ERROR - 2017-10-26 10:45:30 --> Severity: Notice --> Undefined index: mode /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 21
INFO - 2017-10-26 10:45:30 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:30 --> Total execution time: 0.0403
INFO - 2017-10-26 10:45:34 --> Config Class Initialized
INFO - 2017-10-26 10:45:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:34 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:34 --> URI Class Initialized
INFO - 2017-10-26 10:45:34 --> Router Class Initialized
INFO - 2017-10-26 10:45:34 --> Output Class Initialized
INFO - 2017-10-26 10:45:34 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:34 --> Input Class Initialized
INFO - 2017-10-26 10:45:34 --> Language Class Initialized
INFO - 2017-10-26 10:45:34 --> Loader Class Initialized
INFO - 2017-10-26 10:45:34 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:34 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:34 --> Email Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Controller Class Initialized
INFO - 2017-10-26 10:45:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> Model Class Initialized
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:45:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:45:34 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:34 --> Total execution time: 0.0188
INFO - 2017-10-26 10:45:36 --> Config Class Initialized
INFO - 2017-10-26 10:45:36 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:36 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:36 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:36 --> URI Class Initialized
INFO - 2017-10-26 10:45:36 --> Router Class Initialized
INFO - 2017-10-26 10:45:36 --> Output Class Initialized
INFO - 2017-10-26 10:45:36 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:36 --> Input Class Initialized
INFO - 2017-10-26 10:45:36 --> Language Class Initialized
INFO - 2017-10-26 10:45:36 --> Loader Class Initialized
INFO - 2017-10-26 10:45:36 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:36 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:36 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:36 --> Email Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Controller Class Initialized
INFO - 2017-10-26 10:45:36 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> Model Class Initialized
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:45:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:45:36 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:36 --> Total execution time: 0.0199
INFO - 2017-10-26 10:45:42 --> Config Class Initialized
INFO - 2017-10-26 10:45:42 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:42 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:42 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:42 --> URI Class Initialized
INFO - 2017-10-26 10:45:42 --> Router Class Initialized
INFO - 2017-10-26 10:45:42 --> Output Class Initialized
INFO - 2017-10-26 10:45:42 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:42 --> Input Class Initialized
INFO - 2017-10-26 10:45:42 --> Language Class Initialized
INFO - 2017-10-26 10:45:42 --> Loader Class Initialized
INFO - 2017-10-26 10:45:42 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:42 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:42 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:42 --> Email Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Controller Class Initialized
INFO - 2017-10-26 10:45:42 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Model Class Initialized
INFO - 2017-10-26 10:45:42 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:45:42 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:45:42 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:42 --> Total execution time: 0.0187
INFO - 2017-10-26 10:45:52 --> Config Class Initialized
INFO - 2017-10-26 10:45:52 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:52 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:52 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:52 --> URI Class Initialized
INFO - 2017-10-26 10:45:52 --> Router Class Initialized
INFO - 2017-10-26 10:45:52 --> Output Class Initialized
INFO - 2017-10-26 10:45:52 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:52 --> Input Class Initialized
INFO - 2017-10-26 10:45:52 --> Language Class Initialized
INFO - 2017-10-26 10:45:52 --> Loader Class Initialized
INFO - 2017-10-26 10:45:52 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:52 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:52 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:52 --> Email Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Controller Class Initialized
INFO - 2017-10-26 10:45:52 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> Model Class Initialized
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:45:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:45:52 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:52 --> Total execution time: 0.0190
INFO - 2017-10-26 10:45:53 --> Config Class Initialized
INFO - 2017-10-26 10:45:53 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:53 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:53 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:53 --> URI Class Initialized
INFO - 2017-10-26 10:45:53 --> Router Class Initialized
INFO - 2017-10-26 10:45:53 --> Output Class Initialized
INFO - 2017-10-26 10:45:53 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:53 --> Input Class Initialized
INFO - 2017-10-26 10:45:53 --> Language Class Initialized
INFO - 2017-10-26 10:45:53 --> Loader Class Initialized
INFO - 2017-10-26 10:45:53 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:53 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:53 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:53 --> Email Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Controller Class Initialized
INFO - 2017-10-26 10:45:53 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> Model Class Initialized
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:45:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:45:53 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:53 --> Total execution time: 0.0205
INFO - 2017-10-26 10:45:57 --> Config Class Initialized
INFO - 2017-10-26 10:45:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:45:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:45:57 --> Utf8 Class Initialized
INFO - 2017-10-26 10:45:57 --> URI Class Initialized
INFO - 2017-10-26 10:45:57 --> Router Class Initialized
INFO - 2017-10-26 10:45:57 --> Output Class Initialized
INFO - 2017-10-26 10:45:57 --> Security Class Initialized
DEBUG - 2017-10-26 10:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:45:57 --> Input Class Initialized
INFO - 2017-10-26 10:45:57 --> Language Class Initialized
INFO - 2017-10-26 10:45:57 --> Loader Class Initialized
INFO - 2017-10-26 10:45:57 --> Helper loaded: url_helper
INFO - 2017-10-26 10:45:57 --> Helper loaded: common_helper
INFO - 2017-10-26 10:45:57 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:45:57 --> Email Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Controller Class Initialized
INFO - 2017-10-26 10:45:57 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Model Class Initialized
INFO - 2017-10-26 10:45:57 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:45:57 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:45:57 --> Final output sent to browser
DEBUG - 2017-10-26 10:45:57 --> Total execution time: 0.0186
INFO - 2017-10-26 10:46:01 --> Config Class Initialized
INFO - 2017-10-26 10:46:01 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:01 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:01 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:01 --> URI Class Initialized
INFO - 2017-10-26 10:46:01 --> Router Class Initialized
INFO - 2017-10-26 10:46:01 --> Output Class Initialized
INFO - 2017-10-26 10:46:01 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:01 --> Input Class Initialized
INFO - 2017-10-26 10:46:01 --> Language Class Initialized
INFO - 2017-10-26 10:46:01 --> Loader Class Initialized
INFO - 2017-10-26 10:46:01 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:01 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:01 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:01 --> Email Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Controller Class Initialized
INFO - 2017-10-26 10:46:01 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> Model Class Initialized
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:46:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:46:01 --> Final output sent to browser
DEBUG - 2017-10-26 10:46:01 --> Total execution time: 0.0178
INFO - 2017-10-26 10:46:02 --> Config Class Initialized
INFO - 2017-10-26 10:46:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:02 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:02 --> URI Class Initialized
INFO - 2017-10-26 10:46:02 --> Router Class Initialized
INFO - 2017-10-26 10:46:02 --> Output Class Initialized
INFO - 2017-10-26 10:46:02 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:02 --> Input Class Initialized
INFO - 2017-10-26 10:46:02 --> Language Class Initialized
INFO - 2017-10-26 10:46:02 --> Loader Class Initialized
INFO - 2017-10-26 10:46:02 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:02 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:02 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:02 --> Email Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Controller Class Initialized
INFO - 2017-10-26 10:46:02 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> Model Class Initialized
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:46:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:46:02 --> Final output sent to browser
DEBUG - 2017-10-26 10:46:02 --> Total execution time: 0.0205
INFO - 2017-10-26 10:46:03 --> Config Class Initialized
INFO - 2017-10-26 10:46:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:03 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:03 --> URI Class Initialized
INFO - 2017-10-26 10:46:03 --> Router Class Initialized
INFO - 2017-10-26 10:46:03 --> Output Class Initialized
INFO - 2017-10-26 10:46:03 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:03 --> Input Class Initialized
INFO - 2017-10-26 10:46:03 --> Language Class Initialized
INFO - 2017-10-26 10:46:03 --> Loader Class Initialized
INFO - 2017-10-26 10:46:03 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:03 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:03 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:03 --> Email Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Controller Class Initialized
INFO - 2017-10-26 10:46:03 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> Model Class Initialized
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:46:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:46:03 --> Final output sent to browser
DEBUG - 2017-10-26 10:46:03 --> Total execution time: 0.0210
INFO - 2017-10-26 10:46:07 --> Config Class Initialized
INFO - 2017-10-26 10:46:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:07 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:07 --> URI Class Initialized
INFO - 2017-10-26 10:46:07 --> Router Class Initialized
INFO - 2017-10-26 10:46:07 --> Output Class Initialized
INFO - 2017-10-26 10:46:07 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:07 --> Input Class Initialized
INFO - 2017-10-26 10:46:07 --> Language Class Initialized
INFO - 2017-10-26 10:46:07 --> Loader Class Initialized
INFO - 2017-10-26 10:46:07 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:07 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:07 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:07 --> Email Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Controller Class Initialized
INFO - 2017-10-26 10:46:07 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Model Class Initialized
INFO - 2017-10-26 10:46:07 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:46:07 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:46:07 --> Final output sent to browser
DEBUG - 2017-10-26 10:46:07 --> Total execution time: 0.0191
INFO - 2017-10-26 10:46:24 --> Config Class Initialized
INFO - 2017-10-26 10:46:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:24 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:24 --> URI Class Initialized
INFO - 2017-10-26 10:46:24 --> Router Class Initialized
INFO - 2017-10-26 10:46:24 --> Output Class Initialized
INFO - 2017-10-26 10:46:24 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:24 --> Input Class Initialized
INFO - 2017-10-26 10:46:24 --> Language Class Initialized
INFO - 2017-10-26 10:46:24 --> Loader Class Initialized
INFO - 2017-10-26 10:46:24 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:24 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:24 --> Email Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Controller Class Initialized
INFO - 2017-10-26 10:46:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> Model Class Initialized
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:46:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:46:24 --> Final output sent to browser
DEBUG - 2017-10-26 10:46:24 --> Total execution time: 0.0313
INFO - 2017-10-26 10:46:26 --> Config Class Initialized
INFO - 2017-10-26 10:46:26 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:46:26 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:46:26 --> Utf8 Class Initialized
INFO - 2017-10-26 10:46:26 --> URI Class Initialized
INFO - 2017-10-26 10:46:26 --> Router Class Initialized
INFO - 2017-10-26 10:46:26 --> Output Class Initialized
INFO - 2017-10-26 10:46:26 --> Security Class Initialized
DEBUG - 2017-10-26 10:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:46:26 --> Input Class Initialized
INFO - 2017-10-26 10:46:26 --> Language Class Initialized
INFO - 2017-10-26 10:46:26 --> Loader Class Initialized
INFO - 2017-10-26 10:46:26 --> Helper loaded: url_helper
INFO - 2017-10-26 10:46:26 --> Helper loaded: common_helper
INFO - 2017-10-26 10:46:26 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:46:26 --> Email Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Controller Class Initialized
INFO - 2017-10-26 10:46:26 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Model Class Initialized
INFO - 2017-10-26 10:46:26 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:46:26 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:47:05 --> Config Class Initialized
INFO - 2017-10-26 10:47:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:47:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:47:05 --> Utf8 Class Initialized
INFO - 2017-10-26 10:47:05 --> URI Class Initialized
INFO - 2017-10-26 10:47:05 --> Router Class Initialized
INFO - 2017-10-26 10:47:05 --> Output Class Initialized
INFO - 2017-10-26 10:47:05 --> Security Class Initialized
DEBUG - 2017-10-26 10:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:47:05 --> Input Class Initialized
INFO - 2017-10-26 10:47:05 --> Language Class Initialized
INFO - 2017-10-26 10:47:05 --> Loader Class Initialized
INFO - 2017-10-26 10:47:05 --> Helper loaded: url_helper
INFO - 2017-10-26 10:47:05 --> Helper loaded: common_helper
INFO - 2017-10-26 10:47:05 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:47:05 --> Email Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Controller Class Initialized
INFO - 2017-10-26 10:47:05 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> Model Class Initialized
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:47:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:47:05 --> Final output sent to browser
DEBUG - 2017-10-26 10:47:05 --> Total execution time: 0.0219
INFO - 2017-10-26 10:47:08 --> Config Class Initialized
INFO - 2017-10-26 10:47:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:47:08 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:47:08 --> Utf8 Class Initialized
INFO - 2017-10-26 10:47:08 --> URI Class Initialized
INFO - 2017-10-26 10:47:08 --> Router Class Initialized
INFO - 2017-10-26 10:47:08 --> Output Class Initialized
INFO - 2017-10-26 10:47:08 --> Security Class Initialized
DEBUG - 2017-10-26 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:47:08 --> Input Class Initialized
INFO - 2017-10-26 10:47:08 --> Language Class Initialized
INFO - 2017-10-26 10:47:08 --> Loader Class Initialized
INFO - 2017-10-26 10:47:08 --> Helper loaded: url_helper
INFO - 2017-10-26 10:47:08 --> Helper loaded: common_helper
INFO - 2017-10-26 10:47:08 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:47:08 --> Email Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Controller Class Initialized
INFO - 2017-10-26 10:47:08 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Model Class Initialized
INFO - 2017-10-26 10:47:08 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:47:08 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:48:15 --> Config Class Initialized
INFO - 2017-10-26 10:48:15 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:48:15 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:48:15 --> Utf8 Class Initialized
INFO - 2017-10-26 10:48:15 --> URI Class Initialized
INFO - 2017-10-26 10:48:15 --> Router Class Initialized
INFO - 2017-10-26 10:48:15 --> Output Class Initialized
INFO - 2017-10-26 10:48:15 --> Security Class Initialized
DEBUG - 2017-10-26 10:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:48:15 --> Input Class Initialized
INFO - 2017-10-26 10:48:15 --> Language Class Initialized
INFO - 2017-10-26 10:48:15 --> Loader Class Initialized
INFO - 2017-10-26 10:48:15 --> Helper loaded: url_helper
INFO - 2017-10-26 10:48:15 --> Helper loaded: common_helper
INFO - 2017-10-26 10:48:15 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:48:15 --> Email Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Controller Class Initialized
INFO - 2017-10-26 10:48:15 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> Model Class Initialized
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:48:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:48:15 --> Final output sent to browser
DEBUG - 2017-10-26 10:48:15 --> Total execution time: 0.0205
INFO - 2017-10-26 10:48:17 --> Config Class Initialized
INFO - 2017-10-26 10:48:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:48:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:48:17 --> Utf8 Class Initialized
INFO - 2017-10-26 10:48:17 --> URI Class Initialized
INFO - 2017-10-26 10:48:17 --> Router Class Initialized
INFO - 2017-10-26 10:48:17 --> Output Class Initialized
INFO - 2017-10-26 10:48:17 --> Security Class Initialized
DEBUG - 2017-10-26 10:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:48:17 --> Input Class Initialized
INFO - 2017-10-26 10:48:17 --> Language Class Initialized
INFO - 2017-10-26 10:48:17 --> Loader Class Initialized
INFO - 2017-10-26 10:48:17 --> Helper loaded: url_helper
INFO - 2017-10-26 10:48:17 --> Helper loaded: common_helper
INFO - 2017-10-26 10:48:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:48:17 --> Email Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Controller Class Initialized
INFO - 2017-10-26 10:48:17 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Model Class Initialized
INFO - 2017-10-26 10:48:17 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:48:17 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:48:17 --> Final output sent to browser
DEBUG - 2017-10-26 10:48:17 --> Total execution time: 0.0195
INFO - 2017-10-26 10:48:49 --> Config Class Initialized
INFO - 2017-10-26 10:48:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:48:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:48:49 --> Utf8 Class Initialized
INFO - 2017-10-26 10:48:49 --> URI Class Initialized
DEBUG - 2017-10-26 10:48:49 --> No URI present. Default controller set.
INFO - 2017-10-26 10:48:49 --> Router Class Initialized
INFO - 2017-10-26 10:48:49 --> Output Class Initialized
INFO - 2017-10-26 10:48:49 --> Security Class Initialized
DEBUG - 2017-10-26 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:48:49 --> Input Class Initialized
INFO - 2017-10-26 10:48:49 --> Language Class Initialized
INFO - 2017-10-26 10:48:49 --> Loader Class Initialized
INFO - 2017-10-26 10:48:49 --> Helper loaded: url_helper
INFO - 2017-10-26 10:48:49 --> Helper loaded: common_helper
INFO - 2017-10-26 10:48:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:48:49 --> Email Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Controller Class Initialized
INFO - 2017-10-26 10:48:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> Model Class Initialized
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:48:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:48:49 --> Final output sent to browser
DEBUG - 2017-10-26 10:48:49 --> Total execution time: 0.0174
INFO - 2017-10-26 10:48:51 --> Config Class Initialized
INFO - 2017-10-26 10:48:51 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:48:51 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:48:51 --> Utf8 Class Initialized
INFO - 2017-10-26 10:48:51 --> URI Class Initialized
INFO - 2017-10-26 10:48:51 --> Router Class Initialized
INFO - 2017-10-26 10:48:51 --> Output Class Initialized
INFO - 2017-10-26 10:48:51 --> Security Class Initialized
DEBUG - 2017-10-26 10:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:48:51 --> Input Class Initialized
INFO - 2017-10-26 10:48:51 --> Language Class Initialized
INFO - 2017-10-26 10:48:51 --> Loader Class Initialized
INFO - 2017-10-26 10:48:51 --> Helper loaded: url_helper
INFO - 2017-10-26 10:48:51 --> Helper loaded: common_helper
INFO - 2017-10-26 10:48:51 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:48:51 --> Email Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Controller Class Initialized
INFO - 2017-10-26 10:48:51 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> Model Class Initialized
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:48:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:48:51 --> Final output sent to browser
DEBUG - 2017-10-26 10:48:51 --> Total execution time: 0.0198
INFO - 2017-10-26 10:48:52 --> Config Class Initialized
INFO - 2017-10-26 10:48:52 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:48:52 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:48:52 --> Utf8 Class Initialized
INFO - 2017-10-26 10:48:52 --> URI Class Initialized
INFO - 2017-10-26 10:48:52 --> Router Class Initialized
INFO - 2017-10-26 10:48:52 --> Output Class Initialized
INFO - 2017-10-26 10:48:52 --> Security Class Initialized
DEBUG - 2017-10-26 10:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:48:52 --> Input Class Initialized
INFO - 2017-10-26 10:48:52 --> Language Class Initialized
INFO - 2017-10-26 10:48:52 --> Loader Class Initialized
INFO - 2017-10-26 10:48:52 --> Helper loaded: url_helper
INFO - 2017-10-26 10:48:52 --> Helper loaded: common_helper
INFO - 2017-10-26 10:48:52 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:48:52 --> Email Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Controller Class Initialized
INFO - 2017-10-26 10:48:52 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> Model Class Initialized
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:48:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:48:52 --> Final output sent to browser
DEBUG - 2017-10-26 10:48:52 --> Total execution time: 0.0208
INFO - 2017-10-26 10:52:12 --> Config Class Initialized
INFO - 2017-10-26 10:52:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:52:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:52:12 --> Utf8 Class Initialized
INFO - 2017-10-26 10:52:12 --> URI Class Initialized
INFO - 2017-10-26 10:52:12 --> Router Class Initialized
INFO - 2017-10-26 10:52:12 --> Output Class Initialized
INFO - 2017-10-26 10:52:12 --> Security Class Initialized
DEBUG - 2017-10-26 10:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:52:12 --> Input Class Initialized
INFO - 2017-10-26 10:52:12 --> Language Class Initialized
INFO - 2017-10-26 10:52:12 --> Loader Class Initialized
INFO - 2017-10-26 10:52:12 --> Helper loaded: url_helper
INFO - 2017-10-26 10:52:12 --> Helper loaded: common_helper
INFO - 2017-10-26 10:52:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:52:12 --> Email Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Controller Class Initialized
INFO - 2017-10-26 10:52:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Model Class Initialized
INFO - 2017-10-26 10:52:12 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:52:12 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:52:12 --> Final output sent to browser
DEBUG - 2017-10-26 10:52:12 --> Total execution time: 0.0207
INFO - 2017-10-26 10:52:52 --> Config Class Initialized
INFO - 2017-10-26 10:52:52 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:52:52 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:52:52 --> Utf8 Class Initialized
INFO - 2017-10-26 10:52:52 --> URI Class Initialized
INFO - 2017-10-26 10:52:52 --> Router Class Initialized
INFO - 2017-10-26 10:52:52 --> Output Class Initialized
INFO - 2017-10-26 10:52:52 --> Security Class Initialized
DEBUG - 2017-10-26 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:52:52 --> Input Class Initialized
INFO - 2017-10-26 10:52:52 --> Language Class Initialized
INFO - 2017-10-26 10:52:52 --> Loader Class Initialized
INFO - 2017-10-26 10:52:52 --> Helper loaded: url_helper
INFO - 2017-10-26 10:52:52 --> Helper loaded: common_helper
INFO - 2017-10-26 10:52:52 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:52:52 --> Email Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Controller Class Initialized
INFO - 2017-10-26 10:52:52 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Model Class Initialized
INFO - 2017-10-26 10:52:52 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:52:52 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:52:52 --> Final output sent to browser
DEBUG - 2017-10-26 10:52:52 --> Total execution time: 0.0299
INFO - 2017-10-26 10:56:50 --> Config Class Initialized
INFO - 2017-10-26 10:56:50 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:56:50 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:56:50 --> Utf8 Class Initialized
INFO - 2017-10-26 10:56:50 --> URI Class Initialized
DEBUG - 2017-10-26 10:56:50 --> No URI present. Default controller set.
INFO - 2017-10-26 10:56:50 --> Router Class Initialized
INFO - 2017-10-26 10:56:50 --> Output Class Initialized
INFO - 2017-10-26 10:56:50 --> Security Class Initialized
DEBUG - 2017-10-26 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:56:50 --> Input Class Initialized
INFO - 2017-10-26 10:56:50 --> Language Class Initialized
INFO - 2017-10-26 10:56:50 --> Loader Class Initialized
INFO - 2017-10-26 10:56:50 --> Helper loaded: url_helper
INFO - 2017-10-26 10:56:50 --> Helper loaded: common_helper
INFO - 2017-10-26 10:56:50 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:56:50 --> Email Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Controller Class Initialized
INFO - 2017-10-26 10:56:50 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> Model Class Initialized
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:56:50 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:56:50 --> Final output sent to browser
DEBUG - 2017-10-26 10:56:50 --> Total execution time: 0.0210
INFO - 2017-10-26 10:56:53 --> Config Class Initialized
INFO - 2017-10-26 10:56:53 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:56:53 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:56:53 --> Utf8 Class Initialized
INFO - 2017-10-26 10:56:53 --> URI Class Initialized
INFO - 2017-10-26 10:56:53 --> Router Class Initialized
INFO - 2017-10-26 10:56:53 --> Output Class Initialized
INFO - 2017-10-26 10:56:53 --> Security Class Initialized
DEBUG - 2017-10-26 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:56:53 --> Input Class Initialized
INFO - 2017-10-26 10:56:53 --> Language Class Initialized
INFO - 2017-10-26 10:56:53 --> Loader Class Initialized
INFO - 2017-10-26 10:56:53 --> Helper loaded: url_helper
INFO - 2017-10-26 10:56:53 --> Helper loaded: common_helper
INFO - 2017-10-26 10:56:53 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:56:53 --> Email Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Controller Class Initialized
INFO - 2017-10-26 10:56:53 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> Model Class Initialized
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:56:53 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:56:53 --> Final output sent to browser
DEBUG - 2017-10-26 10:56:53 --> Total execution time: 0.0199
INFO - 2017-10-26 10:56:58 --> Config Class Initialized
INFO - 2017-10-26 10:56:58 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:56:58 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:56:58 --> Utf8 Class Initialized
INFO - 2017-10-26 10:56:58 --> URI Class Initialized
INFO - 2017-10-26 10:56:58 --> Router Class Initialized
INFO - 2017-10-26 10:56:58 --> Output Class Initialized
INFO - 2017-10-26 10:56:58 --> Security Class Initialized
DEBUG - 2017-10-26 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:56:58 --> Input Class Initialized
INFO - 2017-10-26 10:56:58 --> Language Class Initialized
INFO - 2017-10-26 10:56:58 --> Loader Class Initialized
INFO - 2017-10-26 10:56:58 --> Helper loaded: url_helper
INFO - 2017-10-26 10:56:58 --> Helper loaded: common_helper
INFO - 2017-10-26 10:56:58 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:56:58 --> Email Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Controller Class Initialized
INFO - 2017-10-26 10:56:58 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> Model Class Initialized
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:56:58 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:56:58 --> Final output sent to browser
DEBUG - 2017-10-26 10:56:58 --> Total execution time: 0.0252
INFO - 2017-10-26 10:57:01 --> Config Class Initialized
INFO - 2017-10-26 10:57:01 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:57:01 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:57:01 --> Utf8 Class Initialized
INFO - 2017-10-26 10:57:01 --> URI Class Initialized
INFO - 2017-10-26 10:57:01 --> Router Class Initialized
INFO - 2017-10-26 10:57:01 --> Output Class Initialized
INFO - 2017-10-26 10:57:01 --> Security Class Initialized
DEBUG - 2017-10-26 10:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:57:01 --> Input Class Initialized
INFO - 2017-10-26 10:57:01 --> Language Class Initialized
INFO - 2017-10-26 10:57:01 --> Loader Class Initialized
INFO - 2017-10-26 10:57:01 --> Helper loaded: url_helper
INFO - 2017-10-26 10:57:01 --> Helper loaded: common_helper
INFO - 2017-10-26 10:57:01 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:57:01 --> Email Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Controller Class Initialized
INFO - 2017-10-26 10:57:01 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Model Class Initialized
INFO - 2017-10-26 10:57:01 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:57:01 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
ERROR - 2017-10-26 10:57:01 --> Severity: error --> Exception: Call to undefined method Payment::add_field() /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 67
INFO - 2017-10-26 10:57:27 --> Config Class Initialized
INFO - 2017-10-26 10:57:27 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:57:27 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:57:27 --> Utf8 Class Initialized
INFO - 2017-10-26 10:57:27 --> URI Class Initialized
INFO - 2017-10-26 10:57:27 --> Router Class Initialized
INFO - 2017-10-26 10:57:27 --> Output Class Initialized
INFO - 2017-10-26 10:57:27 --> Security Class Initialized
DEBUG - 2017-10-26 10:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:57:27 --> Input Class Initialized
INFO - 2017-10-26 10:57:27 --> Language Class Initialized
INFO - 2017-10-26 10:57:27 --> Loader Class Initialized
INFO - 2017-10-26 10:57:27 --> Helper loaded: url_helper
INFO - 2017-10-26 10:57:27 --> Helper loaded: common_helper
INFO - 2017-10-26 10:57:27 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:57:27 --> Email Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Controller Class Initialized
INFO - 2017-10-26 10:57:27 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> Model Class Initialized
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 10:57:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 10:57:27 --> Final output sent to browser
DEBUG - 2017-10-26 10:57:27 --> Total execution time: 0.0208
INFO - 2017-10-26 10:57:29 --> Config Class Initialized
INFO - 2017-10-26 10:57:29 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:57:29 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:57:29 --> Utf8 Class Initialized
INFO - 2017-10-26 10:57:29 --> URI Class Initialized
INFO - 2017-10-26 10:57:29 --> Router Class Initialized
INFO - 2017-10-26 10:57:29 --> Output Class Initialized
INFO - 2017-10-26 10:57:29 --> Security Class Initialized
DEBUG - 2017-10-26 10:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:57:29 --> Input Class Initialized
INFO - 2017-10-26 10:57:29 --> Language Class Initialized
INFO - 2017-10-26 10:57:29 --> Loader Class Initialized
INFO - 2017-10-26 10:57:29 --> Helper loaded: url_helper
INFO - 2017-10-26 10:57:29 --> Helper loaded: common_helper
INFO - 2017-10-26 10:57:29 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:57:29 --> Email Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Controller Class Initialized
INFO - 2017-10-26 10:57:29 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Model Class Initialized
INFO - 2017-10-26 10:57:29 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:57:29 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:57:29 --> Final output sent to browser
DEBUG - 2017-10-26 10:57:29 --> Total execution time: 0.0195
INFO - 2017-10-26 10:57:49 --> Config Class Initialized
INFO - 2017-10-26 10:57:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:57:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 10:57:49 --> Utf8 Class Initialized
INFO - 2017-10-26 10:57:49 --> URI Class Initialized
INFO - 2017-10-26 10:57:49 --> Router Class Initialized
INFO - 2017-10-26 10:57:49 --> Output Class Initialized
INFO - 2017-10-26 10:57:49 --> Security Class Initialized
DEBUG - 2017-10-26 10:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 10:57:49 --> Input Class Initialized
INFO - 2017-10-26 10:57:49 --> Language Class Initialized
INFO - 2017-10-26 10:57:49 --> Loader Class Initialized
INFO - 2017-10-26 10:57:49 --> Helper loaded: url_helper
INFO - 2017-10-26 10:57:49 --> Helper loaded: common_helper
INFO - 2017-10-26 10:57:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 10:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 10:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 10:57:49 --> Email Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Controller Class Initialized
INFO - 2017-10-26 10:57:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Model Class Initialized
INFO - 2017-10-26 10:57:49 --> Helper loaded: form_helper
DEBUG - 2017-10-26 10:57:49 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 10:57:49 --> Final output sent to browser
DEBUG - 2017-10-26 10:57:49 --> Total execution time: 0.0183
INFO - 2017-10-26 11:03:19 --> Config Class Initialized
INFO - 2017-10-26 11:03:19 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:03:19 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:03:19 --> Utf8 Class Initialized
INFO - 2017-10-26 11:03:19 --> URI Class Initialized
DEBUG - 2017-10-26 11:03:19 --> No URI present. Default controller set.
INFO - 2017-10-26 11:03:19 --> Router Class Initialized
INFO - 2017-10-26 11:03:19 --> Output Class Initialized
INFO - 2017-10-26 11:03:19 --> Security Class Initialized
DEBUG - 2017-10-26 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:03:19 --> Input Class Initialized
INFO - 2017-10-26 11:03:19 --> Language Class Initialized
INFO - 2017-10-26 11:03:19 --> Loader Class Initialized
INFO - 2017-10-26 11:03:19 --> Helper loaded: url_helper
INFO - 2017-10-26 11:03:19 --> Helper loaded: common_helper
INFO - 2017-10-26 11:03:19 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:03:19 --> Email Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Controller Class Initialized
INFO - 2017-10-26 11:03:19 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> Model Class Initialized
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:03:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:03:19 --> Final output sent to browser
DEBUG - 2017-10-26 11:03:19 --> Total execution time: 0.0203
INFO - 2017-10-26 11:03:20 --> Config Class Initialized
INFO - 2017-10-26 11:03:20 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:03:20 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:03:20 --> Utf8 Class Initialized
INFO - 2017-10-26 11:03:20 --> URI Class Initialized
INFO - 2017-10-26 11:03:20 --> Router Class Initialized
INFO - 2017-10-26 11:03:20 --> Output Class Initialized
INFO - 2017-10-26 11:03:20 --> Security Class Initialized
DEBUG - 2017-10-26 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:03:20 --> Input Class Initialized
INFO - 2017-10-26 11:03:20 --> Language Class Initialized
INFO - 2017-10-26 11:03:20 --> Loader Class Initialized
INFO - 2017-10-26 11:03:20 --> Helper loaded: url_helper
INFO - 2017-10-26 11:03:20 --> Helper loaded: common_helper
INFO - 2017-10-26 11:03:20 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:03:20 --> Email Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Controller Class Initialized
INFO - 2017-10-26 11:03:20 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> Model Class Initialized
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:03:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:03:20 --> Final output sent to browser
DEBUG - 2017-10-26 11:03:20 --> Total execution time: 0.0205
INFO - 2017-10-26 11:03:22 --> Config Class Initialized
INFO - 2017-10-26 11:03:22 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:03:22 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:03:22 --> Utf8 Class Initialized
INFO - 2017-10-26 11:03:22 --> URI Class Initialized
INFO - 2017-10-26 11:03:22 --> Router Class Initialized
INFO - 2017-10-26 11:03:22 --> Output Class Initialized
INFO - 2017-10-26 11:03:22 --> Security Class Initialized
DEBUG - 2017-10-26 11:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:03:22 --> Input Class Initialized
INFO - 2017-10-26 11:03:22 --> Language Class Initialized
INFO - 2017-10-26 11:03:22 --> Loader Class Initialized
INFO - 2017-10-26 11:03:22 --> Helper loaded: url_helper
INFO - 2017-10-26 11:03:22 --> Helper loaded: common_helper
INFO - 2017-10-26 11:03:22 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:03:22 --> Email Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Controller Class Initialized
INFO - 2017-10-26 11:03:22 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> Model Class Initialized
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:03:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:03:22 --> Final output sent to browser
DEBUG - 2017-10-26 11:03:22 --> Total execution time: 0.0212
INFO - 2017-10-26 11:03:25 --> Config Class Initialized
INFO - 2017-10-26 11:03:25 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:03:25 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:03:25 --> Utf8 Class Initialized
INFO - 2017-10-26 11:03:25 --> URI Class Initialized
INFO - 2017-10-26 11:03:25 --> Router Class Initialized
INFO - 2017-10-26 11:03:25 --> Output Class Initialized
INFO - 2017-10-26 11:03:25 --> Security Class Initialized
DEBUG - 2017-10-26 11:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:03:25 --> Input Class Initialized
INFO - 2017-10-26 11:03:25 --> Language Class Initialized
ERROR - 2017-10-26 11:03:25 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 53
INFO - 2017-10-26 11:04:14 --> Config Class Initialized
INFO - 2017-10-26 11:04:14 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:04:14 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:04:14 --> Utf8 Class Initialized
INFO - 2017-10-26 11:04:14 --> URI Class Initialized
DEBUG - 2017-10-26 11:04:14 --> No URI present. Default controller set.
INFO - 2017-10-26 11:04:14 --> Router Class Initialized
INFO - 2017-10-26 11:04:14 --> Output Class Initialized
INFO - 2017-10-26 11:04:14 --> Security Class Initialized
DEBUG - 2017-10-26 11:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:04:14 --> Input Class Initialized
INFO - 2017-10-26 11:04:14 --> Language Class Initialized
INFO - 2017-10-26 11:04:14 --> Loader Class Initialized
INFO - 2017-10-26 11:04:14 --> Helper loaded: url_helper
INFO - 2017-10-26 11:04:14 --> Helper loaded: common_helper
INFO - 2017-10-26 11:04:14 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:04:14 --> Email Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Controller Class Initialized
INFO - 2017-10-26 11:04:14 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> Model Class Initialized
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:04:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:04:14 --> Final output sent to browser
DEBUG - 2017-10-26 11:04:14 --> Total execution time: 0.0193
INFO - 2017-10-26 11:04:16 --> Config Class Initialized
INFO - 2017-10-26 11:04:16 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:04:16 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:04:16 --> Utf8 Class Initialized
INFO - 2017-10-26 11:04:16 --> URI Class Initialized
INFO - 2017-10-26 11:04:16 --> Router Class Initialized
INFO - 2017-10-26 11:04:16 --> Output Class Initialized
INFO - 2017-10-26 11:04:16 --> Security Class Initialized
DEBUG - 2017-10-26 11:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:04:16 --> Input Class Initialized
INFO - 2017-10-26 11:04:16 --> Language Class Initialized
INFO - 2017-10-26 11:04:16 --> Loader Class Initialized
INFO - 2017-10-26 11:04:16 --> Helper loaded: url_helper
INFO - 2017-10-26 11:04:16 --> Helper loaded: common_helper
INFO - 2017-10-26 11:04:16 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:04:16 --> Email Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Controller Class Initialized
INFO - 2017-10-26 11:04:16 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> Model Class Initialized
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:04:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:04:16 --> Final output sent to browser
DEBUG - 2017-10-26 11:04:16 --> Total execution time: 0.0559
INFO - 2017-10-26 11:04:17 --> Config Class Initialized
INFO - 2017-10-26 11:04:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:04:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:04:17 --> Utf8 Class Initialized
INFO - 2017-10-26 11:04:17 --> URI Class Initialized
INFO - 2017-10-26 11:04:17 --> Router Class Initialized
INFO - 2017-10-26 11:04:17 --> Output Class Initialized
INFO - 2017-10-26 11:04:17 --> Security Class Initialized
DEBUG - 2017-10-26 11:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:04:17 --> Input Class Initialized
INFO - 2017-10-26 11:04:17 --> Language Class Initialized
INFO - 2017-10-26 11:04:17 --> Loader Class Initialized
INFO - 2017-10-26 11:04:17 --> Helper loaded: url_helper
INFO - 2017-10-26 11:04:17 --> Helper loaded: common_helper
INFO - 2017-10-26 11:04:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:04:17 --> Email Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Controller Class Initialized
INFO - 2017-10-26 11:04:17 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> Model Class Initialized
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:04:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:04:17 --> Final output sent to browser
DEBUG - 2017-10-26 11:04:17 --> Total execution time: 0.0206
INFO - 2017-10-26 11:04:21 --> Config Class Initialized
INFO - 2017-10-26 11:04:21 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:04:21 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:04:21 --> Utf8 Class Initialized
INFO - 2017-10-26 11:04:21 --> URI Class Initialized
INFO - 2017-10-26 11:04:21 --> Router Class Initialized
INFO - 2017-10-26 11:04:21 --> Output Class Initialized
INFO - 2017-10-26 11:04:21 --> Security Class Initialized
DEBUG - 2017-10-26 11:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:04:21 --> Input Class Initialized
INFO - 2017-10-26 11:04:21 --> Language Class Initialized
INFO - 2017-10-26 11:04:21 --> Loader Class Initialized
INFO - 2017-10-26 11:04:21 --> Helper loaded: url_helper
INFO - 2017-10-26 11:04:21 --> Helper loaded: common_helper
INFO - 2017-10-26 11:04:21 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:04:21 --> Email Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Controller Class Initialized
INFO - 2017-10-26 11:04:21 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Model Class Initialized
INFO - 2017-10-26 11:04:21 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:04:21 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:04:21 --> Final output sent to browser
DEBUG - 2017-10-26 11:04:21 --> Total execution time: 0.0191
INFO - 2017-10-26 11:06:19 --> Config Class Initialized
INFO - 2017-10-26 11:06:19 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:06:19 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:06:19 --> Utf8 Class Initialized
INFO - 2017-10-26 11:06:19 --> URI Class Initialized
DEBUG - 2017-10-26 11:06:19 --> No URI present. Default controller set.
INFO - 2017-10-26 11:06:19 --> Router Class Initialized
INFO - 2017-10-26 11:06:19 --> Output Class Initialized
INFO - 2017-10-26 11:06:19 --> Security Class Initialized
DEBUG - 2017-10-26 11:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:06:19 --> Input Class Initialized
INFO - 2017-10-26 11:06:19 --> Language Class Initialized
INFO - 2017-10-26 11:06:19 --> Loader Class Initialized
INFO - 2017-10-26 11:06:19 --> Helper loaded: url_helper
INFO - 2017-10-26 11:06:19 --> Helper loaded: common_helper
INFO - 2017-10-26 11:06:19 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:06:19 --> Email Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Controller Class Initialized
INFO - 2017-10-26 11:06:19 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> Model Class Initialized
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:06:19 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:06:19 --> Final output sent to browser
DEBUG - 2017-10-26 11:06:19 --> Total execution time: 0.0198
INFO - 2017-10-26 11:06:22 --> Config Class Initialized
INFO - 2017-10-26 11:06:22 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:06:22 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:06:22 --> Utf8 Class Initialized
INFO - 2017-10-26 11:06:22 --> URI Class Initialized
INFO - 2017-10-26 11:06:22 --> Router Class Initialized
INFO - 2017-10-26 11:06:22 --> Output Class Initialized
INFO - 2017-10-26 11:06:22 --> Security Class Initialized
DEBUG - 2017-10-26 11:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:06:22 --> Input Class Initialized
INFO - 2017-10-26 11:06:22 --> Language Class Initialized
INFO - 2017-10-26 11:06:22 --> Loader Class Initialized
INFO - 2017-10-26 11:06:22 --> Helper loaded: url_helper
INFO - 2017-10-26 11:06:22 --> Helper loaded: common_helper
INFO - 2017-10-26 11:06:22 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:06:22 --> Email Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Controller Class Initialized
INFO - 2017-10-26 11:06:22 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> Model Class Initialized
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:06:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:06:22 --> Final output sent to browser
DEBUG - 2017-10-26 11:06:22 --> Total execution time: 0.0204
INFO - 2017-10-26 11:06:23 --> Config Class Initialized
INFO - 2017-10-26 11:06:23 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:06:23 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:06:23 --> Utf8 Class Initialized
INFO - 2017-10-26 11:06:23 --> URI Class Initialized
INFO - 2017-10-26 11:06:23 --> Router Class Initialized
INFO - 2017-10-26 11:06:23 --> Output Class Initialized
INFO - 2017-10-26 11:06:23 --> Security Class Initialized
DEBUG - 2017-10-26 11:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:06:23 --> Input Class Initialized
INFO - 2017-10-26 11:06:23 --> Language Class Initialized
INFO - 2017-10-26 11:06:23 --> Loader Class Initialized
INFO - 2017-10-26 11:06:23 --> Helper loaded: url_helper
INFO - 2017-10-26 11:06:23 --> Helper loaded: common_helper
INFO - 2017-10-26 11:06:23 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:06:23 --> Email Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Controller Class Initialized
INFO - 2017-10-26 11:06:23 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> Model Class Initialized
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:06:23 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:06:23 --> Final output sent to browser
DEBUG - 2017-10-26 11:06:23 --> Total execution time: 0.0216
INFO - 2017-10-26 11:06:26 --> Config Class Initialized
INFO - 2017-10-26 11:06:26 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:06:26 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:06:26 --> Utf8 Class Initialized
INFO - 2017-10-26 11:06:26 --> URI Class Initialized
INFO - 2017-10-26 11:06:26 --> Router Class Initialized
INFO - 2017-10-26 11:06:26 --> Output Class Initialized
INFO - 2017-10-26 11:06:26 --> Security Class Initialized
DEBUG - 2017-10-26 11:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:06:26 --> Input Class Initialized
INFO - 2017-10-26 11:06:26 --> Language Class Initialized
INFO - 2017-10-26 11:06:26 --> Loader Class Initialized
INFO - 2017-10-26 11:06:26 --> Helper loaded: url_helper
INFO - 2017-10-26 11:06:26 --> Helper loaded: common_helper
INFO - 2017-10-26 11:06:26 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:06:26 --> Email Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Controller Class Initialized
INFO - 2017-10-26 11:06:26 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Model Class Initialized
INFO - 2017-10-26 11:06:26 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:06:26 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:06:26 --> Final output sent to browser
DEBUG - 2017-10-26 11:06:26 --> Total execution time: 0.0184
INFO - 2017-10-26 11:06:55 --> Config Class Initialized
INFO - 2017-10-26 11:06:55 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:06:55 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:06:55 --> Utf8 Class Initialized
INFO - 2017-10-26 11:06:55 --> URI Class Initialized
INFO - 2017-10-26 11:06:55 --> Router Class Initialized
INFO - 2017-10-26 11:06:55 --> Output Class Initialized
INFO - 2017-10-26 11:06:55 --> Security Class Initialized
DEBUG - 2017-10-26 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:06:55 --> Input Class Initialized
INFO - 2017-10-26 11:06:55 --> Language Class Initialized
INFO - 2017-10-26 11:06:55 --> Loader Class Initialized
INFO - 2017-10-26 11:06:55 --> Helper loaded: url_helper
INFO - 2017-10-26 11:06:55 --> Helper loaded: common_helper
INFO - 2017-10-26 11:06:55 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:06:55 --> Email Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Controller Class Initialized
INFO - 2017-10-26 11:06:55 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Model Class Initialized
INFO - 2017-10-26 11:06:55 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:06:55 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:06:55 --> Final output sent to browser
DEBUG - 2017-10-26 11:06:55 --> Total execution time: 0.0191
INFO - 2017-10-26 11:28:04 --> Config Class Initialized
INFO - 2017-10-26 11:28:04 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:04 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:04 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:04 --> URI Class Initialized
DEBUG - 2017-10-26 11:28:04 --> No URI present. Default controller set.
INFO - 2017-10-26 11:28:04 --> Router Class Initialized
INFO - 2017-10-26 11:28:04 --> Output Class Initialized
INFO - 2017-10-26 11:28:04 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:04 --> Input Class Initialized
INFO - 2017-10-26 11:28:04 --> Language Class Initialized
INFO - 2017-10-26 11:28:04 --> Loader Class Initialized
INFO - 2017-10-26 11:28:04 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:04 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:04 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:04 --> Email Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Controller Class Initialized
INFO - 2017-10-26 11:28:04 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> Model Class Initialized
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:28:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:28:04 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:04 --> Total execution time: 0.0208
INFO - 2017-10-26 11:28:07 --> Config Class Initialized
INFO - 2017-10-26 11:28:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:07 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:07 --> URI Class Initialized
INFO - 2017-10-26 11:28:07 --> Router Class Initialized
INFO - 2017-10-26 11:28:07 --> Output Class Initialized
INFO - 2017-10-26 11:28:07 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:07 --> Input Class Initialized
INFO - 2017-10-26 11:28:07 --> Language Class Initialized
INFO - 2017-10-26 11:28:07 --> Loader Class Initialized
INFO - 2017-10-26 11:28:07 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:07 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:07 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:07 --> Email Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Controller Class Initialized
INFO - 2017-10-26 11:28:07 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> Model Class Initialized
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:28:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:28:07 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:07 --> Total execution time: 0.0202
INFO - 2017-10-26 11:28:08 --> Config Class Initialized
INFO - 2017-10-26 11:28:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:08 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:08 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:08 --> URI Class Initialized
INFO - 2017-10-26 11:28:08 --> Router Class Initialized
INFO - 2017-10-26 11:28:08 --> Output Class Initialized
INFO - 2017-10-26 11:28:08 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:08 --> Input Class Initialized
INFO - 2017-10-26 11:28:08 --> Language Class Initialized
INFO - 2017-10-26 11:28:08 --> Loader Class Initialized
INFO - 2017-10-26 11:28:08 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:08 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:08 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:08 --> Email Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Controller Class Initialized
INFO - 2017-10-26 11:28:08 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> Model Class Initialized
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:28:08 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:28:08 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:08 --> Total execution time: 0.0196
INFO - 2017-10-26 11:28:10 --> Config Class Initialized
INFO - 2017-10-26 11:28:10 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:10 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:10 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:10 --> URI Class Initialized
INFO - 2017-10-26 11:28:10 --> Router Class Initialized
INFO - 2017-10-26 11:28:10 --> Output Class Initialized
INFO - 2017-10-26 11:28:10 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:10 --> Input Class Initialized
INFO - 2017-10-26 11:28:10 --> Language Class Initialized
INFO - 2017-10-26 11:28:10 --> Loader Class Initialized
INFO - 2017-10-26 11:28:10 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:10 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:10 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:10 --> Email Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Controller Class Initialized
INFO - 2017-10-26 11:28:10 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> Model Class Initialized
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:28:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:28:10 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:10 --> Total execution time: 0.0188
INFO - 2017-10-26 11:28:13 --> Config Class Initialized
INFO - 2017-10-26 11:28:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:13 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:13 --> URI Class Initialized
INFO - 2017-10-26 11:28:13 --> Router Class Initialized
INFO - 2017-10-26 11:28:13 --> Output Class Initialized
INFO - 2017-10-26 11:28:13 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:13 --> Input Class Initialized
INFO - 2017-10-26 11:28:13 --> Language Class Initialized
ERROR - 2017-10-26 11:28:13 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 153
INFO - 2017-10-26 11:28:31 --> Config Class Initialized
INFO - 2017-10-26 11:28:31 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:31 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:31 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:31 --> URI Class Initialized
INFO - 2017-10-26 11:28:31 --> Router Class Initialized
INFO - 2017-10-26 11:28:31 --> Output Class Initialized
INFO - 2017-10-26 11:28:31 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:31 --> Input Class Initialized
INFO - 2017-10-26 11:28:31 --> Language Class Initialized
INFO - 2017-10-26 11:28:31 --> Loader Class Initialized
INFO - 2017-10-26 11:28:31 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:31 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:31 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:31 --> Email Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Controller Class Initialized
INFO - 2017-10-26 11:28:31 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> Model Class Initialized
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:28:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:28:31 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:31 --> Total execution time: 0.0209
INFO - 2017-10-26 11:28:33 --> Config Class Initialized
INFO - 2017-10-26 11:28:33 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:28:33 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:28:33 --> Utf8 Class Initialized
INFO - 2017-10-26 11:28:33 --> URI Class Initialized
INFO - 2017-10-26 11:28:33 --> Router Class Initialized
INFO - 2017-10-26 11:28:33 --> Output Class Initialized
INFO - 2017-10-26 11:28:33 --> Security Class Initialized
DEBUG - 2017-10-26 11:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:28:33 --> Input Class Initialized
INFO - 2017-10-26 11:28:33 --> Language Class Initialized
INFO - 2017-10-26 11:28:33 --> Loader Class Initialized
INFO - 2017-10-26 11:28:33 --> Helper loaded: url_helper
INFO - 2017-10-26 11:28:33 --> Helper loaded: common_helper
INFO - 2017-10-26 11:28:33 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:28:33 --> Email Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Controller Class Initialized
INFO - 2017-10-26 11:28:33 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Model Class Initialized
INFO - 2017-10-26 11:28:33 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:28:33 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:28:33 --> Final output sent to browser
DEBUG - 2017-10-26 11:28:33 --> Total execution time: 0.0187
INFO - 2017-10-26 11:29:17 --> Config Class Initialized
INFO - 2017-10-26 11:29:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:29:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:29:17 --> Utf8 Class Initialized
INFO - 2017-10-26 11:29:17 --> URI Class Initialized
INFO - 2017-10-26 11:29:17 --> Router Class Initialized
INFO - 2017-10-26 11:29:17 --> Output Class Initialized
INFO - 2017-10-26 11:29:17 --> Security Class Initialized
DEBUG - 2017-10-26 11:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:29:17 --> Input Class Initialized
INFO - 2017-10-26 11:29:17 --> Language Class Initialized
INFO - 2017-10-26 11:29:17 --> Loader Class Initialized
INFO - 2017-10-26 11:29:17 --> Helper loaded: url_helper
INFO - 2017-10-26 11:29:17 --> Helper loaded: common_helper
INFO - 2017-10-26 11:29:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:29:17 --> Email Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Controller Class Initialized
INFO - 2017-10-26 11:29:17 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
INFO - 2017-10-26 11:29:17 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:29:17 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:29:17 --> Model Class Initialized
ERROR - 2017-10-26 11:29:17 --> Severity: Notice --> Undefined index: category /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 142
ERROR - 2017-10-26 11:29:17 --> Query error: Column 'category_id' cannot be null - Invalid query: INSERT INTO `user_subscription` (`txn_id`, `user_id`, `item_id`, `item_name`, `category_id`, `gross_amount`, `currency`, `payer_email`, `subscription_date`, `subscription_expiry`, `subscription_type`) VALUES ('93X43923HG907211X', '28', '1', 'Membership B 100€/month or 1000€/year', NULL, '100.00', 'EUR', '', '2017-10-26 11:29:17', '2017-11-26 11:29:17', NULL)
INFO - 2017-10-26 11:29:17 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-26 11:30:16 --> Config Class Initialized
INFO - 2017-10-26 11:30:16 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:30:16 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:30:16 --> Utf8 Class Initialized
INFO - 2017-10-26 11:30:16 --> URI Class Initialized
DEBUG - 2017-10-26 11:30:16 --> No URI present. Default controller set.
INFO - 2017-10-26 11:30:16 --> Router Class Initialized
INFO - 2017-10-26 11:30:16 --> Output Class Initialized
INFO - 2017-10-26 11:30:16 --> Security Class Initialized
DEBUG - 2017-10-26 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:30:16 --> Input Class Initialized
INFO - 2017-10-26 11:30:16 --> Language Class Initialized
INFO - 2017-10-26 11:30:16 --> Loader Class Initialized
INFO - 2017-10-26 11:30:16 --> Helper loaded: url_helper
INFO - 2017-10-26 11:30:16 --> Helper loaded: common_helper
INFO - 2017-10-26 11:30:16 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:30:16 --> Email Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Controller Class Initialized
INFO - 2017-10-26 11:30:16 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> Model Class Initialized
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:30:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:30:16 --> Final output sent to browser
DEBUG - 2017-10-26 11:30:16 --> Total execution time: 0.0198
INFO - 2017-10-26 11:30:17 --> Config Class Initialized
INFO - 2017-10-26 11:30:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:30:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:30:17 --> Utf8 Class Initialized
INFO - 2017-10-26 11:30:17 --> URI Class Initialized
INFO - 2017-10-26 11:30:17 --> Router Class Initialized
INFO - 2017-10-26 11:30:17 --> Output Class Initialized
INFO - 2017-10-26 11:30:17 --> Security Class Initialized
DEBUG - 2017-10-26 11:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:30:17 --> Input Class Initialized
INFO - 2017-10-26 11:30:17 --> Language Class Initialized
INFO - 2017-10-26 11:30:17 --> Loader Class Initialized
INFO - 2017-10-26 11:30:17 --> Helper loaded: url_helper
INFO - 2017-10-26 11:30:17 --> Helper loaded: common_helper
INFO - 2017-10-26 11:30:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:30:17 --> Email Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Controller Class Initialized
INFO - 2017-10-26 11:30:17 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> Model Class Initialized
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:30:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:30:17 --> Final output sent to browser
DEBUG - 2017-10-26 11:30:17 --> Total execution time: 0.0197
INFO - 2017-10-26 11:31:09 --> Config Class Initialized
INFO - 2017-10-26 11:31:09 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:31:09 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:31:09 --> Utf8 Class Initialized
INFO - 2017-10-26 11:31:09 --> URI Class Initialized
INFO - 2017-10-26 11:31:09 --> Router Class Initialized
INFO - 2017-10-26 11:31:09 --> Output Class Initialized
INFO - 2017-10-26 11:31:09 --> Security Class Initialized
DEBUG - 2017-10-26 11:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:31:09 --> Input Class Initialized
INFO - 2017-10-26 11:31:09 --> Language Class Initialized
INFO - 2017-10-26 11:31:09 --> Loader Class Initialized
INFO - 2017-10-26 11:31:09 --> Helper loaded: url_helper
INFO - 2017-10-26 11:31:09 --> Helper loaded: common_helper
INFO - 2017-10-26 11:31:09 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:31:09 --> Email Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Controller Class Initialized
INFO - 2017-10-26 11:31:09 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> Model Class Initialized
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:31:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:31:09 --> Final output sent to browser
DEBUG - 2017-10-26 11:31:09 --> Total execution time: 0.0201
INFO - 2017-10-26 11:31:13 --> Config Class Initialized
INFO - 2017-10-26 11:31:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:31:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:31:13 --> Utf8 Class Initialized
INFO - 2017-10-26 11:31:13 --> URI Class Initialized
INFO - 2017-10-26 11:31:13 --> Router Class Initialized
INFO - 2017-10-26 11:31:13 --> Output Class Initialized
INFO - 2017-10-26 11:31:13 --> Security Class Initialized
DEBUG - 2017-10-26 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:31:13 --> Input Class Initialized
INFO - 2017-10-26 11:31:13 --> Language Class Initialized
INFO - 2017-10-26 11:31:13 --> Loader Class Initialized
INFO - 2017-10-26 11:31:13 --> Helper loaded: url_helper
INFO - 2017-10-26 11:31:13 --> Helper loaded: common_helper
INFO - 2017-10-26 11:31:13 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:31:13 --> Email Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Controller Class Initialized
INFO - 2017-10-26 11:31:13 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Model Class Initialized
INFO - 2017-10-26 11:31:13 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:31:13 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/reminder_service.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:31:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:31:13 --> Final output sent to browser
DEBUG - 2017-10-26 11:31:13 --> Total execution time: 0.0213
INFO - 2017-10-26 11:31:23 --> Config Class Initialized
INFO - 2017-10-26 11:31:23 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:31:23 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:31:23 --> Utf8 Class Initialized
INFO - 2017-10-26 11:31:23 --> URI Class Initialized
INFO - 2017-10-26 11:31:23 --> Router Class Initialized
INFO - 2017-10-26 11:31:23 --> Output Class Initialized
INFO - 2017-10-26 11:31:23 --> Security Class Initialized
DEBUG - 2017-10-26 11:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:31:23 --> Input Class Initialized
INFO - 2017-10-26 11:31:23 --> Language Class Initialized
INFO - 2017-10-26 11:31:23 --> Loader Class Initialized
INFO - 2017-10-26 11:31:23 --> Helper loaded: url_helper
INFO - 2017-10-26 11:31:23 --> Helper loaded: common_helper
INFO - 2017-10-26 11:31:23 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:31:23 --> Email Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Controller Class Initialized
INFO - 2017-10-26 11:31:23 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Model Class Initialized
INFO - 2017-10-26 11:31:23 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:31:23 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:31:23 --> Final output sent to browser
DEBUG - 2017-10-26 11:31:23 --> Total execution time: 0.0184
INFO - 2017-10-26 11:31:31 --> Config Class Initialized
INFO - 2017-10-26 11:31:31 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:31:31 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:31:31 --> Utf8 Class Initialized
INFO - 2017-10-26 11:31:31 --> URI Class Initialized
INFO - 2017-10-26 11:31:31 --> Router Class Initialized
INFO - 2017-10-26 11:31:31 --> Output Class Initialized
INFO - 2017-10-26 11:31:31 --> Security Class Initialized
DEBUG - 2017-10-26 11:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:31:31 --> Input Class Initialized
INFO - 2017-10-26 11:31:31 --> Language Class Initialized
INFO - 2017-10-26 11:31:31 --> Loader Class Initialized
INFO - 2017-10-26 11:31:31 --> Helper loaded: url_helper
INFO - 2017-10-26 11:31:31 --> Helper loaded: common_helper
INFO - 2017-10-26 11:31:31 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:31:31 --> Email Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Controller Class Initialized
INFO - 2017-10-26 11:31:31 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Model Class Initialized
INFO - 2017-10-26 11:31:31 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:31:31 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/reminder_service.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:31:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:31:31 --> Final output sent to browser
DEBUG - 2017-10-26 11:31:31 --> Total execution time: 0.0211
INFO - 2017-10-26 11:32:52 --> Config Class Initialized
INFO - 2017-10-26 11:32:52 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:32:52 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:32:52 --> Utf8 Class Initialized
INFO - 2017-10-26 11:32:52 --> URI Class Initialized
INFO - 2017-10-26 11:32:52 --> Router Class Initialized
INFO - 2017-10-26 11:32:52 --> Output Class Initialized
INFO - 2017-10-26 11:32:52 --> Security Class Initialized
DEBUG - 2017-10-26 11:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:32:52 --> Input Class Initialized
INFO - 2017-10-26 11:32:52 --> Language Class Initialized
INFO - 2017-10-26 11:32:52 --> Loader Class Initialized
INFO - 2017-10-26 11:32:52 --> Helper loaded: url_helper
INFO - 2017-10-26 11:32:52 --> Helper loaded: common_helper
INFO - 2017-10-26 11:32:52 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:32:52 --> Email Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Controller Class Initialized
INFO - 2017-10-26 11:32:52 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> Model Class Initialized
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:32:52 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:32:52 --> Final output sent to browser
DEBUG - 2017-10-26 11:32:52 --> Total execution time: 0.0256
INFO - 2017-10-26 11:40:18 --> Config Class Initialized
INFO - 2017-10-26 11:40:18 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:18 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:18 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:18 --> URI Class Initialized
INFO - 2017-10-26 11:40:18 --> Router Class Initialized
INFO - 2017-10-26 11:40:18 --> Output Class Initialized
INFO - 2017-10-26 11:40:18 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:18 --> Input Class Initialized
INFO - 2017-10-26 11:40:18 --> Language Class Initialized
INFO - 2017-10-26 11:40:18 --> Loader Class Initialized
INFO - 2017-10-26 11:40:18 --> Helper loaded: url_helper
INFO - 2017-10-26 11:40:18 --> Helper loaded: common_helper
INFO - 2017-10-26 11:40:18 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:40:18 --> Email Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Controller Class Initialized
INFO - 2017-10-26 11:40:18 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> Model Class Initialized
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:40:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:40:18 --> Final output sent to browser
DEBUG - 2017-10-26 11:40:18 --> Total execution time: 0.0220
INFO - 2017-10-26 11:40:20 --> Config Class Initialized
INFO - 2017-10-26 11:40:20 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:20 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:20 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:20 --> URI Class Initialized
INFO - 2017-10-26 11:40:20 --> Router Class Initialized
INFO - 2017-10-26 11:40:20 --> Output Class Initialized
INFO - 2017-10-26 11:40:20 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:20 --> Input Class Initialized
INFO - 2017-10-26 11:40:20 --> Language Class Initialized
ERROR - 2017-10-26 11:40:20 --> 404 Page Not Found: Service/number-game
INFO - 2017-10-26 11:40:24 --> Config Class Initialized
INFO - 2017-10-26 11:40:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:24 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:24 --> URI Class Initialized
INFO - 2017-10-26 11:40:24 --> Router Class Initialized
INFO - 2017-10-26 11:40:24 --> Output Class Initialized
INFO - 2017-10-26 11:40:24 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:24 --> Input Class Initialized
INFO - 2017-10-26 11:40:24 --> Language Class Initialized
INFO - 2017-10-26 11:40:24 --> Loader Class Initialized
INFO - 2017-10-26 11:40:24 --> Helper loaded: url_helper
INFO - 2017-10-26 11:40:24 --> Helper loaded: common_helper
INFO - 2017-10-26 11:40:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:40:24 --> Email Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Controller Class Initialized
INFO - 2017-10-26 11:40:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> Model Class Initialized
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:40:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:40:24 --> Final output sent to browser
DEBUG - 2017-10-26 11:40:24 --> Total execution time: 0.0204
INFO - 2017-10-26 11:40:25 --> Config Class Initialized
INFO - 2017-10-26 11:40:25 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:25 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:25 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:25 --> URI Class Initialized
INFO - 2017-10-26 11:40:25 --> Router Class Initialized
INFO - 2017-10-26 11:40:25 --> Output Class Initialized
INFO - 2017-10-26 11:40:25 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:25 --> Input Class Initialized
INFO - 2017-10-26 11:40:25 --> Language Class Initialized
INFO - 2017-10-26 11:40:25 --> Loader Class Initialized
INFO - 2017-10-26 11:40:25 --> Helper loaded: url_helper
INFO - 2017-10-26 11:40:25 --> Helper loaded: common_helper
INFO - 2017-10-26 11:40:25 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:40:25 --> Email Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Controller Class Initialized
INFO - 2017-10-26 11:40:25 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> Model Class Initialized
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/number_game.php
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:40:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:40:25 --> Final output sent to browser
DEBUG - 2017-10-26 11:40:25 --> Total execution time: 0.0537
INFO - 2017-10-26 11:40:27 --> Config Class Initialized
INFO - 2017-10-26 11:40:27 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:27 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:27 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:27 --> URI Class Initialized
INFO - 2017-10-26 11:40:27 --> Router Class Initialized
INFO - 2017-10-26 11:40:27 --> Output Class Initialized
INFO - 2017-10-26 11:40:27 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:27 --> Input Class Initialized
INFO - 2017-10-26 11:40:27 --> Language Class Initialized
INFO - 2017-10-26 11:40:27 --> Loader Class Initialized
INFO - 2017-10-26 11:40:27 --> Helper loaded: url_helper
INFO - 2017-10-26 11:40:27 --> Helper loaded: common_helper
INFO - 2017-10-26 11:40:27 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:40:27 --> Email Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Controller Class Initialized
INFO - 2017-10-26 11:40:27 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> Model Class Initialized
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:40:27 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:40:27 --> Final output sent to browser
DEBUG - 2017-10-26 11:40:27 --> Total execution time: 0.0207
INFO - 2017-10-26 11:40:28 --> Config Class Initialized
INFO - 2017-10-26 11:40:28 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:40:28 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:40:28 --> Utf8 Class Initialized
INFO - 2017-10-26 11:40:28 --> URI Class Initialized
INFO - 2017-10-26 11:40:28 --> Router Class Initialized
INFO - 2017-10-26 11:40:28 --> Output Class Initialized
INFO - 2017-10-26 11:40:28 --> Security Class Initialized
DEBUG - 2017-10-26 11:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:40:28 --> Input Class Initialized
INFO - 2017-10-26 11:40:28 --> Language Class Initialized
INFO - 2017-10-26 11:40:28 --> Loader Class Initialized
INFO - 2017-10-26 11:40:28 --> Helper loaded: url_helper
INFO - 2017-10-26 11:40:28 --> Helper loaded: common_helper
INFO - 2017-10-26 11:40:28 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:40:28 --> Email Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Controller Class Initialized
INFO - 2017-10-26 11:40:28 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> Model Class Initialized
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:40:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:40:28 --> Final output sent to browser
DEBUG - 2017-10-26 11:40:28 --> Total execution time: 0.0204
INFO - 2017-10-26 11:42:10 --> Config Class Initialized
INFO - 2017-10-26 11:42:10 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:42:10 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:42:10 --> Utf8 Class Initialized
INFO - 2017-10-26 11:42:10 --> URI Class Initialized
INFO - 2017-10-26 11:42:10 --> Router Class Initialized
INFO - 2017-10-26 11:42:10 --> Output Class Initialized
INFO - 2017-10-26 11:42:10 --> Security Class Initialized
DEBUG - 2017-10-26 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:42:10 --> Input Class Initialized
INFO - 2017-10-26 11:42:10 --> Language Class Initialized
INFO - 2017-10-26 11:42:10 --> Loader Class Initialized
INFO - 2017-10-26 11:42:10 --> Helper loaded: url_helper
INFO - 2017-10-26 11:42:10 --> Helper loaded: common_helper
INFO - 2017-10-26 11:42:10 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:42:10 --> Email Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Controller Class Initialized
INFO - 2017-10-26 11:42:10 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> Model Class Initialized
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:42:10 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:42:10 --> Final output sent to browser
DEBUG - 2017-10-26 11:42:10 --> Total execution time: 0.0286
INFO - 2017-10-26 11:42:12 --> Config Class Initialized
INFO - 2017-10-26 11:42:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:42:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:42:12 --> Utf8 Class Initialized
INFO - 2017-10-26 11:42:12 --> URI Class Initialized
INFO - 2017-10-26 11:42:12 --> Router Class Initialized
INFO - 2017-10-26 11:42:12 --> Output Class Initialized
INFO - 2017-10-26 11:42:12 --> Security Class Initialized
DEBUG - 2017-10-26 11:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:42:12 --> Input Class Initialized
INFO - 2017-10-26 11:42:12 --> Language Class Initialized
INFO - 2017-10-26 11:42:12 --> Loader Class Initialized
INFO - 2017-10-26 11:42:12 --> Helper loaded: url_helper
INFO - 2017-10-26 11:42:12 --> Helper loaded: common_helper
INFO - 2017-10-26 11:42:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:42:12 --> Email Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Controller Class Initialized
INFO - 2017-10-26 11:42:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> Model Class Initialized
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:42:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:42:12 --> Final output sent to browser
DEBUG - 2017-10-26 11:42:12 --> Total execution time: 0.0222
INFO - 2017-10-26 11:42:16 --> Config Class Initialized
INFO - 2017-10-26 11:42:16 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:42:16 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:42:16 --> Utf8 Class Initialized
INFO - 2017-10-26 11:42:16 --> URI Class Initialized
INFO - 2017-10-26 11:42:16 --> Router Class Initialized
INFO - 2017-10-26 11:42:16 --> Output Class Initialized
INFO - 2017-10-26 11:42:16 --> Security Class Initialized
DEBUG - 2017-10-26 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:42:16 --> Input Class Initialized
INFO - 2017-10-26 11:42:16 --> Language Class Initialized
INFO - 2017-10-26 11:42:16 --> Loader Class Initialized
INFO - 2017-10-26 11:42:16 --> Helper loaded: url_helper
INFO - 2017-10-26 11:42:16 --> Helper loaded: common_helper
INFO - 2017-10-26 11:42:16 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:42:16 --> Email Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Controller Class Initialized
INFO - 2017-10-26 11:42:16 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Model Class Initialized
INFO - 2017-10-26 11:42:16 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:42:16 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:42:16 --> Final output sent to browser
DEBUG - 2017-10-26 11:42:16 --> Total execution time: 0.0231
INFO - 2017-10-26 11:42:32 --> Config Class Initialized
INFO - 2017-10-26 11:42:32 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:42:32 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:42:32 --> Utf8 Class Initialized
INFO - 2017-10-26 11:42:32 --> URI Class Initialized
INFO - 2017-10-26 11:42:32 --> Router Class Initialized
INFO - 2017-10-26 11:42:32 --> Output Class Initialized
INFO - 2017-10-26 11:42:32 --> Security Class Initialized
DEBUG - 2017-10-26 11:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:42:32 --> Input Class Initialized
INFO - 2017-10-26 11:42:32 --> Language Class Initialized
INFO - 2017-10-26 11:42:33 --> Loader Class Initialized
INFO - 2017-10-26 11:42:33 --> Helper loaded: url_helper
INFO - 2017-10-26 11:42:33 --> Helper loaded: common_helper
INFO - 2017-10-26 11:42:33 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:42:33 --> Email Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Controller Class Initialized
INFO - 2017-10-26 11:42:33 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> Model Class Initialized
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:42:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:42:33 --> Final output sent to browser
DEBUG - 2017-10-26 11:42:33 --> Total execution time: 0.0218
INFO - 2017-10-26 11:43:08 --> Config Class Initialized
INFO - 2017-10-26 11:43:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:43:08 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:43:08 --> Utf8 Class Initialized
INFO - 2017-10-26 11:43:08 --> URI Class Initialized
INFO - 2017-10-26 11:43:08 --> Router Class Initialized
INFO - 2017-10-26 11:43:08 --> Output Class Initialized
INFO - 2017-10-26 11:43:08 --> Security Class Initialized
DEBUG - 2017-10-26 11:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:43:08 --> Input Class Initialized
INFO - 2017-10-26 11:43:08 --> Language Class Initialized
INFO - 2017-10-26 11:43:08 --> Loader Class Initialized
INFO - 2017-10-26 11:43:08 --> Helper loaded: url_helper
INFO - 2017-10-26 11:43:08 --> Helper loaded: common_helper
INFO - 2017-10-26 11:43:08 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:43:08 --> Email Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Controller Class Initialized
INFO - 2017-10-26 11:43:08 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Model Class Initialized
INFO - 2017-10-26 11:43:08 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:43:08 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:43:08 --> Final output sent to browser
DEBUG - 2017-10-26 11:43:08 --> Total execution time: 0.0199
INFO - 2017-10-26 11:43:25 --> Config Class Initialized
INFO - 2017-10-26 11:43:25 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:43:25 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:43:25 --> Utf8 Class Initialized
INFO - 2017-10-26 11:43:25 --> URI Class Initialized
INFO - 2017-10-26 11:43:25 --> Router Class Initialized
INFO - 2017-10-26 11:43:25 --> Output Class Initialized
INFO - 2017-10-26 11:43:25 --> Security Class Initialized
DEBUG - 2017-10-26 11:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:43:25 --> Input Class Initialized
INFO - 2017-10-26 11:43:25 --> Language Class Initialized
INFO - 2017-10-26 11:43:25 --> Loader Class Initialized
INFO - 2017-10-26 11:43:25 --> Helper loaded: url_helper
INFO - 2017-10-26 11:43:25 --> Helper loaded: common_helper
INFO - 2017-10-26 11:43:25 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:43:25 --> Email Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Controller Class Initialized
INFO - 2017-10-26 11:43:25 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> Model Class Initialized
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:43:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:43:25 --> Final output sent to browser
DEBUG - 2017-10-26 11:43:25 --> Total execution time: 0.0230
INFO - 2017-10-26 11:44:06 --> Config Class Initialized
INFO - 2017-10-26 11:44:06 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:44:06 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:44:06 --> Utf8 Class Initialized
INFO - 2017-10-26 11:44:06 --> URI Class Initialized
INFO - 2017-10-26 11:44:06 --> Router Class Initialized
INFO - 2017-10-26 11:44:06 --> Output Class Initialized
INFO - 2017-10-26 11:44:06 --> Security Class Initialized
DEBUG - 2017-10-26 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:44:06 --> Input Class Initialized
INFO - 2017-10-26 11:44:06 --> Language Class Initialized
INFO - 2017-10-26 11:44:06 --> Loader Class Initialized
INFO - 2017-10-26 11:44:06 --> Helper loaded: url_helper
INFO - 2017-10-26 11:44:06 --> Helper loaded: common_helper
INFO - 2017-10-26 11:44:06 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:44:06 --> Email Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Controller Class Initialized
INFO - 2017-10-26 11:44:06 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Model Class Initialized
INFO - 2017-10-26 11:44:06 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:44:06 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:44:36 --> Config Class Initialized
INFO - 2017-10-26 11:44:36 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:44:36 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:44:36 --> Utf8 Class Initialized
INFO - 2017-10-26 11:44:36 --> URI Class Initialized
INFO - 2017-10-26 11:44:36 --> Router Class Initialized
INFO - 2017-10-26 11:44:36 --> Output Class Initialized
INFO - 2017-10-26 11:44:36 --> Security Class Initialized
DEBUG - 2017-10-26 11:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:44:36 --> Input Class Initialized
INFO - 2017-10-26 11:44:36 --> Language Class Initialized
INFO - 2017-10-26 11:44:36 --> Loader Class Initialized
INFO - 2017-10-26 11:44:36 --> Helper loaded: url_helper
INFO - 2017-10-26 11:44:36 --> Helper loaded: common_helper
INFO - 2017-10-26 11:44:36 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:44:36 --> Email Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Controller Class Initialized
INFO - 2017-10-26 11:44:36 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> Model Class Initialized
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:44:36 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:44:36 --> Final output sent to browser
DEBUG - 2017-10-26 11:44:36 --> Total execution time: 0.0203
INFO - 2017-10-26 11:51:24 --> Config Class Initialized
INFO - 2017-10-26 11:51:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:51:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:51:24 --> Utf8 Class Initialized
INFO - 2017-10-26 11:51:24 --> URI Class Initialized
INFO - 2017-10-26 11:51:24 --> Router Class Initialized
INFO - 2017-10-26 11:51:24 --> Output Class Initialized
INFO - 2017-10-26 11:51:24 --> Security Class Initialized
DEBUG - 2017-10-26 11:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:51:24 --> Input Class Initialized
INFO - 2017-10-26 11:51:24 --> Language Class Initialized
INFO - 2017-10-26 11:51:24 --> Loader Class Initialized
INFO - 2017-10-26 11:51:24 --> Helper loaded: url_helper
INFO - 2017-10-26 11:51:24 --> Helper loaded: common_helper
INFO - 2017-10-26 11:51:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:51:24 --> Email Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Controller Class Initialized
INFO - 2017-10-26 11:51:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> Model Class Initialized
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:51:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:51:24 --> Final output sent to browser
DEBUG - 2017-10-26 11:51:24 --> Total execution time: 0.0232
INFO - 2017-10-26 11:52:45 --> Config Class Initialized
INFO - 2017-10-26 11:52:45 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:52:45 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:52:45 --> Utf8 Class Initialized
INFO - 2017-10-26 11:52:45 --> URI Class Initialized
INFO - 2017-10-26 11:52:45 --> Router Class Initialized
INFO - 2017-10-26 11:52:45 --> Output Class Initialized
INFO - 2017-10-26 11:52:45 --> Security Class Initialized
DEBUG - 2017-10-26 11:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:52:45 --> Input Class Initialized
INFO - 2017-10-26 11:52:45 --> Language Class Initialized
INFO - 2017-10-26 11:52:45 --> Loader Class Initialized
INFO - 2017-10-26 11:52:45 --> Helper loaded: url_helper
INFO - 2017-10-26 11:52:45 --> Helper loaded: common_helper
INFO - 2017-10-26 11:52:45 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:52:45 --> Email Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Controller Class Initialized
INFO - 2017-10-26 11:52:45 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> Model Class Initialized
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:52:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:52:45 --> Final output sent to browser
DEBUG - 2017-10-26 11:52:45 --> Total execution time: 0.0214
INFO - 2017-10-26 11:53:26 --> Config Class Initialized
INFO - 2017-10-26 11:53:26 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:26 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:26 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:26 --> URI Class Initialized
INFO - 2017-10-26 11:53:26 --> Router Class Initialized
INFO - 2017-10-26 11:53:26 --> Output Class Initialized
INFO - 2017-10-26 11:53:26 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:26 --> Input Class Initialized
INFO - 2017-10-26 11:53:26 --> Language Class Initialized
INFO - 2017-10-26 11:53:26 --> Loader Class Initialized
INFO - 2017-10-26 11:53:26 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:26 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:26 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:26 --> Email Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Controller Class Initialized
INFO - 2017-10-26 11:53:26 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> Model Class Initialized
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:53:26 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:53:26 --> Final output sent to browser
DEBUG - 2017-10-26 11:53:26 --> Total execution time: 0.0308
INFO - 2017-10-26 11:53:29 --> Config Class Initialized
INFO - 2017-10-26 11:53:29 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:29 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:29 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:29 --> URI Class Initialized
INFO - 2017-10-26 11:53:29 --> Router Class Initialized
INFO - 2017-10-26 11:53:29 --> Output Class Initialized
INFO - 2017-10-26 11:53:29 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:29 --> Input Class Initialized
INFO - 2017-10-26 11:53:29 --> Language Class Initialized
INFO - 2017-10-26 11:53:29 --> Loader Class Initialized
INFO - 2017-10-26 11:53:29 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:29 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:29 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:29 --> Email Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Controller Class Initialized
INFO - 2017-10-26 11:53:29 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> Model Class Initialized
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:53:29 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:53:29 --> Final output sent to browser
DEBUG - 2017-10-26 11:53:29 --> Total execution time: 0.0317
INFO - 2017-10-26 11:53:30 --> Config Class Initialized
INFO - 2017-10-26 11:53:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:30 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:30 --> URI Class Initialized
INFO - 2017-10-26 11:53:30 --> Router Class Initialized
INFO - 2017-10-26 11:53:30 --> Output Class Initialized
INFO - 2017-10-26 11:53:30 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:30 --> Input Class Initialized
INFO - 2017-10-26 11:53:30 --> Language Class Initialized
INFO - 2017-10-26 11:53:30 --> Loader Class Initialized
INFO - 2017-10-26 11:53:30 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:30 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:30 --> Email Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Controller Class Initialized
INFO - 2017-10-26 11:53:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:30 --> Model Class Initialized
INFO - 2017-10-26 11:53:31 --> Model Class Initialized
INFO - 2017-10-26 11:53:31 --> Model Class Initialized
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:53:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:53:31 --> Final output sent to browser
DEBUG - 2017-10-26 11:53:31 --> Total execution time: 0.0394
INFO - 2017-10-26 11:53:35 --> Config Class Initialized
INFO - 2017-10-26 11:53:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:35 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:35 --> URI Class Initialized
INFO - 2017-10-26 11:53:35 --> Router Class Initialized
INFO - 2017-10-26 11:53:35 --> Output Class Initialized
INFO - 2017-10-26 11:53:35 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:35 --> Input Class Initialized
INFO - 2017-10-26 11:53:35 --> Language Class Initialized
INFO - 2017-10-26 11:53:35 --> Loader Class Initialized
INFO - 2017-10-26 11:53:35 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:35 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:35 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:35 --> Email Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Controller Class Initialized
INFO - 2017-10-26 11:53:35 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> Model Class Initialized
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:53:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:53:35 --> Final output sent to browser
DEBUG - 2017-10-26 11:53:35 --> Total execution time: 0.0874
INFO - 2017-10-26 11:53:43 --> Config Class Initialized
INFO - 2017-10-26 11:53:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:43 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:43 --> URI Class Initialized
INFO - 2017-10-26 11:53:43 --> Router Class Initialized
INFO - 2017-10-26 11:53:43 --> Output Class Initialized
INFO - 2017-10-26 11:53:43 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:43 --> Input Class Initialized
INFO - 2017-10-26 11:53:43 --> Language Class Initialized
INFO - 2017-10-26 11:53:43 --> Loader Class Initialized
INFO - 2017-10-26 11:53:43 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:43 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:43 --> Email Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Controller Class Initialized
INFO - 2017-10-26 11:53:43 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Model Class Initialized
INFO - 2017-10-26 11:53:43 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:53:43 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:53:59 --> Config Class Initialized
INFO - 2017-10-26 11:53:59 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:53:59 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:53:59 --> Utf8 Class Initialized
INFO - 2017-10-26 11:53:59 --> URI Class Initialized
INFO - 2017-10-26 11:53:59 --> Router Class Initialized
INFO - 2017-10-26 11:53:59 --> Output Class Initialized
INFO - 2017-10-26 11:53:59 --> Security Class Initialized
DEBUG - 2017-10-26 11:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:53:59 --> Input Class Initialized
INFO - 2017-10-26 11:53:59 --> Language Class Initialized
INFO - 2017-10-26 11:53:59 --> Loader Class Initialized
INFO - 2017-10-26 11:53:59 --> Helper loaded: url_helper
INFO - 2017-10-26 11:53:59 --> Helper loaded: common_helper
INFO - 2017-10-26 11:53:59 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:53:59 --> Email Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Controller Class Initialized
INFO - 2017-10-26 11:53:59 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> Model Class Initialized
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:53:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:53:59 --> Final output sent to browser
DEBUG - 2017-10-26 11:53:59 --> Total execution time: 0.0940
INFO - 2017-10-26 11:54:03 --> Config Class Initialized
INFO - 2017-10-26 11:54:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:54:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:54:03 --> Utf8 Class Initialized
INFO - 2017-10-26 11:54:03 --> URI Class Initialized
INFO - 2017-10-26 11:54:03 --> Router Class Initialized
INFO - 2017-10-26 11:54:03 --> Output Class Initialized
INFO - 2017-10-26 11:54:03 --> Security Class Initialized
DEBUG - 2017-10-26 11:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:54:03 --> Input Class Initialized
INFO - 2017-10-26 11:54:03 --> Language Class Initialized
INFO - 2017-10-26 11:54:03 --> Loader Class Initialized
INFO - 2017-10-26 11:54:03 --> Helper loaded: url_helper
INFO - 2017-10-26 11:54:03 --> Helper loaded: common_helper
INFO - 2017-10-26 11:54:03 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:54:03 --> Email Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Controller Class Initialized
INFO - 2017-10-26 11:54:03 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Model Class Initialized
INFO - 2017-10-26 11:54:03 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:54:03 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:54:03 --> Final output sent to browser
DEBUG - 2017-10-26 11:54:03 --> Total execution time: 0.1209
INFO - 2017-10-26 11:55:56 --> Config Class Initialized
INFO - 2017-10-26 11:55:56 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:55:56 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:55:56 --> Utf8 Class Initialized
INFO - 2017-10-26 11:55:56 --> URI Class Initialized
INFO - 2017-10-26 11:55:56 --> Router Class Initialized
INFO - 2017-10-26 11:55:56 --> Output Class Initialized
INFO - 2017-10-26 11:55:56 --> Security Class Initialized
DEBUG - 2017-10-26 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:55:56 --> Input Class Initialized
INFO - 2017-10-26 11:55:56 --> Language Class Initialized
INFO - 2017-10-26 11:55:56 --> Loader Class Initialized
INFO - 2017-10-26 11:55:56 --> Helper loaded: url_helper
INFO - 2017-10-26 11:55:56 --> Helper loaded: common_helper
INFO - 2017-10-26 11:55:56 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:55:56 --> Email Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Controller Class Initialized
INFO - 2017-10-26 11:55:56 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Model Class Initialized
INFO - 2017-10-26 11:55:56 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:55:56 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: tx /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 80
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: st /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 81
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: amt /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 82
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: amt /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 83
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: cc /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 84
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined index: cm /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 89
ERROR - 2017-10-26 11:55:56 --> Severity: Notice --> Undefined offset: 1 /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 91
INFO - 2017-10-26 11:55:56 --> Final output sent to browser
DEBUG - 2017-10-26 11:55:56 --> Total execution time: 0.0187
INFO - 2017-10-26 11:57:04 --> Config Class Initialized
INFO - 2017-10-26 11:57:04 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:57:04 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:57:04 --> Utf8 Class Initialized
INFO - 2017-10-26 11:57:04 --> URI Class Initialized
DEBUG - 2017-10-26 11:57:04 --> No URI present. Default controller set.
INFO - 2017-10-26 11:57:04 --> Router Class Initialized
INFO - 2017-10-26 11:57:04 --> Output Class Initialized
INFO - 2017-10-26 11:57:04 --> Security Class Initialized
DEBUG - 2017-10-26 11:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:57:04 --> Input Class Initialized
INFO - 2017-10-26 11:57:04 --> Language Class Initialized
INFO - 2017-10-26 11:57:04 --> Loader Class Initialized
INFO - 2017-10-26 11:57:04 --> Helper loaded: url_helper
INFO - 2017-10-26 11:57:04 --> Helper loaded: common_helper
INFO - 2017-10-26 11:57:04 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:57:04 --> Email Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Controller Class Initialized
INFO - 2017-10-26 11:57:04 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> Model Class Initialized
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:57:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:57:04 --> Final output sent to browser
DEBUG - 2017-10-26 11:57:04 --> Total execution time: 0.0326
INFO - 2017-10-26 11:57:06 --> Config Class Initialized
INFO - 2017-10-26 11:57:06 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:57:06 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:57:06 --> Utf8 Class Initialized
INFO - 2017-10-26 11:57:06 --> URI Class Initialized
INFO - 2017-10-26 11:57:06 --> Router Class Initialized
INFO - 2017-10-26 11:57:06 --> Output Class Initialized
INFO - 2017-10-26 11:57:06 --> Security Class Initialized
DEBUG - 2017-10-26 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:57:06 --> Input Class Initialized
INFO - 2017-10-26 11:57:06 --> Language Class Initialized
INFO - 2017-10-26 11:57:06 --> Loader Class Initialized
INFO - 2017-10-26 11:57:06 --> Helper loaded: url_helper
INFO - 2017-10-26 11:57:06 --> Helper loaded: common_helper
INFO - 2017-10-26 11:57:06 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:57:06 --> Email Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Controller Class Initialized
INFO - 2017-10-26 11:57:06 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> Model Class Initialized
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:57:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:57:06 --> Final output sent to browser
DEBUG - 2017-10-26 11:57:06 --> Total execution time: 0.0218
INFO - 2017-10-26 11:57:09 --> Config Class Initialized
INFO - 2017-10-26 11:57:09 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:57:09 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:57:09 --> Utf8 Class Initialized
INFO - 2017-10-26 11:57:09 --> URI Class Initialized
INFO - 2017-10-26 11:57:09 --> Router Class Initialized
INFO - 2017-10-26 11:57:09 --> Output Class Initialized
INFO - 2017-10-26 11:57:09 --> Security Class Initialized
DEBUG - 2017-10-26 11:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:57:09 --> Input Class Initialized
INFO - 2017-10-26 11:57:09 --> Language Class Initialized
INFO - 2017-10-26 11:57:09 --> Loader Class Initialized
INFO - 2017-10-26 11:57:09 --> Helper loaded: url_helper
INFO - 2017-10-26 11:57:09 --> Helper loaded: common_helper
INFO - 2017-10-26 11:57:09 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:57:09 --> Email Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Controller Class Initialized
INFO - 2017-10-26 11:57:09 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> Model Class Initialized
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:57:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:57:09 --> Final output sent to browser
DEBUG - 2017-10-26 11:57:09 --> Total execution time: 0.0203
INFO - 2017-10-26 11:57:12 --> Config Class Initialized
INFO - 2017-10-26 11:57:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:57:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:57:12 --> Utf8 Class Initialized
INFO - 2017-10-26 11:57:12 --> URI Class Initialized
INFO - 2017-10-26 11:57:12 --> Router Class Initialized
INFO - 2017-10-26 11:57:12 --> Output Class Initialized
INFO - 2017-10-26 11:57:12 --> Security Class Initialized
DEBUG - 2017-10-26 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:57:12 --> Input Class Initialized
INFO - 2017-10-26 11:57:12 --> Language Class Initialized
INFO - 2017-10-26 11:57:12 --> Loader Class Initialized
INFO - 2017-10-26 11:57:12 --> Helper loaded: url_helper
INFO - 2017-10-26 11:57:12 --> Helper loaded: common_helper
INFO - 2017-10-26 11:57:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:57:12 --> Email Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Controller Class Initialized
INFO - 2017-10-26 11:57:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Model Class Initialized
INFO - 2017-10-26 11:57:12 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:57:12 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:57:12 --> Final output sent to browser
DEBUG - 2017-10-26 11:57:12 --> Total execution time: 0.0220
INFO - 2017-10-26 11:58:04 --> Config Class Initialized
INFO - 2017-10-26 11:58:04 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:04 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:04 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:04 --> URI Class Initialized
INFO - 2017-10-26 11:58:04 --> Router Class Initialized
INFO - 2017-10-26 11:58:04 --> Output Class Initialized
INFO - 2017-10-26 11:58:04 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:04 --> Input Class Initialized
INFO - 2017-10-26 11:58:04 --> Language Class Initialized
INFO - 2017-10-26 11:58:04 --> Loader Class Initialized
INFO - 2017-10-26 11:58:04 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:04 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:04 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:04 --> Email Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Controller Class Initialized
INFO - 2017-10-26 11:58:04 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Model Class Initialized
INFO - 2017-10-26 11:58:04 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:58:04 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:58:21 --> Config Class Initialized
INFO - 2017-10-26 11:58:21 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:21 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:21 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:21 --> URI Class Initialized
DEBUG - 2017-10-26 11:58:21 --> No URI present. Default controller set.
INFO - 2017-10-26 11:58:21 --> Router Class Initialized
INFO - 2017-10-26 11:58:21 --> Output Class Initialized
INFO - 2017-10-26 11:58:21 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:21 --> Input Class Initialized
INFO - 2017-10-26 11:58:21 --> Language Class Initialized
INFO - 2017-10-26 11:58:21 --> Loader Class Initialized
INFO - 2017-10-26 11:58:21 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:21 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:21 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:21 --> Email Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Controller Class Initialized
INFO - 2017-10-26 11:58:21 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> Model Class Initialized
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:58:21 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:58:21 --> Final output sent to browser
DEBUG - 2017-10-26 11:58:21 --> Total execution time: 0.0203
INFO - 2017-10-26 11:58:24 --> Config Class Initialized
INFO - 2017-10-26 11:58:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:24 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:24 --> URI Class Initialized
INFO - 2017-10-26 11:58:24 --> Router Class Initialized
INFO - 2017-10-26 11:58:24 --> Output Class Initialized
INFO - 2017-10-26 11:58:24 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:24 --> Input Class Initialized
INFO - 2017-10-26 11:58:24 --> Language Class Initialized
INFO - 2017-10-26 11:58:24 --> Loader Class Initialized
INFO - 2017-10-26 11:58:24 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:24 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:24 --> Email Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Controller Class Initialized
INFO - 2017-10-26 11:58:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> Model Class Initialized
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:58:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:58:24 --> Final output sent to browser
DEBUG - 2017-10-26 11:58:24 --> Total execution time: 0.0225
INFO - 2017-10-26 11:58:25 --> Config Class Initialized
INFO - 2017-10-26 11:58:25 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:25 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:25 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:25 --> URI Class Initialized
INFO - 2017-10-26 11:58:25 --> Router Class Initialized
INFO - 2017-10-26 11:58:25 --> Output Class Initialized
INFO - 2017-10-26 11:58:25 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:25 --> Input Class Initialized
INFO - 2017-10-26 11:58:25 --> Language Class Initialized
INFO - 2017-10-26 11:58:25 --> Loader Class Initialized
INFO - 2017-10-26 11:58:25 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:25 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:25 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:25 --> Email Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Controller Class Initialized
INFO - 2017-10-26 11:58:25 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> Model Class Initialized
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 11:58:25 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 11:58:25 --> Final output sent to browser
DEBUG - 2017-10-26 11:58:25 --> Total execution time: 0.0239
INFO - 2017-10-26 11:58:28 --> Config Class Initialized
INFO - 2017-10-26 11:58:28 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:28 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:28 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:28 --> URI Class Initialized
INFO - 2017-10-26 11:58:28 --> Router Class Initialized
INFO - 2017-10-26 11:58:28 --> Output Class Initialized
INFO - 2017-10-26 11:58:28 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:28 --> Input Class Initialized
INFO - 2017-10-26 11:58:28 --> Language Class Initialized
INFO - 2017-10-26 11:58:28 --> Loader Class Initialized
INFO - 2017-10-26 11:58:28 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:28 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:28 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:28 --> Email Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Controller Class Initialized
INFO - 2017-10-26 11:58:28 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Model Class Initialized
INFO - 2017-10-26 11:58:28 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:58:28 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:58:28 --> Final output sent to browser
DEBUG - 2017-10-26 11:58:28 --> Total execution time: 0.0265
INFO - 2017-10-26 11:58:51 --> Config Class Initialized
INFO - 2017-10-26 11:58:51 --> Hooks Class Initialized
DEBUG - 2017-10-26 11:58:51 --> UTF-8 Support Enabled
INFO - 2017-10-26 11:58:51 --> Utf8 Class Initialized
INFO - 2017-10-26 11:58:51 --> URI Class Initialized
INFO - 2017-10-26 11:58:51 --> Router Class Initialized
INFO - 2017-10-26 11:58:51 --> Output Class Initialized
INFO - 2017-10-26 11:58:51 --> Security Class Initialized
DEBUG - 2017-10-26 11:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 11:58:51 --> Input Class Initialized
INFO - 2017-10-26 11:58:51 --> Language Class Initialized
INFO - 2017-10-26 11:58:51 --> Loader Class Initialized
INFO - 2017-10-26 11:58:51 --> Helper loaded: url_helper
INFO - 2017-10-26 11:58:51 --> Helper loaded: common_helper
INFO - 2017-10-26 11:58:51 --> Database Driver Class Initialized
DEBUG - 2017-10-26 11:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 11:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 11:58:51 --> Email Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Controller Class Initialized
INFO - 2017-10-26 11:58:51 --> Helper loaded: cookie_helper
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
INFO - 2017-10-26 11:58:51 --> Helper loaded: form_helper
DEBUG - 2017-10-26 11:58:51 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 11:58:51 --> Model Class Initialized
ERROR - 2017-10-26 11:58:51 --> Query error: Column 'subscription_type' cannot be null - Invalid query: INSERT INTO `user_subscription` (`txn_id`, `user_id`, `item_id`, `item_name`, `category_id`, `gross_amount`, `currency`, `payer_email`, `subscription_date`, `subscription_expiry`, `subscription_type`) VALUES ('7EY38060HB443272P', '28', '3', 'Upgraded Usership 1€/month or 9,9€ for a year', '3', '1.00', 'EUR', '', '2017-10-26 11:58:51', '2017-11-26 11:58:51', NULL)
INFO - 2017-10-26 11:58:51 --> Language file loaded: language/english/db_lang.php
INFO - 2017-10-26 12:16:30 --> Config Class Initialized
INFO - 2017-10-26 12:16:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:16:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:16:30 --> Utf8 Class Initialized
INFO - 2017-10-26 12:16:30 --> URI Class Initialized
DEBUG - 2017-10-26 12:16:30 --> No URI present. Default controller set.
INFO - 2017-10-26 12:16:30 --> Router Class Initialized
INFO - 2017-10-26 12:16:30 --> Output Class Initialized
INFO - 2017-10-26 12:16:30 --> Security Class Initialized
DEBUG - 2017-10-26 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:16:30 --> Input Class Initialized
INFO - 2017-10-26 12:16:30 --> Language Class Initialized
INFO - 2017-10-26 12:16:30 --> Loader Class Initialized
INFO - 2017-10-26 12:16:30 --> Helper loaded: url_helper
INFO - 2017-10-26 12:16:30 --> Helper loaded: common_helper
INFO - 2017-10-26 12:16:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:16:30 --> Email Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Controller Class Initialized
INFO - 2017-10-26 12:16:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> Model Class Initialized
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:16:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:16:30 --> Final output sent to browser
DEBUG - 2017-10-26 12:16:30 --> Total execution time: 0.0934
INFO - 2017-10-26 12:16:34 --> Config Class Initialized
INFO - 2017-10-26 12:16:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:16:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:16:34 --> Utf8 Class Initialized
INFO - 2017-10-26 12:16:34 --> URI Class Initialized
INFO - 2017-10-26 12:16:34 --> Router Class Initialized
INFO - 2017-10-26 12:16:34 --> Output Class Initialized
INFO - 2017-10-26 12:16:34 --> Security Class Initialized
DEBUG - 2017-10-26 12:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:16:34 --> Input Class Initialized
INFO - 2017-10-26 12:16:34 --> Language Class Initialized
INFO - 2017-10-26 12:16:34 --> Loader Class Initialized
INFO - 2017-10-26 12:16:34 --> Helper loaded: url_helper
INFO - 2017-10-26 12:16:34 --> Helper loaded: common_helper
INFO - 2017-10-26 12:16:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:16:34 --> Email Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Controller Class Initialized
INFO - 2017-10-26 12:16:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> Model Class Initialized
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:16:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:16:34 --> Final output sent to browser
DEBUG - 2017-10-26 12:16:34 --> Total execution time: 0.1125
INFO - 2017-10-26 12:16:38 --> Config Class Initialized
INFO - 2017-10-26 12:16:38 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:16:38 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:16:38 --> Utf8 Class Initialized
INFO - 2017-10-26 12:16:38 --> URI Class Initialized
INFO - 2017-10-26 12:16:38 --> Router Class Initialized
INFO - 2017-10-26 12:16:38 --> Output Class Initialized
INFO - 2017-10-26 12:16:38 --> Security Class Initialized
DEBUG - 2017-10-26 12:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:16:38 --> Input Class Initialized
INFO - 2017-10-26 12:16:38 --> Language Class Initialized
INFO - 2017-10-26 12:16:38 --> Loader Class Initialized
INFO - 2017-10-26 12:16:38 --> Helper loaded: url_helper
INFO - 2017-10-26 12:16:38 --> Helper loaded: common_helper
INFO - 2017-10-26 12:16:38 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:16:38 --> Email Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Controller Class Initialized
INFO - 2017-10-26 12:16:38 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> Model Class Initialized
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:16:38 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:16:38 --> Final output sent to browser
DEBUG - 2017-10-26 12:16:38 --> Total execution time: 0.0716
INFO - 2017-10-26 12:16:42 --> Config Class Initialized
INFO - 2017-10-26 12:16:42 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:16:42 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:16:42 --> Utf8 Class Initialized
INFO - 2017-10-26 12:16:42 --> URI Class Initialized
INFO - 2017-10-26 12:16:42 --> Router Class Initialized
INFO - 2017-10-26 12:16:42 --> Output Class Initialized
INFO - 2017-10-26 12:16:42 --> Security Class Initialized
DEBUG - 2017-10-26 12:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:16:42 --> Input Class Initialized
INFO - 2017-10-26 12:16:42 --> Language Class Initialized
INFO - 2017-10-26 12:16:42 --> Loader Class Initialized
INFO - 2017-10-26 12:16:42 --> Helper loaded: url_helper
INFO - 2017-10-26 12:16:42 --> Helper loaded: common_helper
INFO - 2017-10-26 12:16:42 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:16:42 --> Email Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Controller Class Initialized
INFO - 2017-10-26 12:16:42 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Model Class Initialized
INFO - 2017-10-26 12:16:42 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:16:42 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:16:42 --> Final output sent to browser
DEBUG - 2017-10-26 12:16:42 --> Total execution time: 0.0504
INFO - 2017-10-26 12:17:08 --> Config Class Initialized
INFO - 2017-10-26 12:17:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:08 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:08 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:08 --> URI Class Initialized
INFO - 2017-10-26 12:17:08 --> Router Class Initialized
INFO - 2017-10-26 12:17:08 --> Output Class Initialized
INFO - 2017-10-26 12:17:08 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:08 --> Input Class Initialized
INFO - 2017-10-26 12:17:08 --> Language Class Initialized
ERROR - 2017-10-26 12:17:08 --> 404 Page Not Found: module/payment/Payment/cancel
INFO - 2017-10-26 12:17:12 --> Config Class Initialized
INFO - 2017-10-26 12:17:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:12 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:12 --> URI Class Initialized
DEBUG - 2017-10-26 12:17:12 --> No URI present. Default controller set.
INFO - 2017-10-26 12:17:12 --> Router Class Initialized
INFO - 2017-10-26 12:17:12 --> Output Class Initialized
INFO - 2017-10-26 12:17:12 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:12 --> Input Class Initialized
INFO - 2017-10-26 12:17:12 --> Language Class Initialized
INFO - 2017-10-26 12:17:12 --> Loader Class Initialized
INFO - 2017-10-26 12:17:12 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:12 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:12 --> Email Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Controller Class Initialized
INFO - 2017-10-26 12:17:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> Model Class Initialized
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:17:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:17:12 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:12 --> Total execution time: 0.0256
INFO - 2017-10-26 12:17:14 --> Config Class Initialized
INFO - 2017-10-26 12:17:14 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:14 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:14 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:14 --> URI Class Initialized
INFO - 2017-10-26 12:17:14 --> Router Class Initialized
INFO - 2017-10-26 12:17:14 --> Output Class Initialized
INFO - 2017-10-26 12:17:14 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:14 --> Input Class Initialized
INFO - 2017-10-26 12:17:14 --> Language Class Initialized
INFO - 2017-10-26 12:17:14 --> Loader Class Initialized
INFO - 2017-10-26 12:17:14 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:14 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:14 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:14 --> Email Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Controller Class Initialized
INFO - 2017-10-26 12:17:14 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> Model Class Initialized
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:17:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:17:14 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:14 --> Total execution time: 0.0256
INFO - 2017-10-26 12:17:16 --> Config Class Initialized
INFO - 2017-10-26 12:17:16 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:16 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:16 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:16 --> URI Class Initialized
INFO - 2017-10-26 12:17:16 --> Router Class Initialized
INFO - 2017-10-26 12:17:16 --> Output Class Initialized
INFO - 2017-10-26 12:17:16 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:16 --> Input Class Initialized
INFO - 2017-10-26 12:17:16 --> Language Class Initialized
INFO - 2017-10-26 12:17:16 --> Loader Class Initialized
INFO - 2017-10-26 12:17:16 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:16 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:16 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:16 --> Email Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Controller Class Initialized
INFO - 2017-10-26 12:17:16 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> Model Class Initialized
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:17:16 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:17:16 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:16 --> Total execution time: 0.0276
INFO - 2017-10-26 12:17:17 --> Config Class Initialized
INFO - 2017-10-26 12:17:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:17 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:17 --> URI Class Initialized
INFO - 2017-10-26 12:17:17 --> Router Class Initialized
INFO - 2017-10-26 12:17:17 --> Output Class Initialized
INFO - 2017-10-26 12:17:17 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:17 --> Input Class Initialized
INFO - 2017-10-26 12:17:17 --> Language Class Initialized
INFO - 2017-10-26 12:17:17 --> Loader Class Initialized
INFO - 2017-10-26 12:17:17 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:17 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:17 --> Email Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Controller Class Initialized
INFO - 2017-10-26 12:17:17 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:17 --> Model Class Initialized
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:17:18 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:17:18 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:18 --> Total execution time: 0.0268
INFO - 2017-10-26 12:17:21 --> Config Class Initialized
INFO - 2017-10-26 12:17:21 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:21 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:21 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:21 --> URI Class Initialized
INFO - 2017-10-26 12:17:21 --> Router Class Initialized
INFO - 2017-10-26 12:17:21 --> Output Class Initialized
INFO - 2017-10-26 12:17:21 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:21 --> Input Class Initialized
INFO - 2017-10-26 12:17:21 --> Language Class Initialized
INFO - 2017-10-26 12:17:21 --> Loader Class Initialized
INFO - 2017-10-26 12:17:21 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:21 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:21 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:21 --> Email Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Controller Class Initialized
INFO - 2017-10-26 12:17:21 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Model Class Initialized
INFO - 2017-10-26 12:17:21 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:17:21 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:17:21 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:21 --> Total execution time: 0.0378
INFO - 2017-10-26 12:17:47 --> Config Class Initialized
INFO - 2017-10-26 12:17:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:47 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:47 --> URI Class Initialized
INFO - 2017-10-26 12:17:47 --> Router Class Initialized
INFO - 2017-10-26 12:17:47 --> Output Class Initialized
INFO - 2017-10-26 12:17:47 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:47 --> Input Class Initialized
INFO - 2017-10-26 12:17:47 --> Language Class Initialized
INFO - 2017-10-26 12:17:47 --> Loader Class Initialized
INFO - 2017-10-26 12:17:47 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:47 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:47 --> Email Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Controller Class Initialized
INFO - 2017-10-26 12:17:47 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:17:47 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Config Class Initialized
INFO - 2017-10-26 12:17:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:17:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:17:47 --> Utf8 Class Initialized
INFO - 2017-10-26 12:17:47 --> URI Class Initialized
INFO - 2017-10-26 12:17:47 --> Router Class Initialized
INFO - 2017-10-26 12:17:47 --> Output Class Initialized
INFO - 2017-10-26 12:17:47 --> Security Class Initialized
DEBUG - 2017-10-26 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:17:47 --> Input Class Initialized
INFO - 2017-10-26 12:17:47 --> Language Class Initialized
INFO - 2017-10-26 12:17:47 --> Loader Class Initialized
INFO - 2017-10-26 12:17:47 --> Helper loaded: url_helper
INFO - 2017-10-26 12:17:47 --> Helper loaded: common_helper
INFO - 2017-10-26 12:17:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:17:47 --> Email Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Controller Class Initialized
INFO - 2017-10-26 12:17:47 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> Model Class Initialized
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/home.php
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:17:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:17:47 --> Final output sent to browser
DEBUG - 2017-10-26 12:17:47 --> Total execution time: 0.0637
INFO - 2017-10-26 12:19:13 --> Config Class Initialized
INFO - 2017-10-26 12:19:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:19:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:19:13 --> Utf8 Class Initialized
INFO - 2017-10-26 12:19:13 --> URI Class Initialized
INFO - 2017-10-26 12:19:13 --> Router Class Initialized
INFO - 2017-10-26 12:19:13 --> Output Class Initialized
INFO - 2017-10-26 12:19:13 --> Security Class Initialized
DEBUG - 2017-10-26 12:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:19:13 --> Input Class Initialized
INFO - 2017-10-26 12:19:13 --> Language Class Initialized
INFO - 2017-10-26 12:19:13 --> Loader Class Initialized
INFO - 2017-10-26 12:19:13 --> Helper loaded: url_helper
INFO - 2017-10-26 12:19:13 --> Helper loaded: common_helper
INFO - 2017-10-26 12:19:13 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:19:13 --> Email Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Controller Class Initialized
INFO - 2017-10-26 12:19:13 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> Model Class Initialized
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:19:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:19:13 --> Final output sent to browser
DEBUG - 2017-10-26 12:19:13 --> Total execution time: 0.0317
INFO - 2017-10-26 12:19:24 --> Config Class Initialized
INFO - 2017-10-26 12:19:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:19:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:19:24 --> Utf8 Class Initialized
INFO - 2017-10-26 12:19:24 --> URI Class Initialized
INFO - 2017-10-26 12:19:24 --> Router Class Initialized
INFO - 2017-10-26 12:19:24 --> Output Class Initialized
INFO - 2017-10-26 12:19:24 --> Security Class Initialized
DEBUG - 2017-10-26 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:19:24 --> Input Class Initialized
INFO - 2017-10-26 12:19:24 --> Language Class Initialized
INFO - 2017-10-26 12:19:24 --> Loader Class Initialized
INFO - 2017-10-26 12:19:24 --> Helper loaded: url_helper
INFO - 2017-10-26 12:19:24 --> Helper loaded: common_helper
INFO - 2017-10-26 12:19:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:19:24 --> Email Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Controller Class Initialized
INFO - 2017-10-26 12:19:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> Model Class Initialized
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:19:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:19:24 --> Final output sent to browser
DEBUG - 2017-10-26 12:19:24 --> Total execution time: 0.0204
INFO - 2017-10-26 12:19:30 --> Config Class Initialized
INFO - 2017-10-26 12:19:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:19:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:19:30 --> Utf8 Class Initialized
INFO - 2017-10-26 12:19:30 --> URI Class Initialized
INFO - 2017-10-26 12:19:30 --> Router Class Initialized
INFO - 2017-10-26 12:19:30 --> Output Class Initialized
INFO - 2017-10-26 12:19:30 --> Security Class Initialized
DEBUG - 2017-10-26 12:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:19:30 --> Input Class Initialized
INFO - 2017-10-26 12:19:30 --> Language Class Initialized
INFO - 2017-10-26 12:19:30 --> Loader Class Initialized
INFO - 2017-10-26 12:19:30 --> Helper loaded: url_helper
INFO - 2017-10-26 12:19:30 --> Helper loaded: common_helper
INFO - 2017-10-26 12:19:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:19:30 --> Email Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Controller Class Initialized
INFO - 2017-10-26 12:19:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> Model Class Initialized
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:19:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:19:30 --> Final output sent to browser
DEBUG - 2017-10-26 12:19:30 --> Total execution time: 0.0198
INFO - 2017-10-26 12:19:57 --> Config Class Initialized
INFO - 2017-10-26 12:19:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:19:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:19:57 --> Utf8 Class Initialized
INFO - 2017-10-26 12:19:57 --> URI Class Initialized
INFO - 2017-10-26 12:19:57 --> Router Class Initialized
INFO - 2017-10-26 12:19:57 --> Output Class Initialized
INFO - 2017-10-26 12:19:57 --> Security Class Initialized
DEBUG - 2017-10-26 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:19:57 --> Input Class Initialized
INFO - 2017-10-26 12:19:57 --> Language Class Initialized
INFO - 2017-10-26 12:19:57 --> Loader Class Initialized
INFO - 2017-10-26 12:19:57 --> Helper loaded: url_helper
INFO - 2017-10-26 12:19:57 --> Helper loaded: common_helper
INFO - 2017-10-26 12:19:57 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:19:57 --> Email Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Controller Class Initialized
INFO - 2017-10-26 12:19:57 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Model Class Initialized
INFO - 2017-10-26 12:19:57 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:19:57 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:19:57 --> Final output sent to browser
DEBUG - 2017-10-26 12:19:57 --> Total execution time: 0.0264
INFO - 2017-10-26 12:20:15 --> Config Class Initialized
INFO - 2017-10-26 12:20:15 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:20:15 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:20:15 --> Utf8 Class Initialized
INFO - 2017-10-26 12:20:15 --> URI Class Initialized
INFO - 2017-10-26 12:20:15 --> Router Class Initialized
INFO - 2017-10-26 12:20:15 --> Output Class Initialized
INFO - 2017-10-26 12:20:15 --> Security Class Initialized
DEBUG - 2017-10-26 12:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:20:15 --> Input Class Initialized
INFO - 2017-10-26 12:20:15 --> Language Class Initialized
INFO - 2017-10-26 12:20:15 --> Loader Class Initialized
INFO - 2017-10-26 12:20:15 --> Helper loaded: url_helper
INFO - 2017-10-26 12:20:15 --> Helper loaded: common_helper
INFO - 2017-10-26 12:20:15 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:20:15 --> Email Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Controller Class Initialized
INFO - 2017-10-26 12:20:15 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> Model Class Initialized
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:20:15 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:20:15 --> Final output sent to browser
DEBUG - 2017-10-26 12:20:15 --> Total execution time: 0.0789
INFO - 2017-10-26 12:22:33 --> Config Class Initialized
INFO - 2017-10-26 12:22:33 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:22:33 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:22:33 --> Utf8 Class Initialized
INFO - 2017-10-26 12:22:33 --> URI Class Initialized
INFO - 2017-10-26 12:22:33 --> Router Class Initialized
INFO - 2017-10-26 12:22:33 --> Output Class Initialized
INFO - 2017-10-26 12:22:33 --> Security Class Initialized
DEBUG - 2017-10-26 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:22:33 --> Input Class Initialized
INFO - 2017-10-26 12:22:33 --> Language Class Initialized
INFO - 2017-10-26 12:22:33 --> Loader Class Initialized
INFO - 2017-10-26 12:22:33 --> Helper loaded: url_helper
INFO - 2017-10-26 12:22:33 --> Helper loaded: common_helper
INFO - 2017-10-26 12:22:33 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:22:33 --> Email Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Controller Class Initialized
INFO - 2017-10-26 12:22:33 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> Model Class Initialized
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:22:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:22:33 --> Final output sent to browser
DEBUG - 2017-10-26 12:22:33 --> Total execution time: 0.0246
INFO - 2017-10-26 12:22:38 --> Config Class Initialized
INFO - 2017-10-26 12:22:38 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:22:38 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:22:38 --> Utf8 Class Initialized
INFO - 2017-10-26 12:22:38 --> URI Class Initialized
INFO - 2017-10-26 12:22:38 --> Router Class Initialized
INFO - 2017-10-26 12:22:38 --> Output Class Initialized
INFO - 2017-10-26 12:22:38 --> Security Class Initialized
DEBUG - 2017-10-26 12:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:22:38 --> Input Class Initialized
INFO - 2017-10-26 12:22:38 --> Language Class Initialized
INFO - 2017-10-26 12:22:38 --> Loader Class Initialized
INFO - 2017-10-26 12:22:38 --> Helper loaded: url_helper
INFO - 2017-10-26 12:22:38 --> Helper loaded: common_helper
INFO - 2017-10-26 12:22:38 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:22:38 --> Email Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Controller Class Initialized
INFO - 2017-10-26 12:22:38 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Model Class Initialized
INFO - 2017-10-26 12:22:38 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:22:38 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:22:38 --> Final output sent to browser
DEBUG - 2017-10-26 12:22:38 --> Total execution time: 0.0231
INFO - 2017-10-26 12:22:53 --> Config Class Initialized
INFO - 2017-10-26 12:22:53 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:22:53 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:22:53 --> Utf8 Class Initialized
INFO - 2017-10-26 12:22:53 --> URI Class Initialized
INFO - 2017-10-26 12:22:53 --> Router Class Initialized
INFO - 2017-10-26 12:22:53 --> Output Class Initialized
INFO - 2017-10-26 12:22:53 --> Security Class Initialized
DEBUG - 2017-10-26 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:22:53 --> Input Class Initialized
INFO - 2017-10-26 12:22:53 --> Language Class Initialized
ERROR - 2017-10-26 12:22:53 --> 404 Page Not Found: module/payment/Payment/cancel
INFO - 2017-10-26 12:22:57 --> Config Class Initialized
INFO - 2017-10-26 12:22:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:22:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:22:57 --> Utf8 Class Initialized
INFO - 2017-10-26 12:22:57 --> URI Class Initialized
DEBUG - 2017-10-26 12:22:57 --> No URI present. Default controller set.
INFO - 2017-10-26 12:22:57 --> Router Class Initialized
INFO - 2017-10-26 12:22:57 --> Output Class Initialized
INFO - 2017-10-26 12:22:57 --> Security Class Initialized
DEBUG - 2017-10-26 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:22:57 --> Input Class Initialized
INFO - 2017-10-26 12:22:57 --> Language Class Initialized
INFO - 2017-10-26 12:22:57 --> Loader Class Initialized
INFO - 2017-10-26 12:22:57 --> Helper loaded: url_helper
INFO - 2017-10-26 12:22:57 --> Helper loaded: common_helper
INFO - 2017-10-26 12:22:57 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:22:57 --> Email Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Controller Class Initialized
INFO - 2017-10-26 12:22:57 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> Model Class Initialized
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:22:57 --> Final output sent to browser
DEBUG - 2017-10-26 12:22:57 --> Total execution time: 0.1090
INFO - 2017-10-26 12:23:33 --> Config Class Initialized
INFO - 2017-10-26 12:23:33 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:23:33 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:23:33 --> Utf8 Class Initialized
INFO - 2017-10-26 12:23:33 --> URI Class Initialized
DEBUG - 2017-10-26 12:23:33 --> No URI present. Default controller set.
INFO - 2017-10-26 12:23:33 --> Router Class Initialized
INFO - 2017-10-26 12:23:33 --> Output Class Initialized
INFO - 2017-10-26 12:23:33 --> Security Class Initialized
DEBUG - 2017-10-26 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:23:33 --> Input Class Initialized
INFO - 2017-10-26 12:23:33 --> Language Class Initialized
INFO - 2017-10-26 12:23:33 --> Loader Class Initialized
INFO - 2017-10-26 12:23:33 --> Helper loaded: url_helper
INFO - 2017-10-26 12:23:33 --> Helper loaded: common_helper
INFO - 2017-10-26 12:23:33 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:23:33 --> Email Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Controller Class Initialized
INFO - 2017-10-26 12:23:33 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> Model Class Initialized
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:23:33 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:23:33 --> Final output sent to browser
DEBUG - 2017-10-26 12:23:33 --> Total execution time: 0.0924
INFO - 2017-10-26 12:23:37 --> Config Class Initialized
INFO - 2017-10-26 12:23:37 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:23:37 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:23:37 --> Utf8 Class Initialized
INFO - 2017-10-26 12:23:37 --> URI Class Initialized
INFO - 2017-10-26 12:23:37 --> Router Class Initialized
INFO - 2017-10-26 12:23:37 --> Output Class Initialized
INFO - 2017-10-26 12:23:37 --> Security Class Initialized
DEBUG - 2017-10-26 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:23:37 --> Input Class Initialized
INFO - 2017-10-26 12:23:37 --> Language Class Initialized
INFO - 2017-10-26 12:23:37 --> Loader Class Initialized
INFO - 2017-10-26 12:23:37 --> Helper loaded: url_helper
INFO - 2017-10-26 12:23:37 --> Helper loaded: common_helper
INFO - 2017-10-26 12:23:37 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:23:37 --> Email Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Controller Class Initialized
INFO - 2017-10-26 12:23:37 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> Model Class Initialized
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:23:37 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:23:37 --> Final output sent to browser
DEBUG - 2017-10-26 12:23:37 --> Total execution time: 0.1295
INFO - 2017-10-26 12:23:44 --> Config Class Initialized
INFO - 2017-10-26 12:23:44 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:23:44 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:23:44 --> Utf8 Class Initialized
INFO - 2017-10-26 12:23:44 --> URI Class Initialized
INFO - 2017-10-26 12:23:44 --> Router Class Initialized
INFO - 2017-10-26 12:23:44 --> Output Class Initialized
INFO - 2017-10-26 12:23:44 --> Security Class Initialized
DEBUG - 2017-10-26 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:23:44 --> Input Class Initialized
INFO - 2017-10-26 12:23:44 --> Language Class Initialized
INFO - 2017-10-26 12:23:44 --> Loader Class Initialized
INFO - 2017-10-26 12:23:44 --> Helper loaded: url_helper
INFO - 2017-10-26 12:23:44 --> Helper loaded: common_helper
INFO - 2017-10-26 12:23:44 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:23:44 --> Email Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Controller Class Initialized
INFO - 2017-10-26 12:23:44 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> Model Class Initialized
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:23:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:23:44 --> Final output sent to browser
DEBUG - 2017-10-26 12:23:44 --> Total execution time: 0.0927
INFO - 2017-10-26 12:23:51 --> Config Class Initialized
INFO - 2017-10-26 12:23:51 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:23:51 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:23:51 --> Utf8 Class Initialized
INFO - 2017-10-26 12:23:51 --> URI Class Initialized
INFO - 2017-10-26 12:23:51 --> Router Class Initialized
INFO - 2017-10-26 12:23:51 --> Output Class Initialized
INFO - 2017-10-26 12:23:51 --> Security Class Initialized
DEBUG - 2017-10-26 12:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:23:51 --> Input Class Initialized
INFO - 2017-10-26 12:23:51 --> Language Class Initialized
INFO - 2017-10-26 12:23:51 --> Loader Class Initialized
INFO - 2017-10-26 12:23:51 --> Helper loaded: url_helper
INFO - 2017-10-26 12:23:51 --> Helper loaded: common_helper
INFO - 2017-10-26 12:23:51 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:23:51 --> Email Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Controller Class Initialized
INFO - 2017-10-26 12:23:51 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:51 --> Model Class Initialized
INFO - 2017-10-26 12:23:52 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:23:52 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:23:52 --> Final output sent to browser
DEBUG - 2017-10-26 12:23:52 --> Total execution time: 0.0688
INFO - 2017-10-26 12:26:35 --> Config Class Initialized
INFO - 2017-10-26 12:26:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:26:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:26:35 --> Utf8 Class Initialized
INFO - 2017-10-26 12:26:35 --> URI Class Initialized
INFO - 2017-10-26 12:26:35 --> Router Class Initialized
INFO - 2017-10-26 12:26:35 --> Output Class Initialized
INFO - 2017-10-26 12:26:35 --> Security Class Initialized
DEBUG - 2017-10-26 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:26:35 --> Input Class Initialized
INFO - 2017-10-26 12:26:35 --> Language Class Initialized
INFO - 2017-10-26 12:26:35 --> Loader Class Initialized
INFO - 2017-10-26 12:26:35 --> Helper loaded: url_helper
INFO - 2017-10-26 12:26:35 --> Helper loaded: common_helper
INFO - 2017-10-26 12:26:35 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:26:35 --> Email Class Initialized
INFO - 2017-10-26 12:26:35 --> Model Class Initialized
INFO - 2017-10-26 12:26:35 --> Controller Class Initialized
INFO - 2017-10-26 12:26:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:26:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:26:35 --> Final output sent to browser
DEBUG - 2017-10-26 12:26:35 --> Total execution time: 0.0776
INFO - 2017-10-26 12:26:50 --> Config Class Initialized
INFO - 2017-10-26 12:26:50 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:26:50 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:26:50 --> Utf8 Class Initialized
INFO - 2017-10-26 12:26:50 --> URI Class Initialized
INFO - 2017-10-26 12:26:50 --> Router Class Initialized
INFO - 2017-10-26 12:26:50 --> Output Class Initialized
INFO - 2017-10-26 12:26:50 --> Security Class Initialized
DEBUG - 2017-10-26 12:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:26:50 --> Input Class Initialized
INFO - 2017-10-26 12:26:50 --> Language Class Initialized
INFO - 2017-10-26 12:26:50 --> Loader Class Initialized
INFO - 2017-10-26 12:26:50 --> Helper loaded: url_helper
INFO - 2017-10-26 12:26:50 --> Helper loaded: common_helper
INFO - 2017-10-26 12:26:50 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:26:50 --> Email Class Initialized
INFO - 2017-10-26 12:26:50 --> Model Class Initialized
INFO - 2017-10-26 12:26:50 --> Controller Class Initialized
INFO - 2017-10-26 12:26:51 --> Model Class Initialized
INFO - 2017-10-26 12:26:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:26:51 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:26:51 --> Final output sent to browser
DEBUG - 2017-10-26 12:26:51 --> Total execution time: 0.0554
INFO - 2017-10-26 12:26:55 --> Config Class Initialized
INFO - 2017-10-26 12:26:55 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:26:55 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:26:55 --> Utf8 Class Initialized
INFO - 2017-10-26 12:26:55 --> URI Class Initialized
INFO - 2017-10-26 12:26:55 --> Router Class Initialized
INFO - 2017-10-26 12:26:55 --> Output Class Initialized
INFO - 2017-10-26 12:26:55 --> Security Class Initialized
DEBUG - 2017-10-26 12:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:26:55 --> Input Class Initialized
INFO - 2017-10-26 12:26:55 --> Language Class Initialized
INFO - 2017-10-26 12:26:55 --> Loader Class Initialized
INFO - 2017-10-26 12:26:55 --> Helper loaded: url_helper
INFO - 2017-10-26 12:26:55 --> Helper loaded: common_helper
INFO - 2017-10-26 12:26:55 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:26:55 --> Email Class Initialized
INFO - 2017-10-26 12:26:55 --> Model Class Initialized
INFO - 2017-10-26 12:26:55 --> Controller Class Initialized
INFO - 2017-10-26 12:26:55 --> Model Class Initialized
INFO - 2017-10-26 12:26:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:26:55 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:26:55 --> Final output sent to browser
DEBUG - 2017-10-26 12:26:55 --> Total execution time: 0.0028
INFO - 2017-10-26 12:27:09 --> Config Class Initialized
INFO - 2017-10-26 12:27:09 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:09 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:09 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:09 --> URI Class Initialized
INFO - 2017-10-26 12:27:09 --> Router Class Initialized
INFO - 2017-10-26 12:27:09 --> Output Class Initialized
INFO - 2017-10-26 12:27:09 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:09 --> Input Class Initialized
INFO - 2017-10-26 12:27:09 --> Language Class Initialized
INFO - 2017-10-26 12:27:09 --> Loader Class Initialized
INFO - 2017-10-26 12:27:09 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:09 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:09 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:09 --> Email Class Initialized
INFO - 2017-10-26 12:27:09 --> Model Class Initialized
INFO - 2017-10-26 12:27:09 --> Controller Class Initialized
INFO - 2017-10-26 12:27:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:27:09 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:27:09 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:09 --> Total execution time: 0.0104
INFO - 2017-10-26 12:27:22 --> Config Class Initialized
INFO - 2017-10-26 12:27:22 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:22 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:22 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:22 --> URI Class Initialized
INFO - 2017-10-26 12:27:22 --> Router Class Initialized
INFO - 2017-10-26 12:27:22 --> Output Class Initialized
INFO - 2017-10-26 12:27:22 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:22 --> Input Class Initialized
INFO - 2017-10-26 12:27:22 --> Language Class Initialized
INFO - 2017-10-26 12:27:22 --> Loader Class Initialized
INFO - 2017-10-26 12:27:22 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:22 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:22 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:22 --> Email Class Initialized
INFO - 2017-10-26 12:27:22 --> Model Class Initialized
INFO - 2017-10-26 12:27:22 --> Controller Class Initialized
INFO - 2017-10-26 12:27:22 --> Model Class Initialized
INFO - 2017-10-26 12:27:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:27:22 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:27:22 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:22 --> Total execution time: 0.0024
INFO - 2017-10-26 12:27:28 --> Config Class Initialized
INFO - 2017-10-26 12:27:28 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:28 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:28 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:28 --> URI Class Initialized
INFO - 2017-10-26 12:27:28 --> Router Class Initialized
INFO - 2017-10-26 12:27:28 --> Output Class Initialized
INFO - 2017-10-26 12:27:28 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:28 --> Input Class Initialized
INFO - 2017-10-26 12:27:28 --> Language Class Initialized
INFO - 2017-10-26 12:27:28 --> Loader Class Initialized
INFO - 2017-10-26 12:27:28 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:28 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:28 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:28 --> Email Class Initialized
INFO - 2017-10-26 12:27:28 --> Model Class Initialized
INFO - 2017-10-26 12:27:28 --> Controller Class Initialized
INFO - 2017-10-26 12:27:28 --> Model Class Initialized
INFO - 2017-10-26 12:27:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:27:28 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:27:28 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:28 --> Total execution time: 0.0061
INFO - 2017-10-26 12:27:34 --> Config Class Initialized
INFO - 2017-10-26 12:27:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:34 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:34 --> URI Class Initialized
INFO - 2017-10-26 12:27:34 --> Router Class Initialized
INFO - 2017-10-26 12:27:34 --> Output Class Initialized
INFO - 2017-10-26 12:27:34 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:34 --> Input Class Initialized
INFO - 2017-10-26 12:27:34 --> Language Class Initialized
INFO - 2017-10-26 12:27:34 --> Loader Class Initialized
INFO - 2017-10-26 12:27:34 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:34 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:34 --> Email Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Controller Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Config Class Initialized
INFO - 2017-10-26 12:27:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:34 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:34 --> URI Class Initialized
INFO - 2017-10-26 12:27:34 --> Router Class Initialized
INFO - 2017-10-26 12:27:34 --> Output Class Initialized
INFO - 2017-10-26 12:27:34 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:34 --> Input Class Initialized
INFO - 2017-10-26 12:27:34 --> Language Class Initialized
INFO - 2017-10-26 12:27:34 --> Loader Class Initialized
INFO - 2017-10-26 12:27:34 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:34 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:34 --> Email Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Controller Class Initialized
INFO - 2017-10-26 12:27:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 12:27:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> Model Class Initialized
INFO - 2017-10-26 12:27:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-10-26 12:27:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 12:27:34 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 12:27:34 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:34 --> Total execution time: 0.2039
INFO - 2017-10-26 12:27:35 --> Config Class Initialized
INFO - 2017-10-26 12:27:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:35 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:35 --> URI Class Initialized
INFO - 2017-10-26 12:27:35 --> Router Class Initialized
INFO - 2017-10-26 12:27:35 --> Output Class Initialized
INFO - 2017-10-26 12:27:35 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:35 --> Input Class Initialized
INFO - 2017-10-26 12:27:35 --> Language Class Initialized
ERROR - 2017-10-26 12:27:35 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:27:35 --> Config Class Initialized
INFO - 2017-10-26 12:27:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:35 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:35 --> URI Class Initialized
INFO - 2017-10-26 12:27:35 --> Router Class Initialized
INFO - 2017-10-26 12:27:35 --> Output Class Initialized
INFO - 2017-10-26 12:27:35 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:35 --> Input Class Initialized
INFO - 2017-10-26 12:27:35 --> Language Class Initialized
ERROR - 2017-10-26 12:27:35 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:27:40 --> Config Class Initialized
INFO - 2017-10-26 12:27:40 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:40 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:40 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:40 --> URI Class Initialized
INFO - 2017-10-26 12:27:40 --> Router Class Initialized
INFO - 2017-10-26 12:27:40 --> Output Class Initialized
INFO - 2017-10-26 12:27:40 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:40 --> Input Class Initialized
INFO - 2017-10-26 12:27:40 --> Language Class Initialized
INFO - 2017-10-26 12:27:40 --> Loader Class Initialized
INFO - 2017-10-26 12:27:40 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:40 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:40 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:40 --> Email Class Initialized
INFO - 2017-10-26 12:27:40 --> Model Class Initialized
INFO - 2017-10-26 12:27:40 --> Controller Class Initialized
INFO - 2017-10-26 12:27:40 --> Model Class Initialized
INFO - 2017-10-26 12:27:40 --> Config Class Initialized
INFO - 2017-10-26 12:27:40 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:40 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:40 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:40 --> URI Class Initialized
INFO - 2017-10-26 12:27:40 --> Router Class Initialized
INFO - 2017-10-26 12:27:40 --> Output Class Initialized
INFO - 2017-10-26 12:27:40 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:40 --> Input Class Initialized
INFO - 2017-10-26 12:27:40 --> Language Class Initialized
INFO - 2017-10-26 12:27:40 --> Loader Class Initialized
INFO - 2017-10-26 12:27:40 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:40 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:40 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:40 --> Email Class Initialized
INFO - 2017-10-26 12:27:40 --> Model Class Initialized
INFO - 2017-10-26 12:27:40 --> Controller Class Initialized
INFO - 2017-10-26 12:27:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module//auth/login.php
INFO - 2017-10-26 12:27:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/public_default_template.php
INFO - 2017-10-26 12:27:40 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:40 --> Total execution time: 0.0028
INFO - 2017-10-26 12:27:47 --> Config Class Initialized
INFO - 2017-10-26 12:27:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:47 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:47 --> URI Class Initialized
INFO - 2017-10-26 12:27:47 --> Router Class Initialized
INFO - 2017-10-26 12:27:47 --> Output Class Initialized
INFO - 2017-10-26 12:27:47 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:47 --> Input Class Initialized
INFO - 2017-10-26 12:27:47 --> Language Class Initialized
INFO - 2017-10-26 12:27:47 --> Loader Class Initialized
INFO - 2017-10-26 12:27:47 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:47 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:47 --> Email Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Controller Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Config Class Initialized
INFO - 2017-10-26 12:27:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:47 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:47 --> URI Class Initialized
INFO - 2017-10-26 12:27:47 --> Router Class Initialized
INFO - 2017-10-26 12:27:47 --> Output Class Initialized
INFO - 2017-10-26 12:27:47 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:47 --> Input Class Initialized
INFO - 2017-10-26 12:27:47 --> Language Class Initialized
INFO - 2017-10-26 12:27:47 --> Loader Class Initialized
INFO - 2017-10-26 12:27:47 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:47 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:47 --> Email Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Controller Class Initialized
INFO - 2017-10-26 12:27:47 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 12:27:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> Model Class Initialized
INFO - 2017-10-26 12:27:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-10-26 12:27:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 12:27:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 12:27:47 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:47 --> Total execution time: 0.0543
INFO - 2017-10-26 12:27:48 --> Config Class Initialized
INFO - 2017-10-26 12:27:48 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:48 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:48 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:48 --> URI Class Initialized
INFO - 2017-10-26 12:27:48 --> Router Class Initialized
INFO - 2017-10-26 12:27:48 --> Output Class Initialized
INFO - 2017-10-26 12:27:48 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:48 --> Input Class Initialized
INFO - 2017-10-26 12:27:48 --> Language Class Initialized
ERROR - 2017-10-26 12:27:48 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:27:48 --> Config Class Initialized
INFO - 2017-10-26 12:27:48 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:48 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:48 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:48 --> URI Class Initialized
INFO - 2017-10-26 12:27:48 --> Router Class Initialized
INFO - 2017-10-26 12:27:48 --> Output Class Initialized
INFO - 2017-10-26 12:27:48 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:48 --> Input Class Initialized
INFO - 2017-10-26 12:27:48 --> Language Class Initialized
ERROR - 2017-10-26 12:27:48 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:27:56 --> Config Class Initialized
INFO - 2017-10-26 12:27:56 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:56 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:56 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:56 --> URI Class Initialized
INFO - 2017-10-26 12:27:56 --> Router Class Initialized
INFO - 2017-10-26 12:27:56 --> Output Class Initialized
INFO - 2017-10-26 12:27:56 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:56 --> Input Class Initialized
INFO - 2017-10-26 12:27:56 --> Language Class Initialized
INFO - 2017-10-26 12:27:56 --> Loader Class Initialized
INFO - 2017-10-26 12:27:56 --> Helper loaded: url_helper
INFO - 2017-10-26 12:27:56 --> Helper loaded: common_helper
INFO - 2017-10-26 12:27:56 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:27:56 --> Email Class Initialized
INFO - 2017-10-26 12:27:56 --> Model Class Initialized
INFO - 2017-10-26 12:27:56 --> Controller Class Initialized
INFO - 2017-10-26 12:27:56 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:27:56 --> Model Class Initialized
INFO - 2017-10-26 12:27:56 --> Model Class Initialized
INFO - 2017-10-26 12:27:56 --> Model Class Initialized
INFO - 2017-10-26 12:27:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 12:27:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 12:27:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/order/manage_subscriptions.php
INFO - 2017-10-26 12:27:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 12:27:56 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 12:27:56 --> Final output sent to browser
DEBUG - 2017-10-26 12:27:56 --> Total execution time: 0.0096
INFO - 2017-10-26 12:27:56 --> Config Class Initialized
INFO - 2017-10-26 12:27:56 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:56 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:56 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:56 --> URI Class Initialized
INFO - 2017-10-26 12:27:56 --> Router Class Initialized
INFO - 2017-10-26 12:27:56 --> Output Class Initialized
INFO - 2017-10-26 12:27:56 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:56 --> Input Class Initialized
INFO - 2017-10-26 12:27:56 --> Language Class Initialized
ERROR - 2017-10-26 12:27:56 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:27:56 --> Config Class Initialized
INFO - 2017-10-26 12:27:56 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:27:56 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:27:56 --> Utf8 Class Initialized
INFO - 2017-10-26 12:27:56 --> URI Class Initialized
INFO - 2017-10-26 12:27:56 --> Router Class Initialized
INFO - 2017-10-26 12:27:56 --> Output Class Initialized
INFO - 2017-10-26 12:27:56 --> Security Class Initialized
DEBUG - 2017-10-26 12:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:27:56 --> Input Class Initialized
INFO - 2017-10-26 12:27:56 --> Language Class Initialized
ERROR - 2017-10-26 12:27:56 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
INFO - 2017-10-26 12:28:02 --> Loader Class Initialized
INFO - 2017-10-26 12:28:02 --> Helper loaded: url_helper
INFO - 2017-10-26 12:28:02 --> Helper loaded: common_helper
INFO - 2017-10-26 12:28:02 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:28:02 --> Email Class Initialized
INFO - 2017-10-26 12:28:02 --> Model Class Initialized
INFO - 2017-10-26 12:28:02 --> Controller Class Initialized
INFO - 2017-10-26 12:28:02 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:28:02 --> Model Class Initialized
INFO - 2017-10-26 12:28:02 --> Model Class Initialized
INFO - 2017-10-26 12:28:02 --> Model Class Initialized
INFO - 2017-10-26 12:28:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 12:28:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 12:28:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/manage_membership.php
INFO - 2017-10-26 12:28:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 12:28:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 12:28:02 --> Final output sent to browser
DEBUG - 2017-10-26 12:28:02 --> Total execution time: 0.0188
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Config Class Initialized
INFO - 2017-10-26 12:28:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:02 --> URI Class Initialized
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:02 --> Router Class Initialized
INFO - 2017-10-26 12:28:02 --> Output Class Initialized
INFO - 2017-10-26 12:28:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:02 --> Input Class Initialized
INFO - 2017-10-26 12:28:02 --> Language Class Initialized
ERROR - 2017-10-26 12:28:02 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 12:28:03 --> Config Class Initialized
INFO - 2017-10-26 12:28:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:03 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:03 --> URI Class Initialized
INFO - 2017-10-26 12:28:03 --> Router Class Initialized
INFO - 2017-10-26 12:28:03 --> Output Class Initialized
INFO - 2017-10-26 12:28:03 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:03 --> Input Class Initialized
INFO - 2017-10-26 12:28:03 --> Language Class Initialized
INFO - 2017-10-26 12:28:03 --> Loader Class Initialized
INFO - 2017-10-26 12:28:03 --> Helper loaded: url_helper
INFO - 2017-10-26 12:28:03 --> Helper loaded: common_helper
INFO - 2017-10-26 12:28:03 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:28:03 --> Email Class Initialized
INFO - 2017-10-26 12:28:03 --> Model Class Initialized
INFO - 2017-10-26 12:28:03 --> Controller Class Initialized
INFO - 2017-10-26 12:28:03 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:28:03 --> Model Class Initialized
INFO - 2017-10-26 12:28:03 --> Model Class Initialized
INFO - 2017-10-26 12:28:03 --> Model Class Initialized
INFO - 2017-10-26 12:28:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 12:28:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 12:28:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
INFO - 2017-10-26 12:28:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-10-26 12:28:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 12:28:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 12:28:03 --> Final output sent to browser
DEBUG - 2017-10-26 12:28:03 --> Total execution time: 0.0233
INFO - 2017-10-26 12:28:03 --> Config Class Initialized
INFO - 2017-10-26 12:28:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:03 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:03 --> URI Class Initialized
INFO - 2017-10-26 12:28:03 --> Router Class Initialized
INFO - 2017-10-26 12:28:03 --> Output Class Initialized
INFO - 2017-10-26 12:28:03 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:03 --> Input Class Initialized
INFO - 2017-10-26 12:28:03 --> Language Class Initialized
ERROR - 2017-10-26 12:28:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:28:03 --> Config Class Initialized
INFO - 2017-10-26 12:28:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:28:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:28:03 --> Utf8 Class Initialized
INFO - 2017-10-26 12:28:03 --> URI Class Initialized
INFO - 2017-10-26 12:28:03 --> Router Class Initialized
INFO - 2017-10-26 12:28:03 --> Output Class Initialized
INFO - 2017-10-26 12:28:03 --> Security Class Initialized
DEBUG - 2017-10-26 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:28:03 --> Input Class Initialized
INFO - 2017-10-26 12:28:03 --> Language Class Initialized
ERROR - 2017-10-26 12:28:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 12:35:59 --> Config Class Initialized
INFO - 2017-10-26 12:35:59 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:35:59 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:35:59 --> Utf8 Class Initialized
INFO - 2017-10-26 12:35:59 --> URI Class Initialized
INFO - 2017-10-26 12:35:59 --> Router Class Initialized
INFO - 2017-10-26 12:35:59 --> Output Class Initialized
INFO - 2017-10-26 12:35:59 --> Security Class Initialized
DEBUG - 2017-10-26 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:35:59 --> Input Class Initialized
INFO - 2017-10-26 12:35:59 --> Language Class Initialized
INFO - 2017-10-26 12:35:59 --> Loader Class Initialized
INFO - 2017-10-26 12:35:59 --> Helper loaded: url_helper
INFO - 2017-10-26 12:35:59 --> Helper loaded: common_helper
INFO - 2017-10-26 12:35:59 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:35:59 --> Email Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Controller Class Initialized
INFO - 2017-10-26 12:35:59 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> Model Class Initialized
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:35:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:35:59 --> Final output sent to browser
DEBUG - 2017-10-26 12:35:59 --> Total execution time: 0.0203
INFO - 2017-10-26 12:36:02 --> Config Class Initialized
INFO - 2017-10-26 12:36:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:02 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:02 --> URI Class Initialized
INFO - 2017-10-26 12:36:02 --> Router Class Initialized
INFO - 2017-10-26 12:36:02 --> Output Class Initialized
INFO - 2017-10-26 12:36:02 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:02 --> Input Class Initialized
INFO - 2017-10-26 12:36:02 --> Language Class Initialized
INFO - 2017-10-26 12:36:02 --> Loader Class Initialized
INFO - 2017-10-26 12:36:02 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:02 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:02 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:02 --> Email Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Controller Class Initialized
INFO - 2017-10-26 12:36:02 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> Model Class Initialized
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:36:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:36:02 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:02 --> Total execution time: 0.0203
INFO - 2017-10-26 12:36:14 --> Config Class Initialized
INFO - 2017-10-26 12:36:14 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:14 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:14 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:14 --> URI Class Initialized
INFO - 2017-10-26 12:36:14 --> Router Class Initialized
INFO - 2017-10-26 12:36:14 --> Output Class Initialized
INFO - 2017-10-26 12:36:14 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:14 --> Input Class Initialized
INFO - 2017-10-26 12:36:14 --> Language Class Initialized
INFO - 2017-10-26 12:36:14 --> Loader Class Initialized
INFO - 2017-10-26 12:36:14 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:14 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:14 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:14 --> Email Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Controller Class Initialized
INFO - 2017-10-26 12:36:14 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:36:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:36:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 12:36:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 12:36:14 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 12:36:14 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:14 --> Total execution time: 0.0278
INFO - 2017-10-26 12:36:14 --> Config Class Initialized
INFO - 2017-10-26 12:36:14 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:14 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:14 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:14 --> URI Class Initialized
INFO - 2017-10-26 12:36:14 --> Router Class Initialized
INFO - 2017-10-26 12:36:14 --> Output Class Initialized
INFO - 2017-10-26 12:36:14 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:14 --> Input Class Initialized
INFO - 2017-10-26 12:36:14 --> Language Class Initialized
INFO - 2017-10-26 12:36:14 --> Loader Class Initialized
INFO - 2017-10-26 12:36:14 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:14 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:14 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:14 --> Email Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Controller Class Initialized
INFO - 2017-10-26 12:36:14 --> Model Class Initialized
INFO - 2017-10-26 12:36:14 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:14 --> Total execution time: 0.0023
INFO - 2017-10-26 12:36:16 --> Config Class Initialized
INFO - 2017-10-26 12:36:16 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:16 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:16 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:16 --> URI Class Initialized
INFO - 2017-10-26 12:36:16 --> Router Class Initialized
INFO - 2017-10-26 12:36:16 --> Output Class Initialized
INFO - 2017-10-26 12:36:16 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:16 --> Input Class Initialized
INFO - 2017-10-26 12:36:16 --> Language Class Initialized
INFO - 2017-10-26 12:36:16 --> Loader Class Initialized
INFO - 2017-10-26 12:36:16 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:16 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:16 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:16 --> Email Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Controller Class Initialized
INFO - 2017-10-26 12:36:16 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:16 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:36:17 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:36:17 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:17 --> Total execution time: 0.0558
INFO - 2017-10-26 12:36:17 --> Config Class Initialized
INFO - 2017-10-26 12:36:17 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:17 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:17 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:17 --> URI Class Initialized
INFO - 2017-10-26 12:36:17 --> Router Class Initialized
INFO - 2017-10-26 12:36:17 --> Output Class Initialized
INFO - 2017-10-26 12:36:17 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:17 --> Input Class Initialized
INFO - 2017-10-26 12:36:17 --> Language Class Initialized
INFO - 2017-10-26 12:36:17 --> Loader Class Initialized
INFO - 2017-10-26 12:36:17 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:17 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:17 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:17 --> Email Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Controller Class Initialized
INFO - 2017-10-26 12:36:17 --> Model Class Initialized
INFO - 2017-10-26 12:36:17 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:17 --> Total execution time: 0.0033
INFO - 2017-10-26 12:36:31 --> Config Class Initialized
INFO - 2017-10-26 12:36:31 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:36:31 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:36:31 --> Utf8 Class Initialized
INFO - 2017-10-26 12:36:31 --> URI Class Initialized
INFO - 2017-10-26 12:36:31 --> Router Class Initialized
INFO - 2017-10-26 12:36:31 --> Output Class Initialized
INFO - 2017-10-26 12:36:31 --> Security Class Initialized
DEBUG - 2017-10-26 12:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:36:31 --> Input Class Initialized
INFO - 2017-10-26 12:36:31 --> Language Class Initialized
INFO - 2017-10-26 12:36:31 --> Loader Class Initialized
INFO - 2017-10-26 12:36:31 --> Helper loaded: url_helper
INFO - 2017-10-26 12:36:31 --> Helper loaded: common_helper
INFO - 2017-10-26 12:36:31 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:36:31 --> Email Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Controller Class Initialized
INFO - 2017-10-26 12:36:31 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Model Class Initialized
INFO - 2017-10-26 12:36:31 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:36:31 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:36:31 --> Final output sent to browser
DEBUG - 2017-10-26 12:36:31 --> Total execution time: 0.0195
INFO - 2017-10-26 12:47:40 --> Config Class Initialized
INFO - 2017-10-26 12:47:40 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:40 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:40 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:40 --> URI Class Initialized
DEBUG - 2017-10-26 12:47:40 --> No URI present. Default controller set.
INFO - 2017-10-26 12:47:40 --> Router Class Initialized
INFO - 2017-10-26 12:47:40 --> Output Class Initialized
INFO - 2017-10-26 12:47:40 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:40 --> Input Class Initialized
INFO - 2017-10-26 12:47:40 --> Language Class Initialized
INFO - 2017-10-26 12:47:40 --> Loader Class Initialized
INFO - 2017-10-26 12:47:40 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:40 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:40 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:40 --> Email Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Controller Class Initialized
INFO - 2017-10-26 12:47:40 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> Model Class Initialized
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/cms/single.php
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:47:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:47:40 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:40 --> Total execution time: 0.0194
INFO - 2017-10-26 12:47:41 --> Config Class Initialized
INFO - 2017-10-26 12:47:41 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:41 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:41 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:41 --> URI Class Initialized
INFO - 2017-10-26 12:47:41 --> Router Class Initialized
INFO - 2017-10-26 12:47:41 --> Output Class Initialized
INFO - 2017-10-26 12:47:41 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:41 --> Input Class Initialized
INFO - 2017-10-26 12:47:41 --> Language Class Initialized
INFO - 2017-10-26 12:47:41 --> Loader Class Initialized
INFO - 2017-10-26 12:47:41 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:41 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:41 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:41 --> Email Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Controller Class Initialized
INFO - 2017-10-26 12:47:41 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> Model Class Initialized
INFO - 2017-10-26 12:47:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:47:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:47:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 12:47:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 12:47:41 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 12:47:41 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:41 --> Total execution time: 0.0265
INFO - 2017-10-26 12:47:42 --> Config Class Initialized
INFO - 2017-10-26 12:47:42 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:42 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:42 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:42 --> URI Class Initialized
INFO - 2017-10-26 12:47:42 --> Router Class Initialized
INFO - 2017-10-26 12:47:42 --> Output Class Initialized
INFO - 2017-10-26 12:47:42 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:42 --> Input Class Initialized
INFO - 2017-10-26 12:47:42 --> Language Class Initialized
INFO - 2017-10-26 12:47:42 --> Loader Class Initialized
INFO - 2017-10-26 12:47:42 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:42 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:42 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:42 --> Email Class Initialized
INFO - 2017-10-26 12:47:42 --> Model Class Initialized
INFO - 2017-10-26 12:47:42 --> Controller Class Initialized
INFO - 2017-10-26 12:47:42 --> Model Class Initialized
INFO - 2017-10-26 12:47:42 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:42 --> Total execution time: 0.0032
INFO - 2017-10-26 12:47:43 --> Config Class Initialized
INFO - 2017-10-26 12:47:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:43 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:43 --> URI Class Initialized
INFO - 2017-10-26 12:47:43 --> Router Class Initialized
INFO - 2017-10-26 12:47:43 --> Output Class Initialized
INFO - 2017-10-26 12:47:43 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:43 --> Input Class Initialized
INFO - 2017-10-26 12:47:43 --> Language Class Initialized
INFO - 2017-10-26 12:47:43 --> Loader Class Initialized
INFO - 2017-10-26 12:47:43 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:43 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:43 --> Email Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Controller Class Initialized
INFO - 2017-10-26 12:47:43 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:47:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:47:43 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:43 --> Total execution time: 0.0737
INFO - 2017-10-26 12:47:43 --> Config Class Initialized
INFO - 2017-10-26 12:47:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:43 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:43 --> URI Class Initialized
INFO - 2017-10-26 12:47:43 --> Router Class Initialized
INFO - 2017-10-26 12:47:43 --> Output Class Initialized
INFO - 2017-10-26 12:47:43 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:43 --> Input Class Initialized
INFO - 2017-10-26 12:47:43 --> Language Class Initialized
INFO - 2017-10-26 12:47:43 --> Loader Class Initialized
INFO - 2017-10-26 12:47:43 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:43 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:43 --> Email Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Controller Class Initialized
INFO - 2017-10-26 12:47:43 --> Model Class Initialized
INFO - 2017-10-26 12:47:43 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:43 --> Total execution time: 0.0031
INFO - 2017-10-26 12:47:49 --> Config Class Initialized
INFO - 2017-10-26 12:47:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:47:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:47:49 --> Utf8 Class Initialized
INFO - 2017-10-26 12:47:49 --> URI Class Initialized
INFO - 2017-10-26 12:47:49 --> Router Class Initialized
INFO - 2017-10-26 12:47:49 --> Output Class Initialized
INFO - 2017-10-26 12:47:49 --> Security Class Initialized
DEBUG - 2017-10-26 12:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:47:49 --> Input Class Initialized
INFO - 2017-10-26 12:47:49 --> Language Class Initialized
INFO - 2017-10-26 12:47:49 --> Loader Class Initialized
INFO - 2017-10-26 12:47:49 --> Helper loaded: url_helper
INFO - 2017-10-26 12:47:49 --> Helper loaded: common_helper
INFO - 2017-10-26 12:47:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:47:49 --> Email Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Controller Class Initialized
INFO - 2017-10-26 12:47:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Model Class Initialized
INFO - 2017-10-26 12:47:49 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:47:49 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 12:47:49 --> Final output sent to browser
DEBUG - 2017-10-26 12:47:49 --> Total execution time: 0.0186
INFO - 2017-10-26 12:48:12 --> Config Class Initialized
INFO - 2017-10-26 12:48:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:12 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:12 --> URI Class Initialized
INFO - 2017-10-26 12:48:12 --> Router Class Initialized
INFO - 2017-10-26 12:48:12 --> Output Class Initialized
INFO - 2017-10-26 12:48:12 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:12 --> Input Class Initialized
INFO - 2017-10-26 12:48:12 --> Language Class Initialized
INFO - 2017-10-26 12:48:12 --> Loader Class Initialized
INFO - 2017-10-26 12:48:12 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:12 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:12 --> Email Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Controller Class Initialized
INFO - 2017-10-26 12:48:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Helper loaded: form_helper
DEBUG - 2017-10-26 12:48:12 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
ERROR - 2017-10-26 12:48:12 --> Severity: Notice --> Undefined offset: 1 /var/www/html/spaceage_guru/application/controllers/module/payment/Payment.php 94
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Config Class Initialized
INFO - 2017-10-26 12:48:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:12 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:12 --> URI Class Initialized
INFO - 2017-10-26 12:48:12 --> Router Class Initialized
INFO - 2017-10-26 12:48:12 --> Output Class Initialized
INFO - 2017-10-26 12:48:12 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:12 --> Input Class Initialized
INFO - 2017-10-26 12:48:12 --> Language Class Initialized
INFO - 2017-10-26 12:48:12 --> Loader Class Initialized
INFO - 2017-10-26 12:48:12 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:12 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:12 --> Email Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Controller Class Initialized
INFO - 2017-10-26 12:48:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> Model Class Initialized
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:48:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:48:12 --> Final output sent to browser
DEBUG - 2017-10-26 12:48:12 --> Total execution time: 0.0296
INFO - 2017-10-26 12:48:45 --> Config Class Initialized
INFO - 2017-10-26 12:48:45 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:45 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:45 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:45 --> URI Class Initialized
INFO - 2017-10-26 12:48:45 --> Router Class Initialized
INFO - 2017-10-26 12:48:45 --> Output Class Initialized
INFO - 2017-10-26 12:48:45 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:45 --> Input Class Initialized
INFO - 2017-10-26 12:48:45 --> Language Class Initialized
INFO - 2017-10-26 12:48:45 --> Loader Class Initialized
INFO - 2017-10-26 12:48:45 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:45 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:45 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:45 --> Email Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Controller Class Initialized
INFO - 2017-10-26 12:48:45 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:48:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:48:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 12:48:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 12:48:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 12:48:45 --> Final output sent to browser
DEBUG - 2017-10-26 12:48:45 --> Total execution time: 0.0273
INFO - 2017-10-26 12:48:45 --> Config Class Initialized
INFO - 2017-10-26 12:48:45 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:45 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:45 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:45 --> URI Class Initialized
INFO - 2017-10-26 12:48:45 --> Router Class Initialized
INFO - 2017-10-26 12:48:45 --> Output Class Initialized
INFO - 2017-10-26 12:48:45 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:45 --> Input Class Initialized
INFO - 2017-10-26 12:48:45 --> Language Class Initialized
INFO - 2017-10-26 12:48:45 --> Loader Class Initialized
INFO - 2017-10-26 12:48:45 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:45 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:45 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:45 --> Email Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Controller Class Initialized
INFO - 2017-10-26 12:48:45 --> Model Class Initialized
INFO - 2017-10-26 12:48:45 --> Final output sent to browser
DEBUG - 2017-10-26 12:48:45 --> Total execution time: 0.0027
INFO - 2017-10-26 12:48:46 --> Config Class Initialized
INFO - 2017-10-26 12:48:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:46 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:46 --> URI Class Initialized
INFO - 2017-10-26 12:48:46 --> Router Class Initialized
INFO - 2017-10-26 12:48:46 --> Output Class Initialized
INFO - 2017-10-26 12:48:46 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:46 --> Input Class Initialized
INFO - 2017-10-26 12:48:46 --> Language Class Initialized
INFO - 2017-10-26 12:48:46 --> Loader Class Initialized
INFO - 2017-10-26 12:48:46 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:46 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:46 --> Email Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Controller Class Initialized
INFO - 2017-10-26 12:48:46 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> Model Class Initialized
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/page.php
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:48:46 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:48:46 --> Final output sent to browser
DEBUG - 2017-10-26 12:48:46 --> Total execution time: 0.0554
INFO - 2017-10-26 12:48:47 --> Config Class Initialized
INFO - 2017-10-26 12:48:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:48:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:48:47 --> Utf8 Class Initialized
INFO - 2017-10-26 12:48:47 --> URI Class Initialized
INFO - 2017-10-26 12:48:47 --> Router Class Initialized
INFO - 2017-10-26 12:48:47 --> Output Class Initialized
INFO - 2017-10-26 12:48:47 --> Security Class Initialized
DEBUG - 2017-10-26 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:48:47 --> Input Class Initialized
INFO - 2017-10-26 12:48:47 --> Language Class Initialized
INFO - 2017-10-26 12:48:47 --> Loader Class Initialized
INFO - 2017-10-26 12:48:47 --> Helper loaded: url_helper
INFO - 2017-10-26 12:48:47 --> Helper loaded: common_helper
INFO - 2017-10-26 12:48:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:48:47 --> Email Class Initialized
INFO - 2017-10-26 12:48:47 --> Model Class Initialized
INFO - 2017-10-26 12:48:47 --> Controller Class Initialized
INFO - 2017-10-26 12:48:47 --> Model Class Initialized
INFO - 2017-10-26 12:48:47 --> Final output sent to browser
DEBUG - 2017-10-26 12:48:47 --> Total execution time: 0.0020
INFO - 2017-10-26 12:49:31 --> Config Class Initialized
INFO - 2017-10-26 12:49:31 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:49:31 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:49:31 --> Utf8 Class Initialized
INFO - 2017-10-26 12:49:31 --> URI Class Initialized
INFO - 2017-10-26 12:49:31 --> Router Class Initialized
INFO - 2017-10-26 12:49:31 --> Output Class Initialized
INFO - 2017-10-26 12:49:31 --> Security Class Initialized
DEBUG - 2017-10-26 12:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:49:31 --> Input Class Initialized
INFO - 2017-10-26 12:49:31 --> Language Class Initialized
INFO - 2017-10-26 12:49:31 --> Loader Class Initialized
INFO - 2017-10-26 12:49:31 --> Helper loaded: url_helper
INFO - 2017-10-26 12:49:31 --> Helper loaded: common_helper
INFO - 2017-10-26 12:49:31 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:49:31 --> Email Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Controller Class Initialized
INFO - 2017-10-26 12:49:31 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> Model Class Initialized
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:49:31 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:49:31 --> Final output sent to browser
DEBUG - 2017-10-26 12:49:31 --> Total execution time: 0.0198
INFO - 2017-10-26 12:49:35 --> Config Class Initialized
INFO - 2017-10-26 12:49:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:49:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:49:35 --> Utf8 Class Initialized
INFO - 2017-10-26 12:49:35 --> URI Class Initialized
INFO - 2017-10-26 12:49:35 --> Router Class Initialized
INFO - 2017-10-26 12:49:35 --> Output Class Initialized
INFO - 2017-10-26 12:49:35 --> Security Class Initialized
DEBUG - 2017-10-26 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:49:35 --> Input Class Initialized
INFO - 2017-10-26 12:49:35 --> Language Class Initialized
INFO - 2017-10-26 12:49:35 --> Loader Class Initialized
INFO - 2017-10-26 12:49:35 --> Helper loaded: url_helper
INFO - 2017-10-26 12:49:35 --> Helper loaded: common_helper
INFO - 2017-10-26 12:49:35 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:49:35 --> Email Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Controller Class Initialized
INFO - 2017-10-26 12:49:35 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> Model Class Initialized
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:49:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:49:35 --> Final output sent to browser
DEBUG - 2017-10-26 12:49:35 --> Total execution time: 0.0199
INFO - 2017-10-26 12:50:30 --> Config Class Initialized
INFO - 2017-10-26 12:50:30 --> Hooks Class Initialized
DEBUG - 2017-10-26 12:50:30 --> UTF-8 Support Enabled
INFO - 2017-10-26 12:50:30 --> Utf8 Class Initialized
INFO - 2017-10-26 12:50:30 --> URI Class Initialized
INFO - 2017-10-26 12:50:30 --> Router Class Initialized
INFO - 2017-10-26 12:50:30 --> Output Class Initialized
INFO - 2017-10-26 12:50:30 --> Security Class Initialized
DEBUG - 2017-10-26 12:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 12:50:30 --> Input Class Initialized
INFO - 2017-10-26 12:50:30 --> Language Class Initialized
INFO - 2017-10-26 12:50:30 --> Loader Class Initialized
INFO - 2017-10-26 12:50:30 --> Helper loaded: url_helper
INFO - 2017-10-26 12:50:30 --> Helper loaded: common_helper
INFO - 2017-10-26 12:50:30 --> Database Driver Class Initialized
DEBUG - 2017-10-26 12:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 12:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 12:50:30 --> Email Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Controller Class Initialized
INFO - 2017-10-26 12:50:30 --> Helper loaded: cookie_helper
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> Model Class Initialized
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 12:50:30 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 12:50:30 --> Final output sent to browser
DEBUG - 2017-10-26 12:50:30 --> Total execution time: 0.0830
INFO - 2017-10-26 13:03:35 --> Config Class Initialized
INFO - 2017-10-26 13:03:35 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:03:35 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:03:35 --> Utf8 Class Initialized
INFO - 2017-10-26 13:03:35 --> URI Class Initialized
INFO - 2017-10-26 13:03:35 --> Router Class Initialized
INFO - 2017-10-26 13:03:35 --> Output Class Initialized
INFO - 2017-10-26 13:03:35 --> Security Class Initialized
DEBUG - 2017-10-26 13:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:03:35 --> Input Class Initialized
INFO - 2017-10-26 13:03:35 --> Language Class Initialized
INFO - 2017-10-26 13:03:35 --> Loader Class Initialized
INFO - 2017-10-26 13:03:35 --> Helper loaded: url_helper
INFO - 2017-10-26 13:03:35 --> Helper loaded: common_helper
INFO - 2017-10-26 13:03:35 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:03:35 --> Email Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Controller Class Initialized
INFO - 2017-10-26 13:03:35 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Model Class Initialized
INFO - 2017-10-26 13:03:35 --> Helper loaded: form_helper
DEBUG - 2017-10-26 13:03:35 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 13:03:35 --> Final output sent to browser
DEBUG - 2017-10-26 13:03:35 --> Total execution time: 0.0206
INFO - 2017-10-26 13:03:49 --> Config Class Initialized
INFO - 2017-10-26 13:03:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:03:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:03:49 --> Utf8 Class Initialized
INFO - 2017-10-26 13:03:49 --> URI Class Initialized
INFO - 2017-10-26 13:03:49 --> Router Class Initialized
INFO - 2017-10-26 13:03:49 --> Output Class Initialized
INFO - 2017-10-26 13:03:49 --> Security Class Initialized
DEBUG - 2017-10-26 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:03:49 --> Input Class Initialized
INFO - 2017-10-26 13:03:49 --> Language Class Initialized
INFO - 2017-10-26 13:03:49 --> Loader Class Initialized
INFO - 2017-10-26 13:03:49 --> Helper loaded: url_helper
INFO - 2017-10-26 13:03:49 --> Helper loaded: common_helper
INFO - 2017-10-26 13:03:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:03:49 --> Email Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Controller Class Initialized
INFO - 2017-10-26 13:03:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Helper loaded: form_helper
DEBUG - 2017-10-26 13:03:49 --> Config file loaded: /var/www/html/spaceage_guru/application/config/paypallib_config.php
INFO - 2017-10-26 13:03:49 --> Config Class Initialized
INFO - 2017-10-26 13:03:49 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:03:49 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:03:49 --> Utf8 Class Initialized
INFO - 2017-10-26 13:03:49 --> URI Class Initialized
INFO - 2017-10-26 13:03:49 --> Router Class Initialized
INFO - 2017-10-26 13:03:49 --> Output Class Initialized
INFO - 2017-10-26 13:03:49 --> Security Class Initialized
DEBUG - 2017-10-26 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:03:49 --> Input Class Initialized
INFO - 2017-10-26 13:03:49 --> Language Class Initialized
INFO - 2017-10-26 13:03:49 --> Loader Class Initialized
INFO - 2017-10-26 13:03:49 --> Helper loaded: url_helper
INFO - 2017-10-26 13:03:49 --> Helper loaded: common_helper
INFO - 2017-10-26 13:03:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:03:49 --> Email Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Controller Class Initialized
INFO - 2017-10-26 13:03:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> Model Class Initialized
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 13:03:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 13:03:49 --> Final output sent to browser
DEBUG - 2017-10-26 13:03:49 --> Total execution time: 0.0277
INFO - 2017-10-26 13:22:54 --> Config Class Initialized
INFO - 2017-10-26 13:22:54 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:54 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:54 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:54 --> URI Class Initialized
INFO - 2017-10-26 13:22:54 --> Router Class Initialized
INFO - 2017-10-26 13:22:54 --> Output Class Initialized
INFO - 2017-10-26 13:22:54 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:54 --> Input Class Initialized
INFO - 2017-10-26 13:22:54 --> Language Class Initialized
INFO - 2017-10-26 13:22:54 --> Loader Class Initialized
INFO - 2017-10-26 13:22:54 --> Helper loaded: url_helper
INFO - 2017-10-26 13:22:54 --> Helper loaded: common_helper
INFO - 2017-10-26 13:22:54 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:22:54 --> Email Class Initialized
INFO - 2017-10-26 13:22:54 --> Model Class Initialized
INFO - 2017-10-26 13:22:54 --> Controller Class Initialized
INFO - 2017-10-26 13:22:54 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:22:54 --> Model Class Initialized
INFO - 2017-10-26 13:22:54 --> Model Class Initialized
INFO - 2017-10-26 13:22:54 --> Model Class Initialized
INFO - 2017-10-26 13:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/order/manage_subscriptions.php
INFO - 2017-10-26 13:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:22:54 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:22:54 --> Final output sent to browser
DEBUG - 2017-10-26 13:22:54 --> Total execution time: 0.0043
INFO - 2017-10-26 13:22:54 --> Config Class Initialized
INFO - 2017-10-26 13:22:54 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:54 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:54 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:54 --> URI Class Initialized
INFO - 2017-10-26 13:22:54 --> Router Class Initialized
INFO - 2017-10-26 13:22:54 --> Output Class Initialized
INFO - 2017-10-26 13:22:54 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:54 --> Input Class Initialized
INFO - 2017-10-26 13:22:54 --> Language Class Initialized
ERROR - 2017-10-26 13:22:54 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:22:54 --> Config Class Initialized
INFO - 2017-10-26 13:22:54 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:54 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:54 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:54 --> URI Class Initialized
INFO - 2017-10-26 13:22:54 --> Router Class Initialized
INFO - 2017-10-26 13:22:54 --> Output Class Initialized
INFO - 2017-10-26 13:22:54 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:54 --> Input Class Initialized
INFO - 2017-10-26 13:22:54 --> Language Class Initialized
ERROR - 2017-10-26 13:22:54 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:22:57 --> Config Class Initialized
INFO - 2017-10-26 13:22:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:57 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:57 --> URI Class Initialized
INFO - 2017-10-26 13:22:57 --> Router Class Initialized
INFO - 2017-10-26 13:22:57 --> Output Class Initialized
INFO - 2017-10-26 13:22:57 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:57 --> Input Class Initialized
INFO - 2017-10-26 13:22:57 --> Language Class Initialized
INFO - 2017-10-26 13:22:57 --> Loader Class Initialized
INFO - 2017-10-26 13:22:57 --> Helper loaded: url_helper
INFO - 2017-10-26 13:22:57 --> Helper loaded: common_helper
INFO - 2017-10-26 13:22:57 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:22:57 --> Email Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Controller Class Initialized
INFO - 2017-10-26 13:22:57 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> Model Class Initialized
INFO - 2017-10-26 13:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/service/manage_data.php
INFO - 2017-10-26 13:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:22:57 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:22:57 --> Final output sent to browser
DEBUG - 2017-10-26 13:22:57 --> Total execution time: 0.1179
INFO - 2017-10-26 13:22:57 --> Config Class Initialized
INFO - 2017-10-26 13:22:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:57 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:57 --> URI Class Initialized
INFO - 2017-10-26 13:22:57 --> Router Class Initialized
INFO - 2017-10-26 13:22:57 --> Output Class Initialized
INFO - 2017-10-26 13:22:57 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:57 --> Input Class Initialized
INFO - 2017-10-26 13:22:57 --> Language Class Initialized
ERROR - 2017-10-26 13:22:57 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:22:57 --> Config Class Initialized
INFO - 2017-10-26 13:22:57 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:57 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:57 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:57 --> URI Class Initialized
INFO - 2017-10-26 13:22:57 --> Router Class Initialized
INFO - 2017-10-26 13:22:57 --> Output Class Initialized
INFO - 2017-10-26 13:22:57 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:57 --> Input Class Initialized
INFO - 2017-10-26 13:22:57 --> Language Class Initialized
ERROR - 2017-10-26 13:22:57 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:22:59 --> Config Class Initialized
INFO - 2017-10-26 13:22:59 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:59 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:59 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:59 --> URI Class Initialized
INFO - 2017-10-26 13:22:59 --> Router Class Initialized
INFO - 2017-10-26 13:22:59 --> Output Class Initialized
INFO - 2017-10-26 13:22:59 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:59 --> Input Class Initialized
INFO - 2017-10-26 13:22:59 --> Language Class Initialized
INFO - 2017-10-26 13:22:59 --> Loader Class Initialized
INFO - 2017-10-26 13:22:59 --> Helper loaded: url_helper
INFO - 2017-10-26 13:22:59 --> Helper loaded: common_helper
INFO - 2017-10-26 13:22:59 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:22:59 --> Email Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Controller Class Initialized
INFO - 2017-10-26 13:22:59 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:22:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> Model Class Initialized
INFO - 2017-10-26 13:22:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-10-26 13:22:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:22:59 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:22:59 --> Final output sent to browser
DEBUG - 2017-10-26 13:22:59 --> Total execution time: 0.0408
INFO - 2017-10-26 13:22:59 --> Config Class Initialized
INFO - 2017-10-26 13:22:59 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:59 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:59 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:59 --> URI Class Initialized
INFO - 2017-10-26 13:22:59 --> Router Class Initialized
INFO - 2017-10-26 13:22:59 --> Output Class Initialized
INFO - 2017-10-26 13:22:59 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:59 --> Input Class Initialized
INFO - 2017-10-26 13:22:59 --> Language Class Initialized
ERROR - 2017-10-26 13:22:59 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:22:59 --> Config Class Initialized
INFO - 2017-10-26 13:22:59 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:22:59 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:22:59 --> Utf8 Class Initialized
INFO - 2017-10-26 13:22:59 --> URI Class Initialized
INFO - 2017-10-26 13:22:59 --> Router Class Initialized
INFO - 2017-10-26 13:22:59 --> Output Class Initialized
INFO - 2017-10-26 13:22:59 --> Security Class Initialized
DEBUG - 2017-10-26 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:22:59 --> Input Class Initialized
INFO - 2017-10-26 13:22:59 --> Language Class Initialized
ERROR - 2017-10-26 13:22:59 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:02 --> Config Class Initialized
INFO - 2017-10-26 13:23:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:02 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:02 --> URI Class Initialized
INFO - 2017-10-26 13:23:02 --> Router Class Initialized
INFO - 2017-10-26 13:23:02 --> Output Class Initialized
INFO - 2017-10-26 13:23:02 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:02 --> Input Class Initialized
INFO - 2017-10-26 13:23:02 --> Language Class Initialized
INFO - 2017-10-26 13:23:02 --> Loader Class Initialized
INFO - 2017-10-26 13:23:02 --> Helper loaded: url_helper
INFO - 2017-10-26 13:23:02 --> Helper loaded: common_helper
INFO - 2017-10-26 13:23:02 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:23:02 --> Email Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Controller Class Initialized
INFO - 2017-10-26 13:23:02 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:23:02 --> Model Class Initialized
INFO - 2017-10-26 13:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php
INFO - 2017-10-26 13:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:23:02 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:23:02 --> Final output sent to browser
DEBUG - 2017-10-26 13:23:02 --> Total execution time: 0.0072
INFO - 2017-10-26 13:23:02 --> Config Class Initialized
INFO - 2017-10-26 13:23:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:02 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:02 --> URI Class Initialized
INFO - 2017-10-26 13:23:02 --> Router Class Initialized
INFO - 2017-10-26 13:23:02 --> Output Class Initialized
INFO - 2017-10-26 13:23:02 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:02 --> Input Class Initialized
INFO - 2017-10-26 13:23:02 --> Language Class Initialized
ERROR - 2017-10-26 13:23:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:02 --> Config Class Initialized
INFO - 2017-10-26 13:23:02 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:02 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:02 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:02 --> URI Class Initialized
INFO - 2017-10-26 13:23:02 --> Router Class Initialized
INFO - 2017-10-26 13:23:02 --> Output Class Initialized
INFO - 2017-10-26 13:23:02 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:02 --> Input Class Initialized
INFO - 2017-10-26 13:23:02 --> Language Class Initialized
ERROR - 2017-10-26 13:23:02 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:03 --> Config Class Initialized
INFO - 2017-10-26 13:23:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:03 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:03 --> URI Class Initialized
INFO - 2017-10-26 13:23:03 --> Router Class Initialized
INFO - 2017-10-26 13:23:03 --> Output Class Initialized
INFO - 2017-10-26 13:23:03 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:03 --> Input Class Initialized
INFO - 2017-10-26 13:23:03 --> Language Class Initialized
ERROR - 2017-10-26 13:23:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:13 --> Config Class Initialized
INFO - 2017-10-26 13:23:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:13 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:13 --> URI Class Initialized
INFO - 2017-10-26 13:23:13 --> Router Class Initialized
INFO - 2017-10-26 13:23:13 --> Output Class Initialized
INFO - 2017-10-26 13:23:13 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:13 --> Input Class Initialized
INFO - 2017-10-26 13:23:13 --> Language Class Initialized
INFO - 2017-10-26 13:23:13 --> Loader Class Initialized
INFO - 2017-10-26 13:23:13 --> Helper loaded: url_helper
INFO - 2017-10-26 13:23:13 --> Helper loaded: common_helper
INFO - 2017-10-26 13:23:13 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:23:13 --> Email Class Initialized
INFO - 2017-10-26 13:23:13 --> Model Class Initialized
INFO - 2017-10-26 13:23:13 --> Controller Class Initialized
INFO - 2017-10-26 13:23:13 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:23:13 --> Model Class Initialized
INFO - 2017-10-26 13:23:13 --> Model Class Initialized
INFO - 2017-10-26 13:23:13 --> Model Class Initialized
INFO - 2017-10-26 13:23:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:23:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:23:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/order/manage_subscriptions.php
INFO - 2017-10-26 13:23:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:23:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:23:13 --> Final output sent to browser
DEBUG - 2017-10-26 13:23:13 --> Total execution time: 0.0052
INFO - 2017-10-26 13:23:13 --> Config Class Initialized
INFO - 2017-10-26 13:23:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:13 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:13 --> URI Class Initialized
INFO - 2017-10-26 13:23:13 --> Router Class Initialized
INFO - 2017-10-26 13:23:13 --> Output Class Initialized
INFO - 2017-10-26 13:23:13 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:13 --> Input Class Initialized
INFO - 2017-10-26 13:23:13 --> Language Class Initialized
ERROR - 2017-10-26 13:23:13 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:13 --> Config Class Initialized
INFO - 2017-10-26 13:23:13 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:13 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:13 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:13 --> URI Class Initialized
INFO - 2017-10-26 13:23:13 --> Router Class Initialized
INFO - 2017-10-26 13:23:13 --> Output Class Initialized
INFO - 2017-10-26 13:23:13 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:13 --> Input Class Initialized
INFO - 2017-10-26 13:23:13 --> Language Class Initialized
ERROR - 2017-10-26 13:23:13 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:19 --> Config Class Initialized
INFO - 2017-10-26 13:23:19 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:19 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:19 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:19 --> URI Class Initialized
INFO - 2017-10-26 13:23:19 --> Router Class Initialized
INFO - 2017-10-26 13:23:19 --> Output Class Initialized
INFO - 2017-10-26 13:23:19 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:19 --> Input Class Initialized
INFO - 2017-10-26 13:23:19 --> Language Class Initialized
INFO - 2017-10-26 13:23:19 --> Loader Class Initialized
INFO - 2017-10-26 13:23:19 --> Helper loaded: url_helper
INFO - 2017-10-26 13:23:19 --> Helper loaded: common_helper
INFO - 2017-10-26 13:23:20 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:23:20 --> Email Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Controller Class Initialized
INFO - 2017-10-26 13:23:20 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:23:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> Model Class Initialized
INFO - 2017-10-26 13:23:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/manage_users.php
INFO - 2017-10-26 13:23:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:23:20 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:23:20 --> Final output sent to browser
DEBUG - 2017-10-26 13:23:20 --> Total execution time: 0.0411
INFO - 2017-10-26 13:23:20 --> Config Class Initialized
INFO - 2017-10-26 13:23:20 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:20 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:20 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:20 --> URI Class Initialized
INFO - 2017-10-26 13:23:20 --> Router Class Initialized
INFO - 2017-10-26 13:23:20 --> Output Class Initialized
INFO - 2017-10-26 13:23:20 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:20 --> Input Class Initialized
INFO - 2017-10-26 13:23:20 --> Language Class Initialized
ERROR - 2017-10-26 13:23:20 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:20 --> Config Class Initialized
INFO - 2017-10-26 13:23:20 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:20 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:20 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:20 --> URI Class Initialized
INFO - 2017-10-26 13:23:20 --> Router Class Initialized
INFO - 2017-10-26 13:23:20 --> Output Class Initialized
INFO - 2017-10-26 13:23:20 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:20 --> Input Class Initialized
INFO - 2017-10-26 13:23:20 --> Language Class Initialized
ERROR - 2017-10-26 13:23:20 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:24 --> Config Class Initialized
INFO - 2017-10-26 13:23:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:24 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:24 --> URI Class Initialized
INFO - 2017-10-26 13:23:24 --> Router Class Initialized
INFO - 2017-10-26 13:23:24 --> Output Class Initialized
INFO - 2017-10-26 13:23:24 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:24 --> Input Class Initialized
INFO - 2017-10-26 13:23:24 --> Language Class Initialized
INFO - 2017-10-26 13:23:24 --> Loader Class Initialized
INFO - 2017-10-26 13:23:24 --> Helper loaded: url_helper
INFO - 2017-10-26 13:23:24 --> Helper loaded: common_helper
INFO - 2017-10-26 13:23:24 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:23:24 --> Email Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Controller Class Initialized
INFO - 2017-10-26 13:23:24 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
INFO - 2017-10-26 13:23:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 13:23:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 13:23:24 --> Model Class Initialized
ERROR - 2017-10-26 13:23:24 --> Severity: Notice --> Undefined property: stdClass::$item_id /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 190
ERROR - 2017-10-26 13:23:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 190
ERROR - 2017-10-26 13:23:24 --> Severity: Notice --> Undefined property: stdClass::$date_created /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php 211
INFO - 2017-10-26 13:23:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/user/edit_user.php
INFO - 2017-10-26 13:23:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 13:23:24 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 13:23:24 --> Final output sent to browser
DEBUG - 2017-10-26 13:23:24 --> Total execution time: 0.0067
INFO - 2017-10-26 13:23:24 --> Config Class Initialized
INFO - 2017-10-26 13:23:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:24 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:24 --> URI Class Initialized
INFO - 2017-10-26 13:23:24 --> Router Class Initialized
INFO - 2017-10-26 13:23:24 --> Output Class Initialized
INFO - 2017-10-26 13:23:24 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:24 --> Input Class Initialized
INFO - 2017-10-26 13:23:24 --> Language Class Initialized
ERROR - 2017-10-26 13:23:24 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:24 --> Config Class Initialized
INFO - 2017-10-26 13:23:24 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:24 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:24 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:24 --> URI Class Initialized
INFO - 2017-10-26 13:23:24 --> Router Class Initialized
INFO - 2017-10-26 13:23:24 --> Output Class Initialized
INFO - 2017-10-26 13:23:24 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:24 --> Input Class Initialized
INFO - 2017-10-26 13:23:24 --> Language Class Initialized
ERROR - 2017-10-26 13:23:24 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 13:23:41 --> Config Class Initialized
INFO - 2017-10-26 13:23:41 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:23:41 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:23:41 --> Utf8 Class Initialized
INFO - 2017-10-26 13:23:41 --> URI Class Initialized
INFO - 2017-10-26 13:23:41 --> Router Class Initialized
INFO - 2017-10-26 13:23:41 --> Output Class Initialized
INFO - 2017-10-26 13:23:41 --> Security Class Initialized
DEBUG - 2017-10-26 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:23:41 --> Input Class Initialized
INFO - 2017-10-26 13:23:41 --> Language Class Initialized
ERROR - 2017-10-26 13:23:41 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 13:51:01 --> Config Class Initialized
INFO - 2017-10-26 13:51:01 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:51:01 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:51:01 --> Utf8 Class Initialized
INFO - 2017-10-26 13:51:01 --> URI Class Initialized
INFO - 2017-10-26 13:51:01 --> Router Class Initialized
INFO - 2017-10-26 13:51:01 --> Output Class Initialized
INFO - 2017-10-26 13:51:01 --> Security Class Initialized
DEBUG - 2017-10-26 13:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:51:01 --> Input Class Initialized
INFO - 2017-10-26 13:51:01 --> Language Class Initialized
INFO - 2017-10-26 13:51:01 --> Loader Class Initialized
INFO - 2017-10-26 13:51:01 --> Helper loaded: url_helper
INFO - 2017-10-26 13:51:01 --> Helper loaded: common_helper
INFO - 2017-10-26 13:51:01 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:51:01 --> Email Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Controller Class Initialized
INFO - 2017-10-26 13:51:01 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> Model Class Initialized
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 13:51:01 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 13:51:01 --> Final output sent to browser
DEBUG - 2017-10-26 13:51:01 --> Total execution time: 0.0843
INFO - 2017-10-26 13:51:06 --> Config Class Initialized
INFO - 2017-10-26 13:51:06 --> Hooks Class Initialized
DEBUG - 2017-10-26 13:51:06 --> UTF-8 Support Enabled
INFO - 2017-10-26 13:51:06 --> Utf8 Class Initialized
INFO - 2017-10-26 13:51:06 --> URI Class Initialized
INFO - 2017-10-26 13:51:06 --> Router Class Initialized
INFO - 2017-10-26 13:51:06 --> Output Class Initialized
INFO - 2017-10-26 13:51:06 --> Security Class Initialized
DEBUG - 2017-10-26 13:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 13:51:06 --> Input Class Initialized
INFO - 2017-10-26 13:51:06 --> Language Class Initialized
INFO - 2017-10-26 13:51:06 --> Loader Class Initialized
INFO - 2017-10-26 13:51:06 --> Helper loaded: url_helper
INFO - 2017-10-26 13:51:06 --> Helper loaded: common_helper
INFO - 2017-10-26 13:51:06 --> Database Driver Class Initialized
DEBUG - 2017-10-26 13:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 13:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 13:51:06 --> Email Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Controller Class Initialized
INFO - 2017-10-26 13:51:06 --> Helper loaded: cookie_helper
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> Model Class Initialized
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/membership/membership.php
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 13:51:06 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 13:51:06 --> Final output sent to browser
DEBUG - 2017-10-26 13:51:06 --> Total execution time: 0.0212
INFO - 2017-10-26 14:54:34 --> Config Class Initialized
INFO - 2017-10-26 14:54:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 14:54:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 14:54:34 --> Utf8 Class Initialized
INFO - 2017-10-26 14:54:34 --> URI Class Initialized
INFO - 2017-10-26 14:54:34 --> Router Class Initialized
INFO - 2017-10-26 14:54:34 --> Output Class Initialized
INFO - 2017-10-26 14:54:34 --> Security Class Initialized
DEBUG - 2017-10-26 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 14:54:34 --> Input Class Initialized
INFO - 2017-10-26 14:54:34 --> Language Class Initialized
INFO - 2017-10-26 14:54:34 --> Loader Class Initialized
INFO - 2017-10-26 14:54:34 --> Helper loaded: url_helper
INFO - 2017-10-26 14:54:34 --> Helper loaded: common_helper
INFO - 2017-10-26 14:54:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 14:54:34 --> Email Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Controller Class Initialized
INFO - 2017-10-26 14:54:34 --> Helper loaded: cookie_helper
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Model Class Initialized
INFO - 2017-10-26 14:54:34 --> Config Class Initialized
INFO - 2017-10-26 14:54:34 --> Hooks Class Initialized
DEBUG - 2017-10-26 14:54:34 --> UTF-8 Support Enabled
INFO - 2017-10-26 14:54:34 --> Utf8 Class Initialized
INFO - 2017-10-26 14:54:34 --> URI Class Initialized
INFO - 2017-10-26 14:54:34 --> Router Class Initialized
INFO - 2017-10-26 14:54:34 --> Output Class Initialized
INFO - 2017-10-26 14:54:34 --> Security Class Initialized
DEBUG - 2017-10-26 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 14:54:34 --> Input Class Initialized
INFO - 2017-10-26 14:54:34 --> Language Class Initialized
INFO - 2017-10-26 14:54:34 --> Loader Class Initialized
INFO - 2017-10-26 14:54:34 --> Helper loaded: url_helper
INFO - 2017-10-26 14:54:34 --> Helper loaded: common_helper
INFO - 2017-10-26 14:54:34 --> Database Driver Class Initialized
DEBUG - 2017-10-26 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 14:54:35 --> Email Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Controller Class Initialized
INFO - 2017-10-26 14:54:35 --> Helper loaded: cookie_helper
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> Model Class Initialized
INFO - 2017-10-26 14:54:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 14:54:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 14:54:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-26 14:54:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 14:54:35 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 14:54:35 --> Final output sent to browser
DEBUG - 2017-10-26 14:54:35 --> Total execution time: 0.0181
INFO - 2017-10-26 15:09:03 --> Config Class Initialized
INFO - 2017-10-26 15:09:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:03 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:03 --> URI Class Initialized
INFO - 2017-10-26 15:09:03 --> Router Class Initialized
INFO - 2017-10-26 15:09:03 --> Output Class Initialized
INFO - 2017-10-26 15:09:03 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:03 --> Input Class Initialized
INFO - 2017-10-26 15:09:03 --> Language Class Initialized
INFO - 2017-10-26 15:09:03 --> Loader Class Initialized
INFO - 2017-10-26 15:09:03 --> Helper loaded: url_helper
INFO - 2017-10-26 15:09:03 --> Helper loaded: common_helper
INFO - 2017-10-26 15:09:03 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:09:03 --> Email Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Controller Class Initialized
INFO - 2017-10-26 15:09:03 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 15:09:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> Model Class Initialized
INFO - 2017-10-26 15:09:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/service/manage_data.php
INFO - 2017-10-26 15:09:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 15:09:03 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 15:09:03 --> Final output sent to browser
DEBUG - 2017-10-26 15:09:03 --> Total execution time: 0.0497
INFO - 2017-10-26 15:09:03 --> Config Class Initialized
INFO - 2017-10-26 15:09:03 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:03 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:03 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:03 --> URI Class Initialized
INFO - 2017-10-26 15:09:03 --> Router Class Initialized
INFO - 2017-10-26 15:09:03 --> Output Class Initialized
INFO - 2017-10-26 15:09:03 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:03 --> Input Class Initialized
INFO - 2017-10-26 15:09:03 --> Language Class Initialized
ERROR - 2017-10-26 15:09:03 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
INFO - 2017-10-26 15:09:05 --> Loader Class Initialized
INFO - 2017-10-26 15:09:05 --> Helper loaded: url_helper
INFO - 2017-10-26 15:09:05 --> Helper loaded: common_helper
INFO - 2017-10-26 15:09:05 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:09:05 --> Email Class Initialized
INFO - 2017-10-26 15:09:05 --> Model Class Initialized
INFO - 2017-10-26 15:09:05 --> Controller Class Initialized
INFO - 2017-10-26 15:09:05 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:09:05 --> Model Class Initialized
INFO - 2017-10-26 15:09:05 --> Model Class Initialized
INFO - 2017-10-26 15:09:05 --> Model Class Initialized
INFO - 2017-10-26 15:09:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 15:09:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
INFO - 2017-10-26 15:09:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/manage_membership.php
INFO - 2017-10-26 15:09:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 15:09:05 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 15:09:05 --> Final output sent to browser
DEBUG - 2017-10-26 15:09:05 --> Total execution time: 0.0055
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:05 --> Config Class Initialized
INFO - 2017-10-26 15:09:05 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:05 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:05 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:05 --> URI Class Initialized
INFO - 2017-10-26 15:09:05 --> Router Class Initialized
INFO - 2017-10-26 15:09:05 --> Output Class Initialized
INFO - 2017-10-26 15:09:05 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:05 --> Input Class Initialized
INFO - 2017-10-26 15:09:05 --> Language Class Initialized
ERROR - 2017-10-26 15:09:05 --> 404 Page Not Found: Assets/admin
INFO - 2017-10-26 15:09:07 --> Config Class Initialized
INFO - 2017-10-26 15:09:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:07 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:07 --> URI Class Initialized
INFO - 2017-10-26 15:09:07 --> Router Class Initialized
INFO - 2017-10-26 15:09:07 --> Output Class Initialized
INFO - 2017-10-26 15:09:07 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:07 --> Input Class Initialized
INFO - 2017-10-26 15:09:07 --> Language Class Initialized
INFO - 2017-10-26 15:09:07 --> Loader Class Initialized
INFO - 2017-10-26 15:09:07 --> Helper loaded: url_helper
INFO - 2017-10-26 15:09:07 --> Helper loaded: common_helper
INFO - 2017-10-26 15:09:07 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:09:07 --> Email Class Initialized
INFO - 2017-10-26 15:09:07 --> Model Class Initialized
INFO - 2017-10-26 15:09:07 --> Controller Class Initialized
INFO - 2017-10-26 15:09:07 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:09:07 --> Model Class Initialized
INFO - 2017-10-26 15:09:07 --> Model Class Initialized
INFO - 2017-10-26 15:09:07 --> Model Class Initialized
INFO - 2017-10-26 15:09:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/sidebar.php
INFO - 2017-10-26 15:09:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/header.php
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Undefined variable: membership /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
ERROR - 2017-10-26 15:09:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php 123
INFO - 2017-10-26 15:09:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/module/membership/new_membership.php
INFO - 2017-10-26 15:09:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/layouts/footer.php
INFO - 2017-10-26 15:09:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/admin/logged_in_template.php
INFO - 2017-10-26 15:09:07 --> Final output sent to browser
DEBUG - 2017-10-26 15:09:07 --> Total execution time: 0.0068
INFO - 2017-10-26 15:09:07 --> Config Class Initialized
INFO - 2017-10-26 15:09:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:07 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:07 --> URI Class Initialized
INFO - 2017-10-26 15:09:07 --> Router Class Initialized
INFO - 2017-10-26 15:09:07 --> Output Class Initialized
INFO - 2017-10-26 15:09:07 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:07 --> Input Class Initialized
INFO - 2017-10-26 15:09:07 --> Language Class Initialized
ERROR - 2017-10-26 15:09:07 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 15:09:07 --> Config Class Initialized
INFO - 2017-10-26 15:09:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:09:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:09:07 --> Utf8 Class Initialized
INFO - 2017-10-26 15:09:07 --> URI Class Initialized
INFO - 2017-10-26 15:09:07 --> Router Class Initialized
INFO - 2017-10-26 15:09:07 --> Output Class Initialized
INFO - 2017-10-26 15:09:07 --> Security Class Initialized
DEBUG - 2017-10-26 15:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:09:07 --> Input Class Initialized
INFO - 2017-10-26 15:09:07 --> Language Class Initialized
ERROR - 2017-10-26 15:09:07 --> 404 Page Not Found: Assets/uploads
INFO - 2017-10-26 15:14:04 --> Config Class Initialized
INFO - 2017-10-26 15:14:04 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:14:04 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:14:04 --> Utf8 Class Initialized
INFO - 2017-10-26 15:14:04 --> URI Class Initialized
INFO - 2017-10-26 15:14:04 --> Router Class Initialized
INFO - 2017-10-26 15:14:04 --> Output Class Initialized
INFO - 2017-10-26 15:14:04 --> Security Class Initialized
DEBUG - 2017-10-26 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:14:04 --> Input Class Initialized
INFO - 2017-10-26 15:14:04 --> Language Class Initialized
INFO - 2017-10-26 15:14:04 --> Loader Class Initialized
INFO - 2017-10-26 15:14:04 --> Helper loaded: url_helper
INFO - 2017-10-26 15:14:04 --> Helper loaded: common_helper
INFO - 2017-10-26 15:14:04 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:14:04 --> Email Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Controller Class Initialized
INFO - 2017-10-26 15:14:04 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> Model Class Initialized
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 15:14:04 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 15:14:04 --> Final output sent to browser
DEBUG - 2017-10-26 15:14:04 --> Total execution time: 0.0444
INFO - 2017-10-26 15:14:07 --> Config Class Initialized
INFO - 2017-10-26 15:14:07 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:14:07 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:14:07 --> Utf8 Class Initialized
INFO - 2017-10-26 15:14:07 --> URI Class Initialized
INFO - 2017-10-26 15:14:07 --> Router Class Initialized
INFO - 2017-10-26 15:14:07 --> Output Class Initialized
INFO - 2017-10-26 15:14:07 --> Security Class Initialized
DEBUG - 2017-10-26 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:14:07 --> Input Class Initialized
INFO - 2017-10-26 15:14:07 --> Language Class Initialized
INFO - 2017-10-26 15:14:07 --> Loader Class Initialized
INFO - 2017-10-26 15:14:07 --> Helper loaded: url_helper
INFO - 2017-10-26 15:14:07 --> Helper loaded: common_helper
INFO - 2017-10-26 15:14:07 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:14:07 --> Email Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Controller Class Initialized
INFO - 2017-10-26 15:14:07 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> Model Class Initialized
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 15:14:07 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 15:14:07 --> Final output sent to browser
DEBUG - 2017-10-26 15:14:07 --> Total execution time: 0.0203
INFO - 2017-10-26 15:26:43 --> Config Class Initialized
INFO - 2017-10-26 15:26:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:26:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:26:43 --> Utf8 Class Initialized
INFO - 2017-10-26 15:26:43 --> URI Class Initialized
INFO - 2017-10-26 15:26:43 --> Router Class Initialized
INFO - 2017-10-26 15:26:43 --> Output Class Initialized
INFO - 2017-10-26 15:26:43 --> Security Class Initialized
DEBUG - 2017-10-26 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:26:43 --> Input Class Initialized
INFO - 2017-10-26 15:26:43 --> Language Class Initialized
INFO - 2017-10-26 15:26:43 --> Loader Class Initialized
INFO - 2017-10-26 15:26:43 --> Helper loaded: url_helper
INFO - 2017-10-26 15:26:43 --> Helper loaded: common_helper
INFO - 2017-10-26 15:26:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:26:43 --> Email Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Controller Class Initialized
INFO - 2017-10-26 15:26:43 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:43 --> Model Class Initialized
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_questionnaire.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_rpq.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile_wpq.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/profile.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 15:26:44 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 15:26:44 --> Final output sent to browser
DEBUG - 2017-10-26 15:26:44 --> Total execution time: 0.0923
INFO - 2017-10-26 15:26:45 --> Config Class Initialized
INFO - 2017-10-26 15:26:45 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:26:45 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:26:45 --> Utf8 Class Initialized
INFO - 2017-10-26 15:26:45 --> URI Class Initialized
INFO - 2017-10-26 15:26:45 --> Router Class Initialized
INFO - 2017-10-26 15:26:45 --> Output Class Initialized
INFO - 2017-10-26 15:26:45 --> Security Class Initialized
DEBUG - 2017-10-26 15:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:26:45 --> Input Class Initialized
INFO - 2017-10-26 15:26:45 --> Language Class Initialized
INFO - 2017-10-26 15:26:45 --> Loader Class Initialized
INFO - 2017-10-26 15:26:45 --> Helper loaded: url_helper
INFO - 2017-10-26 15:26:45 --> Helper loaded: common_helper
INFO - 2017-10-26 15:26:45 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:26:45 --> Email Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Controller Class Initialized
INFO - 2017-10-26 15:26:45 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> Model Class Initialized
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/shop.php
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 15:26:45 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 15:26:45 --> Final output sent to browser
DEBUG - 2017-10-26 15:26:45 --> Total execution time: 0.0214
INFO - 2017-10-26 15:41:40 --> Config Class Initialized
INFO - 2017-10-26 15:41:40 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:40 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:40 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:40 --> URI Class Initialized
INFO - 2017-10-26 15:41:40 --> Router Class Initialized
INFO - 2017-10-26 15:41:40 --> Output Class Initialized
INFO - 2017-10-26 15:41:40 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:40 --> Input Class Initialized
INFO - 2017-10-26 15:41:40 --> Language Class Initialized
INFO - 2017-10-26 15:41:40 --> Loader Class Initialized
INFO - 2017-10-26 15:41:40 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:40 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:40 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:40 --> Email Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Controller Class Initialized
INFO - 2017-10-26 15:41:40 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> Model Class Initialized
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/escrow_view.php
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 15:41:40 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 15:41:40 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:40 --> Total execution time: 0.0302
INFO - 2017-10-26 15:41:43 --> Config Class Initialized
INFO - 2017-10-26 15:41:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:43 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:43 --> URI Class Initialized
INFO - 2017-10-26 15:41:43 --> Router Class Initialized
INFO - 2017-10-26 15:41:43 --> Output Class Initialized
INFO - 2017-10-26 15:41:43 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:43 --> Input Class Initialized
INFO - 2017-10-26 15:41:43 --> Language Class Initialized
INFO - 2017-10-26 15:41:43 --> Loader Class Initialized
INFO - 2017-10-26 15:41:43 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:43 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:43 --> Email Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Controller Class Initialized
INFO - 2017-10-26 15:41:43 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:41:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:41:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 15:41:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 15:41:43 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 15:41:43 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:43 --> Total execution time: 0.0526
INFO - 2017-10-26 15:41:43 --> Config Class Initialized
INFO - 2017-10-26 15:41:43 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:43 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:43 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:43 --> URI Class Initialized
INFO - 2017-10-26 15:41:43 --> Router Class Initialized
INFO - 2017-10-26 15:41:43 --> Output Class Initialized
INFO - 2017-10-26 15:41:43 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:43 --> Input Class Initialized
INFO - 2017-10-26 15:41:43 --> Language Class Initialized
INFO - 2017-10-26 15:41:43 --> Loader Class Initialized
INFO - 2017-10-26 15:41:43 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:43 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:43 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:43 --> Email Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Controller Class Initialized
INFO - 2017-10-26 15:41:43 --> Model Class Initialized
INFO - 2017-10-26 15:41:43 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:43 --> Total execution time: 0.0023
INFO - 2017-10-26 15:41:46 --> Config Class Initialized
INFO - 2017-10-26 15:41:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:46 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:46 --> URI Class Initialized
INFO - 2017-10-26 15:41:46 --> Router Class Initialized
INFO - 2017-10-26 15:41:46 --> Output Class Initialized
INFO - 2017-10-26 15:41:46 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:46 --> Input Class Initialized
INFO - 2017-10-26 15:41:46 --> Language Class Initialized
INFO - 2017-10-26 15:41:46 --> Loader Class Initialized
INFO - 2017-10-26 15:41:46 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:46 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:46 --> Email Class Initialized
INFO - 2017-10-26 15:41:46 --> Model Class Initialized
INFO - 2017-10-26 15:41:46 --> Controller Class Initialized
INFO - 2017-10-26 15:41:46 --> Model Class Initialized
INFO - 2017-10-26 15:41:46 --> Config Class Initialized
INFO - 2017-10-26 15:41:46 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:46 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:46 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:46 --> URI Class Initialized
INFO - 2017-10-26 15:41:46 --> Router Class Initialized
INFO - 2017-10-26 15:41:46 --> Output Class Initialized
INFO - 2017-10-26 15:41:46 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:46 --> Input Class Initialized
INFO - 2017-10-26 15:41:46 --> Language Class Initialized
INFO - 2017-10-26 15:41:46 --> Loader Class Initialized
INFO - 2017-10-26 15:41:46 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:46 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:46 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:47 --> Total execution time: 0.3183
INFO - 2017-10-26 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:47 --> Email Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Controller Class Initialized
INFO - 2017-10-26 15:41:47 --> Helper loaded: cookie_helper
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 15:41:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 15:41:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 15:41:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 15:41:47 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 15:41:47 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:47 --> Total execution time: 0.3363
INFO - 2017-10-26 15:41:47 --> Config Class Initialized
INFO - 2017-10-26 15:41:47 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:47 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:47 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:47 --> URI Class Initialized
INFO - 2017-10-26 15:41:47 --> Router Class Initialized
INFO - 2017-10-26 15:41:47 --> Output Class Initialized
INFO - 2017-10-26 15:41:47 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:47 --> Input Class Initialized
INFO - 2017-10-26 15:41:47 --> Language Class Initialized
INFO - 2017-10-26 15:41:47 --> Loader Class Initialized
INFO - 2017-10-26 15:41:47 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:47 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:47 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:47 --> Email Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Controller Class Initialized
INFO - 2017-10-26 15:41:47 --> Model Class Initialized
INFO - 2017-10-26 15:41:47 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:47 --> Total execution time: 0.0024
INFO - 2017-10-26 15:41:48 --> Config Class Initialized
INFO - 2017-10-26 15:41:48 --> Hooks Class Initialized
DEBUG - 2017-10-26 15:41:48 --> UTF-8 Support Enabled
INFO - 2017-10-26 15:41:48 --> Utf8 Class Initialized
INFO - 2017-10-26 15:41:48 --> URI Class Initialized
INFO - 2017-10-26 15:41:48 --> Router Class Initialized
INFO - 2017-10-26 15:41:48 --> Output Class Initialized
INFO - 2017-10-26 15:41:48 --> Security Class Initialized
DEBUG - 2017-10-26 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 15:41:48 --> Input Class Initialized
INFO - 2017-10-26 15:41:48 --> Language Class Initialized
INFO - 2017-10-26 15:41:48 --> Loader Class Initialized
INFO - 2017-10-26 15:41:48 --> Helper loaded: url_helper
INFO - 2017-10-26 15:41:48 --> Helper loaded: common_helper
INFO - 2017-10-26 15:41:48 --> Database Driver Class Initialized
DEBUG - 2017-10-26 15:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 15:41:48 --> Email Class Initialized
INFO - 2017-10-26 15:41:48 --> Model Class Initialized
INFO - 2017-10-26 15:41:48 --> Controller Class Initialized
INFO - 2017-10-26 15:41:48 --> Final output sent to browser
DEBUG - 2017-10-26 15:41:48 --> Total execution time: 0.0024
INFO - 2017-10-26 17:09:48 --> Config Class Initialized
INFO - 2017-10-26 17:09:48 --> Hooks Class Initialized
DEBUG - 2017-10-26 17:09:48 --> UTF-8 Support Enabled
INFO - 2017-10-26 17:09:48 --> Utf8 Class Initialized
INFO - 2017-10-26 17:09:48 --> URI Class Initialized
INFO - 2017-10-26 17:09:48 --> Router Class Initialized
INFO - 2017-10-26 17:09:48 --> Output Class Initialized
INFO - 2017-10-26 17:09:48 --> Security Class Initialized
DEBUG - 2017-10-26 17:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 17:09:48 --> Input Class Initialized
INFO - 2017-10-26 17:09:48 --> Language Class Initialized
INFO - 2017-10-26 17:09:48 --> Loader Class Initialized
INFO - 2017-10-26 17:09:48 --> Helper loaded: url_helper
INFO - 2017-10-26 17:09:49 --> Helper loaded: common_helper
INFO - 2017-10-26 17:09:49 --> Database Driver Class Initialized
DEBUG - 2017-10-26 17:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 17:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 17:09:49 --> Email Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Controller Class Initialized
INFO - 2017-10-26 17:09:49 --> Helper loaded: cookie_helper
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> Model Class Initialized
INFO - 2017-10-26 17:09:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 17:09:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/main_menu.php
INFO - 2017-10-26 17:09:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_left_menu.php
INFO - 2017-10-26 17:09:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/services/library.php
INFO - 2017-10-26 17:09:49 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/library_template.php
INFO - 2017-10-26 17:09:49 --> Final output sent to browser
DEBUG - 2017-10-26 17:09:49 --> Total execution time: 1.1448
INFO - 2017-10-26 17:09:50 --> Config Class Initialized
INFO - 2017-10-26 17:09:50 --> Hooks Class Initialized
DEBUG - 2017-10-26 17:09:50 --> UTF-8 Support Enabled
INFO - 2017-10-26 17:09:50 --> Utf8 Class Initialized
INFO - 2017-10-26 17:09:50 --> URI Class Initialized
INFO - 2017-10-26 17:09:50 --> Router Class Initialized
INFO - 2017-10-26 17:09:50 --> Output Class Initialized
INFO - 2017-10-26 17:09:50 --> Security Class Initialized
DEBUG - 2017-10-26 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 17:09:50 --> Input Class Initialized
INFO - 2017-10-26 17:09:50 --> Language Class Initialized
INFO - 2017-10-26 17:09:50 --> Loader Class Initialized
INFO - 2017-10-26 17:09:50 --> Helper loaded: url_helper
INFO - 2017-10-26 17:09:50 --> Helper loaded: common_helper
INFO - 2017-10-26 17:09:50 --> Database Driver Class Initialized
DEBUG - 2017-10-26 17:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 17:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 17:09:50 --> Email Class Initialized
INFO - 2017-10-26 17:09:50 --> Model Class Initialized
INFO - 2017-10-26 17:09:50 --> Controller Class Initialized
INFO - 2017-10-26 17:09:50 --> Model Class Initialized
INFO - 2017-10-26 17:09:50 --> Final output sent to browser
DEBUG - 2017-10-26 17:09:50 --> Total execution time: 0.0326
INFO - 2017-10-26 17:10:12 --> Config Class Initialized
INFO - 2017-10-26 17:10:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 17:10:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 17:10:12 --> Utf8 Class Initialized
INFO - 2017-10-26 17:10:12 --> URI Class Initialized
INFO - 2017-10-26 17:10:12 --> Router Class Initialized
INFO - 2017-10-26 17:10:12 --> Output Class Initialized
INFO - 2017-10-26 17:10:12 --> Security Class Initialized
DEBUG - 2017-10-26 17:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 17:10:12 --> Input Class Initialized
INFO - 2017-10-26 17:10:12 --> Language Class Initialized
INFO - 2017-10-26 17:10:12 --> Loader Class Initialized
INFO - 2017-10-26 17:10:12 --> Helper loaded: url_helper
INFO - 2017-10-26 17:10:12 --> Helper loaded: common_helper
INFO - 2017-10-26 17:10:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 17:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 17:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 17:10:12 --> Email Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Controller Class Initialized
INFO - 2017-10-26 17:10:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Config Class Initialized
INFO - 2017-10-26 17:10:12 --> Hooks Class Initialized
DEBUG - 2017-10-26 17:10:12 --> UTF-8 Support Enabled
INFO - 2017-10-26 17:10:12 --> Utf8 Class Initialized
INFO - 2017-10-26 17:10:12 --> URI Class Initialized
INFO - 2017-10-26 17:10:12 --> Router Class Initialized
INFO - 2017-10-26 17:10:12 --> Output Class Initialized
INFO - 2017-10-26 17:10:12 --> Security Class Initialized
DEBUG - 2017-10-26 17:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-10-26 17:10:12 --> Input Class Initialized
INFO - 2017-10-26 17:10:12 --> Language Class Initialized
INFO - 2017-10-26 17:10:12 --> Loader Class Initialized
INFO - 2017-10-26 17:10:12 --> Helper loaded: url_helper
INFO - 2017-10-26 17:10:12 --> Helper loaded: common_helper
INFO - 2017-10-26 17:10:12 --> Database Driver Class Initialized
DEBUG - 2017-10-26 17:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-10-26 17:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-10-26 17:10:12 --> Email Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Controller Class Initialized
INFO - 2017-10-26 17:10:12 --> Helper loaded: cookie_helper
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> Model Class Initialized
INFO - 2017-10-26 17:10:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/header.php
INFO - 2017-10-26 17:10:12 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/left_menu.php
INFO - 2017-10-26 17:10:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/module/auth/login.php
INFO - 2017-10-26 17:10:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/layouts/library_right_menu.php
INFO - 2017-10-26 17:10:13 --> File loaded: /var/www/html/spaceage_guru/application/views/templates/public/public_master_template.php
INFO - 2017-10-26 17:10:13 --> Final output sent to browser
DEBUG - 2017-10-26 17:10:13 --> Total execution time: 0.5138
