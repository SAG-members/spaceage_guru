<div class="services_text">
<h2><?php echo $title;?></h2>
<p>3D timeline where you can place pictures and visual notes from anything important to you. The idea is to combine and synchronize the timelines with all of the users and Members to make all of the things wished to happen</p>
<video width="100%" autoplay loop>
  <source src="<?php echo base_url('assets/uploads/timeline/DNA_TIMELINE_FUNCTIONAL.mp4'); ?>" type="video/mp4">  
  Your browser does not support HTML5 video.
</video>
</div>