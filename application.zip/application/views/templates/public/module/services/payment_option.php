<h2>Please select your preferred payment method</h2>
<div class="services_text">
	<div class="col3"></div>
	<div class="col3"></div>
	<div class="col3"></div>
</div>