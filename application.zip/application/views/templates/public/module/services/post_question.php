<h2>Post Your Question Here</h2>
<div id="new-post" class="services_text"> 
	<form name="" action="<?php echo base_url('index.php/faq/post-question')?>" method="post">
	<textarea class="classy-editor" name="question-summary" placeholder="Question Description"></textarea>
	<div class="checkboobmain">
		<input type="checkbox" name="anonymous" value="1"/> <label>Post as Anonymous</label>
	</div>
	<div class="field buttons">
		<button type="submit" name="btn-submit-question" class="field button" >Ask Question</button>
	</div>
	
	</form> 
</div>
