<?php 
echo "<pre>";
print_r($_REQUEST);
echo "==============================";
print_r($_POST);
echo "==============================";
print_r($_GET);

?>