<div class="services_text lean_canvas">
<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:21.3333px">Lean canvas SCC</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Challenge</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Human beings are addictive by nature and today U.S. researchers estimate that 8 to 10 percent of the population is taking antidepressants</span><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:cambria; font-size:17.3333px">₁</span><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">. We want to ease the process for users to find their drug of choice be it yoga, coffee or something else supporting the sustainable growth of global consciousness.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Human beings are becoming human doings losing their respect towards planet earth, fellow brothers and sisters and worst of all themselves.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Big corporations and strict governmental policies are turning the system into a legal jungle which is killing the entrepreneurial spirit and banks are becoming demanding which customers to support.</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Unique Value proposition</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">We are committed to heal the world and its population&nbsp;by teaching through our anonymous society which is&nbsp;based on a number game where people can trade with services and products while ranking other members&nbsp;of the club.</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">All users and members will be given an offshore number account connected to the user/member number.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">We are seeking for users who want to develop themselves as members who are willing to develop community around them. In practice when the program is launched fully tested at 24</span><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:10.4px">th</span><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px"> of March 2017 the members have a possibility to move their operation to their desired land of location.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Santa Claus Club (latter SCC) does not take any legal responsibility of what is sold in the system rather it lets the members /&nbsp;stockholders to guard the whole system while teaching and sparring its users to the enlightenment while&nbsp;keeping planet earth sustainable for future generations.</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">We are helping all people to live fully and not to be in the risk of exclusion.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">The society funds and aids its members and users who have received high reputation from their peers.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">The whole idea of the number game is to have fun with respect for oneself since none of us really knows when it is the last&nbsp;day of your live and we want to make your live worth living while building a better tomorrow.</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Solution &amp; Channel</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">We give the change of new beginning for everyone with a secure platform where people are free to trade on goods and services globally. </span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Registration as user demands a personal profile filling that will teach you what kind of a person you are (worth 190&euro;&acute;s). This information will be channeled to aid you reach your desired goals.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Educational blogs, social profile, receiving messages and information collected to a Wiki-library are free to access.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Legal aid, logistics, services, goods, e-banking system and messaging are priced and will be charged from your number account.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">You may rent yourself to work for services for which you will get paid instantly to your personal number account. In order to be able to sell goods or pay rent for assistant you must be a member.</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Cost structure and Revenue Stream</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Program is free to use for users after the initial personal profile registration. (Worth 190&euro;&acute;s)</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Members have to invest annual payment with possible part time payment arrangements depending on the package between of 10&euro; to 1000&euro;&acute;s. As a Member you have the possibility to purchase a stock option with 10&euro; to be part of designing it.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">The company will charge commission 10+1% of the trade volume between accounts.</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Hosting will be handled from Marshall Islands which has the most favorable due diligence laws towards our mutual case.&nbsp;Marshall Island belongs to the United States and is under its protection. The </span><span style="background-color:transparent; color:rgb(37, 37, 37); font-family:tahoma; font-size:17.3333px">government of Marshall Islands declared that an area covering nearly 2,000,000 square kilometers of ocean shall be reserved as a shark sanctuary.</span></p>

<p dir="ltr" style="text-align:center"><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Our 5 year goal is to get at least 1 million members and 99 million users.</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Key Metrics</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Internal ranking of the members</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">How many active members and users we have</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">The amount of currency and time flowing through our system</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Is the global temperature staying the same or changing</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Is the ozone layer building itself backup</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">How people are handling their stress and pressure while keeping up with their spiritual growth.</span></p>

<p>&nbsp;</p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">Integrity is doing the right thing, even if</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">nobody is watching.</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">&mdash;Anonymous</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">If you would like to be treated with</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">respect, you must first treat others</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">with respect.</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">&mdash;Unknown</span></p>

<p dir="ltr" style="text-align:center"><span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">The road to enlightenment is as tough with chemicals or with</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">spiritual growth.</span><br />
<span style="background-color:transparent; color:rgb(0, 0, 0); font-family:tahoma; font-size:17.3333px">&mdash;Yogi Bhajan</span></p>

<div>&nbsp;</div>
</div>