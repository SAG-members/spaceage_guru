<h2>Satan Clause Ltd</h2>
<div class="services_text">
<p><span style="font-size:20px"><strong>Challenge</strong></span></p>

<p>U.S., researchers estimate that 8 to 10 percent of the population is taking an antidepressants</p>

<p>Human beings are losing their respect towards planet earth and fellow brothers and sisters.</p>

<p>Big corporations and strict governmental policies are killing entrepreneurial spirit and people with bad credit&nbsp;are treated as 2nd class citizens while the gap between poor and rich is growing.</p>

<p><span style="font-size:20px"><strong>Unique Value proposition</strong></span></p>

<p>We are committed to heal the world and its population&nbsp;by teaching through our anonymous society which is&nbsp;based on a number game where people can play by selling services and products and ranking other members&nbsp;of the society.&nbsp;Satan Clause does not take any legal responsibility of what is sold in the system rather it lets the members /&nbsp;stockholders to guard the whole system while teaching and sparring its users to the enlightenment while&nbsp;keeping planet earth sustainable for future generations.&nbsp;We are helping all people to live fully and not to be in the risk of exclusion.</p>

<p>The society funds and aids its members who have received high reputation from their peers.</p>

<p>The whole idea of the game is to have fun with respect for oneself since none of us really know when is the last&nbsp;day of our lives and we want to make the live worth living.</p>

<p><span style="font-size:20px"><strong>Solution</strong></span></p>

<p>We give the same change for everyone to work themselves from the bottom to up&nbsp;We provide legal aid, distribution channels, banking system that is affordable even for poor people.&nbsp;Everything is based on a number based anonymous society where people are free to trade on goods and&nbsp;services globally with universal currency on number accounts.</p>

<p><span style="font-size:20px"><strong>Channels</strong></span></p>

<p>Internet based web shop only for members and users who have registered and filled a lab-profile for internal&nbsp;matching</p>

<p>purposes.&nbsp;Mobile phone based software with&nbsp;google adworks and what&acute;s up marketing.</p>

<p><span style="font-size:20px"><strong>Cost Structure and Revenue Stream</strong></span></p>

<p>Program is free to use for users after the initial personal profile registration.&nbsp;Members/traders have to invest 100&euro; to be part of it.</p>

<p>The corporation will charge 10+1% of the trade volume. 1% is reserved for the costs and 10% for commission&nbsp;and building up the society.</p>

<p>Hosting will be handled from Marshall Islands which has the most favorable due diligence laws towards our mutual case.&nbsp;Marshall Island belongs to the United States and is under its protection.&nbsp;The 5 year goal is to get 100 million members and 1 billion users.</p>

<p><span style="font-size:20px"><strong>Key Metrics</strong></span></p>

<p>Internal ranking of the members</p>

<p>How many active members and users we have</p>

<p>The amount of currency flowing through our system</p>

<p>Is the global temperature staying the same or changing</p>

<p>Is the ozone layer building itself backup</p>

<p>How people are handling their stress and pressure while keeping up with their spiritual growth.</p>

<p><a href="mailto:service@satanclause.club">service@satanclause.club</a></p>

<p><em>Integrity is doing the right thing, even if&nbsp;nobody is watching.</em><br />
&mdash;Anonymous</p>

<p><em>If you would like to be treated with&nbsp;respect, you must first treat others&nbsp;with respect.</em><br />
&mdash;Unknown</p>

<p><em>The road to enlightenment is as tough with chemicals or with&nbsp;spiritual growth.</em><br />
&mdash;Yogi Bhajan</p>

<p>&nbsp;</p>
</div>
