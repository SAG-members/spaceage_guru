<div class="services_text">
<p>OOPS…</p>
<p>The world of crypto currencies is fast and modern,
Still sometimes transactions don’t work as supposed immediately and you need to take a deep breath
with some patience.</p>
<p>If the money was not transferred from your account please replicate the payment process with a clear
thought and it will work better when you do it consciously or at least you notice what the problem was.
If the money was taken from your account without successful payment notification,
Please give the system 48 hours to correct and update the payment process details to you.</p>
<p>If you are still having doubts please contact our support through chat with friends in payments group or
email payments@spaceage.guru</p>

<p>With constructive regards,</p>
<p>Space Age Guru</p>
</div>