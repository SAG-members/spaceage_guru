<div class="leftmain">
	<ul>
		<li>
		<a class="pull-left add-pss" href="<?php echo base_url('user/dashboard#myProducts');?>" title="View My Product" alt="View My Product"><i class="fa fa-minus"></i> </a>
		<span class="text-center" style="margin-left: 40px;">Public Library</span>
		<a class="pull-right add-pss" href="<?php echo base_url('user/add/data');?>" title="View My Product" alt="View My Product"><i class="fa fa-plus"></i> </a>
		</li>
		
	</ul>	
	<div class="copyright">&copy; <?php echo date("Y");?> Satanclause</div>
	<span class="text-center" style="color:#fff; border:1px solid #fff;">INSTANT LEGAL AID</span>
	<div class="clearfix"></div>
</div>