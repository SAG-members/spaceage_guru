<html>
<body style="margin:0; padding:0;">
	<div style="border:1px solid #E7E7E7; background-color:#087dc2; color:#FFF; text-align:center;"><p style="text-align: center;"><img src="<?php echo base_url('assets/img/logo-1.png')?>" style="width: 255.842px; height: 180px;"><br></p></div>
	<div style="margin:0px; text-align:center;height:300px;padding:10px;">	
		<h3>Password Reset By Admin </h3>	
		<p>

		<b>Hello, <?php echo $name;?></b><br/><br/>
		Your password has been changed by Admin, Please use the below mentioned password to login, Also Ensure to change your password after logging to the site
		<br /><br />
		<b>Password <?php echo $password;?></b>
	</div>
</body>
</html>