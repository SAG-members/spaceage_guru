<html>
<body style="margin:0; padding:0;">
	<div style="border:1px solid #E7E7E7; background-color:#087dc2; color:#FFF; text-align:center;"><p style="text-align: center;"><img src="<?php echo base_url('assets/img/logo-1.png')?>" style="width: 255.842px; height: 180px;"><br></p></div>
	<div style="margin:0px; text-align:center;height:100px;padding:10px;">	
		<h3>Blocked User</h3>	
		<p>

		<b>Hello, <?php echo $name;?></b><br/><br/>
		You have been blocked by site Administrator, Please contact to unblock
		<br /><br />
	</div>
</body>
</html>