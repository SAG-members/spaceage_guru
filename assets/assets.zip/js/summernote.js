/**
 * 
 */

$(function(){
	/* Enable Summernote Editor */
	$('#summernote').summernote({height: 500,disableResizeEditor: true});
});